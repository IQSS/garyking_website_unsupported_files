

chapter11.2 <- function()
{
    message("Dataobj for examples 11.2...")
    message("Respiratory infections; Bulgaria and 30 years forecast...")
    verb <- T
    verb <- user.prompt(1)
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    rspi <- eval(as.symbol(data(rspi)))
    population <- eval(as.symbol(data(population)))
    cntrycode <- eval(as.symbol(data(cntry.codes)))
    rspi[rspi[,"rspi"] <= 0.5 & !is.na(rspi[,"rspi"]),"rspi"] <- 0.5
    
    dataobj <<- dataobjWHO(disease = rspi,pop=population, cov.REDUCE= NULL, 
                           cov.FULL= NULL, lagyears = 30,  
                           cntry.vec = c(Bulgaria=4030),
                           nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                           icode="ggggaatttt",proxfile=NULL,
                           Gnames=cntrycode, selectages=NULL,verbose=verb)
   
    message("Formula for male respiratory infections...")
    ff <- log(rspi2/popu2) ~ time 
    print(ff)
    message("Running yourcast with model LC...")
    user.prompt()
    ylc <- yourcast(formula=ff, dataobj=dataobj, model="LC",verbose=verb)
    
    message("Generating the graphics for LC...")
    user.prompt()
    yourgraph(ylc, pred.insample=F,demoFile="chp.11.2.1")
   
    message("Running yourcast with MAP model...")
    user.prompt()
    zmean <- c(-7.474950, -10.391050, -10.745170, -10.511022, -10.450573, -10.321841, -10.066730, 
               -9.721626,  -9.362865,  -8.995520,  -8.607914,  -8.233437,  -7.752187,  -7.240793, 
                -6.626354,  -6.019082,  -4.938154)
    names(zmean) <- 0:16*5
    ymap <- yourcast(model="map", Ha.sigma=0.2, Ht.sigma=NA,Hat.sigma=NA,
                     zero.mean=zmean, verbose=verb)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap,pred.insample=F,demoFile="chp.11.2.2")
    
  }

chapter11.2()
