

chapter11.7 <- function()
  
{
   fhisto <- function(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, ff){
 ###   silent <- readline("\nEnter 'h' to see the histograms else <return>...\n")
    silent <- 'h'
    if(silent=='h'){
      depvar <- leftside.formula(ff)$numerator
      histograph(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, depvar,
                 model="ebayes", graphics.file=NA)
    }
    else
      return(list())
  }
   
   message("Countries with unless 20 death observations; lag 30 years...")
   verb <- T
   verb <- user.prompt(1)
   if(exists("dataobj", inherits=TRUE))
     try(rm(dataobj, inherits=T), silent=T)
  
   lung <- eval(as.symbol(data(lung)))
   population <- eval(as.symbol(data(population)))
   gdp  <- eval(as.symbol(data(gdp)))
   tobacco <- eval(as.symbol(data(tobacco)))
   cntrycode  <- eval(as.symbol(data(cntry.codes)))
   
   lung[lung[,"lung"] <= 0.5 & !is.na(lung[,"lung"]),"lung"] <- 0.5
  
   dataobj <<- dataobjWHO(disease=lung, pop=population,
                          cov.REDUCE=c(list(gdp)),  
                          cov.FULL=tobacco,lagyears = 30,  
                          cntry.vec =NULL,nobvs=20, covselect.WHO=seq(0,10, 5), 
                          icode="ggggaatttt",proxfile=NULL,
                          Gnames=cntrycode,
                          selectages=seq(from=30,to=80,by=5),verbose=verb)

   
   message("Formula for male lung disease...")

   ff <- log(lung2 /popu2) ~ time + log(time - 1876) + log(gdp) + log(tobacco2)

   print(ff)
   message("Running yourcast with model ebayes...")
###   user.prompt()
   zmean <- c(-11.123375, -10.188764,  -9.239278,  -8.419195,  -7.699627,
              -7.141269,  -6.702073,-6.400106,  -6.223774,  -6.153787,  -6.231790)
   names(zmean) <- 6:16*5
   
   yebayes <- yourcast(formula=ff, dataobj=dataobj, elim.collinear= FALSE,
                       model="ebayes", zero.mean=zmean,
                       Ha.deriv=c(0,0,1), Ha.sigma=0.3, Hat.sigma=NA, Ht.sigma=NA,verbose=verb)
   
   auto <- unlist(yebayes$summary)
   distvec   <- yebayes$summary.vec
   d1.a.vec  <- distvec$d1.a
   d1.t.vec  <- distvec$d1.t
   dtda.vec  <- distvec$dtda
   SD.vec <- distvec$SD
   
   messout("Summary measures are...", verbose=verb)
   
   fs <- fhisto(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, ff)
   
   d1.a <- auto["d1.a"]
   d1.t <- auto["d1.t"]
   dtda <- auto["dtda"]
   SD   <- auto["SD"]
   sims <- c(sims=50)
      
   message("Lung cancer, Peru ...")
 ###  user.prompt()
   if(exists("dataobj", inherits=TRUE))
     try(rm(dataobj, inherits=T), silent=T)
    
   dataobj <<- dataobjWHO(disease=lung, pop=population,
                          cov.REDUCE=NULL,  cov.FULL=NULL,
                          lagyears = 30, cntry.vec =c(Peru=2370), 
                          nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                          icode="ggggaatttt",proxfile=NULL,
                          Gnames=cntrycode, selectages=seq(from=30,to=80,by=5),verbose=verb)
   
   message("Formula for male lung disease...")

   ff <- log(lung2/popu2) ~ time + log(time - 1876)
   
   print(ff)
   message("Running yourcast with model MAP...")
   user.prompt()
   ymap <- yourcast(formula=ff, dataobj=dataobj, model="map",elim.collinear=FALSE, 
                    Ha.sigma=c(0.1,1.5,5,d1.a, SD=NULL),
                    Ht.sigma=c(0.1,1.5,5,d1.t, sims),
                    Hat.sigma=c(0.05,1.5,5,dtda),
                    zero.mean=zmean,
                    Ha.deriv=c(0,0,1),
                    Hat.a.deriv=c(0,1), Hat.t.deriv=c(0,0,1),
                    Ht.deriv=c(0,0,1),verbose=verb)
   
 
###   message("Generating the graphics for MAP...")
   user.prompt()
   yourgraph(ymap)
    
    
   
 }

chapter11.7()
