### DESCRIPTION :
###               The arguments of datawho are the files WHO and the output is a list,
###               which is element dataobj$data of the data object pass to yourcast. 
###               It may also takes objects (data.frames) as arguments instead of files. 
###               The object output (i.e. dataobj$data) is a list whose elements are
###               csid (cross-sectional-time-series) matrices.
###               The list elements of the ouput object are named after the csid
###               (or country+age combination), say "245045", 
###               for country US ("2450") and age group 45.  Every element is a matrix
###               which columns are either disease=c("allc", "brst", "lung"),
###               pop= "population", or covariates.  The covariates are supply with
###               cov.REDUCE=c("fat", "hc") and cov.FULL=c("tobacco", "FULL.gdp"). 
###               The columns names are the covariates' names,
###               diseases names and "popu" for population.
###               Gender is appended to the name of the diseases for each column in the matrix
###               such as "allc2", "allc3" for males and females,
###               and "popu2", "popu3" and "tobacco2", "tobacco3";
###               gender independent covariates are represented as it "gdp"; 
###               The maximum number of list elements
###               is the number of cross sectional time series units in files WHO;
###               i. e., 191 x 17 = 3247 for 191 countries and 17 age groups.
###               Optionally if cntry.vec is not null then instead of returning a list
###               with all countries, only the countries in cntry.vec will be in the return object.
###               Similarly, if nobvs is non-null then a subset of countries will be included
###               in the return data object.  Those countries that has number of disease or death
###               observations and population observations greater than or equal to nobvs.
###               If files contain a restrictive list of countries, 
###               extracted from the WHO files,then the output series dataobj$data
###               has less than 3247 matrices suited to the csid presented in the files.
###               Also, some of the files may have been restricted to only one gender or strata,
###               in which case only one column with the corresponding strata will
###               be in the matrix, say allc2.
###               If the disease files or covariates files contain different subsets
###               of countries, it will find the common denominator and construct
###               the list dataobj$data for the common countries.
###               We can also pass objects (data.frames) to the arguments disease=allc
###               and cov.FULL= c(list(tobacco)) and cov.REDUCE=c(list(gdp),list(hc))
###               instead of files names containing the same information
###               as the files to building the dataobj$data from the data.frames. 
###
### INPUT:
###       datapath, the name of the directory with the files or links to the WHO files;
###
###       disease, a vector of characters or an object list with death causes from WHO files;
###                Example, disease=c("allc", "stom") or disease=brst; brst is a data.frame.
###
###       pop,either a string with population for all csid and two genders or the data.frame.
###
###       cov.FULL, vector of strings for covariates tobacco, and possibly gender,
###                 age independent covariates; gender,age independent covs
###                 are in the FULL.cov version expanded to all csid.Optionally you
###                 may provide an object with the covariates data as c(list(tobacco), list(gdp)). 
###
###       cov.REDUCE, a vector of strings or list of data.frames containing covariate data 
###                   for age and gender independents covariates.
###                   The function expand.cov will be used to create the FULL version 
###                   of the covariates for every country, age group and two genders.
### 
###       lagyears, an optional parameter to advance covariates number of years.
### 
###       timeseries, logical to append the observation years  to the matrices for every csid.
### 
###       cntry.vec,vector to select specific countries from the dataset
###  
###       nobvs,number of observations to select the countries that have
###             number of death observations >= nobvs
### 
###       covselect.WHO, vector with age groups to exclude from covariate tobacco. '
###
###       selectages a numeric vector, with ages groups selected from all csid
###                  or NULL (default) for all ages in the matrix sets.
###
###       Default values for the arguments are all the WHO files in datapath.
###
### CALL
###     datawho()
###     datawho(disease=c("allc", "cerv", "cvds"), lagyears=30)
###     datawho(disease=c("allc", "cerv", "cvds"), pop=NULL, cov.FULL=c("FULL.gdp", "tobacco"), timeseries=T)
###     datawho(disease=NULL, cov.FULL=c("FULL.gdp", "tobacco"))
###     datawho(disease=NULL, pop=NULL, cov.FULL=c("FULL.gdp", "tobacco"))
###     datawho(disease=c("livc", "malr"), cov.FULL=NULL)
###     datawho(disease=c("livc", "malr"), cov.FULL=NULL, cov.REDUCE=c("gdp", "fat", "tfr"))
###     datawho(disease=c("livc", "malr"), cov.FULL="tobacco", cov.REDUCE=c("gdp", "fat"))
###     datawho(disease="lung", lagyears=30, timeseries=T, selectages=seq(from=30, to=80, by=5))
###     datawho(disease=allc, pop=population,cov.FULL=tobacco, cov.REDUCE=c(list(gdp), list(hc),list(fat))
###     When one of the argumnets, disease, pop, cov.FULL are set to NULL, none
###     of the corresponding files will be included in the output object
###
### OUTPUT a list with as many elements as csid units
###        (i.e., 3247 list elements or a subset of them if either cntry.vec or nobvs are non-null)
###        Names of list elements are csid identifiers
###        Elements are matrices with two columns for each disease, population
###       for genders 2 and 3.  Two columns for tobacco, and one column for each of
###       the covariates that are not gender dependent.If files or object inputs
###       only contain data for one of the genders then matrices will have only one column
###       for the given disease or covs but with the numbers 2 or 3 append if they are
###       gender dependent.  
###
### USES: disease.WHO, buildcovs.WHO, checkerrors.WHO, joindthcov.WHO, lagcovariates.WHO,
###       selectcntry.WHO, countobvs.WHO, processnolag.WHO, expand.cov, parse.index.code
###
### AUTHOR: Elena Villalon
###         IQSS, Harvard University
###         evillalon@iq.harvard.edu
###         August 31th, 2006
###
#########################################################################################################

datawho <- function(datapath=NULL, disease = c("aids","allc", "allo", "brst", "cerv",
                                           "cvds", "dgst", "homi", "livc", "lung", "malr",
                                           "matc", "molp", "omal", "otin", "pern", "rspc",
                                           "rspi", "stom", "suic", "trns", "tubr","unin","ward"),
                    pop= "population",cov.REDUCE = NULL, 
                    cov.FULL= c("FULL.fat", "FULL.gdp", "FULL.hc", "FULL.tfr", "tobacco"),
                    lagyears = 0, timeseries=TRUE,
                    cntry.vec = NULL, nobvs=NULL, covselect.WHO=seq(0,10, 5),
                    selectages=NULL, icode="ggggaatttt", verbose=T, f=3, m=2)
  
  ###f=3 means gender 3 for female
  ###m=2 means gender 2 for male
  {

     
    if(length(disease) <= 0 && length(pop) <= 0 &&
       length(cov.FULL) <= 0 && length(cov.REDUCE) <= 0)
      stop("No data available")
### the # digits for country, age and years in the csid identifiers:2450451980
    lstind <- as.list(parse.index.code(icode))
    todiscard <- lstind$digit.first
    
    cdigits <- lstind$cntry.digits
    cdigits <- cdigits + todiscard
    adigits <- lstind$age.digits
    ydigits <- lstind$year.digits
     
    if(!is.character(disease) || !is.character(pop) ||
       !is.character(cov.FULL) || !is.character(cov.REDUCE))
      {
        driver <- match.call()      
        find.coltags(driver, pt=F); ### to find the arguments pass 
      }
 
    covs.single <- NULL
    if(is.character(cov.FULL) || is.character(cov.REDUCE))
      covs.single <- c(cov.FULL, cov.REDUCE)  ### all entry for covs
    else  
      covs.single <- jointcovs(cov.FULL, cov.REDUCE) ### if objects
    
 ###   print(covs.single)    
    ix <- NULL
    if(length(cov.FULL) > 0)           
      ix <- grep("FULL", cov.FULL)
    
    if(length(ix) > 0 && is.character(cov.FULL))
      {
        covs.s <- sapply(cov.FULL[ix], substring, 6)
        covs.single[ix] <- covs.s ###bare names without the FULL for all covs
        covs.single <- unique.default(unlist(covs.single)) ### all covs without FULL. append to names
      }
    booltob <- F ### tobacco??
   
    if(length(cov.FULL) > 0)
      booltob <- check.for.tobs(cov.FULL)

### list of disease and population for csid and two genders
    alldths <- NULL
    nmdths  <- NULL
  
    if(length(disease) > 0 || length(pop) > 0){
 
      alldths <- disease.WHO(datapath, disease, pop,lstind, f, m)
      nmdths  <- names(alldths)
   
    }
    
   age.groups <- find.age.groups(alldths, lstind)
   
### list of covariates for each csid and all covs and for the genders
    allcovs <- NULL
    nmcovs  <- NULL
    if(length(cov.REDUCE) > 0)
      allcovs <- covs.single ### bare names for all covs
    else if(length(cov.FULL) > 0)
      allcovs <- cov.FULL ### all covs with FULL
  
    if(length(allcovs) > 0)
      allcovs <- buildcovs.WHO(datapath, allcovs, lstind, age.g=age.groups, f, m)
  
    if(length(allcovs) > 0)
      nmcovs <- names(allcovs)
   
   
  ### passing covs and no diseases 
    if(length(allcovs) > 0 && length(alldths)<= 0){
      cstid <- allcovs[[1]][,1]
      dd <- cdigits + adigits + 1
      years <- as.numeric(substring(cstid, dd))
      nmforall <- nmcovs
    }
  
  ### passing diseases and no covs
    if(length(allcovs) <= 0 && length(alldths) > 0){
       cstid <- alldths[[1]][,1]
       dd <- cdigits + adigits + 1
       years <- as.numeric(substring(cstid, dd))
       nmforall <- nmdths
     }
  
  
    ### passing both covs and diseases
    if(length(allcovs) > 0 && length(alldths) > 0){
   
      nmforall <- intersect(nmcovs, nmdths)
   ###   print(length(nmforall))
      if(length(nmforall) <= 0)
        stop("covariates index differ from death causes")
      ind <- match(nmforall, nmcovs)
      if(length(ind) > 0)
        allcovs <- allcovs[ind]
        
        
      ind <- match(nmforall, nmdths)
      if(length(ind) > 0)
        alldths <- alldths[ind]
     

      if(length(allcovs) <= 0 && length(alldths) <= 0){
        messout("No data available for yours selections",verbose)
        return(list())
      }
   
      
    }
  
### checking for errors: cross sectional time series must be identical
    ind <- NULL
    if(length(alldths) >0 )
      ind <- 1:length(alldths)
   
    if(length(ind) > 0 && length(covs.single) > 0){
      if(length(allcovs) > 0){
        ix <- match(nmdths, names(allcovs))
        ix <- na.omit(ix)
      }else
      ix <- NULL
 ###     print(ix)
      if(length(ix) > 0) #### double checking 
        allcovs <- allcovs[ix]
          
      ix <- lapply(ind, FUN="checkerrors.WHO", alldths, allcovs)
    }
 
    if(lagyears <0){
      messout("Setting lagyears = 0", verbose)
      lagyears <- 0
    }
    
 ### no lag of covariates
  
    if(lagyears <= 0)
      {
        
        datalst <- processnolag.WHO(alldths, allcovs, timeseries,lagyears, years,
                                    cntry.vec, nobvs, covs.single, cov.FULL,
                                    covselect.WHO, booltob, lstind)
 
       if(length(selectages) <= 0)
          return(datalst)
        else
          return(datalst <- selectagesWHO(datalst, age.vec=selectages, lstind))
            
      }
  
  
### from here on lagyears > 0, lag covariates for number of years=lagyears.     
### Add NA's for each element of list for alldths beyond observations, 
### according to lagyears to match the lag of covariates
###    nc <- ifelse(length(pop) > 0, 2 * length(disease) + 2, 2 * length(disease))
    if(length(alldths) > 0)
      {
        nc <- ncol(alldths[[1]]) - 1
        
        ln <- nc * lagyears
        lagdeath <- rep(NA, ln)
   
 
        lagdeath <- matrix(lagdeath, ncol=nc)
     
        onedth <- alldths[[1]]
        lastyear <- as.numeric(rownames(onedth)[nrow(onedth)])
        vyears <- (lastyear+1):(lastyear+lagyears)
        rownames(lagdeath) <- vyears
        alldths <- lapply(alldths, function(mat){
###    print(ncol(mat[,-1]))
###    print(ncol(lagdeath))
          cnm <- colnames(mat)[-1]
          mmm <- rbind(as.matrix(mat[,-1]), lagdeath)
          colnames(mmm) <- cnm
          return(mmm)
        })
      
      } ###if(length(alldths) > 0)
   
 ### lag each element list for all covs
    if(length(allcovs) <=0)
      {
  
        datalst <- joindthcov.WHO(alldths, allcovs, timeseries, lagyears, years)
     
        if(length(cntry.vec) > 0)
          datalst <- selectcntry.WHO(cntry.vec, datalst, lstind)
        
        if(length(nobvs) > 0 && is.character(covs.single))
          datalst <- countobvs.WHO(nobvs, datalst, covs.single, lstind)
        else if(length(nobvs) > 0){
          nm <- unlist(sapply(covs.single, function(mat) {
          cnm <- colnames(mat)[1]
        }))
        datalst <- countobvs.WHO(nobvs, datalst, nm, lstind)
        }
      
        
        indcov <- 1:length(datalst)
        names(indcov) <- names(datalst)
        csidwho <- names(datalst)
       
        datalst <- lapply(indcov, FUN="agesexclude.WHO", datalst, csidwho, covselect.WHO, lstind)
        if(length(selectages) <= 0)
          return(datalst)
        else
          return(datalst <- selectagesWHO(datalst, age.vec=selectages, lstind))
      
      }
      
  
    nc <- ncol(allcovs[[1]]) -1
  
    ln <- nc * lagyears
   
    lagcovs <- rep(NA, ln)
   
    lagcovs <- matrix(lagcovs, ncol=nc)
    ind <- 1:length(allcovs)
    names(ind) <- names(allcovs)
    allcovs <- lapply(ind, FUN="lagcovariates.WHO", allcovs, lagcovs)
      
 ### join diseases and cov.FULL
    datalst <- joindthcov.WHO(alldths, allcovs, timeseries, lagyears, years)
   
    if(length(cntry.vec) > 0)
      datalst <- selectcntry.WHO(cntry.vec, datalst, lstind)
     
    if(length(nobvs) > 0 && is.character(covs.single))
      datalst <- countobvs.WHO(nobvs, datalst, covs.single, lstind)
    else if(length(nobvs) > 0){
          nm <- unlist(sapply(covs.single, function(mat) {
          cnm <- colnames(mat)[1]
        }))
        datalst <- countobvs.WHO(nobvs, datalst, nm, lstind)
        }
     

     
    indcov <- 1:length(datalst)
    names(indcov) <- names(datalst)
    csidwho <- names(datalst)
    datalst <- lapply(indcov, FUN="agesexclude.WHO", datalst, csidwho, covselect.WHO, lstind)
    if(length(selectages) <= 0)
      return(datalst)
    else
      return(datalst <- selectagesWHO(datalst, age.vec=selectages, lstind))  
    
  
  }

### DESCRIPTION helper function to datawho.
### Takes the arguments cov.FULL and cov.REDUCE, which may be string vectors or lists
### Return a single list with all covariates. 

  jointcovs <- function(cov.FULL, cov.REDUCE){ 
        if(is.data.frame(cov.FULL) && is.data.frame(cov.REDUCE)){
          ret <- c(list(cov.FULL), list(cov.REDUCE))
          return(ret)
        }
        if(is.data.frame(cov.FULL)){
          ret <- c(list(cov.FULL), cov.REDUCE)
          return(ret)
        }
        if(is.data.frame(cov.REDUCE)){
          ret <- c(cov.FULL, list(cov.REDUCE))
          return(ret)
        }
        ret <- c(cov.FULL, cov.REDUCE)
        return(ret)
      }
      

### Error checking for datawho.  The cross sectional time series must be identical for
### covariates and deaths otherwise stop the program
### INPUT: index entry n, and the lists of covaraites and diseases


 checkerrors.WHO <- function(n, alldths, allcovs)
{
  mad <- alldths[[n]]
  rownames(mad) <- NULL


 
  if(length(allcovs) <= 0)
    return(list())
  mac <- allcovs[[n]]
   
  rownames(mac) <- NULL


  if(!identical(mad[,1], mac[, 1]))
    stop("matrices of covariates and diseases differents csid")
  
  return(n)
}
### DESCRIPTION helper function to datawho
### It checks if tobacco is in the vector of covariates cov.FULL
### returns a boolean true or false

check.for.tobs <- function(cov.FULL)
  {      
    ind <- F
   
    if(is.character(cov.FULL) &&
       length(grep("tobacco",cov.FULL)) > 0 )
      return(ind <- T)
   
    if( !is.data.frame(cov.FULL) && length(cov.FULL) > 1)
      {
        ix  <- 1:length(cov.FULL)
        for(n in ix){
          dat <- cov.FULL[n]
   
          if( cl <- try(all(identical(dat, tobacco)), silent=T) )
            ind <- T
        }
        return(ind)
      }
   
     if( cl <- try(all(identical(cov.FULL, tobacco)), silent=T) )
       ind <- T    
   
    return(ind)
  }
        
### takes the results of calling match.call from the arguments of any function
### Get the different components and prints them.

  find.coltags <- function(driver,pt=T, verbose=T){
    
    verb <- try(get("verbose", env=parent.frame()),silent=T)
    if(class(verb)!="try-error")
      verbose <- verb
          
### print(driver)
        driver <- as.character(driver)
        if(pt){
          messout(paste("You have enter the args ", driver, sep=""),verbose)
      
      
        }
### name of the calling function 
        driver.call <- driver[1] #### datawho
        datadir     <- driver[2] #### "~/INPUT/"
        cause  <- driver[3]  #### "allc" 
        popu   <- driver[4]  #### "population"
        covRedc <- driver[5] #### "gdp"
        covFull <- driver[6] #### "tobacco", "gdp.FULL"
###        print(cause)
###        print(popu)
### give me its arguments
        args  <- names(formals(driver))
        names(args) <- args
###        print(args)

        if(is.list(cause))
          vecdis <- unlist(cause)
        return(invisible(driver))
        
      }
### Helper function to datawho. It lags the covariates by appending
### the matrix lagcovs whose entries are  NA's to the elemenst of allcovs
### INPUT: the index number m, list of covariates and lagcovs a matrix. 

lagcovariates.WHO <- function(m, allcovs, lagcovs)
  {
  
    mat <- allcovs[[m]]
    nm <- colnames(mat)
    nm <- as.vector(nm[-1])
      
    if(ncol(mat) > 2){
      mat <- as.matrix(rbind(lagcovs, mat[,-1]))
    }else{
      vec <- mat[,-1]
      mat <- matrix(vec, ncol=1)
      mat <- matrix(rbind(lagcovs, mat))
      colnames(mat) <- nm
    }
    return(mat)
  }

### DESCRIPTION takes list alldths, allcovs and bind them together for each csid; 
###             rownames for each matrix element is the time series years
###
### INPUT the lists of diseases, alldths,  for every csid
###       the list of covariates, allcovs, for every csid
###       times a logical to include time series years as one of the columns
###       ly number of years to lag covariates; years the observation time series for files WHO
###
### OUTPUT a list of elements csid combining all covariates and diseases from alldths, allcovs
###        and appending time series if times = T
###
### USES: shapelst.WHO, elimallna.cols 
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
#####################################################################################

joindthcov.WHO <- function(alldths, allcovs, times=T, ly, years)
  {
    ind <- NULL
    datalst <- allcovs
 
    if(length(alldths) > 0)
      {
        ind <- 1:length(alldths)
        names(ind) <- names(alldths)
    
        datalst <- lapply(ind, function(n){
        
          if(length(alldths) >0)
            mat.dth <- alldths[[n]]
          else
            mat.dth <- NULL
       
          if(length(allcovs) >0)
            mat.cov <- allcovs[[n]]
          else
            mat.cov <- NULL
          
          if(length(mat.dth) > 0 && length(mat.cov) > 0)
            mat <- builds.cbind(mat.dth,mat.cov, mess="joindthcov.WHO")
          else if(length(mat.dth) > 0)
            mat <- mat.dth
          else if (length(mat.cov) > 0)
            mat <- mat.cov
          
          return(mat)
           })
      }
 
     if(length(alldths) <= 0)
       {
         datalst <- lapply(datalst, function(mat) {
           lay <- years[length(years)]
           mat <- as.matrix(mat)
          
           if(ly > 0) 
             rownames(mat) <- years[1]:(lay+ly)
           else
             rownames(mat) <- years
           return(mat)
         })
       }
### remove all NA's for columns years < 1950
   
    datalst <- lapply(datalst, FUN="shapelst.WHO", times, ly)
   
### eliminate any column of datalst matrices elements that are all na's      
    datalst <- lapply(datalst, FUN="elimallna.cols")
  
    return(datalst)
  }
### HELPER function to joindthcov.WHO;
###
### USES removeNA.WHO
###
### INPUT: mat, a matrix; times a logical; ly number of years to lag
###
### OUTPUT modify matrix mat
###
### AUTHOR Elena Villalon
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
##################################################################################

shapelst.WHO <- function(mat,times,ly)
{
  nm <- colnames(mat)
  
  ind <- 1:nrow(mat)         
  ind.toremove <- sapply(ind,FUN= "removeNA.WHO",mat)
         
  ind.toremove <- unlist(ind.toremove)
  sx <- 1:length(ind.toremove)
  sx <- sx + ind.toremove[[1]] -1

  fix <- (sx == ind.toremove )
  ind.toremove <- ind.toremove[fix]
      
  if(length(ind.toremove) > 0)
    mat <- as.matrix(mat[-ind.toremove, ])
  colnames(mat) <- nm
      
  if(times){
    nm <- colnames(mat)
    tm <- as.numeric(rownames(mat)) - ly
    mat <- builds.cbind(mat,tm, mess="shapelst.WHO")

    colnames(mat) <- c(nm, "time") 
  }
  return(mat)
}
### DESCRIPTION: binds two matrices with the same number of rows
###              or print an error message

builds.cbind <- function(m1, m2, mess=" ",verbose=T)
  {
     verb <- try(get("verbose", env=get("env.base", env=parent.frame())),silent=T)
    if(class(verb)!="try-error")
      verbose <- verb
    m1 <- as.matrix(m1)
    m2 <-  as.matrix(m2)
    mat <- NULL
    
    if(nrow(m1) == nrow(m2) && length(m1) > 0 && length(m2) > 0)
      mat <- cbind(m1, m2)
    else if(length(m1 ) > 0 && length(m2) > 0)
      messout(paste("Number of rows differ in ", mess,sep=""),verbose)
    else if(length(m1) > 0)
      mat <- m1
    else
      mat <- m2
    
    return(mat)
  }
### DESCRIPTION given a matrix mat and index row n
###             finds if all elements in the row are NA and return NULL
###             otherwise if not all elements in the row are NA, return the row index
###
### AUTHOR Elena Villalon
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
##################################################################################
removeNA.WHO <- function(n, mat){
  rr <- mat[n, ]
  if(all(is.na(rr)))
    return(n)
  else
    return(NULL)
}

### DESCRIPTION builds the list with cross-sectional identifiers for all 
###             files in datapath whose names are in vector disease and population
###
### INPUT datapath, a character string with a directory name; 
###       disease, a vector with names of death causes of diseases;
###                it may also be an object with data.frame for disease. 
###       pop, a string with the name of the file for population
###            it may also be a dat.frame with population info. 
###
### OUTPUT: the list of csid elements one for each country and age group
###         Every element of the list is a matrix with two columns for
###         each disease and for population according to gender,
###         such as allc2, allc3, popu2, popu3 for male and female
###         If the files or objects only contain information for one of
###         the genders, then only one column will be included with the
###         corresponding gender number append to the name of the
###         disease and/or population.
###
### USES: builddths.WHO
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###
########################################################################
disease.WHO <- function(datapath, disease, pop, lstind, f=3, m=2)
  {
    
### all deaths included in disease and population for both genders
### the number of digits for country, age and years
    
    todiscard <- lstind$digit.first
    cdigits <- lstind$cntry.digits
    cdigits <- cdigits + todiscard
    adigits <- lstind$age.digits
    ydigits <- lstind$year.digits
    
   
    alldths <- buildths.WHO(datapath,disease, pop)
 
    if(length(alldths) <= 0)
      return(list())       
### split according to gender
     
    nc     <- ncol(alldths)
    strata <- unique.default(alldths[,nc])
 ###   print(strata )
    alldths.female <- NULL
    alldths.male <- NULL
    alldths <- split.data.frame(alldths, alldths[,nc])
    
    if(length(alldths) >= 2){
       alldths.male <- alldths[[1]]
       alldths.female <- alldths[[2]]
     }
    if(length(alldths) < 2){
         
       if(strata >=f)
         alldths.female <- alldths[[1]]
       else
         alldths.male <- alldths[[1]]
     }
        
### split according to csid (or cntry+age identifiers)
    males.csid <- alldths.male
    females.csid <- alldths.female
    
    if(length(alldths.male) > 0 )
      {
        males.csid <- split.data.frame(alldths.male, floor(alldths.male[,1]/10^ydigits))
       
### change columns names from allc to allc2 or allc3 depending on male or females
        males.csid <- lapply(males.csid, FUN="appendstrata.WHO",lstind)
       
        ind <- 1:length(males.csid)
        names(ind) <- names(males.csid)
      }
    if(length(alldths.female) > 0)
      {
        females.csid <- split.data.frame(alldths.female, floor(alldths.female[,1]/10^ydigits))
        females.csid <- lapply(females.csid, FUN="appendstrata.WHO", lstind)
      }
### error checking
       if(length(males.csid) > 0 && length(females.csid) > 0 &&
          (abs(length(males.csid) - length(females.csid)) > 0 ||
          !identical(names(males.csid), names(females.csid))))
         stop("error building csid males and females")
     
### construct list of matrices for each csid with males and females
### diseases (e.g, allc2 and allc3, cerv2, cerv3)
### and population (e.g, popu2, popu3)
    if(length(males.csid) > 0 && length(females.csid) > 0){
       alldths <- lapply(ind, function(n){
                         
                         nm2 <- colnames(males.csid[[n]])
                         nm3 <- colnames(females.csid[[n]])
                         nm3 <- nm3[-1]
                         mat <- builds.cbind(males.csid[[n]], females.csid[[n]][,-1],
                                             mess="disease.WHO")
                   
                         colnames(mat) <- c(nm2, nm3)
                         return(mat)})
     }
    if(length(males.csid) <= 0)
      alldths <- females.csid
    if(length(females.csid) <= 0)
      alldths <- males.csid
 
       return(alldths)
}

### DESCRIPTION helper function to disease.WHO
###             reads the files in datapath whose names are in the vectors disease, pop
###             Binds them in columns for every files
###
### INPUT datapath with directory name; 
###       disease vector of death causes, or an object data.frame, or list of objects
###       pop string with file population or data.frame
###
### OUTPUT A matrix with as many columns as files in disease and pop plus
###        two additional columns to identify the gender and the cstid or cross sectional year
###        such as "4080351999", for cntry "4080", age "35" and year "1999"
###
### USES: const.dataframe
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
#########################################################################
buildths.WHO <- function(datapath, disease, pop, alldths=NULL, verbose=T)
  {
    verb <- try(get("verbose", env=parent.frame()),silent=T)
    if(class(verb)!="try-error")
      verbose <- verb
    if(length(disease) <= 0 && length(pop) <= 0)
      return(list())
    
    alldths <- NULL
    csidth  <- NULL
### disease may be a vector of strings with names for death causes   
    if(is.character(disease)){ 
      for(n in 1:length(disease))
        {       
          dthstring  <- paste(datapath,"/",disease[n],".txt",sep="")
          messout(paste("Reading file ", dthstring, sep=""), verbose)
          dth0 <- scan(file=dthstring,
                       na.strings=c("-999.0000", "-999", "NA"),
                       multi.line=T,quiet=T)
          dth0 <- matrix(dth0,ncol=3,byrow=T)
          csidth <- dth0[,2]
          strata <- unique.default(dth0[, 3])
              
          if(n <= 1){
            alldths <- as.matrix(dth0[,1])
            allcsid <- csidth
            next
             
          }
         
          cs <- intersect(csidth, allcsid) ### gives the actual values
            
          ind1 <- na.omit(match(allcsid, csidth)) ### indeces of intersect on vector csidth
          ind2 <- na.omit(match(csidth, allcsid))### indeces on vector allcsid
          csidth <- csidth[ind1]
          allcsid <- allcsid[ind2]
            
          alldths <- alldths[ind2, ]
          dth0 <- dth0[ind1,]
          ind <- NULL
  ###          cat("now ", length(allcsid),"  ", length(csidth),"\n")
          if(length(allcsid) != length(csidth)){ 
            ind <- unlist(sapply(allcsid,grep, csidth))
            if(length(ind) > 0)
              alldths[ind, ]
          }
      ####    alldths <- builds.cbind(alldths,dth0[,1], mess="buildths.WHO")
          alldths <- cbind(alldths, nm=as.matrix(dth0[,1]))
          
          allcsid <- csidth
        }
      
        colnames(alldths) <- disease
      }
    ### if disease is an object data.frame 
    if(!is.character(disease) && length(disease) > 0){
   
      
     lst <-  const.datafrm(disease) ### disease is a data.frame or list
     strata <- lst$strata
     alldths <- lst$alldths
     csidth <- lst$csidth
     csidth <- unique.default(csidth)
     
        }
    
       
    if (length(pop) <= 0){
    
      alldths <- try(cbind(csid=csidth, alldths, strata=strata))
     
      if(class(alldths)=="try-error"){
        messout("Error binding matrices in buildths.WHO", verbose)
        alldths <- NULL
      }
  
      return(alldths)
    }
    
 ### if pop is the name of a file read it
    if(is.character(pop)){
      
      popstring <- paste(datapath,"/",pop,".txt",sep="")
      mesout(paste("Reading file ", popstring, sep=""), verbose)
      pop0 <- scan(file=popstring,
                   na.strings=c("-999.0000", "-999", "NA"),multi.line=T,quiet=T)
      pop0 <- matrix(pop0, ncol=3, byrow=T)
      
    }
    
 ### if pop is an object data.frame
    if(!is.character(pop) && length(pop) > 0)
        {
          pop0 <- as.matrix(pop) 
          
        }    
            
  
    csid <- pop0[,2]
    csid <- unique.default(csid)
    if(dim(alldths)[[1]] != dim(pop0)[[1]] &&
       length(alldths)>0 && length(pop0) >0)
      {
        ind <- grep(strata, pop0[,3])
        if(length(ind) > 0)
        pop0 <- pop0[ind, ]
   ###     pop0 <- split.data.frame(pop0, pop0[, 3]==strata)$T
        ind  <- match(csidth, pop0[,2])
        if(length(na.omit(ind)) > 0)
          pop0 <- pop0[ind,]
                                 
      }
    if(length(csidth) <= 0)
      csidth <- pop0[,2]
    
    pop0 <- pop0[,-2]
  
    colnames(pop0) <- c("popu", "strata")
    nmall <- colnames(alldths)
    nmpop <- colnames(pop0)
    if(length(alldths) >0){
      
      alldths <- try(cbind(csidth,as.matrix(alldths), as.matrix(pop0)))
      colnames(alldths) <- c("csid", nmall, nmpop)
     if(class(alldths) == "try-error"){
       
       messout("Error binding matrices in buildths.WHO", verbose)
       alldths <- NULL}
      
    }else{
  
     
       alldths <- cbind(as.matrix(csidth),as.matrix(pop0))
       colnames(alldths) <- c("csid", nmpop)
         
     }
    ind <- order(alldths[, 1])
    alldths <- alldths[ind, ]

    return(alldths)
  }

#### DESCRIPTION: helper function to buildths.WHO if disease is a data.frame
###               or a list of data.frames

const.datafrm <- function(disease, chk=T)
  {
    alldths <- NULL
 ###   print(length(disease))
 ###   print(str(disease))
 ###   print(is.data.frame(disease))
  
    if(length(disease) > 1 && chk && !is.data.frame(disease)){
### check all deaths components have same no of rows
             
      disease <- find.common.csid(disease, cl=2)
  
      nr <- sapply(as.list(1:length(disease)), function(n){
        mat <- as.matrix(disease[[n]])
        if(is.list(mat))
          mat <- mat[[1]]
      ###  print(nrow(mat))
        return(nrow(mat))})
      nru <- unique.default(unlist(nr))
      if(length(nru) > 1)
        stop("Incompatible sizes of disease list elements")
    }
### it is a list of data.frames    
    if(!is.data.frame(disease))
      {       
        for(dat in disease){
          dth0 <- as.matrix(dat)
          cnm  <- colnames(dth0)
###   print(cnm)
          csidth <- dth0[,2]
          strata <- unique.default(dth0[, 3])
          cnmall <- colnames(alldths)
     ###     alldths <- builds.cbind(alldths,dth0[,1], mess="const.datafrm")
       
          alldths <- cbind(alldths, nm=as.matrix(dth0[,1]))
          colnames(alldths) <- c(cnmall, cnm[1])
        }
        lst <- c(list(strata=strata), list(alldths=alldths), list(csidth=csidth))
        return(lst)
      }
    
  ### is a data.frame (only one death cause present)
    dth0 <- as.matrix(disease)
    cnm  <- colnames(dth0)
###   print(cnm)
    csidth <- dth0[,2]
    strata <- unique.default(dth0[, 3])
    cnmall <- colnames(alldths)
###    alldths <- builds.cbind(alldths,dth0[,1], mess="const.datafrm")
    
    alldths <- cbind(alldths, nm=as.matrix(dth0[,1]))
    colnames(alldths) <- c(cnmall, cnm[1])
    
    lst <- c(list(strata=strata), list(alldths=alldths), list(csidth=csidth))          
    return(lst)
  }

### DESCRIPTION: helper function to const.datafrm
###              It takes a list with data.frames and
###              cl the column corresponding to the cstsid identifiers.  
###              finds the common csid identifiers for all elements
###              If none it stops the program
###              Otherwise it redefine the elemnts of disease to
###              contain only the common identifiers.
###              Returns disease with only values common to all elemnst.

 find.common.csid <- function(disease, cl){
        if(length(disease) <= 1)
          return(disease)
        
         for(n in 1:length(disease)){
           
           mat <- as.matrix(disease[[n]])
           
           csid <- mat[,cl] ### say, 2450451980 list of cstsid
           if(n <= 1){
             fcsid <- csid
           }else{
             fcsid <- intersect(fcsid, csid)
          
           }
         }
       
         if(length(fcsid) <= 0)
           stop("Incompatible sizes of disease list elements")
      
      
         for(n in 1:length(disease)){
         
           mat <-  as.matrix(disease[[n]])
           vec <- mat[, cl]
           if(length(vec) == length(fcsid)){
             disease[[n]] <- mat
             next
           }
           ind <- match(fcsid, vec)
           ind <- unlist(ind)
           if (length(ind) > 0)
             mat <- mat[ind, ]
           disease[[n]] <- mat
         }
         return(disease)
       }
        
### given a matrix with a death or covariate column a gender column
### it appends the number 2 or 3 to the column name identifying the
### disease or covariate and delete the gender (strata) column
### returns the modified matrix 
appendstrata.WHO <- function(mat, lstind)
{
### the number of digits for country, age and years

  todiscard <- lstind$digit.first
  cdigits <- lstind$cntry.digits
  cdigits <- cdigits + todiscard

  adigits <- lstind$age.digits
  ydigits <- lstind$year.digits
   
  cnm <- colnames(mat)
  no  <- mat[1,"strata"]
  ind <- grep("strata", cnm)
  
  mat <- mat[,-ind]
  cnm <- cnm[-ind]
  ind <- grep("csid", cnm)
  rcnm <- cnm[-ind]
  rcnm <- paste(rcnm,no, sep="")
  cnm <- c("csid", rcnm) 
  colnames(mat) <- cnm
  csid <- mat[,"csid"]
  dd   <- cdigits + adigits + 1
  rnm  <- substring(csid, dd)
  rownames(mat) <- rnm
  return(mat)
}
### DESCRIPTION builds the list with cross-sectional identifiers for all 
###             files in datapath whose names are in vectors
###             cov.FULL or cov.REDUCE of covariates
###
### INPUT datapath, a character string with a directory name; 
###       cov, a vector with names of covariates or object list
###       with data.frames for each cov.  
###
### OUTPUT: the list of csid elements one for each country and age group
###         Every element of the list is a matrix with two columns for
###         each covariate according to gender if tobacco, 
###         such as tobacco2, tobacco3,for male and female
###         Otherwise the name of the covariate if strata independent, "gdp"
###
### USES covexceptob.WHO; appendtobgender.WHO; find.tobind
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###
########################################################################
buildcovs.WHO <- function(datapath, cov,lstind, age.g, verbose=T,f=3, m=2)
  {
     verb <- try(get("verbose", env=parent.frame()),silent=T)
    if(class(verb)!="try-error")
      verbose <- verb
### the number of digits for country, age and years
    todiscard <- lstind$digit.first
    cdigits <- lstind$cntry.digits
    cdigits <- cdigits + todiscard
    adigits <- lstind$age.digits
    ydigits <- lstind$year.digits
  
    ind <- find.tobind(cov)### tobacco index
  
    covF <- cov
    covT <-  NULL ### for tobacco
    
    if(length(ind) > 0){
      
      if( !is.data.frame(cov)){
           
        covF <- cov[-ind] ###without tobacco
        covT <- cov[ind]
     
      }else {
        
        covF <- NULL
        covT <- cov
      }
    }
   ###  print(length(covF))
     if(length(covF) > 0){
  
      allcovs.csid <- covexceptob.WHO(datapath, covF, lstind, age.g)
  
    }else
      allcovs.csid <- list()
    
  
    if (length(covT) <= 0){
      
      return(allcovs.csid)
    }

    if(is.character(covT)){ ### tobacco file 
    
      tobstring <- paste(datapath,"/",cov[ind],".txt",sep="")
      messout(paste("Reading file ", tobstring, sep=""), verbose)
      tob0 <- scan(file=tobstring,na.strings=c("NA","-999", "-999.0000"),
                   multi.line=T,quiet=T)
      tob0 <- matrix(tob0, ncol=3, byrow=T)
      
    }else ### tobacco data.frame           
    tob0 <- as.matrix(covT[[1]])
  
    ### strata can be 2 or 3 for male or female
   
    strata <- as.numeric(unique.default(tob0[,3]))
    tobm <- NULL
    tobf <- NULL

    tobg <- split.data.frame(tob0, tob0[,3])
    if(((m %in% strata) && (f %in% strata))|| length(strata) >= 2){ ### 2 for male and 3 for female
      
      tobm <- appendtobgender.WHO(tobg[[1]])
      tobf <- appendtobgender.WHO(tobg[[2]])
    
    }else if(m %in% strata){
      
      tobm <- appendtobgender.WHO(tobg[[1]])
    
    }else if(f %in% strata){
      
      tobf <- appendtobgender.WHO(tobg[[1]])
     
    }
  
    tobm.csid <- NULL
    tobf.csid <- NULL
  
    if(length(tobm) > 0){
      
      tobm.csid <- split.data.frame(tobm, round(tobm[,2]/10^ydigits))
   
    }
    if(length(tobf) > 0){
      
      tobf.csid <- split.data.frame(tobf, round(tobf[,2]/10^ydigits))
   
    }
    lnm <- length(tobm.csid)
    lnf <- length(tobf.csid)
    ln  <- max(lnm, lnf)
  
    if(lnm > lnf)
      nmtobcsid <- names(tobm.csid)
    else
      nmtobcsid <- names(tobf.csid)
  
    nmcovcsid <- names(allcovs.csid)
    if(length(nmtobcsid) > 0 && length(nmcovcsid) > 0)
      nmcsid <- intersect(nmtobcsid, nmcovcsid)
    else if (length(nmtobcsid) > 0)
      nmcsid <- nmtobcsid
    else
      nmcsid <- nmcovcsid
   
    
  ###  if(abs(length(allcovs.csid) - length(ind)) >0 && length(allcovs.csid) > 0 )
  ###    stop("Provide for the FULL version of covariates")
     
    join.gender <- lapply(nmcsid, function(n){
      acv <- NULL
      tm <- NULL
      tf <- NULL
      nmacv <- NULL
 
      if(length(allcovs.csid)> 0){
        acv <- allcovs.csid[[n]]
        nmacv <- colnames(acv)
     
      }
      if(length(tobm.csid) > 0)
        tm <- tobm.csid[[n]]
      if(length(tobf.csid) > 0)
        tf <- tobf.csid[[n]]
    
      nmcol  <- c("csid") 
      acvmn1 <- try(as.matrix(acv[,-1]), silent=T)
      if(class(acvmn1) == "try-error")
        acvmn1 <- NULL
              
      tm2 <- try(as.matrix(tm[,2]), silent=T)
      if(class(tm2) == "try-error"){
        tm2 <- NULL
        tmmn2 <- NULL
      }else{
        tmmn2 <- as.matrix(tm[,-2])
        nmcol <- c(nmcol,"tobacco2")
      }
      
      
      tf2 <- try(as.matrix(tf[,2]), silent=T)
      if(class(tf2) == "try-error"){
      
        tf2 <- NULL
        tfmn2 <- NULL
        
      }else{
        
        tfmn2 <- as.matrix(tf[,-2])
        nmcol <- c(nmcol, "tobacco3")
      }
   
      
      
      if(length(nmacv) >0)
        nmcol <- c(nmcol, nmacv[-1])
      
      
      if(length(tm) > 0){
       
        matbacco <- cbind(tm2, tmmn2, tfmn2, acvmn1)
                             
      }else if(length(tf) > 0){
     
        matbacco <- cbind(tf2, tfmn2, acvmn1)
     
      }
      colnames(matbacco) <- nmcol
     
      return(matbacco)
     
    
    })

    jgnm <- lapply(join.gender, function(mat)
                  ret <- mat[1, 1]%/%10^(ydigits))
    jgnm <- unlist(jgnm)
    names(join.gender) <- jgnm
    
    return(join.gender)
  }

### find if tobacco is in cov vector or list 

find.tobind <- function(cov)
{
  ind <- NULL
  if(is.character(cov)){
       
    ind <- grep("tobacco", cov)
    return(ind)
  }
  
  
  if(!is.data.frame(cov) ){
          
    ix  <- 1:length(cov)
    for(n in ix){
      dat <- cov[[n]]
      if(class(try(identical(dat, tobacco),silent=T)) != "try-error")    
      if(all(identical(dat, tobacco)))
        ind <- n
    }
          
    return(ind)
  }

  if(try(length(cov) == length(tobacco), silent=T)){

  if(cl <- try(all(identical(cov, tobacco)), silent=T))
    ind <- 1
}
  return(ind)
    
}
      
### HELPER function to build.covs;
### INPUT a matrix and returns modify matrix
### Appends the gender number 2 or 3 to colname tobacco
###
appendtobgender.WHO <- function(mat)
  { 
    no <- unique.default(mat[,3])
    mat <- mat[,-3]
    tob <- paste("tobacco", no, sep="")
    colnames(mat) <- c(tob, "csid")
   
    return(mat)
  }
### HELPER function to build.covs, from the REDUCE version of covariates
###
### DESCRIPTION:scan the covariates files or objects and build three column matrices;
###             The files or objects list or data.frames are age gender independents,
###             with one entry for every cntry, one blank age group,
###             and every year for both genders.
###             Uses expand.cov to deploy it for all age groups (repeating the blank 
###             age independent value) and for both genders 
###             Bind all covariates matrices along columns to make a large matrix
###             The matrix has one column to identify the csid, and as many more
###             columns as covariates are included in covF.
###             Split the large matrix will all covaraites values and csid
###             according to the country code + age group and returns the resulting list
###
### INPUT: datapath, a directotry path;
###        covF, a vector with name of covariates or list of data.frames
###        allcovs to append to it
###
### OUTPUT: a list whose elements are csid units (such as "245045")
###         every matrix in the list has as many columns as covaraites
###         in the vector covF, plus the csid time series identifier
###
### USES expand.cov to create a complete csid list for eacxh country
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###
###        August 2006
########################################################################
 leer.REDUCE <- function(datapath, covF, allcovs, lstind, age.g,verbose=T){
  ### the number of digits for country, age and years
   verb <- try(get("verbose", env=parent.frame()),silent=T)
   if(class(verb)!="try-error")
     verbose <- verb
    todiscard <- lstind$digit.first
    cdigits <- lstind$cntry.digits
    cdigits <- cdigits + todiscard
    adigits <- lstind$age.digits
    ydigits <- lstind$year.digits
    
      
   ### covF is a vector of characters
      if(is.character(covF)){
        for(n in 1:length(covF))
          {
            
            covname   <- covF[n]
            covstring <- paste(datapath,"/",covF[n],".txt",sep="")
            messout(paste("Expanding to full size ", covF[n], sep=""), verbose)   
            cov0 <- expand.cov(covname, covstring, ncol=2,type=NA,
                               select= NA,save.FULL=F, cov.path=NULL,
                               lstind=lstind, age.groups= age.g)
            if(n <= 1 && length(allcovs) <= 0){
              allcovs <- cbind(allcovs, cov0[, 2], cov0[,1])
              next
            }
            
     
            ind1 <- na.omit(match(allcovs[,1], cov0[,2]))
     
            ind2 <- na.omit(match(cov0[,2], allcovs[,1]))
     
            if(length(ind2) > 0)
              allcovs <- allcovs[ind2,]
            if(length(ind1) > 0)
              cov0 <- cov0[ind1, ]
          ###      cat(length(allcovs[,1]),"  ", length(cov0[,1]), "\n")
            ord <- order(cov0[,1])
            cov0 <- cov0[ord, ]
            ord <- order(allcovs[,1])
            allcovs <- allcovs[ord,]
        ###    cat(length(allcovs[,1]),"  ", length(cov0[,1]), "\n")
        ###    allcovs <- builds.cbind(allcovs,cov0[,1], mess="leer.REDUCE")
         
            allcovs <- cbind(allcovs, nm=cov0[,1])
            
            
          }
        colnames(allcovs) <- c("csid", covF)
        return(allcovs)
      } ### end of is.character(covF)
      
### covF is a list of data.frames
      csid <- as.list(1:length(covF))
      
       for(n in 1:length(covF)){
         dat <- covF[[n]]
         csid[[n]] <- dat[,2]
         if(n <= 1)
           cmp <- as.vector(dat[, 2])
         else
           cmp <- intersect(cmp, as.vector(dat[,2]))
       }
      
      for(n in 1:length(covF)){
        dat <- covF[[n]]
    
        ind <- na.omit(match(dat[,2], cmp))
        if(length(ind) > 0)
          dat <- dat[ind, ]
        csid <- dat[,2]
        cov0 <- as.matrix(dat)
       
        cnm  <- colnames(cov0)[1]
        
        cov0 <- expand.cov(cov0, covstring=NULL, ncol=2,type=NA,
                           select= NA,save.FULL=F, cov.path=NULL,
                           lstind=lstind, age.groups= age.g) 
      
        csidth <- cov0[,2]
        if(ncol(cov0) >= 3)
          strata <- unique.default(cov0[, 3])
        
        cnmall <- colnames(allcovs)
     
        if(n <= 1){
           allcovs <- builds.cbind(cov0[,2],cov0[,1], mess="leer.REDUCE")
        
          ###allcovs <- cbind(cov0[, 2], cov0[,1])
          colnames(allcovs) <- c("cstsid", cnm)
       
        }else{
        ###  print(nrow(allcovs))
        ###  print(length(cov0[,1]))
          allcovs <- builds.cbind(allcovs,cov0[,1], mess="leer.REDUCE")
          
          ###allcovs <- cbind(allcovs, cov0[,1])
    
          colnames(allcovs) <- c(cnmall, cnm)
        }
        
      } ### end of for loop
             
      return(allcovs)

    }
### DESCRIPTION takes a datapath and a vector of covariates that may
###             contain all age-dependent or age-independent types. 
###             It also takes a list of data.frames with covariates but tobacco.
###             Finds if the word FULL is append to the covariates file names.
###             If FULL is part of the file name it calls leer.FULL
###             If FULL is not append or covF is an object it calls leer.REDUCE
###             It splits the data matrix with all covariates according to csid's.
###             and return the list of matrices with csid identifiers.
###
### USES leer.FULL and leer.REDUCE
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###
###        August 2006
########################################################################
 covexceptob.WHO <- function(datapath, covF, lstind, age.g)
    {
    
      ### the number of digits for country, age and years
    
      todiscard <- lstind$digit.first
    
      cdigits <- lstind$cntry.digits
      cdigits <- cdigits + todiscard
      adigits <- lstind$age.digits
      ydigits <- lstind$year.digits
    
      allcovs <- NULL
      ind <-  NULL
      if(is.character(covF))
        ind   <- unlist(sapply("FULL", grep, covF))
      covF0 <- covF
      if(length(ind) > 0){
        covF  <- covF[ind] ### only FULL covariates
        allcovs <- leer.FULL(datapath, covF, allcovs)
      }else
      covF <- NULL
      
      if(length(covF0) > length(covF)){
        if(length(ind) > 0)
          covF0 <- covF0[-ind] ### only reduced covariates
        
        allcovs <- leer.REDUCE(datapath, covF0, allcovs, lstind, age.g)
       
      }
   
    allcovs.csid <- split.data.frame(allcovs, floor(allcovs[,1]/10^ydigits))
  
    return(allcovs.csid)
    }
### DESCRIPTION takes the data directory(datapath) and a vector of
###             file names or list of dataframes
###             Reads the files in covF that are the full blown up matrices
###             for each cntry, all age groups and genders.
###             It may take object data.frames bind them together 
 leer.FULL <- function(datapath, covF, allcovs,verbose)
  {
     verb <- try(get("verbose", env=parent.frame()),silent=T)
    if(class(verb)!="try-error")
      verbose <- verb
    covFlst <- NULL
    for(n in 1:length(covF)){
  
    if(is.character(covF[n])){
      
      covstring  <- paste(datapath,"/",covF[n],".txt",sep="")
      messout(paste("Reading file ", covstring, sep=""), verbose)
      cov0 <- scan(file=covstring,multi.line=T,na.strings=c("NA", "-999", "-999.0000"),quiet=T)
      cov0 <- matrix(cov0,ncol=3,byrow=T)
      
    }else
     cov0 <- as.matrix(covF[n])
        
    covFlst <- c(covFlst, list(cov0))
  }
   
    
    covFlst <- lapply(covFlst, as.data.frame)
    covFlst <- find.common.csid(disease=covFlst, cl=2)
    for(n in 1:length(covFlst)){
     
      cov0 <- covFlst[[n]]
      cov0 <- as.matrix(cov0)
      if(n <= 1){
     
      allcovs <- cbind(allcovs, cov0[, 2], cov0[,1])
       
    }else{
      allcovs <- builds.cbind(allcovs,cov0[,1], mess="leer.FULL")
    
    
###  allcovs <- cbind(allcovs, nm=cov0[,1])
    } 
    }
  

    rnm <- substring(covF, 6) ###from FULL.gdp to gdp

    colnames(allcovs) <- c("csid", rnm)
    return(allcovs)
  }

### DESCRIPTION: Select a country set of datalst according to vector cntry.vec
###
### INPUT: datalst, a list of elements csid units for counties and age groups
###        cntry.vec, a vector with country codes
###
### OUTPUT: a subset of the list datalst with only the countries included in cntry.vec
###
### AUTHOR: Elena Villalon
###         IQSS, Harvard University
###         evillalon@iq.haravrd.edu
###         March 22, 2006
#################################################################################

selectcntry.WHO <- function(cntry.vec, datalst, lstind)
  {
### the number of digits for country, age and years
    todiscard <- lstind$digit.first
    cdigits <- lstind$cntry.digits
    cdigits <- cdigits + todiscard
    adigits <- lstind$age.digits
    ydigits <- lstind$year.digits
   
    
    csid <- names(datalst)
    ind <- 1:length(datalst)
    names(ind) <- csid
    cntry.vec <- as.character(cntry.vec)
    ind <- sapply(ind, function(n, csid, cntry.vec)
                  {
                    chix <- csid[n]
                    ix <- NULL
                    ix <- if(is.element(substring(chix, 1, cdigits), cntry.vec))
                      ix <- n
                    return(ix)
                  }, csid,cntry.vec)
    ind <- unlist(ind)
    if(length(ind) > 0)
    datalst <- datalst[ind]
    else
      stop("No countries in dataset")
  }
### DESCRIPTION it select a particular subset of countries from datalst
###             if number of observations, for any death
###             or disease and population, is  no observations >= nobsv
###
### INPUT: nobsv, number of observations;
###        datalst, list of csid units for each cntry and age group
###        covs.nm, vector of covariates names to exclude from the counting
###
### OUPUT: datalst with countries satisfying criteria of no observations > nobsv
###
### AUTHOR: Elena Villalon
###         IQSS, Harvard University
###         evillalon@iq.haravrd.edu
###         March 22, 2006
#################################################################################
 

countobvs.WHO <- function(nobvs, datalst,
                          covs.nm =c("fat", "gdp", "hc", "tfr", "tobacco2", "tobacco3"),
                          lstind, verbose=T) 
  {
     verb <- try(get("verbose", env=parent.frame()),silent=T)
    if(class(verb)!="try-error")
      verbose <- verb
### the number of digits for country, age and years
    todiscard <- lstind$digit.first
    cdigits <- lstind$cntry.digits
    cdigits <- cdigits + todiscard
    adigits <- lstind$age.digits
    ydigits <- lstind$year.digits
    
    ind <- 1:length(datalst)
    names(ind) <- names(datalst)
    ind <- sapply(ind, function(n)
                    {                      
                      mat <- datalst[[n]]
                      cnm <- colnames(mat)
                    
                    
                      ix <- unlist(sapply(covs.nm, grep,cnm))
                     
                      if (length(ix) > 0)
                        mat <- mat[, -ix]
                    
                      if(length(ix) == length(cnm))
                        return(n)
                  
                      mat[!is.na(mat)] <- 1
                      mat[is.na(mat)] <- 0
                      vec.sum <- apply(as.matrix(mat), 2, sum)
                      xi <- NULL
                      if(all(vec.sum >= nobvs))
                        xi <- n
                        
                      return(xi)
                      })
    ind <- unlist(ind)
    datalst <- datalst[ind]
    nm <- names(datalst)
    nm <- sapply(nm, substring, 1, cdigits)
    nm <- unique.default(nm)
     nm0 <- nm
    for(m in 1:length(nm)){
      cntry <- nm[m]
      if(m==1)
        allcntry <- cntry
      else
        allcntry <- paste(allcntry, cntry)
    }
     nm <- allcntry[[length(allcntry)]]
       
    messout(paste("Number of countries with unless ", nobvs, " observations is ", length(nm), sep=""), verbose)
    messout("Subset of country codes", verbose)
    messout(nm, verbose)
    
    return(datalst)        
  }

### DESCRIPTION: helper function to datawho(), when lagyears = 0
###              joins deaths and covariates into a single data list according to csid
###              select countriesa if cntry.vec is non null or number observations (nobvs)
###              is positive.  Exclude age groups <= 15 from the tobacco covariate
###
### INPUT: alldths, list of diseases by csid
###        allcovs, list of covaraites by csid
###        timeseries,true or false to inclues the time as covaraite
###        lagyers, integer to lag covariates = 0
###        years, times sereis in data sset
###        cntry.vec, vector of country codes
###        nobvs, number of deaths observations
###        covs.single, vector of covariates names (without the FULL, e.g, fat, gdp)
###        cov.FULL, vector of covarites names , FULL.gdp, FULL.fat
###        covselect.WHO, ages to exclude from tobacco
###
### USES: joindthcov.WHO,selectcntry.WHO, countobvs.WHO, agesexclude.WHO
###
### OUPUT the transform datalst, a list by csid (cntry+age) of data
###       for diseases and covariates
###
### AUTHOR: Elena Villalon
###         IQS, Harvard University
###         evillalon@iq.harvard.edu
###         March 27th, 2006
################################################################################
        
  processnolag.WHO <- function(alldths, allcovs, timeseries,lagyears, years,
                               cntry.vec, nobvs, covs.single, cov.FULL,
                               covselect.WHO, btob, lstind)
  {
      if(length(alldths) > 0)
        alldths <- lapply(alldths, function(mat) {
          nm <- colnames(mat)[-1]
          mat <- as.matrix(mat[,-1])
          colnames(mat) <- nm
          return(mat)})
      
      if(length(allcovs) > 0)
        allcovs <- lapply(allcovs, function(mat) {
          nm <- colnames(mat)[-1]
          mat <- as.matrix(mat[, -1])
          colnames(mat) <- nm
          return(mat)})
   
      datalst <- joindthcov.WHO(alldths, allcovs, timeseries, lagyears, years)
      if(length(cntry.vec) > 0)
        datalst <- selectcntry.WHO(cntry.vec, datalst, lstind)

      if(length(nobvs) > 0 && is.character(covs.single))
        datalst <- countobvs.WHO(nobvs, datalst, covs.single, lstind)
      else if(length(nobvs) > 0){
       nm <- unlist(sapply(covs.single, function(mat) {
          cnm <- colnames(mat)[1]
        }))
        datalst <- countobvs.WHO(nobvs, datalst, nm, lstind)
        }
      
      
     if(length(grep("tobacco",cov.FULL)) > 0 || btob)
       {
         incov <- 1:length(datalst)
         names(incov) <- names(datalst)
         csidwho <- names(datalst)
         datalst <- lapply(incov, FUN="agesexclude.WHO", datalst,csidwho, covselect.WHO, lstind)        
        
       }
      
      
       
    return(datalst)
    }
### DESCRIPTION exclude age groups in covselect.WHO from file

agesexclude.WHO <- function(n, datalst, csidwho, covselect.WHO,lstind, file="tobacco")
{
### the number of digits for country, age and years
  todiscard <- lstind$digit.first
  cdigits <- lstind$cntry.digits
  cdigits <- cdigits + todiscard
  adigits <- lstind$age.digits
  ydigits <- lstind$year.digits
  
  mat <- datalst[[n]]
  csid <- csidwho[n]
  nm <- colnames(mat)
 
  dd <- cdigits+1
  age <- as.numeric(substring(csid, dd))
  ix <- grep(file, nm)
  if(is.element(age, covselect.WHO) && length(ix) > 0)
    mat <- mat[,-ix]
  return(mat)
}
                 
### Not in use for the program; to reduce the number of rows for elemenst
### matrices of datalst.  If any death or disease timeseries has no observations
### for all rows of mat, eliminates the rows before the first observation of death

datana.WHO <- function(datalst, covs.single)
{
  lapply(datalst, function(mat){
    cnm <- colnames(mat)
    ix <- unlist(sapply(covs.single, grep, cnm))
    dth <- mat[,-ix]
   
    dth[!is.na(dth)] <- 1
    dth[is.na(dth)] <- 0
    ix <- match(1, dth[,1])
    return(mat[ix:nrow(mat), ])})
}
### DESCRIPTION 
###        It checks if any of the columns of mat contains only na's
###        If it is the case then removes the column
###
### INPUT: mat, a matrix; 
###
### OUTPUT modify matrix mat with only columns that have unless one observation
###
### AUTHOR Elena Villalon
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
##################################################################################

elimallna.cols <- function(mat)
  {
    ix <- as.list(1:ncol(mat))
    names(ix) <- colnames(mat)
    ix <- sapply(ix, function(n){
      cc <- na.omit(mat[,n])
      
      if(length(cc) >0)
        return(n)
      else
        return(NULL)
      
    })
    ix <- unlist(ix)
    return(mat[, ix])
  }

### DESCRIPTION:construct the list dataobj argument of yourcast, 
###             which has four elements, data, index.code,
###             proximity, and G.names.
###
### INPUT: dataw the list with csd units for dataobj$data; 
###        if dataw=null then it calls datawho() with its defaults
###        arguments to build the list dataw; 
###        icode or index.code, a string; 
###        proxfile, the name of the proximity (or adjacency file); 
###        Gnames, the file for G.names;
###        dpath, the directory name where the files are
###
### OUTPUT: dataobj one of the arguments of yourcast
###
### AUTHOR: Elena Villalon
###         IQS, Harvard University
###         evillalon@iq.harvard.edu
###         March 2006
#################################################################

dataobjWHO <- function(###datapath= "/nfs/where/export/data/death/WHOdata/Jun2002_data/",
                       datapath =NULL, 
                       disease = c("aids","allc", "allo", "brst", "cerv",
                         "cvds", "dgst", "homi", "livc", "lung", "malr",
                         "matc", "molp", "omal", "otin", "pern", "rspc",
                         "rspi", "stom", "suic", "trns", "tubr","unin","ward"),
                       pop= "population", cov.REDUCE= NULL, 
                       cov.FULL= c("FULL.fat", "FULL.gdp", "FULL.hc", "FULL.tfr", "tobacco"),
                       lagyears = 0, timeseries=TRUE, 
                       cntry.vec = NULL, nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                       icode="ggggaatttt",proxfile="adjacency.txt",
                       Gnames="cntry.codes.txt", selectages=NULL, verbose=T)
{

  dataobj <- list()  

  if(length(disease) <= 0 && length(pop) <= 0 &&
     length(cov.FULL)<= 0 && length(cov.REDUCE) <= 0)
    dataw <- datawho()
  else{
  
    dataw <- datawho(datapath, disease, pop,cov.REDUCE, cov.FULL,lagyears, timeseries,
                     cntry.vec, nobvs, covselect.WHO,selectages, icode,verbose)
  }
 
  dpath <- datapath
  dataobj <- c(dataobj, data=list(dataw), index.code=icode)
  
  if(length(Gnames) <= 0){
    gnames <- NULL 
  }else if(is.character(Gnames)){
    Gnames <- paste(dpath,"/", Gnames, sep="") 
    gnames <- build.Gnames(pfile=Gnames)
 
  }else{    
    gnames <- build.Gnames.obj(pfile=as.matrix(Gnames))
  }

  if(length(gnames) > 0)
    dataobj <- c(dataobj, G.names=list(gnames))
  
  if(length(proxfile) > 0)
    {
      proxobj <- proximity.file(datapath=dpath, filenm = proxfile,
                                filename = proxfile, dir="./tmp", savemat=F)
  
      dataobj <- c(dataobj, proximity=list(proxobj))
    }
  return(dataobj)
}
### DESCRIPTION given a list whose elemnts have csid matrices
###             Names of elements ar cntry+age, say "245045"
###             Select those ages groups in all countries that
###             are in vector age.vec

selectagesWHO <- function(datlst, age.vec, lstind)
  {
    todiscard <- lstind$digit.first
    cdigits <- lstind$cntry.digits
    cdigits <- cdigits + todiscard
    adigits <- lstind$age.digits
    ydigits <- lstind$year.digits
    
    age.vec <- as.numeric(age.vec)
    nmlst <- names(datlst)
    ind <- as.list(1:length(nmlst))
    names(ind) <- nmlst
    ind <- sapply(ind, function(n) {
      csid <- nmlst[n]
      age <- as.numeric(substring(csid, cdigits + 1))
      toret <- NULL
      if(is.element(age, age.vec))
        toret <- n
      return(toret)
    })

    ind <- unlist(ind)
    if (length(ind) > 0)
      return(datlst[ind])
    else
      return(datlst)
  }
user.prompt <- function (verbose=NULL){
  verb <- NULL
 if(length(verbose) <= 0)
   silent <- readline("\nPress <return> to continue or Ctrl-c Ctrl-c to quit: ")
 
 else{
   
   answer <- readline("\nEnter 'Y' for verbose output else enter 'N' or \npress Ctrl-c Ctrl-c to quit: " )
   
   if(substr(answer,1,1)=='N')
     verb <- F
   else if(substr(answer,1,1)=='Y')
     verb <- T
   
 }
   return(verb)
     
}
   



selectyearWHO <- function(datlst, year.vec=2000, icode="ggggaatttt")
  {
    lstind    <- as.list(parse.index.code(icode))
    todiscard <- lstind$digit.first
    
    cdigits <- lstind$cntry.digits
    cdigits <- cdigits + todiscard
    adigits <- lstind$age.digits
    ydigits <- lstind$year.digits
    
    year.vec <- as.character(year.vec)
    datlst <- lapply(datlst, function(mat) {
      rw <- rownames(mat)
      cl <- colnames(mat)
      ln <- 1:length(cl)
      ixr <- unlist(sapply(year.vec, grep, rw))
      if(length(ixr) > 0 ){
        mat <- matrix( mat[ixr, ], nrow=length(ixr))
       rownames(mat) <- year.vec
       colnames(mat) <- cl
      }else
        mat <- NULL
     return(mat)
    })
    ind <- sapply(datlst, function(mat){
                  bool <- T
                  if(length(mat) <= 0)
                    bool <- F
                  return(bool)
                })
    
    ind <- unlist(ind)

                    
    datlst <- datlst[ind]
    return(datlst)
  }

### Create a list of, data objects, such as for depvar
### allc <- read.depvarAndcov(file="allc")
### suic <- read.depvarAndcov(file="suic")
### disease <- c(list(allc=allc),list(suic=suic))
### disease <- list(list(allc=allc),list(suic=suic))
### function read.depvarAndcov, takes as arguments
### the directory datapath where the files are and
### file with the filename, nc is the number of columns of
### the output dataframe (value, csid and strata) depending
### on whether the file is gender dependent ("allc) or
### gender independent ("gdp").  It returns the data.frame
### built from the file 
###> allc <- read.depvarAndcov()
###> suic <- read.depvarAndcov(file="suic")
###> dgst <- read.depvarAndcov(file="dgst")
###> cerv <- read.depvarAndcov(file="cerv")
###> trns <- read.depvarAndcov(file="trns")
###> rspi <- read.depvarAndcov(file="rspi")
###> lung <- read.depvarAndcov(file="lung")
###> brst <- read.depvarAndcov(file="brst")
###> tobacco <- read.depvarAndcov(file="tobacco")
###> gdp <- read.depvarAndcov(file="gdp", nc=2)
###> hc <- read.depvarAndcov(file="hc", nc=2)
###> fat <- read.depvarAndcov(file="fat", nc=2)
###> population <- read.depvarAndcov(file="population")
###> adjacency <- read.depvarAndcov(file="adjacency")
###> cntrycode <- read.depvarAndcov(file="cntry.codes",nc=2, codes=T)
###############################################################
  
read.depvarAndcov <- function(datapath="~/yourcast/YourCast/data/",file="allc", nc=3, codes=F, skp=0){

  ff0 <- file
  filepath <- paste(datapath,"/", file,".txt", sep="")
  if(!codes)
    ff <- scan(file=filepath,multi.line=T,na.strings=c("NA", "-999", "-999.0000"),
               quiet=T, skip=skp)
  else
    ff <- try(scan(file=filepath,
                   what=c(integer(0),character(0)),
                   quiet=T,multi.line=T, skip=skp))
             ###      sep="\t",quote="\"", skip=0), silent=T)
  
  ff <- matrix(ff,ncol=nc,byrow=T)
  if(ff0=="tobacco")
    file <- "tobacco"
  
  if(nc>=3)
    colnames(ff) <- c(file, "csid", "strata")
  else
    colnames(ff) <- c(file, "csid")
  
  ff <- data.frame(ff)
  return(invisible(ff))

}


