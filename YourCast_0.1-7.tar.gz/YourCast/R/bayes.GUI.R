##
## DESCRIPTION:  Creates a GUI for Bayesian (Girosi-King models) parameters.
##               It is a complicated GUI with many frames and some are overlap.
##               One frame has two radio buttons for zero-mean with True no action taken;
##               False may use the empirical mean in the code or may take the name
##               of a file with the values to substract from insampy.  The name of
##               the input file may be enter in the entry box below the radio buttons
##               Second frame contains parameters to be used for the Priors. Except for the
##               LI.### and nsample that apply to different type of priors, the rest
##               of parameters are grouped in four categories for age, age-time, time and cntry
##               The fisrt and second  frames are groupped together with one single frame
##               an put in a row of the entire GUI. 
##               Other four frames are matrices with rows for each parameters
##               and columns for elements (function matrix.edit.tab.byrow builds
##               the matrix with tkentry for each element).
##               Some of the parameters are scalars and only one column is normal and the rest
##               are grayed out and disabled. We allow for 5 columns but you may enter less than 5
##               Scalars only have one column available (state="normal").
##               Each of the groups have a button Apply. If you enter numbers for Ha.sigma,
##               Hat.sigma, Ht.sigma, Hct.sigma that are not NA, after pressing Apply they are
##               written in memory (that is in one of the nevironmnet, ewho). If you enter
##               NA for any of the H##.sigma, then after pressing Apply the group is disabled
##               and turns darkgrey, the button label changes to OFF.  You may press OFF and
##               enter values != NA, an the group is regular again.
##               The matrices for each of the 4 group is converted to dataframes and
##               each of the row ins the parameter values, either scalar or vectors elements.
##               Each group of matrices frames for Ha.sigma, and Hat.sigma and for
##               Ht.sigma, and Hct.sigma are groupped into two frames and place by row.
##               Buttons for Close and Apply write into memory any choices of parameters
##               and, Close, quits the GUI. 
##
##                 
## FORMAT: bayes(base,text).  Here base is the tktoplevel container
##         to build the GUI, and textvalues are strings with the texts for labels,
##         
##         The parameter textna = <NA> is the default for NA. 
##
## IMPORTED functions:trim.blanks(), build.display for entering initial values
##                    into the matrix.edit.tab.byrow, convert.dataframe,
##                    matrix.edit.tab.byrow, parse.files
##                    load.file() command for button of File input for zer-mean
##                    bayes.init and bayes.close to close the GUI
##                        
## VALUE:  a tktoplevel, base
##         In addition, any of the smoothing parameters or name of files  
##         can be changed or newly added with the GUI and their new values
##         are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 05/31/2005
## 
## 
## ************************************************************************
## ************************************************************************

 bayes <- function(base, elem =5, 
                   textsmooth = "Priors Smoothing Parameters: ",
                   textage ="Age Groups",
                   textime ="Time Trends",
                   textimeage = "Age & Time",
                   textcntry = "Geographical Index", 
                   textna = "<NA>", 
                   zerotext = paste("Mean Adjustment", "\n", "Hct.c.deriv", sep=""))
                   {
                     
    textexp=paste("(Note: Drop smoothness priors for ", 
                   "Ha.sigma =NA, Hat.sigma =NA, Ht.sigma =NA, Hct.sigma = NA)", sep="")    
    rowHa  <- c("Ha.sigma","Ha.sigma.sd",  "Ha.deriv", 
                "Ha.age.weight", "Ha.time.weight")
    rowHa <- expand.char(rowHa)
     
    rowHat <- c("Hat.sigma","Hat.sigma.sd", "Hat.a.deriv","Hat.t.deriv", 
                "Hat.age.weight", "Hat.time.weight")
    rowHat <- expand.char(rowHat)
    rowHt  <- c("Ht.sigma", "Ht.sigma.sd", "Ht.deriv",
                "Ht.age.weight", "Ht.time.weight")
    rowHt <- expand.char(rowHt)
    rowHct <- c("Hct.sigma","Hct.sigma.sd", "Hct.t.deriv", "Hct.time.weight")
    rowHct <- expand.char(rowHct)    
            
    ewho <- get("ewho", env=parent.frame())
    Ha.sigma <- get("Ha.sigma", env=ewho)
      
    Ht.sigma <- get("Ht.sigma", env=ewho)
    Hat.sigma <- get("Hat.sigma", env=ewho)
    Hct.sigma <- get("Hct.sigma", env=ewho)
    zero.mean <- get("zero.mean", env=ewho)

    Ha.sigma.sd <- get("Ha.sigma.sd", env=ewho)

    Ha.deriv <- get("Ha.deriv", env=ewho)

    Ha.age.weight   <- get("Ha.age.weight", env=ewho)

    Ha.time.weight  <- get("Ha.time.weight", env=ewho)

    Ht.sigma.sd <- get("Ht.sigma.sd", env=ewho)

    Ht.deriv <- get("Ht.deriv", env=ewho)

    Ht.age.weight   <- get("Ht.age.weight", env=ewho)

    Ht.time.weight  <- get("Ht.time.weight", env=ewho)

    Hat.sigma.sd <- get("Hat.sigma.sd", env=ewho)

    Hat.a.deriv <- get("Hat.a.deriv", env=ewho)

    Hat.t.deriv <- get("Hat.t.deriv", env=ewho)

    Hat.age.weight   <- get("Hat.age.weight", env=ewho)

    Hat.time.weight  <- get("Hat.time.weight", env=ewho)

    Hct.sigma.sd <- get("Hct.sigma.sd", env=ewho)

    Hct.t.deriv <- get("Hct.t.deriv", env=ewho)

    Hct.time.weight   <- get("Hct.time.weight", env=ewho)

    lnchar <- nchar("Hct.time.weight")
    model <- get("model", env=ewho)
    nsample  <- get("nsample", env=ewho)
    LI.sigma.mean <- get("LI.sigma.mean", env=ewho)
    LI.sigma.sd <- get("LI.sigma.sd", env=ewho)
    prior.path <- get("prior.path", env=ewho)
    data.path <- get("data.path", env=ewho)
    model <- get("model", env=ewho)
    
    restore.defaults <- F
    ft <- ifelse(toupper(trim.blanks(model)) != "MAP", T, F)
    
    ha  <- ifelse(is.na(Ha.sigma),textna, Ha.sigma)
    ht  <- ifelse(is.na(Ht.sigma),textna, Ht.sigma)
    hat <- ifelse(is.na(Hat.sigma),textna, Hat.sigma)
    hct <- ifelse(is.na(Hct.sigma),textna, Hct.sigma)
    varzero <- tclVar("")
    varLI.mean <- tclVar(LI.sigma.mean)
    varLI.sd <- tclVar(LI.sigma.sd)
    varsample <- tclVar(nsample)
    colorbox <- "white"
    
    rbValue <- tclVar("True")
    localpar <- list(Ha.sigma=ha, Ht.sigma=ht,Hat.sigma=hat)
    if(toupper(trim.blanks(model)) != "MAP") 
     localpar <- c(localpar, list(Hct.sigma=hct))
                          
   
    if(toupper(trim.blanks(model)) == "MAP")
       Hct.sigma <- NA
    
    varzer <- tclVar("") ## name of file for Hct.c.deriv
    eGUI <- environment()
                
    
    tkbayes <- tkframe(base, relief = "groove", borderwidth = 2) 
    frame0  <-  tkframe(tkbayes, relief = "groove", borderwidth = 0) ##textsmooth
    frame1  <-  tkframe(tkbayes, relief = "groove", borderwidth = 0) ## combo frame for frame12, frame13 
    frame3  <-  tkframe(tkbayes, relief = "groove", borderwidth = 1) ## buttons Apply, Close
    framemat1 <- tkframe(tkbayes, relief = "groove", borderwidth = 1) ## combo for frame2, frame21
    framemat2 <- tkframe(tkbayes, relief = "groove", borderwidth = 0) ## combo for frame22, frame23
    
    frame2  <-  tkframe(framemat1, relief = "groove", borderwidth = 0) ## Ha.params matrix
    frame21 <- tkframe(framemat1, relief = "groove", borderwidth = 0) ## Hat.params matrix
    frame22 <- tkframe(framemat2, relief = "groove", borderwidth = 0) ## Ht.params matrix
    frame23 <- tkframe(framemat2, relief = "groove", borderwidth = 0) ## Hct.params matrix
  
    frame12 <- tkframe(frame1, relief = "groove", borderwidth = 0) ##zero-mean, entry box, radio-buttons
    frame13 <- tkframe(frame1, relief = "groove", borderwidth = 0) ##LI.params, nsample
    framenote <- tkframe(tkbayes, relief="groove", borderwidth =0) ## note on NA values
    
    frame0.label0 <- tklabel(frame0, textvariable = tclVar(textsmooth),
                             fg="blue")
    
    tkgrid(frame0.label0, sticky="w") ## 
  
    tkgrid(tklabel(frame0, text="    "))
    tkpack(frame0, fill = "x")  
   
###*****
    load.file <- function()
      {      
        filepath <- tclvalue(tkgetOpenFile())
        if (!nchar(filepath)){
          tkmessageBox(message="No file selected from previous GUI's")
          return(0);
        }
        prior.path <- get("prior.path", env=get("ewho", env=eGUI))
        tkmessageBox(message=paste("File selected is\n",filepath ))
            
        fpath <- filepath
        lst <- strsplit(fpath,"/")[[1]]
        inx <- length(lst)
        userfile <- lst[inx]
        varzero <- tclVar(userfile)
###     cat("retVal is ....");  print(retVal)
        file <- parse.files(filepath=fpath,
                                 directory.def=prior.path, typedef = "txt", dir=prior.path)
        assign("zero.mean", file, env=get("ewho", env=eGUI))
        assign("zero.mean", file, env=ewho)
        ##     in.list[["zero.mean"]] <- file
     
             assign("varzero", varzero, env=eGUI) 
             tkconfigure(frame12.entry, textvariable = varzero)        
           
      }## 
    frame12.label <- tklabel(frame12, textvariable = tclVar(zerotext),
                             fg="blue")
    frame12.label1 <-  tklabel(frame12, textvariable = tclVar("Input File"),fg="black")
    frame12.entry <- tkentry(frame12, textvariable=varzero, width = 15, bg="white")
    frame12.butt <- tkbutton(frame12, textvariable =tclVar("Load"), fg="purple",
                             bg="gray", padx=2, borderwidth=2,command=load.file)
    frame12.rb1   <- tkradiobutton(frame12)
    frame12.rb2   <- tkradiobutton(frame12)
    tkgrid(frame12.label, sticky="w")
    tkconfigure(frame12.rb1, variable=rbValue,value="True")
    tkconfigure(frame12.rb2, variable=rbValue,value="False")
    tkgrid(tklabel(frame12, text="None"), frame12.rb1, sticky="w")
    tkgrid(tklabel(frame12, text="Empirical"), frame12.rb2, sticky="w")
    tkgrid(frame12.label1, frame12.entry, frame12.butt, sticky="w")
    
    frame13.label1 <- tklabel(frame13, text="LI.sigma.mean",
                              fg ="blue")
    frame13.label2 <- tklabel(frame13, text="LI.sigma.sd  ",
                              fg ="blue")
    frame13.label3 <- tklabel(frame13, text="nsample (Gibbs algorithm)",
                              fg ="blue")
    frame13.entry1 <- tkentry(frame13, textvariable = varLI.mean,
                                width = 8, bg=colorbox, state ="normal")
    tkbind(frame13.entry1, "<Tab>",  function() {
      LI.mean.local <- as.numeric(as.character(tclvalue(varLI.mean)))
    
      assign("LI.sigma.mean",LI.mean.local, env=eGUI)
      assign("LI.sigma.mean", LI.mean.local, env=get("ewho", env=eGUI))
  })
    
    frame13.entry2 <- tkentry(frame13, textvariable = varLI.sd,
                              width = 8, bg=colorbox)
    tkbind(frame13.entry2, "<Tab>",  function() {
      LI.sd.local <- as.numeric(as.character(tclvalue(varLI.sd)))
      assign("LI.sigma.sd",LI.sd.local, env=eGUI)
      assign("LI.sigma.sd", LI.sd.local, env=get("ewho", env=eGUI))
  })
    if(toupper(model) != "BAYES")
      frame13.entry3 <- tkentry(frame13, textvariable = varsample,
                                width = 12, state="disabled")
    else
      frame13.entry3 <- tkentry(frame13, textvariable = varsample,
                                width = 12, bg=colorbox)
    
    tkbind(frame13.entry1, "<Tab>",  function() {
      nsample.local <- as.numeric(as.character(tclvalue(varsample)))
    
      assign("nsample",nsample.local, env=eGUI)
      assign("nsample", nsample.local, env=get("ewho", env=eGUI))
  })
    
    tkgrid(frame13.label1, frame13.entry1, sticky="w")
    tkgrid(frame13.label2, frame13.entry2, sticky="w")
    tkgrid(frame13.label3, frame13.entry3, sticky="w")
    
 
    tkgrid(frame12, frame13, padx=10, pady=10)
    
    tkpack(frame1, fill="x")
   
###****    
  
   bayes.init <- function(...) {
     varLI.mean <- get("varLI.mean", env=eGUI)
     LI.mean.local <- as.numeric(as.character(tclvalue(varLI.mean)))
     assign("LI.sigma.mean",LI.mean.local, env=eGUI)
     assign("LI.sigma.mean", LI.mean.local, env=get("ewho", env=eGUI))
    
     varLI.sd <- get("varLI.sd", env=eGUI)
     LI.sd.local <- as.numeric(as.character(tclvalue(varLI.sd)))

     assign("LI.sigma.sd",LI.sd.local, env=eGUI)
     assign("LI.sigma.sd", LI.sd.local, env=get("ewho", env=eGUI))
     
     nsample <- get("nsample", env=eGUI)
     nsample.local <- as.numeric(as.character(tclvalue(varsample)))
     assign("nsample",nsample.local, env=eGUI)
     assign("nsample", nsample.local, env=get("ewho", env=eGUI))
               
     Ha.mat <- try(get("mat", env=e1), silen=T)
  
     if(class(Ha.mat) != "try-error"){
###       cat("Inside Ha.mat....")
###        print(Ha.mat)
      
       Ha.dat <- convert.data.frame(Ha.mat, rowHa);
     
     }else
       Ha.dat <- convert.data.frame(t(Ha.mat0), rowHa)
     
###     print(Ha.dat)
  
     
     ## extract parameters from data.frame
     Ha.sigma <- na.omit(Ha.dat["Ha.sigma"])
     if(length(Ha.sigma) <= 0)
       Ha.sigma <-  NA
     Ha.sigma <- do.vector(Ha.sigma, elem)
     
     assign("Ha.sigma",Ha.sigma, env=eGUI)
     assign("Ha.sigma", Ha.sigma, env=get("ewho", env=eGUI))
     
     Ha.sigma.sd <- na.omit(Ha.dat["Ha.sigma.sd"])
    
     Ha.sigma.sd <- do.vector(Ha.sigma.sd, elem)
    
     assign("Ha.sigma.sd",Ha.sigma.sd, env=eGUI)
     assign("Ha.sigma.sd", Ha.sigma.sd, env=get("ewho", env=eGUI))   
  
     Ha.deriv    <- na.omit(Ha.dat["Ha.deriv"])
    
     Ha.deriv <- do.vector(Ha.deriv, elem)
     assign("Ha.deriv",Ha.deriv, env=eGUI)
     assign("Ha.deriv", Ha.deriv, env=get("ewho", env=eGUI))
     
     Ha.age.weight <- na.omit(Ha.dat["Ha.age.weight"])
    
     Ha.age.weight <- do.vector(Ha.age.weight, elem)
     assign("Ha.age.weight",Ha.age.weight, env=eGUI)
     assign("Ha.age.weight", Ha.age.weight, env=get("ewho", env=eGUI))
     
     Ha.time.weight <- na.omit(Ha.dat["Ha.time.weight"])
    
     Ha.time.weight <- do.vector(Ha.time.weight, elem)
     assign("Ha.time.weight",Ha.time.weight, env=eGUI)
     assign("Ha.time.weight", Ha.time.weight, env=get("ewho", env=eGUI))
     
##     print(Ha.sigma); print(Ha.sigma.sd);
##     print(Ha.deriv); print(Ha.age.weight); print(Ha.time.weight)    
            
     
     Hat.mat <- try(get("mat", env=e2), silent = T)
     if(class(Hat.mat) != "try-error"){
###       cat("Inside Hat.mat ....")
###      print(Hat.mat); print(rowHat)
       Hat.dat <-  convert.data.frame(Hat.mat, rowHat);
    
     }else
     Hat.dat <- convert.data.frame(t(Hat.mat0), rowHat)
     
###     print(Hat.dat)
     Hat.sigma    <- na.omit(Hat.dat["Hat.sigma"])
     if(length(Hat.sigma) <= 0)
         Hat.sigma <- NA
    
     Hat.sigma <- do.vector(Hat.sigma, elem)
     assign("Hat.sigma",Hat.sigma, env=eGUI)
     assign("Hat.sigma", Hat.sigma, env=get("ewho", env=eGUI))
     
     Hat.sigma.sd <- na.omit(Hat.dat["Hat.sigma.sd"])
     Hat.sigma.sd <- do.vector(Hat.sigma.sd, elem)
     assign("Hat.sigma.sd",Hat.sigma.sd, env=eGUI)
     assign("Hat.sigma.sd", Hat.sigma.sd, env=get("ewho", env=eGUI))
     
     Hat.a.deriv    <- na.omit(Hat.dat["Hat.a.deriv"])
     Hat.a.deriv <- do.vector(Hat.a.deriv, elem)
     assign("Hat.a.deriv",Hat.a.deriv, env=eGUI)
     assign("Hat.a.deriv", Hat.a.deriv, env=get("ewho", env=eGUI))
     
     Hat.t.deriv <- na.omit(Hat.dat["Hat.t.deriv"])
     Hat.t.deriv <- do.vector(Hat.t.deriv, elem)
     assign("Hat.t.deriv",Hat.t.deriv, env=eGUI)
     assign("Hat.t.deriv", Hat.t.deriv, env=get("ewho", env=eGUI))
     
     Hat.age.weight <- na.omit(Hat.dat["Hat.age.weight"])
     Hat.age.weight <- do.vector(Hat.age.weight, elem)
     assign("Hat.age.weight",Hat.age.weight, env=eGUI)
     assign("Hat.age.weight", Hat.age.weight, env=get("ewho", env=eGUI))
     
     Hat.time.weight <- na.omit(Hat.dat["Hat.time.weight"])
     Hat.time.weight <- do.vector(Hat.time.weight, elem)
     assign("Hat.time.weight",Hat.time.weight, env=eGUI)
     assign("Hat.time.weight", Hat.time.weight, env=get("ewho", env=eGUI))
     
##     print(Hat.sigma); print(Hat.sigma.sd);
##     print(Hat.a.deriv); print(Hat.t.deriv); print(Hat.age.weight);
##     print(Hat.time.weight)
     
     Ht.mat <- try(get("mat", env=e3), silent =T)
     if(class(Ht.mat) != "try-error"){
 ###       cat("Inside Ht.mat ....")
       Ht.dat <-  convert.data.frame(Ht.mat, rowHt);
     
       }else
     Ht.dat <- convert.data.frame(t(Ht.mat0), rowHt)
##     print(Ht.dat)  
       
     Ht.sigma    <- na.omit(Ht.dat["Ht.sigma"])
     if(length(Ht.sigma) <= 0)
       Ht.sigma <-  NA
     Ht.sigma <- do.vector(Ht.sigma, elem)
     assign("Ht.sigma",Ht.sigma, env=eGUI)
     assign("Ht.sigma", Ht.sigma, env=get("ewho", env=eGUI))
     
     Ht.sigma.sd <- na.omit(Ht.dat["Ht.sigma.sd"])
     Ht.sigma.sd <- do.vector(Ht.sigma.sd, elem)
     assign("Ht.sigma.sd",Ht.sigma.sd, env=eGUI)
     assign("Ht.sigma.sd", Ht.sigma.sd, env=get("ewho", env=eGUI))
     
     Ht.deriv    <- na.omit(Ht.dat["Ht.deriv"])
     Ht.deriv <- do.vector(Ht.deriv, elem)
     assign("Ht.deriv",Ht.deriv, env=eGUI)
     assign("Ht.deriv", Ht.deriv, env=get("ewho", env=eGUI))
     
     Ht.age.weight <- na.omit(Ht.dat["Ht.age.weight"])
     Ht.age.weight <- do.vector(Ht.age.weight, elem)
     assign("Ht.age.weight",Ht.age.weight, env=eGUI)
     assign("Ht.age.weight", Ht.age.weight, env=get("ewho", env=eGUI))
     
     Ht.time.weight <- na.omit(Ht.dat["Ht.time.weight"])
     Ht.time.weight <- do.vector(Ht.time.weight, elem)
     assign("Ht.time.weight",Ht.time.weight, env=eGUI)
     assign("Ht.time.weight", Ht.time.weight, env=get("ewho", env=eGUI))
     
##     print(Ht.sigma); print(Ht.sigma.sd);
##     print(Ht.deriv); print(Ht.age.weight); print(Ht.time.weight)    
                 
    
     Hct.mat <- try(get("mat", env=e4), silent =T)
     if(class(Hct.mat) != "try-error"){
###       cat("Inside Hct.mat ....")
       Hct.dat <-  convert.data.frame(Hct.mat, rowHct);
   
     }else
     Hct.dat <- convert.data.frame(t(Hct.mat0), rowHct)
###     print(Hct.dat)
     
     Hct.sigma    <- na.omit(Hct.dat["Hct.sigma"])
     if(length(Hct.sigma) <= 0)
       Hct.sigma <-  NA
     
     Hct.sigma <- do.vector(Hct.sigma, elem)
     assign("Hct.sigma",Hct.sigma, env=eGUI)
     assign("Hct.sigma", Hct.sigma, env=get("ewho", env=eGUI))
     
     Hct.sigma.sd <- na.omit(Hct.dat["Hct.sigma.sd"])
     Hct.sigma.sd <- do.vector(Hct.sigma.sd, elem)
     assign("Hct.sigma.sd",Hct.sigma.sd, env=eGUI)
     assign("Hct.sigma.sd", Hct.sigma.sd, env=get("ewho", env=eGUI))
     
     Hct.t.deriv    <- na.omit(Hct.dat["Hct.t.deriv"])
     Hct.t.deriv <- do.vector(Hct.t.deriv, elem)
     assign("Hct.t.deriv",Hct.t.deriv, env=eGUI)
     assign("Hct.t.deriv", Hct.t.deriv, env=get("ewho", env=eGUI))
     
     Hct.time.weight <- na.omit(Hct.dat["Hct.time.weight"])
     Hct.time.weight <- do.vector(Hct.time.weight, elem)
     assign("Hct.time.weight",Hct.time.weight, env=eGUI)
     assign("Hct.time.weight", Hct.time.weight, env=get("ewho", env=eGUI))
     
###     print(Hct.sigma); print(Hct.sigma.sd);
###     print(Hct.t.deriv); print(Hct.time.weight)    
              
   }
     
##***
    bayes.close <- function(...) {
       bayes.init(); 
       tkdestroy(base)        
    }
    
 ##initial values to display
    Ha.mat <- build.display(Ha.sigma, H.deriv1 = Ha.deriv, H.deriv2 = "",
                            Ha.age.weight, Ha.time.weight, Ha.sigma.sd)
   
##    cat("Ha.mat ...")
##    print(Ha.mat)
    e1 <- new.env(hash=T, parent=parent.frame())   
    lst.Ha <- matrix.edit.tab.byrow(frame2, nrows=5, ncols=elem,
                                 rownames=rowHa, ptr=e1,defvar=Ha.mat, 
                                 title= paste("Age Groups", "\n"),
                                  grayout = T, whiterows=3 )
    frame2  <- lst.Ha$frame
    Ha.mat  <- lst.Ha$mat
    Ha.mat0 <- Ha.mat
##    print(Ha.mat)
## initial values to display
    Hat.mat <- build.display(Hat.sigma, H.deriv1 =Hat.a.deriv,
                             H.deriv2= Hat.t.deriv, Hat.age.weight,
                             Hat.time.weight, Hat.sigma.sd, width=elem)
##     cat("Hat.mat ...")
##     print(Hat.mat)
    
    e2 <- new.env(hash=T, parent=parent.frame())

    lst.Hat <- matrix.edit.tab.byrow(frame21, nrows=6, ncols=elem,
                                  rownames=rowHat, ptr=e2, defvar=Hat.mat, 
                                  title=paste("Age & Time Groups", "\n"),
                                  grayout = T, whiterows=3:4)
    frame21 <- lst.Hat$frame
    Hat.mat <- lst.Hat$mat
    Hat.mat0 <- Hat.mat
##    print(Hat.mat)
    
    Ht.mat <- build.display(Ht.sigma, H.deriv1 =Ht.deriv,
                            H.deriv2= "", Ht.age.weight,
                            Ht.time.weight, Ht.sigma.sd, width=5)
##      cat("Ht.mat ...")
##     print(Ht.mat)
  
    
    e3 <- new.env(hash=T, parent=parent.frame())
   
    lst.Ht <- matrix.edit.tab.byrow(frame22, nrows=5, ncols=elem, 
                                 rownames=rowHt, ptr=e3,defvar = Ht.mat,   
                                 title=paste("Time Trends", "\n"),
                                 grayout = T, whiterows = 3)
    frame22 <- lst.Ht$frame
    Ht.mat <- lst.Ht$mat
    Ht.mat0 <- Ht.mat
##    print(Ht.mat)
    Hct.mat <- build.display(Hct.sigma, H.deriv1 =Hct.t.deriv,
                            H.deriv2= "", H.age.weight =" ",
                            Hct.time.weight, Hct.sigma.sd, width=5)
##      cat("Hct.mat ...")
##    print(Hct.mat)
    
    
    e4 <- new.env(hash=T, parent=parent.frame())
 
    lst.Hct <- matrix.edit.tab.byrow(frame23, nrows=4,
                                  ncols=elem, rownames = rowHct,
                                  ptr=e4,defvar =Hct.mat,   
                                  title=paste("Geographic Index", "\n"),
                                  grayout=T, whiterows=3 )
    frame23 <- lst.Hct$frame
    Hct.mat <- lst.Hct$mat
    Hct.mat0 <- Hct.mat
##    print(Hct.mat)
    
    tkgrid(frame2, frame21)
    tkpack(framemat1)
    tkgrid(frame22, frame23)
    tkpack(framemat2)
   
    frame3.spacer <- tklabel(frame3, text = "   ")
    tkgrid(tklabel(framenote, textvariable= tclVar(textexp), fg="black"), sticky="ew")
    tkpack(framenote, fill="x")
    frame3.but2 <- tkbutton(frame3,  textvariable =tclVar("Close"),
                            fg="red", padx = 20, command = bayes.close)
    
    frame3.but3 <- tkbutton(frame3, text = "Apply", padx = 20, command = bayes.init)
    tkgrid(frame3.spacer,sticky="nsew")
    tkgrid(frame3.but2, row=0, col=0, sticky = "e")
    tkgrid(frame3.but3, row=0, col=1, sticky = "w")
    tkpack(frame3, fill="x")
    lst <- list(frame=tkbayes)
    return(tkbayes)
}
##
## DESCRIPTION:  Creates the GUI with textboxes for a matrix of nrows and ncols,
##               Each text box is a matrix element. We can give names to
##               the cols with colnames and to the rows with rownamnes.
##               We can tab from one element or entry box to the next byrow
##               That is, when pressing the tab key we move to the next column
##               within the row until we reach the ned and then move to mnext row.
##               We can pass the matrix to display with prameter defvar,
##               and modify any of its elements in the
##               textboxes of the display; if no argument is passed for defvar
##               it defaults to a matrix of empty strings.
##               We can have a partial view of the matrix
##               The total number of rows is trows and the total number of columns is tcols
##               You may have a partial part of the matrix.edit.tab.byrow by choosing
##               nrows (=vector) < trows and  ncols(=col1:col2) < tcols and
##               begin.col = col1 first column to show ; if no value is given to trows and
##               tcols then default to nrows and ncols. The names for all the  rows 
##               wether they are displayed or not, is townames. The names for all the
##               cols whether they are displayed or not is tolnames.  
##               Example choosing a range of cols for a larger matrix
##    col2 <- trim.blanks(tclvalue(var2))
##    col1 <- ifelse(length(col1) <= 0, 1, as.numeric(col1))
##    col2 <- ifelse(length(col2) <= 0, 12, as.numeric(col2))
##    ncol <- col1:col2
##    if(length(colnames) > 0)
##      colname = colnames[ncol] ## subset for cols names 
##    else
##      colname= NULL
## 
##    defvar <- matrix.edit.tab.byrow(base=tktoplevel(),nrows, ncols=ncol, colnames=colname,
##                        defvar =defvar,  begin.col = col1, tcols=ncols,
##                        trows=nrows,  
##                        tolnames=colnames, title = title);
##   A version of this GUI tabbing by column, i.e. moving from row to row until
##   reach last row and then going to next column, is presented in
##   matrix.edit.tab.bycol
##
## INPUT: columns and rows and their names, matrix defvar to display and modify
##        It may build on a frame or a toplevel.  In the implementation here
##        takes a frame and return a frame and the matrix
##        Make sure to set base to a tkframe
##
##
## VALUE:  returns tkframe, and matrix, and environmnet to extract values
##         the environmnet is a pointer. Thus we may use the same
##         function multiple times passing a different pointer
##         and extract the matrix built for each case
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 05/23/2005
## 
## 
## ************************************************************************
## ************************************************************************


matrix.edit.tab.byrow <- function(base,nrows, ncols, colnames=NULL,
                      rownames=NULL, defvar = NULL,
                      begin.col = NULL, return.string =T,     
                      tcols=NULL, trows=NULL, tolnames=NULL,
                      townames=NULL, title="Smooth",
                      ptr=parent.frame(), grayout = F, whiterows = 0){

 
  ev <- environment()
  
  if(length(trows) <= 0) ## set all cols = ncols
    trows <- nrows
  
  if(length(tcols) <= 0) ## set all rows = nrows
    tcols <- ncols
  
  if(length(tolnames) <= 0)  ## set total names for cols
    tolnames <- colnames
  
  if(length(townames) <= 0)
    townames <- rownames
  
   if(length(begin.col) <= 0)
    begin.col= 1

  frame0 <- tkframe(base, relief = "groove", borderwidth = 0)
  separator <- tklabel(frame0, textvariable="     ");
  title.lable <- tklabel(frame0, textvariable=tclVar(title));
  tkgrid(title.lable,sticky="e");
  
  if(length(ncols)==1)
    ncols <- 1:ncols
  if(length(nrows) == 1)
    nrows <- 1:nrows

  if(length(defvar) <= 1)
    defvar <- matrix("", nrow=trows, ncol=tcols)
 
 
  lst <- list()
  vname <- matrix(,nrow=trows, ncol=tcols)
   
  count <- 0
  
   for(rr in 1:trows)
     for(cc in 1:tcols)
       { 
      count <- count + 1
      vname[rr, cc] <- paste("var[",rr,",",cc,"]", sep="")
    ##  print(vname[rr, cc])
      var <- tclVar(defvar[rr, cc])
  
      if (count <= 1)
        lst <- list(var)
      else
        lst <- c(lst, list(var))
    
    }

  names(lst) <- vname
  if(length(tolnames) <= 0)
    tolnames <-  unlist(sapply(as.list(1:tcols),
                               function(x) paste("var",x, sep="")))
  
  for(c in ncols)
    {
      frame.lbl <- tklabel(frame0,textvariable=tclVar(tolnames[c]),
                           fg="blue")
      tkgrid(frame.lbl,row = 0, col= c);
    }
  
  if(length(rownames) <= 0)
    rownames <- as.character(nrows)

  for(r in nrows)
    {
      frame.lbl <- tklabel(frame0,textvariable=tclVar(rownames[r]),
                           fg="blue")
      tkgrid(frame.lbl,row = r, col= 0, sticky="w");
    }

  
  lst.frame <- as.list(1:(trows*tcols))
  txt.lst   <- as.list(1:(trows*tcols))
  if(length(defvar) > 0){
    defvar <- t(defvar)
    txt.lst <- as.list(as.vector(as.matrix(defvar)))
  }
  ## defvar may be a matrix or data.frame 
  else 
    txt.lst <- lapply(txt.lst, function(x) "")

##  print(txt.lst)
  var.lst <- try(get("var.lst", env=.GlobalEnv), silent=T)
  ##print(txt.lst)
  if(class(var.lst) == "try-error")
    {
      var.lst <- list() 
      
      for(i in (1:length(txt.lst)))
        var.lst[[i]] <- tclVar(txt.lst[[i]])
    }

##    var.lst <<- var.lst
 

  count <- (begin.col -1) * trows 

  for(r in nrows){ ##tabbing by row (move from col to next col)
  
    for(c in ncols){
    
      count=count + 1;
      
      interact <-  "disabled"
      colorbg <- "lightgray"
      
      frametmp <- tkframe(frame0,  relief = "groove", borderwidth = 0)
      var <- var.lst[[count]]   
      
        
      lst.frame[[count]] <- tkentry(frame0, textvariable =var.lst[[count]],
                             width=5, bg=colorbg, state= interact)
      
   if( (!is.element(r, whiterows)&& c== 1  && grayout == T ) ||
      (is.element(r, whiterows)) ) 
        {

          interact <- "normal"
          colorbg <- "white"
          tkconfigure(lst.frame[[count]], bg=colorbg, state=interact)
          
        }

      separator <- tklabel(frame0, textvariable="");
###   without separator looks better
###   tkgrid(frame.entry, separator,sticky ="w")
          
      tkgrid(lst.frame[[count]], row=r, col=c, sticky ="w")
      
     }
  }
   
  
  frame1 <- tkframe(base)
  
  varbut <- tclVar("Apply")
  available <- T
  turn.on.off <- function(...) {
     ptr <- get("ptr", env=ev)
 ##    cat("first ev...") ; print(ev); cat("follow by ptr...") ; print(ptr)       
    if(available)
      {
        for(i in (1:(trows * tcols))) 
          defvar[i] <- tclvalue(var.lst[[i]])
        
        defvar <- matrix(defvar, nrow=tcols, byrow = F) ##we need to transpose
        assign("defvar", defvar, env=ev)
        assign("defvar", defvar, env=ptr)
        defvar <- defvar
        mat <- defvar
        assign("mat", mat, env=ptr)
   
        if(tclvalue(var.lst[[1]]) == "NA" ||
           tclvalue(var.lst[[1]]) == "<NA>"||
           is.na(tclvalue(var.lst[[1]])) ||
           trim.blanks(tclvalue(var.lst[[1]])) == "" )
          {           
            assign("available", F, env=ev)            
            tkconfigure(frame1.but, textvariable=tclVar("OFF"))
              
            count <- (begin.col -1) * trows 
            for(c in ncols){
              for(r in nrows){
                count=count + 1;
                tkconfigure(lst.frame[[count]], bg="grey", state="disabled")}}
          }
      }else{ 
     
        for(i in (1:(trows * tcols))) 
          defvar[i] <- tclvalue(var.lst[[i]])
        
        defvar <- matrix(defvar, nrow=tcols, byrow = F) ##transposing
        assign("defvar", defvar, env=ev)
        assign("defvar", defvar, env=ptr)
        defvar <- defvar
        mat <- defvar
        assign("mat", mat, env=ptr)
        tkconfigure(frame1.but, textvariable=tclVar("Apply"))
        available <- T
        assign("available", T, env=ev)
        count <- (begin.col -1) * trows
           for(r in nrows){
             for(c in ncols){
               
               count=count + 1;
               tkconfigure(lst.frame[[count]], bg="white", state="normal")}}
      }
  }
                             
  frame1.but <- tkbutton(frame1,  textvariable =varbut, fg="red",
                         padx = 10, command = turn.on.off )                              
  if(return.string == F)
    {
      defvar[trim.blanks(defvar) == ""] <- NA
      defvar <- as.numeric(defvar)
    }
  
  tkgrid(frame1.but)
  tkpack(frame0)
  tkpack(frame1)
  defvar <- t(defvar)
    
  lst <- list(frame=base, mat = defvar, where=ptr)
 
  return(lst)
}

##
## DESCRIPTION:  Creates the GUI with two entry textboxes and two buttons
##               Given a number of rows and columns for a matrix and
##               its elements in defvar, you may choose a range of cols
##               to display by choosing two number in the entry boxes.
##               It then calls matrix matrix.edit.tab.byrow
##               or matrix.edit.tab.bycol with ncols=col1:col2
##               which are the choices of cols from the entry boxes.
##      
##
## INPUT: columns and rows and their names, matrix defvar to display and modify
##      
##
##
## VALUE:  returns tkframe, and matrix after calling matrix.edit.tab.byrow
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 05/23/2005
## 
## 
## ************************************************************************
## ************************************************************************

modaldiag <- function(ncols, nrows, colnames, rownames,  
                      defvar, title="Counterfactuals")
{
 
  base   <- tktoplevel()
  tkgrab.set(base)
  tkfocus(base) 
  tkwm.title(base,"Choose variables")
  ev <- environment()
 
  
  frame0 <-  tkframe(base, relief = "groove", borderwidth = 0)
  frame1 <- tkframe(base, relief = "groove", borderwidth = 0)
  frame2 <-  tkframe(base, relief = "groove", borderwidth = 0)
  separator <- tklabel(frame1, textvariable="     ");
  var1 <- tclVar(" ")
  var2 <- tclVar(" ")
  lbl  <- tklabel(frame0, text="Enter range of variables indices");
  frm1.lbl1 <- tklabel(frame1, text="Lower");
  frm1.lbl2 <- tklabel(frame1, text="Upper");
  frm1.entry1 <- tkentry(frame1, textvariable = var1,
                         width = 10, bg="white")
  frm1.entry2 <- tkentry(frame1, textvariable = var2,
                         width = 10, bg="white")
  tkgrid(lbl, sticky="w")
  tkgrid(frm1.lbl1, frm1.entry1, sticky="w")
  tkgrid(frm1.lbl2, frm1.entry2, sticky="w")


  ON.OK <- function(){
    col1 <- trim.blanks(tclvalue(var1))
    col2 <- trim.blanks(tclvalue(var2))
    col1 <- ifelse(length(col1) <= 0, 1, as.numeric(col1))
    col2 <- ifelse(length(col2) <= 0, 12, as.numeric(col2))
    ncol <- col1:col2
    if(length(colnames) > 0)
      colname = colnames[ncol]
    else
      colname= NULL
    ncols <- get("ncols", env=ev)
    base <- tkframe
    lst <- matrix.edit.tab.byrow(base=tktoplevel(),nrows, ncols=ncol, colnames=colname,
                        defvar =defvar,  begin.col = col1, tcols=ncols,
                        trows=nrows,  
                        tolnames=colnames, title = title);
    defvar <- lst$mat
    assign("lst", lst, env=ev)
    assign("defvar", defvar, env=ev)
    tkdestroy(base)
    
    
  }
  frame2.but1 <- tkbutton(framze2,  textvariable =tclVar("OK"), fg="blue",
                          padx = 10, command = ON.OK)
  frame2.but2 <- tkbutton(frame2,  textvariable =tclVar("Cancel"), fg="red",
                          padx = 10, command = function() tkdestroy(base))
  tkgrid(frame2.but1, frame2.but2)
  tkpack(frame0)
  tkpack(frame1)
  tkpack(frame2)
  tkwait.window(base)
  return(lst); 
}
## Utility function of no much use (useless)
expand.char <- function(vector)
      {
        len   <- sapply(vector, nchar)
        lmax  <- max(unlist(len))
        vector <- sapply(vector, function(str){
          nch <- nchar(str)
          pad <- lmax - nch
          if(pad > 0){
            pads <- str
            for(n in 1:pad)
              pads <- paste(" ", pads, sep="")
            }  
          return(str)
        })
        vector <- unlist(vector)
        return(vector)
      }

##DESCRIPTION Given a matrix bayes.mat and some characters
##            array for names, converst the matrix into
##            data.frame and named its columns or elements
##            of data.frame with row.nm. Thus,
##            length(row.nm) <= number of elements(or cols)
##            of the data frame, bayes.dat
##
##INPUT matrix and string with names
##
##OUTPUT the data frame properly named
##
##AUTHOR: Elena Villalon
##        Institute for Social Sciences
##        Harvard University
##
##DATE    June 2005
######################################################

 convert.data.frame <- function(bayes.mat, row.nm)
       {
       
         if(class(bayes.mat) != "try-error")
           bayes.mat[trim.blanks(bayes.mat) == ""] <- NA
         else
           return(0); 
    ##debugging stuff:     
    ##     print(dim(bayes.mat)); print(bayes.mat)
    ##       print(row.nm)
      ##  colnames(bayes.mat) <- row.nm
     
  ##         print(mat)
           bayes.dat <- data.frame(bayes.mat)
           names(bayes.dat) <- row.nm
         
  ###         print(bayes.dat)
           return(bayes.dat)

       }

##DESCRIPTION Given a bunch of vectors or scalars
##            of different sizes, but with a maximum
##            number of elements eqaul to width, ie.
##            any of the arguments length <= width.
##            Build a matrix of number of rows equal
##            number of argumnets, i. e. 6 rows corresponding
##            to arguments H.sigma, H.sigma.sd, H.deriv1,
##            H.deriv2, H.age.weight, H.time.weight
##            The number of columns is equal width but fills
##            with "" empty strings for those elemnts which
##            size or length of vector is less than width. 
##            
##
##INPUT matrix elements or argumenst and number of columns = width\
##
##OUTPUT Matrix of number of rows equal to arguments input and number
##       of columns equal width. Scalar elements such as H.sigma,
##       Ha.age.weight, H.time.weight and H.sigma.sd have only
##       one value and the rest of columns to
##       complete width are filled with empty strings for display.
##       Return the matrix of strings with number and "". 
##
##AUTHOR: Elena Villalon
##        Institute for Social Sciences
##        Harvard University
##
##DATE    June 2005
######################################################

 build.display <- function(H.sigma="", H.deriv1="", H.deriv2="",
                           H.age.weight="",H.time.weight="",
                           H.sigma.sd = "", width=5){

      H.lst <- list()
      len <- length(H.sigma)
      blank <- rep(" ", width - len)
      
##      cat("H.sigma   ", all(trim.blanks(na.omit(H.sigma))), "\n")
      if(!all(trim.blanks(na.omit(H.sigma))=="") ){
        ##  print(H.sigma)
        H.sigma.vec <- c(H.sigma, blank)
        H.lst <- c(H.lst, H.sigma = list(H.sigma.vec))}
      
      len <- length(H.sigma.sd)
      blank <- rep(" ", width - len)
##    cat("H.sigma.sd   ", all(trim.blanks(na.omit(H.sigma.sd))), "\n")
       if(!all(trim.blanks(na.omit(H.sigma.sd))=="")){
        ## print(H.sigma.sd)
         H.sigma.sd.vec <-c(H.sigma.sd, blank)
         H.lst <- c(H.lst, H.sigma.sd = list(H.sigma.sd.vec))}
      
      len <- length(H.deriv1)
      blank <- rep(" ", width - len)
##     cat("H.deriv1   ", all(trim.blanks(na.omit(H.deriv1))), "\n")
      if(!all(trim.blanks(na.omit(H.deriv1))=="")){
       ##   print(H.deriv1)
          H.deriv1.vec <- c(H.deriv1, blank)
          H.lst <- c(H.lst, H.deriv1 = list(H.deriv1.vec))}
      
      len <- length(H.deriv2)
      blank <- rep(" ", width - len)
##     cat("H.deriv2   ", all(trim.blanks(na.omit(H.deriv2))), "\n")
      if(!all(trim.blanks(na.omit(H.deriv2))=="")){
       ##   print(H.deriv2)
          H.deriv2.vec <- c(H.deriv2, blank)
          H.lst <- c(H.lst, H.deriv2 = list(H.deriv2.vec))}
      
      len <- length(H.age.weight)
      blank <- rep(" ", width - len)
      
##    cat("H.age.weight   ", all(trim.blanks(na.omit(H.age.weight))), "\n")
      if(!all(trim.blanks(na.omit(H.age.weight))=="")){
      ##  print(H.age.weight)
        H.age.weight.vec <- c(H.age.weight, blank)
        H.lst <- c(H.lst, H.age.weight = list(H.age.weight.vec))}
      
      len <- length(H.time.weight)
      blank <- rep(" ", width - len)
##   cat("H.time.weight   ",all(trim.blanks(na.omit(H.time.weight))), "\n")
       if(!all(trim.blanks(na.omit(H.time.weight))=="")){
       ##   print(H.time.weight)
          H.time.weight.vec <- c(H.time.weight, blank)
          H.lst <- c(H.lst, H.time.weight = list(H.time.weight.vec))}
      

 ##     print(H.sigma.vec);   print(H.deriv1.vec);   print(H.deriv2.vec)
 ##     print(H.age.weight.vec); print(H.time.weight.vec);
 ##     print(H.sigma.sd.vec)
     
      H.mat <- NULL
      for(el in   H.lst)  {
        
        H.mat <- rbind(H.mat, el)
      }
 ###      print(H.mat);
       rownames(H.mat) <- NULL
      return(H.mat)
    }


##
## DESCRIPTION:  Creates the GUI with textboxes for a matrix of nrows and ncols,
##               Each text box is a matrix element. We can give names to
##               the cols with colnames and to the rows with rownamnes. We can pass
##               a matrix to display with defvar and modify its elements in the
##               textboxes of the display; if no argument is passed for defvar
##               it defaults to a matrix of empty strings.
##               We can have a partial view of the matrix
##               The total number of rows is trows and the total number of columns is tcols
##               You may have a partial part of the matrix display by choosing
##               nrows (=vector) < trows and  ncols(=col1:col2) < tcols and
##               begin.col = col1 first column to show ; if no value is given to trows and
##               tcols then default to nrows and ncols. The names for all the  rows 
##               wether they are displayed or not, is townames. The names for all the
##               cols whether they are displayed or not is tolnames.  
##               Example choosing a range of cols for a larger matrix
###    col2 <- trim.blanks(tclvalue(var2))
##    col1 <- ifelse(length(col1) <= 0, 1, as.numeric(col1))
##    col2 <- ifelse(length(col2) <= 0, 12, as.numeric(col2))
##    ncol <- col1:col2
##    if(length(colnames) > 0)
##      colname = colnames[ncol] ## subset for cols names 
##    else
##      colname= NULL
## 
##    defvar <- matrix.edit.tab.bycol(base=tktoplevel(),nrows,
##                        ncols=ncol, colnames=colname,
##                        defvar =defvar,  begin.col = col1, tcols=ncols,
##                        trows=nrows,  
##                        tolnames=colnames, title = title);
##        Main difference between this function and matrix.edit.tab.byrow
##        is that the tab key moves from one row to the next within same col.
##
## INPUT: columns and rows and their names, matrix defvar to display and modify
##        It may build on a frame or a toplevel.  In the implementation here
##        takes a frame and return a frame and the matrix
##        Make sure to set base to a tkframe
##
##
## VALUE:  returns tkframe, and matrix
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 05/23/2005
## 
## 
## ************************************************************************
## ************************************************************************


matrix.edit.tab.bycol <- function(base,nrows, ncols, colnames=NULL,
                      rownames=NULL, defvar = NULL,
                      begin.col = NULL, return.string =T,     
                      tcols=NULL, trows=NULL, tolnames=NULL,
                      townames=NULL, title="Smooth",
                      ptr=parent.frame(), grayout = F, whiterows = 0){

 
  ev <- environment()
  
  if(length(trows) <= 0) ## set all cols = ncols
    trows <- nrows
  
  if(length(tcols) <= 0) ## set all rows = nrows
    tcols <- ncols
  
  if(length(tolnames) <= 0)  ## set total names for cols
    tolnames <- colnames
  
  if(length(townames) <= 0)
    townames <- rownames
  
   if(length(begin.col) <= 0)
    begin.col= 1

  frame0 <- tkframe(base, relief = "groove", borderwidth = 0)
  separator <- tklabel(frame0, textvariable="     ");
  title.lable <- tklabel(frame0, textvariable=tclVar(title));
  tkgrid(title.lable,sticky="e");
  
  if(length(ncols)==1)
    ncols <- 1:ncols
  if(length(nrows) == 1)
    nrows <- 1:nrows

  if(length(defvar) <= 1)
    defvar <- matrix("", nrow=trows, ncol=tcols)
 
 
  lst <- list()
  vname <- matrix(,nrow=trows, ncol=tcols)
   
  count <- 0
  
   for(rr in 1:trows)
     for(cc in 1:tcols)
       { 
      count <- count + 1
      vname[rr, cc] <- paste("var[",rr,",",cc,"]", sep="")
    ##  print(vname[rr, cc])
      var <- tclVar(defvar[rr, cc])
  
      if (count <= 1)
        lst <- list(var)
      else
        lst <- c(lst, list(var))
    
    }

  names(lst) <- vname
  if(length(tolnames) <= 0)
    tolnames <-  unlist(sapply(as.list(1:tcols),
                               function(x) paste("var",x, sep="")))
  
  for(c in ncols)
    {
      frame.lbl <- tklabel(frame0,textvariable=tclVar(tolnames[c]),
                           fg="blue")
      tkgrid(frame.lbl,row = 0, col= c);
    }
  
  if(length(rownames) <= 0)
    rownames <- as.character(nrows)

  for(r in nrows)
    {
      frame.lbl <- tklabel(frame0,textvariable=tclVar(rownames[r]),
                           fg="blue")
      tkgrid(frame.lbl,row = r, col= 0, sticky="w");
    }

  
  lst.frame <- as.list(1:(trows*tcols))
  txt.lst   <- as.list(1:(trows*tcols))
  if(length(defvar) > 0)
    txt.lst <- as.list(as.vector(as.matrix(defvar)))
  ## defvar may be a matrix or data.frame 
  else 
    txt.lst <- lapply(txt.lst, function(x) "")

##  print(txt.lst)
  var.lst <- try(get("var.lst", env=.GlobalEnv), silent=T)
  
  if(class(var.lst) == "try-error")
    {
      var.lst <- list() 
      
      for(i in (1:length(txt.lst)))
        var.lst[[i]] <- tclVar(txt.lst[[i]])
    }

##    var.lst <<- var.lst
 

  count <- (begin.col -1) * trows 

  
  
  for(c in ncols){
    
    for(r in nrows){
      count=count + 1;
      
      interact <-  "disabled"
      colorbg <- "lightgray"
      
      frametmp <- tkframe(frame0,  relief = "groove", borderwidth = 0)
      var <- var.lst[[count]]   
      
        
      lst.frame[[count]] <- tkentry(frame0, textvariable =var.lst[[count]],
                             width=5, bg=colorbg, state= interact)
      
   if( (!is.element(r, whiterows)&& c== 1  && grayout == T ) ||
      (is.element(r, whiterows)) ) 
        {

          interact <- "normal"
          colorbg <- "white"
          tkconfigure(lst.frame[[count]], bg=colorbg, state=interact)
          
        }

      separator <- tklabel(frame0, textvariable="");
###   without separator looks better
###   tkgrid(frame.entry, separator,sticky ="w")
          
      tkgrid(lst.frame[[count]], row=r, col=c, sticky ="w")
      
###      tkgrid(frametmp, row = r, col=c ,sticky="w")
     }
  }
   
  
  frame1 <- tkframe(base)
  
  varbut <- tclVar("Apply")
  available <- T
  turn.on.off <- function(...) {
     ptr <- get("ptr", env=ev)
 ##    cat("first ev...") ; print(ev); cat("follow by ptr...") ; print(ptr)       
    if(available)
      {
        for(i in (1:(trows * tcols))) 
          defvar[i] <- tclvalue(var.lst[[i]])
        
        defvar <- matrix(defvar, nrow=trows, byrow = F)
        assign("defvar", defvar, env=ev)
        assign("defvar", defvar, env=ptr)
        mat <- defvar
        assign("mat", mat, env=ptr)
   
        if(tclvalue(var.lst[[1]]) == "NA" ||
           tclvalue(var.lst[[1]]) == "<NA>"||
           is.na(tclvalue(var.lst[[1]])) ||
           trim.blanks(tclvalue(var.lst[[1]])) == "" )
          {           
            assign("available", F, env=ev)            
            tkconfigure(frame1.but, textvariable=tclVar("OFF"))
              
            count <- (begin.col -1) * trows 
            for(c in ncols){
              for(r in nrows){
                count=count + 1;
                tkconfigure(lst.frame[[count]], bg="grey", state="disabled")}}
          }
      }else{ 
     
        for(i in (1:(trows * tcols))) 
          defvar[i] <- tclvalue(var.lst[[i]])
        
        defvar <- matrix(defvar, nrow=trows, byrow = F)
        assign("defvar", defvar, env=ev)
        assign("defvar", defvar, env=ptr)
        mat <- defvar
        assign("mat", mat, env=ptr)
        tkconfigure(frame1.but, textvariable=tclVar("Apply"))
        available <- T
        assign("available", T, env=ev)
        count <- (begin.col -1) * trows 
        for(c in ncols){
          for(r in nrows){
            count=count + 1;
            tkconfigure(lst.frame[[count]], bg="white", state="normal")}}
      }
  }
                             
  frame1.but <- tkbutton(frame1,  textvariable =varbut, fg="red",
                         padx = 10, command = turn.on.off )                              
                           

  if(return.string == F)
    {
      defvar[trim.blanks(defvar) == ""] <- NA
      defvar <- as.numeric(defvar)
    }
  
  tkgrid(frame1.but)
  tkpack(frame0)
  tkpack(frame1)
 lst <- list(frame=base, mat = defvar, where=ptr)
 
  return(lst)
}



do.vector <- function(HX, w){
  HX.vector <- vector() 
  for(i in 1:w)
    HX.vector[i] <- as.numeric(as.vector(HX[i,1]))
 HX.vector <- na.omit(HX.vector)
##  print(HX.vector)
  
  return(HX.vector)
}
