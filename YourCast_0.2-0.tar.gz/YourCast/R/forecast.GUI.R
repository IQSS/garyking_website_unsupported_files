
##
## DESCRIPTION:  Reads parameter values in function namelists(), the master file
##               setting all defaults. Creates new stings and arrays with defaults
##               age groups, covariates, death causes and death transformation.
##               It also reads the data.path directory for files
###              ending in txt, csv, xls using the function read.dir(datp=data.path). 
##               All values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: set.defaults()
##
## VALUE:  An environment, which stores the relevamnt parameters and vectors.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


set.defaults <- function()
{
  ewho <- namelists()
  in.list <- list()
  model  <- try(get("model", env=ewho), silent = T)
  if(class(model) == "try-error")
    model = ""
 
  in.list <- c(in.list, list(model=model))
  fore   <- get("fore", env=ewho)
  in.list <- c(in.list, list(fore=fore))
  yrest  <- get("yrest", env=ewho)
  in.list <- c(in.list, list(yrest=yrest))
  lag    <-  get("lag", env=ewho)
  in.list <- c(in.list, list(lag=lag))
  svdtol <- get("svdtol", env=ewho)
  in.list <- c(in.list, list(svdtol=svdtol))
  cntry.digits <- get("cntry.digits", env=ewho)
  in.list <- c(in.list, list(cntry.digits=cntry.digits))
  year.digits  <- get("year.digits", env=ewho)
  in.list <- c(in.list, list(year.digits=year.digits))    
  age.digits   <- get("age.digits", env=ewho)
  in.list <- c(in.list, list(age.digits=age.digits))
  digit.first  <- get("digit.first", env=ewho)
  in.list <- c(in.list, list(digit.first=digit.first))
  depvar <- get("depvar", env=ewho)
  in.list <- c(in.list, list(depvar=depvar))
  allcauses  <-  get("allcauses", env=ewho)
  in.list <- c(in.list, list(allcauses=allcauses))
  population <-  get("population", env=ewho)
  in.list <- c(in.list, list(population=population))    
  transform <- get("transform", env=ewho)
  in.list <- c(in.list, list(transform=transform))
  skip <- get("skip", env=ewho)
  in.list <- c(in.list, list(skip=skip))
  usercntrylist <- get("usercntrylist", env=ewho)
  in.list <- c(in.list, list(usercntrylist=usercntrylist))
  data.path <- get("data.path", env=ewho);
  in.list <- c(in.list, list(data.path=data.path) )
  out.path <- get("out.path", env=ewho);
  in.list <- c(in.list, list(out.path=out.path))
  cov.path <- get("cov.path", env=ewho);
  in.list <- c(in.list, list(cov.path=cov.path))
  prior.path <- get("prior.path", env=ewho)
  in.list <- c(in.list, list(prior.path=prior.path))
  reuse.path <- get("reuse.path", env=ewho)
  in.list <- c(in.list, list(reuse.path=reuse.path))
  
  codes.names <- get("codes.names", env=ewho)
  in.list <- c(in.list, list(codes.names=codes.names))
  strata <- get("strata", env=ewho)
  in.list <- c(in.list, list(strata=strata))
  userages <- get("userages", env=ewho)
  in.list <- c(in.list, list(userages=userages))
  cov.select <- get("cov.select", env=ewho)
  in.list <- c(in.list, list(cov.select=cov.select))    
  age.select <- get("age.select", env=ewho)
  in.list <- c(in.list, list(age.select=age.select))
  elim.collinear <- get("elim.collinear", env=ewho)
  in.list <- c(in.list, list(elim.collinear=elim.collinear))
  standardize <- get("standardize", env=ewho)
  in.list <- c(in.list, list(standardize=standardize))
  lag.cutoff <- get("lag.cutoff", env=ewho)
  in.list <- c(in.list, list(lag.cutoff=lag.cutoff))
  tol <- get("tol", env=ewho)
  in.list <- c(in.list, list(tol=tol))
  delta.tol <- get("delta.tol", env=ewho)
  in.list <- c(in.list, list(delta.tol=delta.tol))
  solve.tol <- get("solve.tol", env=ewho)
  in.list <- c(in.list, list(solve.tol=solve.tol))
  cov <- get("cov", env=ewho)
  in.list <- c(in.list, list(cov=cov))
  cov.type <- get("cov.type", env=ewho)
  in.list <- c(in.list, list(cov.type=cov.type))
  zero.mean <- get("zero.mean", env=ewho)
  in.list <- c(in.list, list(zero.mean=zero.mean))
  Ha.sigma <- get("Ha.sigma", env=ewho)
  in.list <- c(in.list, list(Ha.sigma=Ha.sigma))
  Ht.sigma <- get("Ht.sigma", env=ewho)
  in.list <- c(in.list, list(Ht.sigma=Ht.sigma))    
  Hat.sigma <- get("Hat.sigma", env=ewho)
  in.list <- c(in.list, list(Hat.sigma=Hat.sigma))
  Hct.sigma <- get("Hct.sigma", env=ewho)
  in.list <- c(in.list, list(Hct.sigma=Hct.sigma))
  Ha.sigma.sd <- get("Ha.sigma.sd", env=ewho)
  in.list <- c(in.list, list(Ha.sigma.sd=Ha.sigma.sd))
  Ha.deriv <- get("Ha.deriv", env=ewho)
  in.list <- c(in.list, list(Ha.deriv=Ha.deriv))
  Ha.age.weight   <- get("Ha.age.weight", env=ewho)
  in.list <- c(in.list, list(Ha.age.weight=Ha.age.weight))
  Ha.time.weight  <- get("Ha.time.weight", env=ewho)
  in.list <- c(in.list, list(Ha.time.weight=Ha.time.weight))
  Ht.sigma.sd <- get("Ht.sigma.sd", env=ewho)
  in.list <- c(in.list, list(Ht.sigma.sd=Ht.sigma.sd))
  Ht.deriv <- get("Ht.deriv", env=ewho)
  in.list <- c(in.list, list(Ht.deriv=Ht.deriv))
  Ht.age.weight   <- get("Ht.age.weight", env=ewho)
  in.list <- c(in.list, list(Ht.age.weight=Ht.age.weight))
  Ht.time.weight  <- get("Ht.time.weight", env=ewho)
  in.list <- c(in.list, list(Ht.time.weight=Ht.time.weight))
  Hat.sigma.sd <- get("Hat.sigma.sd", env=ewho)
  in.list <- c(in.list, list(Hat.sigma.sd=Hat.sigma.sd))
  Hat.a.deriv <- get("Hat.a.deriv", env=ewho)
  in.list <- c(in.list, list(Hat.a.deriv=Hat.a.deriv))
  Hat.t.deriv <- get("Hat.t.deriv", env=ewho)
  in.list <- c(in.list, list(Hat.t.deriv= Hat.t.deriv))
  Hat.age.weight   <- get("Hat.age.weight", env=ewho)
  in.list <- c(in.list, list(Hat.age.weight=Hat.age.weight))
  Hat.time.weight  <- get("Hat.time.weight", env=ewho)
  in.list <- c(in.list, list(Hat.time.weight=Hat.time.weight))
  Hct.sigma.sd <- get("Hct.sigma.sd", env=ewho)
  in.list <- c(in.list, list(Hct.sigma.sd=Hct.sigma.sd))
  Hct.c.deriv <- get("Hct.c.deriv", env=ewho)
  in.list <- c(in.list, list(Hct.c.deriv=Hct.c.deriv))
  Hct.t.deriv <- get("Hct.t.deriv", env=ewho)
  in.list <- c(in.list, list(Hct.t.deriv=Hct.t.deriv))
  Hct.time.weight  <- get("Hct.time.weight", env=ewho)
  in.list <- c(in.list, list(Hct.time.weight=Hct.time.weight))
  nsample <- get("nsample", env=ewho)
  in.list <- c(in.list, list(nsample=nsample))
  
  LI.sigma.mean <- get("LI.sigma.mean", env=ewho)
  in.list <- c(in.list, list(LI.sigma.mean=LI.sigma.mean))
  LI.sigma.sd <- get("LI.sigma.sd", env=ewho)
  in.list <- c(in.list, list(LI.sigma.sd=LI.sigma.sd))
  save.FULL <- get("save.FULL", env=ewho)
  in.list <- c(in.list, list(save.FULL=save.FULL))
  save.output <- get("save.output", env=ewho)
  in.list <- c(in.list, list(save.output=save.output))
  reuse.data <-  get("reuse.data", env=ewho)
  in.list <- c(in.list, list(reuse.data=reuse.data))
  save.GUI <-  get("save.GUI", env=ewho)
  in.list <- c(in.list, list(save.GUI=save.GUI))
  age.file <- allcauses
  in.list <- c(in.list, list(age.file=age.file))
  assign("age.file", age.file, env=ewho)
  
  agesString <- c("00", "05", "10", "15", "20", "25",
                  "30", "35","40", "45", "50", "55",
                  "60", "65", "70", "75","80")
  
  if(file.exists(paste(data.path,allcauses, sep=""))){
    
    agesRead <- find.ages(datap=data.path, file=allcauses,
                          aged = age.digits, yeard = year.digits)
    mx <- max(agesRead)
    ln <- floor(log10(mx)) + 1
    agesRead <- sapply(agesRead, formatC, width=ln,flag="0")
    agesRead <- unlist(agesRead)
   
  }else
  agesRead <- agesString

## just testing   
##  agesRead <- c("00", "01", "02","03", "04", "05", "06", "07", "08", "09")
##  agesRead <- c(agesRead, as.character(10:80))
  assign("agesRead", agesRead, env=ewho)
  
  covString <- c("gdp", "fat", "hc", "tfr", "tobacco", "<NA>")
  covtypeString <- c("<NA>", "strata.independent", "age.independent",
                     "age.strata.independent", "depvar.like")
  dthString <- c("allc", "malr","aids","tubr", "otin", 
                 "lung", "molp","livc", "stom", "brst",
                 "cerv", "omal", "rspi", "rspc", "cvds",
                 "dgst", "matc", "pern", "allo", "trns", 
                 "unin", "suic", "homi","ward", "population");
  covdthString <- c(covString, dthString)
  dthcovString <- c(dthString, covString)
  
### read the directory input for covariates and death files
### it does not include all files starting with FULL_
  
  covdthRead <- read.dir(data.path)
  if(length(covdthRead) <= 0 && file.exists(data.path)){
 ###   tkmessageBox(message=paste("No files found in dir ", data.path))
    covdthRead <- NULL
  }
  transString <- c("sqrt(depvar)", "log(depvar)", "log(depvar + 1)", "<NA>")
  modelString <- c("Model & Years", "Index Variable", "Bayesian Parameters")
  
  categoryString <- c("Dependent Variable", "Country Selection",
                      "Strata & Ages",
                      "Covariate Selections",  "Age Exclusion & Cov",
                      "Cov Parameters")
  
  strURL <- "http://gking.harvard.edu/yourcast"
  
  model.available <- c("OLS", "POISSON", "MAP", "BAYES")
  
  return(environment())
}
##
## DESCRIPTION:  Creates the GUI with textboxes for the model, year to forecast, lag of covs, 
##               yrest for the insample period, and the svdtol (a tolerance parameter).
##               Defaults values as described in namelist(). Also, two buttons.
##               Upon pressing the button apply changed parameters are written
##               into memory (fore.init). The button close (fore.close), quits the application.
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: fore(base, textvalues).  Here base is the tktoplevel container to build the GUI
##         and textvalues are character strings with the texts for each of the five entry boxes.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, model, year forecast,
##         year insample, covs lag and svdtol, might have been changed and their
##         new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

fore <- function(base, model=NULL, modelo="Forecasting Model",
                 lyear ="Last Forecast Year (fore)",
                 inyear = "Last Year In-sample (yrest)",
                 tol = "SVD Tolerance (svdtol)"){
      
  ewho <- get("ewho", env=parent.frame())
  eGUI <- environment()
  if(length(model) <= 0)
    {     
      model <- get("model", env=ewho)
      defvar1 <- model
    }else {
      defvar1 <- model
    }
    
    defvar2 <- get("fore", env=ewho)
    defvar3 <- get("yrest", env=ewho)
   
    colorbox <- "white"
    disabox <- "lightgrey"
    disabox <- "lightblue"
    rbValue <- tclVar(defvar1) ## radio button default value
    
 fore.close <- function(...) {
     
   fore.init()
   tkdestroy(base)
 }
 fore.init <- function(...) {
        
        defvar1 <- as.character(tclvalue(rbValue)) 
        var2.local <- as.character(tclvalue(var2))
        var2parse <- var2.local
        var3.local <- as.character(tclvalue(var3))
        var3parse <- var3.local
 
        if(identical(trim.blanks(defvar1), "DATA" ) == T)
          defvar1 <- 3
        assign("model",defvar1, env=ewho)
        assign("fore",as.numeric(var2parse), env=ewho)
        assign("yrest", as.numeric(var3parse), env=ewho)

#        cat("model = ", var1.local, "\n")
#        cat("fore = ", var2.local, "\n")
#        cat("yrest = ", var3.local, "\n")

      
        
    }

    tkforecast <- tkframe(base, relief = "groove", borderwidth = 1)
    frame0 <- tkframe(tkforecast, relief = "groove", borderwidth = 1)
    frame1 <- tkframe(tkforecast, relief = "groove", borderwidth = 0)
    frame2 <- tkframe(tkforecast, relief = "groove", borderwidth = 1)
  
    var2 <- tclVar(defvar2)
    var3 <- tclVar(defvar3)
  
    
    frame0.label1 <- tklabel(frame0, textvariable = tclVar(modelo),fg="blue")
    rb1 <- tkradiobutton(frame0)
    rb2 <- tkradiobutton(frame0)
    rb3 <- tkradiobutton(frame0)
    rb4 <- tkradiobutton(frame0)
    rb5 <- tkradiobutton(frame0)
    rb6 <- tkradiobutton(frame0)
    arr.model <- c("MAP", "BAYES", "OLS", "POISSON", "LC", "DATA")
    rb.lst <- list(rb1=rb1,rb2=rb2,rb3=rb3, rb4=rb4,rb5=rb5,rb6=rb6)
    ##  action listeners; click of the button  
      
        tkbind(rb1,"<Button-1>", function(){
          var1 <- arr.model[1] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
     tkbind(rb2,"<Button-1>", function(){
          var1 <- arr.model[2] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
     tkbind(rb3,"<Button-1>", function(){
          var1 <- arr.model[3] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
     tkbind(rb4,"<Button-1>", function(){
          var1 <- arr.model[4] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
    tkbind(rb5,"<Button-1>", function(){
          var1 <- arr.model[5] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
    
     tkbind(rb6,"<Button-1>", function(){
          var1 <- arr.model[6] ### should be DATA
          rbValue <- tclVar(var1)
          assign("defvar1", 3, env=eGUI) ###give number to indicate only data 
          assign("model", 3, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
      
  tkconfigure(rb1, variable= rbValue, value="MAP")
  tkconfigure(rb2, variable= rbValue, value="BAYES")
  tkconfigure(rb3, variable= rbValue, value="OLS")
  tkconfigure(rb4, variable= rbValue, value="POISSON")
  tkconfigure(rb5, variable= rbValue, value="LC")
  tkconfigure(rb6, variable= rbValue, value="DATA")
  tkgrid(frame0.label1, sticky="w")
  tkgrid(tklabel(frame0, text = "MAP"),rb1,
         tklabel(frame0, text = "Least Squares"), rb3, sticky="w")
  tkgrid(tklabel(frame0, text = "Bayes"), rb2,
         tklabel(frame0, text = "Poisson"),rb4,sticky="w")
  tkgrid(tklabel(frame0, text = "Preprocess"),rb6,
         tklabel(frame0, text = "Lee & Carter"), rb5, sticky="w")
  tkpack(frame0)
     
  frame1.label2 <- tklabel(frame1, textvariable = tclVar(lyear),fg="blue")
  frame1.label3 <- tklabel(frame1, textvariable = tclVar(inyear),fg="blue")
  
  frame1.label5 <- tklabel(frame1, textvariable = tclVar(tol),fg="blue")
    
  
###    tkconfigure(frame1.entry1, state = "disabled") 
  frame1.entry2 <- tkentry(frame1, textvariable = var2, width = 10, bg=colorbox)
  ## action listener for the entry box: Tab
  tkbind(frame1.entry2, "<Tab>",  function() {
    var2.local <- as.character(tclvalue(var2))
    var2parse <- as.numeric(var2.local)
    assign("fore",var2parse, env=eGUI)
    assign("fore", var2parse, env=get("ewho", env=eGUI))
  })
    frame1.entry3 <- tkentry(frame1, textvariable = var3, width = 10, bg=colorbox)
    tkbind(frame1.entry3, "<Tab>",  function() {
      var3.local <- as.character(tclvalue(var3))
      var3parse <- as.numeric(var3.local)
      assign("yrest",var3parse, env=eGUI)
      assign("yrest", var3parse, env=get("ewho", env=eGUI))
    }) 
    
   

    tkgrid(frame1.label2, frame1.entry2, sticky = "w")
    tkgrid(frame1.label3, frame1.entry3, sticky = "w")

    tkpack(frame1, fill = "x")
 
    frame2.but1 <- tkbutton(frame2,  textvariable =tclVar("Close"), fg="red",
                            padx = 20, command =fore.close)
   
    frame2.but2 <- tkbutton(frame2, text = "Apply", padx = 20,command = fore.init)   
    tkgrid(frame2.but1, frame2.but2, sticky = "w")
    tkpack(frame2)
    return(tkforecast)
}
 

##
## DESCRIPTION:  Creates the GUI with textboxes for the country, year, age, discard digits 
##               These are the number of digits for the CSTDID identifiers of the code.
##               Say 2450451989, will have 4 digits (2450) for cntry;
##               2 digits for age groups (45) and another 4 digits for the year (1989), and
##               we do not discard any digits at the beginning of the string identifier.
##               Defaults values as described in namelist(). Upon pressing the button apply
##               (digits.init) changes values are written into memory.
##               The button close (digits.close), quits the application.
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: digits(base, textvalues).  Here base is the tktoplevel container to build the GUI
##         and textvalues are character strings with the texts for the entry boxes for
##         cntrty, year, age and discard digits. 
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container, base.
##         In addition, some of the default values for the entry text boxes,cntry, year, 
##         age, and discard, may have been changed and their
##         new values are written in memory
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************
 digits <- function(base, cdigit="Country Digits", ydigit ="Year Digits",
               adigit = "Age Digits", dsdigit = "Digits to Discard")
             {
    ewho <- get("ewho", env=parent.frame())
    defvar1 <- get("cntry.digits", env=ewho)
    defvar2 <- get("year.digits", env=ewho)
    defvar3 <- get("age.digits", env=ewho)
    defvar4 <- get("digit.first", env=ewho)
    cbg <- "white"
    textodisplay <- paste("Example index: 2450401995   \n",  
                          "First  4  digits 2450 (USA)    \n", 
                          "Next 2  digits 40 (age group) \n",
                          "Last 4  digits  1995 (year)    ")
    
 digits.close <- function(...) {
    var1parse <- as.character(tclvalue(var1))
    var2parse <- as.character(tclvalue(var2))
    var3parse <- as.character(tclvalue(var3))
    var4parse <- as.character(tclvalue(var4))
       
    assign("cntry.digits", as.numeric(var1parse), env=ewho)
    assign("year.digits", as.numeric(var2parse), env=ewho)
    assign("age.digits", as.numeric(var3parse), env=ewho)
    assign("digit.first", as.numeric(var4parse), env=ewho)
            
        tkdestroy(base)
    }
 digits.init <- function(...) {
        var1.local <- as.character(tclvalue(var1))
        var1parse <- var1.local
        var2.local <- as.character(tclvalue(var2))
        var2parse <- var2.local
        var3.local <- as.character(tclvalue(var3))
        var3parse <- var3.local
        var4.local <- as.character(tclvalue(var4))
        var4parse <- var4.local
       
        assign("cntry.digits",as.numeric(var1parse), env=ewho)
        assign("year.digits",as.numeric(var2parse), env=ewho)
        assign("age.digits", as.numeric(var3parse), env=ewho)
        assign("digit.first", as.numeric(var4parse), env=ewho)
            
###        cat("cntry.digits = ", var1.local, "\n")
###        cat("year.digits = ", var2.local, "\n")
###        cat("age.digits = ", var3.local, "\n")
###        cat("digit.first = ", var4.local, "\n")
              
              
    }

    tkdigits <-  tkframe(base, relief = "groove", borderwidth = 2)
 
    frame1 <- tkframe(tkdigits, relief = "groove", borderwidth = 2)
    frame2 <- tkframe(tkdigits, relief = "groove", borderwidth = 2)
  
    var1 <- tclVar(defvar1)
    var2 <- tclVar(defvar2)
    var3 <- tclVar(defvar3)
    var4 <- tclVar(defvar4)
   
    frame1.label2 <- tklabel(frame1, textvariable = tclVar(cdigit), fg="blue")
    frame1.label4 <- tklabel(frame1, textvariable = tclVar(ydigit),fg="blue")
    frame1.label3 <- tklabel(frame1, textvariable = tclVar(adigit),fg="blue")
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(dsdigit),fg="blue")
    frame1.label5 <- tklabel(frame1,
                             textvariable = tclVar(textodisplay ),fg="black")
    
    frame1.entry2 <- tkentry(frame1, textvariable = var1, width = 10,bg=cbg)
    frame1.entry4 <- tkentry(frame1, textvariable = var2, width = 10, bg=cbg)
    frame1.entry3 <- tkentry(frame1, textvariable = var3, width = 10, bg=cbg)
    frame1.entry1 <- tkentry(frame1, textvariable = var4, width = 10, bg=cbg)
   
    tkgrid(frame1.label1, frame1.entry1, sticky = "w")
    tkgrid(frame1.label2, frame1.entry2, sticky = "w")
    tkgrid(frame1.label3, frame1.entry3, sticky = "w")
    tkgrid(frame1.label4, frame1.entry4, sticky = "w")
    tkgrid(frame1.label5, sticky = "e")
    tkpack(frame1, fill = "x")
  
    frame2.but1 <- tkbutton(frame2,  textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = digits.close)
  
    frame2.but2 <- tkbutton(frame2, text = "Apply", padx = 20,command = digits.init)   
    tkgrid(frame2.but1, frame2.but2, sticky = "w")
    tkpack(frame2)
    return(tkdigits)
}

##
## DESCRIPTION:  Creates the GUI with textboxes for the depvariable, allcauses of death,
##               population, tarnsformation of depvar. Also two list boxes with the 
##               selections for the depvar and transformations.  Only one list box may
##               be selected at a time. Two buttons, the close button (depvar.close)
##               to cancel the frame and the  apply botton (depvar.init), which 
##               writes into memory any of the selected or entry items in the text boxes. 
##               Textboxes are for Dependent variable and Transformation,
##               the selections from the lists, which Apply registers them into memory
##               as well as the text boxes entries.  
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##
## FORMAT: depvar(base, textvalues).  Here base is the tktoplevel container to build the GUI
##         and textvalues are character strings with the texts for the entry boxes of the GUI
##         and for the list boxes containing the arrays or vectors stored in setdefaults
##         with dthString and transString of available death causes and trnasformations.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container, base.
##         In addition, some of the default values for the entry text boxes,depvar, all causes, 
##         population, and transformation, may have been changed from
##         their default values stored in namelist()and their new values are written in memory
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

trans.tonumber <-  function(defvar="log(depvar)")
    {
      if(is.na(defvar)|| defvar == "NA")
        var3parse <- NA
      else if(defvar == "log(depvar)")
        var3parse <- 1
      else if(defvar =="sqrt(depvar)" )
        var3parse <- 2
      else if(defvar == "log(depvar + 1)" )
        var3parse <- 3
      else
        stop(message="transformation no available")
   
       return(var3parse)
    }

 depvar <- function(base, morte="Dependent Variable", poblacion ="Population",
                    transtext ="Transformations: ",  
                    combdepvar= "Choose from",
                    poputrans ="Divide by: ")
  {
             
    ewho <- get("ewho", env=parent.frame())
    eGUI <- environment()
    defvar1 <- get("depvar", env=ewho)
    defvar2 <- get("population", env=ewho)
    defvar3 <- get("transform", env=ewho)
    dthString <- get("dthString", env =ewho)
    covdthString <- get("covdthString", env=ewho)
    covdthRead <- get("covdthRead", env=ewho) ### reading the data.path dir
    
    transString <- get("transString", env=ewho)
    cbg <- "white"
    combdepvar <- paste(combdepvar, "\n", "\n", "\n", "\n")
    var1parse <- defvar1
    var2parse <- defvar2
    var3parse <- defvar3
    
    depvar.close <- function(...) {
      depvar.init()
      tkdestroy(base)
    }
    
    depvar.init <- function(...) {
      var1parse <- as.character(tclvalue(var1))
      var2parse <- as.character(tclvalue(var2))
      rVal <- as.character(tclvalue(rbValue))
      var3parse <- trans.tonumber(defvar=rVal)
      rSel <- as.character(tclvalue(rbSelect))
   
      if(length(as.numeric(tkcurselection(frame1.lstbox1))) >0){
        lst1choice <- covdthRead[as.numeric(tkcurselection(frame1.lstbox1))+1]
        
        if(rSel == "depvar"){
        
          defvar1 <- lst1choice
          tclvalue(var1) <- defvar1
          var1parse <- as.character(lst1choice)
          assign("depvar",var1parse, env=ewho)
          assign("depvar",var1parse, env=eGUI)
        }
        if(rSel == "popu"){
        
          defvar2 <- lst1choice
          tclvalue(var2) <- defvar2
          var2parse <- as.character(lst1choice)
          assign("population", var2parse, env=ewho)
          assign("population", var2parse, env=eGUI)
        }
      }
      if(rSel == "depvar"){
        tkconfigure(frame1.entry1, state="disabled",bg=cbg)
        tkconfigure(frame1.entry2, state="disabled", bg="grey")
      }
       if(rSel == "popu"){
        tkconfigure(frame1.entry2, state="disabled",bg=cbg)
        tkconfigure(frame1.entry1, state="disabled",bg="grey")
      } 
       
      assign("transform", as.numeric(var3parse), env=ewho)  
      assign("transform", as.numeric(var3parse), env=eGUI)
###      cat("depvar = ", var1parse, "\n")
###      cat("population = ", var2parse, "\n")
###      cat("transform = ", as.numeric(var3parse), "\n")
             
      }

      
######
        
                        
 
    popu.select <- function()
      {
        depvar.file(popu=T); ##population that divides depvar
      }
    depvar.select <- function()
      {
        depvar.file(popu=F) ##depvar
      }
    
    depvar.file <- function(popu = F)
      {
        
        filename <- tclvalue(tkgetOpenFile())
        if (!nchar(filename))
          {
            tkmessageBox(message="No file selected")
            return(list()); 
          }
        
        tkmessageBox(message=paste("File selected is\n",filename ))
        
        lst <- strsplit(filename,"/")[[1]]
        ix  <- length(lst)
        retreive.dth <- filename
### the exact address of userfile
          
        ff <- strsplit(retreive.dth,"/")[[1]]
        dthfile <- NULL
        if(length(ff) > 0){
          dthfile <- ff[length(ff)]
          ftext <- strsplit(dthfile, "\\.")[[1]][1]
        }
### just the name of the file
        if(length(dthfile) > 0 )
          defvar1 <- ftext
        else 
          defvar1 <- ""
        if(popu == F)
          {
            tclvalue(var1) <- defvar1
            var1.local <- as.character(defvar1)
            var1parse  <- var1.local
          }
        else
          {
            tclvalue(var2) <- defvar1
            var2.local <- as.character(defvar1)
            var2parse  <- var1.local
          }
      }
      
    
   ### main frame 
    tkdepvar <-  tkframe(base, relief = "groove", borderwidth = 2)
    topmenu  <- tkmenu(base)
    tkconfigure(base, menu=topmenu)
    filemenu <- tkmenu(topmenu, tearoff=F)
  ### files menu for depvar and population
    tkadd(filemenu, "command", label= "depvar...", command= depvar.select)
    tkadd(filemenu, "command", label= "denominator...", command= popu.select) 
    tkadd(filemenu, "command", label="Quit",
          command=function() tkdestroy(base))
    
### No more menu selection for depvar and population   
### tkadd(topmenu, "cascade", label="File", menu=filemenu)
### frame1 contains textboxes for depvar, population and radio buttons for transformations
    frame1   <- tkframe(tkdepvar, relief = "groove", borderwidth = 1)
    frame2   <- tkframe(tkdepvar, relief = "groove", borderwidth = 0) ## buttons only
    frame3   <- tkframe(tkdepvar, relief = "groove", borderwidth = 0) ## buttons only
    rbSelect <- tclVar("depvar")

    var1 <- tclVar(defvar1) ## text box for depvar
    var2 <- tclVar(defvar2) ## text box for population
    var3 <- tclVar(defvar3) ## radio button choice

    frame1.label1  <- tklabel(frame1, textvariable = tclVar(morte),fg="blue")
    frame1.label12 <- tklabel(frame1, text = "Numerator  ")
    frame1.label4  <- tklabel(frame1, text = "Denominator") ## denominator or population
    
    frame1.label2  <- tklabel(frame1, text =combdepvar, fg="blue")
    ## entry boxes for depvar, population
    
    frame1.entry1  <- tkentry(frame1, textvariable = var1,
                              width = 15, bg=cbg, state="disabled")
    
    tkbind(frame1.entry1, "<Tab>", function() {
      if(as.character(tclvalue(rbSelect))=="depvar")
        depvar.init()
    })
    tkbind(frame1.entry1, "<Button-1>", function() {
      if(as.character(tclvalue(rbSelect))=="depvar")
        depvar.init()
    })
    
    frame1.entry2  <- tkentry(frame1, textvariable = var2,
                              width = 15, bg="grey", state="disabled")
    tkbind(frame1.entry2, "<Tab>",function() {
      if(as.character(tclvalue(rbSelect))=="popu")
        depvar.init()})
    tkbind(frame1.entry2, "<Button-1>", function() {
      if(as.character(tclvalue(rbSelect))=="popu")
        depvar.init()})
   
    
    rbs1 <- tkradiobutton(frame1)
    rbs2 <- tkradiobutton(frame1)
    
    tkbind(rbs1,"<Button-1>", function(){
      rbSelect <- tclVar("depvar")
      assign("rbSelect", rbSelect, env=eGUI)
      rSel <- tclvalue(rbSelect)
      assign("rSel", rSel, env=eGUI)
      if(rSel == "depvar"){
        tkconfigure(frame1.entry1, state="disabled",bg=cbg)
        tkconfigure(frame1.entry2, state="disabled", bg="grey")
      }      
      
    })
    
    tkbind(rbs2,"<Button-1>", function(){ 
      rbSelect <- tclVar("popu")
      assign("rbSelect", rbSelect, env=eGUI)
      rSel <- tclvalue(rbSelect)
      assign("rSel", rSel, env=eGUI)
       if(rSel == "popu"){
        tkconfigure(frame1.entry2, state="disabled",bg=cbg)
        tkconfigure(frame1.entry1, state="disabled",bg="grey")
      }
     })

           
    tkconfigure(rbs1, variable= rbSelect, value="depvar")
    tkconfigure(rbs2, variable= rbSelect, value="popu")
    tkgrid(frame1.label1, sticky="ew")
    tkgrid(frame1.label12,rbs1, frame1.entry1, sticky ="ew")   
    tkgrid(frame1.label4, rbs2, frame1.entry2, sticky="ew")
    ## list box for depvar selection
    scr <- tkscrollbar(frame1, repeatinterval=5,
                       command=function(...)tkyview(frame1.lstbox1, ...))
    frame1.lstbox1 <- tklistbox(frame1, height=4, selectmode="single",
                               yscrollcommand=function(...)tkset(scr,...),
                               background="white")
        
    for (i in 1:length(covdthRead))
      tkinsert(frame1.lstbox1, "end", covdthRead[i])
    tkselection.set(frame1.lstbox1, -1)
    ## bind event double click
    tkbind(frame1.lstbox1, "<Double-Button-1>", function() {
      if(length(as.numeric(tkcurselection(frame1.lstbox1))) >0){
        lst1choice <- covdthRead[as.numeric(tkcurselection(frame1.lstbox1))+1]
        
        if(as.character(tclvalue(rbSelect))=="depvar"){
          defvar1 <- lst1choice
          tclvalue(var1) <- defvar1
          assign("var1", var1, env=eGUI)
          var1.local <- as.character(lst1choice)
          var1parse  <- var1.local
          assign("var1parse", var1parse, env=eGUI)
        }
        if(as.character(tclvalue(rbSelect))=="popu"){
          defvar2 <-  lst1choice
          tclvalue(var2) <- defvar2
          assign("var2", var2, env=eGUI)
          var2.local <- as.character(lst1choice)
          var2parse  <- var2.local
          assign("var2parse", var2parse, env=eGUI)
        }
            
        lst1choice <- tclVar(lst1choice)
      }
    })      
          
    tkgrid(frame1.label2, frame1.lstbox1, scr,  sticky = "w")
    tkgrid.configure(scr, rowspan=4, sticky="nsw")
    
    frame1.label0 <-  tklabel(frame1, text = "   ") ##spacer for nice fitting
    
    frame2.label1 <- tklabel(frame2, text = transtext, fg="blue") ## Transformations
    frame2.label0 <- tklabel(frame2, text = "   ", fg="blue")##spacer
    
    rbValue <- tclVar("log(depvar)") ## radio button default value
    rb1 <- tkradiobutton(frame2)
    rb2 <- tkradiobutton(frame2)
    rb3 <- tkradiobutton(frame2)
    rb4 <- tkradiobutton(frame2)

    tkbind(rb1, "<Button-1>", function(){
      rbValue <- tclVar("log(depvar)")
      rVal <- as.character(tclvalue(rbValue))
      var3parse <- trans.tonumber(defvar=rVal)
      assign("transform", var3parse, env=ewho)
    })
    
    tkbind(rb2, "<Button-1>", function(){
      rbValue <- tclVar("sqrt(depvar)")
      rVal <- as.character(tclvalue(rbValue))
      var3parse <- trans.tonumber(defvar=rVal)
      assign("transform", var3parse, env=ewho)
    })

    tkbind(rb3, "<Button-1>", function(){
      rbValue <- tclVar("log(depvar + 1)")
      rVal <- as.character(tclvalue(rbValue))
      var3parse <- trans.tonumber(defvar=rVal)
      assign("transform", var3parse, env=ewho)
    })
    
     tkbind(rb4, "<Button-1>", function(){
       rbValue <- tclVar("NA")
       rVal <- as.character(tclvalue(rbValue))
       var3parse <- trans.tonumber(defvar=rVal)
       assign("transform", var3parse, env=ewho)
     })
    
    tkconfigure(rb1, variable= rbValue, value="log(depvar)")
    tkconfigure(rb2, variable= rbValue, value="sqrt(depvar)")
    tkconfigure(rb3, variable= rbValue, value="log(depvar + 1)")
    tkconfigure(rb4, variable= rbValue, value="NA")
    tkgrid(frame2.label1)
    
    tkgrid(tklabel(frame2, text = "log(depvar)"),rb1,sticky="w")
    tkgrid(tklabel(frame2, text = "sqrt(depvar)"), rb2,sticky="w")
    tkgrid(tklabel(frame2, text = "log(depvar + 1)"), rb3,sticky="w")
    tkgrid(tklabel(frame2, text = "NA"),rb4,sticky="w")
    
    tkpack(frame1, fill = "x")
    tkpack(frame2, fill="x")
      
    frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"),
                            fg="red",padx = 20, command = depvar.close)
  
    frame3.but2 <- tkbutton(frame3, text = "Apply", padx = 20,command = depvar.init)   
    tkgrid(frame3.but1, frame3.but2, sticky = "w")
    tkpack(frame3)
    return(tkdepvar)
}


##
## DESCRIPTION:  Creates the GUI with a textbox for the skip parameters or minimum observations,
##               and tw list boxes. The list box labeled Codes & Name has the list of
##               available cntrys and their associated codes as read from the file code.names
##               in the datapath directory. The list box labeled Selected Countries
##               takes the selectin from the former list (Codes & Names) and display the user
##               selections of cntrys for the run. Three buttons at the bottom of the panel.
##               The Apply bottom, cntry.init, pick up the multiple selections from the
##               list box Codes & Names and displayed them in the list box to the right.
##               The Remove bottom, cntry.remove, takes the
##               multiple or single selection of the list with the Selected countries
##               and removed them, in case the user changes his mind and decide not to include
##               some of the countries.  The buttom Close, cntry.close, quits the application. 
##               Defaults values for cntry.list and skip are as described in namelist().
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: cntryLst(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the entry and two list boxes.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, cntry.list and skip
##         may be changed and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************
cntryLst <- function(base,lstcntry="Codes  & Names",
                     selectcntry="Selected Countries",
                     objtxt=  "Minimum Observations",
                     codestxt="File for codes.names" ){
  ewho <- get("ewho", env=parent.frame())
  defvar1 <- get("skip", env=ewho)
  defvar2 <- get("usercntrylist", env=ewho)
  datapath <- get("data.path", env=ewho);
  cntry.digits <- get("cntry.digits", env=ewho)
  data.path <- get("data.path", env=ewho)
  codes.names <- get("codes.names", env=ewho)
 ### filename <- paste(data.path,codes.names,".txt", sep="")
    filename <- paste(data.path,codes.names,sep="")
 
   if (!file.exists(filename)){
            tkmessageBox(message=
                         paste("File codes.names does not exist in", data.path));
            filename <- NULL
###            return(0);
          }
###  cat("in cntryLst   ")
###  print(filename)
  eGUI <- environment()
  var1 <- tclVar(defvar1)
  if(length(filename ) > 0){
    tmp <- scan(file=filename,what=c(integer(0),character(0)),
                quiet=T,multi.line=T, sep="\t",quote="\"")
    tmp <- matrix(tmp,ncol=2,byrow=T)
    cod <- as.integer(tmp[,1])
    codn <- length(cod)
    cntryString <- sapply(1:codn, function(n) {
      paste(as.character(tmp[n,1]),"       ", as.character(tmp[n,2]),sep="")})
  
    cntryString <- unlist(cntryString)
  }else{
    cntryString <- "  "
    codn <- 1
  }
  cntrysubString <- NULL
  if(any(!is.na(defvar2)))
    {
      indx <- match(defvar2,tmp[,1])
      tmpsub <- tmp[indx,]
    
    if(length(indx) > 1)
      {
        cntrysubString <- sapply(1:length(indx), function(n) {
          paste(as.character(tmpsub[n,1]),"       ",
                as.character(tmpsub[n,2]),sep="")})
      }
    else
      cntrysubString <- paste(as.character(tmpsub[1]),"       ",
                              as.character(tmpsub[2]),sep="")
  }
  outputlist <- tclVar()
  if (length(cntrysubString) > 0)
    tclObj(outputlist) <- cntrysubString
  
  cbg = "white"
  
  cntry.close <- function(...) {
    var1parse <- as.character(tclvalue(var1))
    defvar2 <- get("defvar2", env=eGUI)
    assign("usercntrylist", defvar2, env=ewho)
    assign("skip", as.numeric(var1parse),env=ewho)
    tkdestroy(base)
  }
  cntry.init <- function(...) {

    cntrysubString <- get("cntrysubString", env =eGUI)
    defvar2 <- get("defvar2", env=eGUI)
    
    if(length(as.numeric(tkcurselection(frame2.lstbox1))) >0){
      
      lst1choice <- cntryString[as.numeric(tkcurselection(frame2.lstbox1))+1]
      cntrysubString <- c(cntrysubString,lst1choice)
      cntrysubString <- unique.default(cntrysubString)
      assign("cntrysubString", cntrysubString, env=eGUI)  
      if(!all(is.na(defvar2)))
        defvar2 <- c(defvar2,
                     as.numeric(sapply(lst1choice,substr,1, cntry.digits)))
      else
        defvar2 <- as.numeric(sapply(lst1choice,substr,1, cntry.digits))
      
      defvar2 <- unique.default(defvar2)
      assign("defvar2", defvar2,env=eGUI)
      assign("usercntrylist", defvar2, env=ewho)

      tclObj(outputlist) <- cntrysubString
       
      ##  if(!is.na(lst1choice[i]) ||lst1choice[i]!="NA" )
      ##   tkinsert(frame2.lstbox2,"end",lst1choice[i])      
      
    }
  }
  
  var1.local <- as.character(tclvalue(var1))
  var1parse  <- var1.local
  assign("skip", as.numeric(var1parse),env=ewho)
###           cat("skip = ", var1.local, "\n")
###           cat("usercntrylst = ", defvar2,"\n")      
  
  cntry.remove <- function(...) {
###      cat("first print...", cntrysubString,"...\n")
    if(length(as.numeric(tkcurselection(frame2.lstbox2))) >0){
      ind.to.delete <- as.numeric(tkcurselection(frame2.lstbox2)) +1
 
      cntrysubString <- cntrysubString[-ind.to.delete]
      
      assign("cntrysubString", cntrysubString, env=eGUI)
      
      tclObj(outputlist) <- cntrysubString
      if(length(cntrysubString) > 0)
        {
          defvar2 <- as.numeric(sapply(cntrysubString,substr,1, cntry.digits))
          defvar2 <- unique.default(defvar2)
        }else{
          defvar2 <- NA
        }
      
      assign("defvar2", defvar2,env=eGUI)
      assign("usercntrylist", defvar2, env=ewho)
      tkselection.set(frame2.lstbox2, length(cntrysubString) + 1)
###         cat("usercntrylst = ", defvar2,"\n")       
      
##print(tclObj(outputlist))
      
      
    }
  }
 
        
 
  tkcntry <-  tkframe(base, relief = "groove", borderwidth = 2)
  
  frame1  <- tkframe(tkcntry, relief = "groove", borderwidth = 2)
  frame2  <- tkframe(tkcntry, relief = "groove", borderwidth = 2)
  frame3  <- tkframe(tkcntry, relief = "groove", borderwidth = 2)
  var1 <- tclVar(defvar1)
  frame1.label1 <- tklabel(frame1, textvariable = tclVar(objtxt),
                           fg="blue", anchor="w")
  frame1.entry1 <- tkentry(frame1, textvariable = var1, width = 5, bg=cbg)

  tkbind(frame1.entry1, "<Tab>", function(){
    var1parse <- as.character(tclvalue(var1))
    assign("skip", as.numeric(var1parse),env=ewho)
    assign("skip", as.numeric(var1parse),env=eGUI)
  })
  
  tkbind(frame1.entry1, "<Button-1>", function(){
    var1parse <- as.character(tclvalue(var1))
    assign("skip", as.numeric(var1parse),env=ewho)
    assign("skip", as.numeric(var1parse),env=eGUI)
  })
  
  tkgrid(frame1.label1, frame1.entry1, sticky = "w")

  tkpack(frame1, fill = "x",anchor="w")
  
  frame2.label1 <- tklabel(frame2, text = lstcntry)
  frame2.label2 <-  tklabel(frame2, text = selectcntry)
  frame2.label3 <-  tklabel(frame2, text = "   ")
  
  scr1 <- tkscrollbar(frame2, repeatinterval=5,
                      command=function(...)tkyview(frame2.lstbox1, ...))
  frame2.lstbox1 <- tklistbox(frame2, height=4, selectmode="extended",
                              yscrollcommand=function(...)tkset(scr1,...),
                              background="white")
  scr2 <- tkscrollbar(frame2, repeatinterval=5,
                      command=function(...)tkyview(frame2.lstbox2, ...))
  for (i in 1:codn)
    tkinsert(frame2.lstbox1, "end", cntryString[i])
  
 
  tkselection.set(frame2.lstbox1, -1)
  
  
  frame2.lstbox2 <- tklistbox(frame2, height=4, selectmode="extended",
                              yscrollcommand=function(...)tkset(scr2,...),
                              background="white",listvariable=outputlist)
  
 ### if(length(cntrysubString) > 0)
    ###  tkinsert(frame2.lstbox2, "end", cntrysubString)   
  
  tkgrid(frame2.label1,frame2.label3,frame2.label2,sticky="w")
  tkgrid(frame2.lstbox1,scr1,frame2.lstbox2,scr2,sticky="e")
  tkgrid.configure(scr1, rowspan=4, sticky="nsw")
  tkgrid.configure(scr2, rowspan=4, sticky="nsw")
  tkpack(frame2)
  
  
  frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"), fg="red",
                          padx = 20, command = cntry.close)
  
  frame3.but2 <- tkbutton(frame3, text = "Apply   >>", padx = 15, command = cntry.init)
  frame3.but3 <- tkbutton(frame3, text = "<<  Remove", padx = 15, command = cntry.remove)
  frame3.label1 <- tklabel(frame3, text = " ")
  tkgrid(frame3.but2, frame3.but1, frame3.but3, sticky = "w")
  ##  tkgrid(frame3.label1,frame3.but1)
  tkpack(frame3)
  return(tkcntry)
}

##
## DESCRIPTION:  Creates the GUI with a radio buttoms for the strata (or gender), 
##               and two list boxes. The list box labeled Age Groups has the list of
##               age groups as in the vector agesRead of set.defaults.
##               The list box labeled Selected Ages takes the selection from the
##               former list (Ages Groups) and display the user
##               selections of ages  for this  run. Three buttons at the bottom of the panel.
##               The Apply bottom, strata.init, pick up the multiple selections from the
##               list box Ages Groups and displayed them in the list box to the right.
##               The Remove bottom, strata.remove, takes the
##               multiple or single selection of the list with the Selected Ages 
##               and removed them, in case the user changes his mind and decide not to include
##               some of the groups.  The buttom Close, strata.close,  quits the application. 
##               Defaults values for strata, userages are as described in namelist().
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: strata.select(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the radio buttons and two list boxes.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, strata and userages 
##         may be changed and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

 strata.select <- function(base,textStrata="Strata Variable",
                           textStrataVal="Strata Value", 
                           textAge1 ="Age Groups",
                           textAge2= "Selected Ages")
             {
    ewho <- get("ewho", env=parent.frame())
    defvar1 <- get("strata", env=ewho)
    defvar2 <- get("userages", env=ewho)
    defvar  <- get("depvar", env=ewho)
    agesRead <- get("agesRead", env=ewho)
    agesList <- tclVar()
    tclObj(agesList) <- agesRead
    varg <- tclVar("gender")
    var1 <- tclVar(defvar1)
    cbg = "white"
    
    outputlist <- tclVar(defvar2)
    if (all(is.na(defvar2)))
      tclObj(outputlist) <- "<NA>"
    agesubString <- NULL
    
    eGUI <- environment()
    
    strata.close <- function(...) {
       
      defvar1 <- as.numeric(tclvalue(var1))    
      
      defvar2 <- get("defvar2", env=eGUI)
      if (length(defvar2) <= 0)
        defvar2 <- NA
      assign("userages", as.numeric(defvar2), env=ewho)
      assign("strata", as.numeric(defvar1), env=ewho)
      
      tkdestroy(base)
    }
     strata.init <- function(...) {
     agesubString <- get("agesubString", env =eGUI)
     defvar2 <- get("defvar2", env=eGUI)
       
       if(length(as.numeric(tkcurselection(frame2.lstbox1))) >0){
        
       lst1choice <- agesRead[as.numeric(tkcurselection(frame2.lstbox1))+1]
       agesubString <- c(agesubString,lst1choice)
       agesubString <- unique.default(agesubString)
       assign("agesubString", agesubString, env=eGUI)  
         if(!all(is.na(defvar2)))
           defvar2 <- c(defvar2, as.numeric(lst1choice))
         else
           defvar2 <- as.numeric(lst1choice)
         
         defvar2 <- unique.default(defvar2)
         assign("defvar2", defvar2,env=eGUI)
         assign("userages", defvar2, env=ewho)
         
       
           tclObj(outputlist) <- agesubString
                  
      }        
       
###      cat("userages = ", defvar2,"\n")
          
        
    }
      strata.remove <- function(...) {
###      cat("first print...", agesubString,"...\n")
      if(length(as.numeric(tkcurselection(frame2.lstbox2))) >0){
        ind.to.delete <- as.numeric(tkcurselection(frame2.lstbox2)) +1
        if(length(agesubString) > 0)
          {   
            agesubString <- agesubString[-ind.to.delete]
            assign("agesubString", agesubString, env=eGUI)
          }
        else
          {
           agesubString <- tclvalue(outputlist)
           agesubString <- unlist(strsplit(agesubString, " "))
           agesubString <- agesubString[-ind.to.delete]
           if(length(agesubString) <= 0){
             agesuString <- NA
             userages <- NA
           }
          
         }
           
        tclObj(outputlist) <- agesubString
        defvar2 <- as.numeric(agesubString)
        defvar2 <- unique.default(defvar2)
        if(length(defvar2) <= 0)
          defvar2 <- NA
        assign("defvar2", defvar2,env=eGUI)
        assign("userages", defvar2, env=ewho)
        assign("agesubString", agesubString, env=eGUI)
        assign("userages",defvar2, env=eGUI)
       
         tkselection.set(frame2.lstbox2, length(agesubString) + 1)
###         cat("userages = ", defvar2,"\n")       
       
        ##print(tclObj(outputlist))
      
  
      }
    }

    tkstrata <-  tkframe(base, relief = "groove", borderwidth = 2)
  
    frame1  <- tkframe(tkstrata, relief = "groove", borderwidth = 2)
    frame2 <- tkframe(tkstrata, relief = "groove", borderwidth = 2)
    frame3 <- tkframe(tkstrata, relief = "groove", borderwidth = 2)
           
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(textStrata),
                             fg="blue")
    frame1.entry1 <- frame1.entry1 <- tkentry(frame1, textvariable = varg,
                                             width = 15, bg=cbg)
    frame1.label2 <- tklabel(frame1, textvariable = tclVar(textStrataVal),
                             fg="black")
    
    frame1.entry2 <- tkentry(frame1, textvariable = var1,
                                             width = 8, bg=cbg)
    tkbind(frame1.entry2, "<Tab>", function(){
          defvar1 <- tclvalue(var1)
          assign("strata", as.numeric(defvar1), env=ewho)
          assign("defvar1", as.numeric(defvar1), env=eGUI)
        })

    tkbind(frame1.entry2, "<Button-1>", function(){
          defvar1 <- tclvalue(var1)
          assign("strata", as.numeric(defvar1), env=ewho)
          assign("defvar1", as.numeric(defvar1), env=eGUI)
        })
          
    tkgrid(frame1.label1,frame1.entry1, sticky="w")
    tkgrid(frame1.label2,frame1.entry2, sticky="w")
                         

    tkbind(frame1.entry2,"<Tab>", function(){
     assign("strata", as.numeric(tclvalue(var1)), env=ewho)
     assign("defvar1", as.numeric(tclvalue(var1)), env=eGUI)})
    
    
    scr1 <- tkscrollbar(frame2, repeatinterval=5,
                       command=function(...)tkyview(frame2.lstbox1, ...))
    frame2.lstbox1 <- tklistbox(frame2, height=4, selectmode="extended",
                               yscrollcommand=function(...)tkset(scr1,...),
                               background="white", listvariable =agesList)
    scr2 <- tkscrollbar(frame2, repeatinterval=5,
                       command=function(...)tkyview(frame2.lstbox2, ...))
    
    tkselection.set(frame2.lstbox1, -1)
    frame2.lstbox2 <- tklistbox(frame2, height=4, selectmode="extended",
                               yscrollcommand=function(...)tkset(scr2,...),
                               background="white",listvariable=outputlist)
    frame2.label1 <- tklabel(frame2, textvariable = tclVar(textAge1),
                             fg="blue")
    frame2.label2 <- tklabel(frame2, textvariable = tclVar(textAge2),
                             fg="blue")
    frame2.label3 <- tklabel(frame2, textvariable = tclVar("   "))
    tkgrid(frame2.label1,frame2.label3,frame2.label2,sticky="w")
    tkgrid(frame2.lstbox1,scr1,frame2.lstbox2,scr2,sticky="e")
    tkgrid.configure(scr1, rowspan=4, sticky="nsw")
    tkgrid.configure(scr2, rowspan=4, sticky="nsw")
    
    frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = strata.close)
    
    frame3.but2 <- tkbutton(frame3, text = "Apply   >>", padx = 15,command = strata.init)
    frame3.but3 <- tkbutton(frame3, text = "<<  Remove", padx = 15,command = strata.remove)
    frame3.label1 <- tklabel(frame3, text = " ")
    tkgrid(frame3.but2, frame3.but1, frame3.but3, sticky = "w")
   
    combFrame <- comboBox(base=tkstrata)
   
     tkpack(frame1, fill = "x")
### how to use the comboBox, with function comboBox()
### that returns a frame, and pack it somewhere 
###    tkpack(combFrame,fill="x")  
    tkpack(frame2,fill="x")
    tkpack(frame3, fill="x")  
   
   return(tkstrata)
}
##
## DESCRIPTION:  Creates the GUI with tthe text box for the covariate name, or otherwise
##               select the name from a combo box dropdown list (Select from:).
##               The covariate selected or selected will not be considered for all age groups.  
##               The age groups that will be excluded from the study for selected covaraites are
##               chosen with the two list boxes. The list box labeled Age Groups has the list of
##               age groups as in the vector agesRead of set.defaults.
##               The list box labeled Selected Ages takes the selection from the
##               former list (Ages Groups) and display the user
##               selections of ages  for this  run. Three buttons at the bottom of the panel.
##               The Apply bottom, covage.init, pick up the multiple selections from the
##               list box Ages Groups and displayed them in the list box to the right.
##               The Remove bottom, covage.remove, takes the
##               multiple or single selection of the list with the Selected Ages 
##               and removed them, in case the user changes his mind and decide not to include
##               some of the groups.  The buttom Close, covage.close,  quits the application. 
##               Defaults values for strata, userages are as described in namelist().
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: covage(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the entry text, combo box,  
##         buttons and two list boxes.
##
## IMPORTED functions:it uses function comboBox that builds the drop down lsit box,
##            also set.defaults with ageString. 
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, age.select and cov.select,   
##         may be changed and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

 covage <- function(base,textCov="Enter Covariate",
                    textOR ="OR", textna = "<NA>", 
                    textCov1 = "Select:", 
                    textAge1 ="Age Groups", textAge2= "Excluded Ages from Cov")
             {
    ewho <- get("ewho", env=parent.frame())
    defvar1 <- unlist(get("cov.select", env=ewho))
    defvar2 <- unlist(get("age.select", env=ewho))
    agesubString <- defvar2
    if(length(defvar1) > 1)
     agesubString <- rep(defvar2, each=length(defvar1))    
    
    names(agesubString) <- rep(defvar1, length(defvar2))
  
    agesRead <- get("agesRead", env=ewho)
    covdthRead  <- get("covdthRead", env=ewho)
  
     if (length(covdthRead) <= 0)
        covdthRead <- "<NA>"
    
    agesList <- tclVar()
    tclObj(agesList) <- agesRead
    outputlist <- tclVar()
    tclObj(outputlist) <- textna
    
    covlst <- tclVar()
    tclObj(covlst) <- covdthRead
  
    var3 <- tclVar()
    tclObj(var3) <- textna
    
    eGUI <- environment()
    if(length(na.omit(defvar1)) <= 0){ 
      cov.exclude <- NULL
      age.exclude <- NULL
    }else{
      cov.exclude <- names(defvar2)
      age.exclude <- defvar2
     
    }
    
###    cat("go with exclude...", "\n")
###    print(cov.exclude)
###    print(age.exclude)
    
    nages <- length(age.exclude)
    names(age.exclude) <- rep(cov.exclude, nages)
    cbg <- "white"
   
    
    covage.close <- function(...) {
       
       tkdestroy(base)
       age.select <- get("age.select", env=get("ewho",env=eGUI))
       cov.select <- get("cov.select", env=get("ewho",env=eGUI))
       age.select <- sort(na.omit(age.select))
       cov.select <- na.omit(cov.select)
###       print(age.select)
###       print(cov.select)
### programs are written so that all covariets in cov.select
### have same age groups excluded, so we need to find
       age.select <- unique.default(age.select)
       names(age.select) <- NULL
       cov.select <- unique.default(unlist(cov.select))
       assign("age.select", as.numeric(age.select),env=ewho)
       assign("cov.select", cov.select,env=ewho)       
    }
     covage.init <- function(...) {
  
     age.exclude <- get("age.exclude", env=eGUI)
     cov.exclude <- get("cov.exclude", env=eGUI)
## if entering a name for covariate in the entry field,
## then ignore the selection for the ComboBox
     comboValue <-  get("comboEntry", env=ewho)[1]
     if( trim.blanks(tclvalue(var3)) != textna && 
         as.character(trim.blanks(tclvalue(var3))) != comboValue  ){
         defvar1 <- tclvalue(tclObj(var3))
         tclObj(var3) <- textna
     }else{
         tclObj(var3) <- textna
         defvar1 <- get("comboEntry", env=get("ewho", env=eGUI))[1]
       }
     assign("defvar1", defvar1, env=eGUI)
     ind.exclude <- grep(defvar1, names(age.exclude))
     if(length(ind.exclude) > 0){
       age.exclude <- age.exclude[-ind.exclude]
       cov.exclude <- cov.exclude[-grep(defvar1,cov.exclude)]
     }
     if(length(as.numeric(tkcurselection(frame2.lstbox1))) >0){    
       lst1choice <- agesRead[as.numeric(tkcurselection(frame2.lstbox1))+1]
       agesubString <- unique.default(lst1choice)
       names(agesubString) <- rep(defvar1,length(agesubString))
    
       age.exclude  <- c(agesubString,age.exclude)    
       cov.exclude  <- unique.default(c(defvar1, cov.exclude))
        
###         print(age.exclude)
###         print(cov.exclude)
       
       }else{
         lst1choice  <- c(NA)
         names(lst1choice) <- defvar1
         agesubString <- textna
         age.exclude <- c(lst1choice, age.exclude)
         cov.exclude <- c(defvar1, cov.exclude)
       }
    
    assign("age.exclude", age.exclude, env=eGUI)
    assign("cov.exclude", cov.exclude, env=eGUI)
    assign("agesubString", agesubString, env=eGUI)
     
         age.select <- as.numeric(age.exclude)
         names(age.select) <- names(age.exclude)
         cov.select <-  unique.default(names(age.exclude))
         assign("age.select", age.select,env=ewho)
         assign("cov.select", cov.select, env=ewho)
         tclObj(outputlist) <- agesubString
                            
     }        
            
      covage.remove <- function(...) {
        
        age.exclude <- get("age.exclude", env=eGUI)
        cov.exclude <- get("cov.exclude", env=eGUI)
         if( tclvalue(var3) != textna &&
           as.character(tclvalue(var3)) != get("comboEntry", env=ewho)[1] ){
          defvar1 <- tclvalue(tclObj(var3))
          tclObj(var3) <- textna
        }else
          defvar1 <- get("comboEntry", env=get("ewho", env=eGUI))[1]
        
      if(length(as.numeric(tkcurselection(frame2.lstbox2))) >0){
        ind.to.delete <- as.numeric(tkcurselection(frame2.lstbox2)) +1
        agesubString <- agesubString[-ind.to.delete]
        defvar2 <- as.numeric(agesubString)
        names(defvar2) <- names(agesubString)
        assign("agesubString", agesubString, env=eGUI)
        tclObj(outputlist) <- agesubString                      
        ind.exclude <- grep(defvar1, names(age.exclude))
        if(length(ind.exclude) > 0){
          age.exclude <- age.exclude[-ind.exclude]
          cov.exclude <- cov.exclude[-grep(defvar1,cov.exclude)]
          age.exclude <- c(agesubString, age.exclude)
          cov.exclude  <- unique.default(c(defvar1, cov.exclude)) }
         
        }else{
          agesubString <- textna
          defvar2 <- as.numeric(agesubString)
          names(defvar2) <- names(agesubString)
          assign("agesubString", agesubString, env=eGUI)
          tclObj(outputlist) <- agesubString
           ind.exclude <- grep(defvar1, names(age.exclude))
        if(length(ind.exclude) > 0){
          age.exclude <- age.exclude[-ind.exclude]
          cov.exclude <- cov.exclude[-grep(defvar1,cov.exclude)]
          age.exclude <- c(agesubString, age.exclude)
          cov.exclude  <- unique.default(c(defvar1, cov.exclude)) }
        }
          assign("age.exclude", age.exclude, env=eGUI)
          assign("cov.exclude", cov.exclude, env=eGUI)
          age.select <- as.numeric(age.exclude)
          names(age.select) <- names(age.exclude)
          cov.select <-  unique.default(names(age.exclude))
          assign("age.select", age.select,env=ewho)
          assign("cov.select", cov.select, env=ewho)
      
              
         tkselection.set(frame2.lstbox2, length(agesubString) + 1)
###         print(age.select)
###         cat("cov.select = ", cov.select,"\n")
       
###       print(tclObj(outputlist))
    }  
      
    
    tkcovage <-  tkframe(base, relief = "groove", borderwidth = 1)
    frame1   <- tkframe(tkcovage, relief = "groove", borderwidth = 1)
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(textCov),
                             fg="blue")
   
    frame1.entry1 <- tkentry(frame1, textvariable = var3, width = 15, bg=cbg)
##  frame1.entry1 <- tkentry(frame1, width = 15)
    tkgrid(frame1.label1, frame1.entry1, sticky = "w")
    frame1.label2 <-  tklabel(frame1, textvariable = tclVar(textOR),
                             fg="red")
 
    frame1.label3 <- tklabel(frame1, textvariable = tclVar("  "),
                              fg="blue")
    tkgrid(frame1.label2, frame1.label3, sticky="w")
    
###    tkpack(frame1, fill = "x")
  ###*****
  ind <- grep(defvar1, covdthRead)
    if(length(na.omit(ind)) <= 0)
      ind <- -1
   
     if(length(covdthRead) <= 0)
      covdthRead <- "<NA>"
###    print(covdthRead)
  combFrame <- comboBox(base=tkcovage,
                        fruits=covdthRead,
                        fruit.selection=ind[1], text=textCov1, 
                        env.towrite= ewho)
    if(!all(is.na(defvar2)))
      tclObj(outputlist) <- sapply(defvar2, formatC,width=2, format="d",flag="0")

### how to use the comboBox, with function comboBox()
### that returns a frame, and pack it somewhere
   
    tkpack(combFrame,fill="x")
  
    frame2 <- tkframe(tkcovage, relief = "groove", borderwidth = 2)
    frame3 <- tkframe(tkcovage, relief = "groove", borderwidth = 2)
  
    scr1 <- tkscrollbar(frame2, repeatinterval=5,
                       command=function(...)tkyview(frame2.lstbox1, ...))
    frame2.lstbox1 <- tklistbox(frame2, height=4, selectmode="extended",
                               yscrollcommand=function(...)tkset(scr1,...),
                               background="white", listvariable =agesList)
    scr2 <- tkscrollbar(frame2, repeatinterval=5,
                       command=function(...)tkyview(frame2.lstbox2, ...))
    
    tkselection.set(frame2.lstbox1, -1)
    frame2.lstbox2 <- tklistbox(frame2, height=4, selectmode="extended",
                               yscrollcommand=function(...)tkset(scr2,...),
                               background="white",listvariable=outputlist)
    frame2.label1 <- tklabel(frame2, textvariable = tclVar(textAge1),
                             fg="blue")
    frame2.label2 <- tklabel(frame2, textvariable = tclVar(textAge2),
                             fg="blue")
    frame2.label3 <- tklabel(frame2, textvariable = tclVar("   "))
    tkgrid(frame2.label1,frame2.label3,frame2.label2,sticky="w")
    tkgrid(frame2.lstbox1,scr1,frame2.lstbox2,scr2,sticky="e")
    tkgrid.configure(scr1, rowspan=4, sticky="nsw")
    tkgrid.configure(scr2, rowspan=4, sticky="nsw")
    
    frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = covage.close)
    
    frame3.but2 <- tkbutton(frame3, text = "Apply   >>", padx = 15,command = covage.init)
    frame3.but3 <- tkbutton(frame3, text = "<<  Remove", padx = 15,command = covage.remove)
    frame3.label1 <- tklabel(frame3, text = " ")
    tkgrid(frame3.but2, frame3.but1, frame3.but3, sticky = "w")
   
  
    tkpack(frame2,fill="x")
    tkpack(frame3, fill="x")  
     return(tkcovage)
 ###   return(environment())
}

##
## DESCRIPTION:  Creates the GUI with a radio buttoms for the standardization of covariates, and
##               for the testing of colliniarities among selected covs. Four text boxes, one
##               for the percentage of data to loose, lag.cutoff, when the covariate is
##               included in the run due to the presence of missing values; a number <= 1 
##               Three text boxes for the tolerance parameters, tol, delta.tol and solve.tol
##               to detect collinearities among covariates. The buttom Apply has command   
##               with standard.init, and writes into memory the new values
##               enter in any of the text boxes or choices for collinearities or standardization. 
##               The buttom Close, standard.close,  quits the application. 
##               Defaults values for tolerances, lag.cutoff and radio buttoms are in namelists().
##               New values are written in the nevironmnet env.who(ewho) or the calling environmnet.
##                 
## FORMAT: standard.cov(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the radio buttons and two list boxes.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, tol, delta.tol, solve.tol
##         and lag.cutoff, as well as the choice for standardization of covaraites (T or F), 
##         and for detection (T or F) of colliniarities, can be changed with the GUI  
##         and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


standard.cov <- function(base,textCollinear="Collinearity",
                    textMissing =paste("Missing Values ", "\n", "(% lost data not exceeding)"),
                    textLag     = " Lag  Cov Years", 
                    textStandard ="Standardization",
                    textTol = "Tolerance Parameters",
                         textsave="Save Expanded Cov", 
                    toltext = "SVD (svdtol)")
             {
    ewho <- get("ewho", env=parent.frame())
    elim.collinear <- get("elim.collinear", env=ewho)
    standardize <- get("standardize", env=ewho)
    lag.cutoff <- get("lag.cutoff", env=ewho)
    lag    <-  get("lag", env=ewho)
    tol <- get("tol", env=ewho)
    delta.tol <- get("delta.tol", env=ewho)
    solve.tol <- get("solve.tol", env=ewho)
    svdtol <- get("svdtol", env=ewho)
    save.FULL <- get("save.FULL", env=ewho)
    if(standardize ) 
      chkst <- tclVar("1")
    else
       chkst <- tclVar("0")
    if(elim.collinear)  
      chkco <- tclVar("1")
    else
       chkco <- tclVar("0")
    if(save.FULL)
      chksave <- tclVar("1")
    else
      chksave <- tclVar("0")
    
    var1 <- tclVar()
    tclObj(var1) <- lag.cutoff
    varlag <- tclVar()
    tclObj(varlag) <- lag
    var2 <- tclVar()
    tclObj(var2) <- tol
    var3 <- tclVar()
    tclObj(var3) <- delta.tol
    var4 <- tclVar()
    tclObj(var4) <- solve.tol
    varst <- tclVar()
    varsvd <- tclVar()
    tclObj(varsvd) <- svdtol
    colorentry <- "white"
    if(elim.collinear)
      tclObj(varst) <- "normal"
    else{
       tclObj(varst) <- "disable"
       colorentry <- "grey"
     }
    var1parse <- as.character(tclvalue(var1))
    varlagparse <- as.character(tclvalue(varlag))
    var2parse <- as.character(tclvalue(var2))
    var3parse <- as.character(tclvalue(var3))
    var4parse <- as.character(tclvalue(var4))
    varsvdparse <- tclvalue(varsvd)
    
    eGUI <- environment()
    
    standard.close <- function(...) {
     
     standard.init()
     tkdestroy(base)
    }
    standard.init <- function(...) {
      
      ewho <- get("ewho", env=eGUI)
      rVal3 <- as.character(tclvalue(chksave))
      
      save.FULL <- ifelse(rVal3 == "0", F, T)
      
      assign("save.FULL", save.FULL, env=get("ewho", env=eGUI))
      assign("save.FULL", save.FULL, env=eGUI)
        
      rVal1 <- as.character(tclvalue(chkst))
      
      if(rVal1 == "0")
        standardize <- F
      else
        standardize <- T
      assign("standardize", standardize, env=ewho)
      assign("standardize", standardize, env=eGUI)
      rVal2 <- as.character(tclvalue(chkco))
            
     
      if(rVal2=="0"){ 
        elim.collinear <- F
        tclObj(varst) <- "disabled"
        tkconfigure(frame3.entry1, state=tclvalue(varst),bg="lightgray")
        tkconfigure(frame3.entry2, state=tclvalue(varst), bg="lightgray")
        tkconfigure(frame3.entry3, state="disabled", bg="lightgray")
      }else{
        elim.collinear <- T
        tclObj(varst) <- "normal"
        tkconfigure(frame3.entry1, state=tclvalue(varst),bg="white")
        tkconfigure(frame3.entry2, state=tclvalue(varst), bg="white")
        tkconfigure(frame3.entry3, state="normal", bg="white")
      }
      assign("elim.collinear", elim.collinear, env=ewho)
      assign("elim.collinear", elim.collinear, env=eGUI)
      
      ##
         
      assign("lag.cutoff",as.numeric(tclvalue(var1)), env=ewho)
      assign("lag",as.numeric(tclvalue(varlag)), env=ewho)
      assign("tol",as.numeric(tclvalue(var2)), env=ewho)
      assign("delta.tol", as.numeric(tclvalue(var3)), env=ewho)
      assign("solve.tol", as.numeric(tclvalue(var4)), env=ewho)
      assign("svdtol", as.numeric(tclvalue(varsvd)), env=ewho)
      
###      cat("lag.cutoff = ", var1parse, "\n")
###      cat("lag = ", varlagparse, "\n")
###      cat("tol = ", var2parse, "\n")
###      cat("delta.tol = ", var3parse, "\n")
###      cat("solve.tol = ", var4parse, "\n")

###        cat ("save.FULL = ", save.FULL, "\n")
###        cat("elim.collinear = ", elim.collinear, "\n")
###        cat("standardize = ", standardize, "\n")
      }        
    
    
    tkstandard <-  tkframe(base, relief = "groove", borderwidth = 2)
    frame03 <- tkframe(tkstandard, relief = "groove", borderwidth = 2)
    frame0 <- tkframe(tkstandard, relief = "groove", borderwidth = 2)
    
    frame12 <-  tkframe(tkstandard, relief = "groove", borderwidth = 1)
    frame3 <- tkframe(tkstandard, relief = "groove", borderwidth = 1)
    frame4 <- tkframe(tkstandard, relief = "groove", borderwidth = 1)
 
### filling frame0
    frame0.label0 <-  tklabel(frame0, textvariable = tclVar(textLag), fg="blue")
    frame0.label1 <- tklabel(frame0, textvariable  = tclVar(textMissing),
                             fg="blue")
    frame0.label2 <- tklabel(frame0, textvariable = tclVar("lag.cutoff"))
    frame0.label3 <- tklabel(frame0, textvariable = tclVar("  lag  "))
    frame0.entry1 <- tkentry(frame0, textvariable = var1,
                             width =8, bg="white")

    tkbind(frame0.entry1,"<Tab>", function(){
      var1parse <- tclvalue(var1)
      assign("lag.cutoff", as.numeric(var1parse), env=get("ewho", env=eGUI))
      assign("lag.cutoff", as.numeric(var1parse), env=eGUI)})
    
    frame0.entry2 <- tkentry(frame0, textvariable = varlag,
                             width =8, bg="white")
    tkbind(frame0.entry2,"<Tab>", function(){
     varlagparse <- tclvalue(varlag)
     assign("lag", as.numeric(varlagparse), env=get("ewho", env=eGUI))
     assign("lag", as.numeric(varlagparse), env=eGUI)})
   
    tkgrid(frame0.label1, tklabel(frame0, text ="        "), frame0.label0,sticky="w")
    tkgrid(frame0.label2, frame0.entry1, frame0.label3, frame0.entry2, sticky = "w")
    tkpack(frame0)
    
### filling frame12
    frame12.label0 <- tklabel(frame12, textvariable = tclVar(textStandard),
                             fg="blue")
### for standard checkbox
    frame12.chkst <- tkcheckbutton(frame12)
    
    tkconfigure(frame12.chkst, variable= chkst)
         
    tkbind(frame12.chkst,"<Button-1>", function(){
      on.off <- as.character(tclvalue(chkst))
      standardize <- ifelse(on.off=="0", T, F)
###      cat("IN button...")
###      print(standardize)
      assign("standardize", standardize, env=eGUI)
      assign("standardize", standardize, env=get("ewho", env=eGUI))
      assign("chkst", chkst, env=eGUI)
         })
    
      
    tkgrid(frame12.label0,frame12.chkst, sticky="w")
     
    frame12.label1 <- tklabel(frame12, textvariable = tclVar(textCollinear),
                             fg="blue")
### collinearities check box
    frame12.chkco <- tkcheckbutton(frame12)
   
    tkconfigure(frame12.chkco, variable= chkco)
    tkbind(frame12.chkco,"<Button-1>", function(){
      on.off <- as.character(tclvalue(chkco))
      elim.collinear <- ifelse(on.off=="0", T,F)
###      cat("In button...")
###      print(elim.collinear)
      assign("elim.collinear", elim.collinear, env=eGUI)
      assign("elim.collinear", elim.collinear, env=get("ewho", env=eGUI))
      tclObj(varst) <- "normal"
      tkconfigure(frame3.entry1, state=tclvalue(varst),bg="white")
      tkconfigure(frame3.entry2, state=tclvalue(varst), bg="white")
      tkconfigure(frame3.entry3, state="normal", bg="white")
      assign("chkco", chkco, env=eGUI)
    })
    
       
    tkgrid(frame12.label1,frame12.chkco, sticky="w")
       
    
    frame12.label2 <- tklabel(frame12,
                                textvariable=tclVar(textsave), fg="blue")
    frame12.chksave <- tkcheckbutton(frame12)
   
    tkconfigure(frame12.chksave, variable= chksave)
         
    tkbind(frame12.chksave,"<Button-1>", function(){
      on.off <- as.character(tclvalue(chksave))
      save.FULL <- ifelse(on.off=="0", T,F)
 ##     cat("In button...")
 ##     print(save.FULL)
      assign("save.FULL", save.FULL, env=eGUI)
      assign("save.FULL", save.FULL, env=ewho)
      assign("chksave", chksave, env=eGUI)
         })
   
    
       
    tkgrid(frame12.label2, frame12.chksave, sticky="w")
   
    tkpack(frame12, fill="x")
   
    
    frame3.label0 <- tklabel(frame3, textvariable = tclVar(textTol),fg="blue")
    frame3.label1 <- tklabel(frame3, textvariable = tclVar("tol"))
    
    frame3.label2 <- tklabel(frame3, textvariable = tclVar("delta.tol"))
    frame3.label3 <- tklabel(frame3, textvariable = tclVar("solve.tol"))
    frame3.label4 <-  tklabel(frame3, textvariable = tclVar(toltext),fg="black")
  
    frame3.entry1 <- tkentry(frame3, textvariable = var2, width = 15)
     tkbind(frame3.entry1,"<Tab>", function(){
       assign("tol", as.numeric(tclvalue(var2)), env=ewho)
       assign("tol", as.numeric(tclvalue(var2)), env=eGUI)})
    
    frame3.entry2 <- tkentry(frame3, textvariable = var3, width = 15)
    tkbind(frame3.entry2,"<Tab>", function(){
      assign("delta.tol", as.numeric(tclvalue(var3)), env=ewho)
      assign("delta.tol", as.numeric(tclvalue(var3)), env=eGUI)})
    
    frame3.entry3 <- tkentry(frame3, textvariable = var4, width = 15)
    tkbind(frame3.entry3,"<Tab>", function(){
      assign("solve.tol", as.numeric(tclvalue(var4)), env=ewho)
      assign("solve.tol", as.numeric(tclvalue(var4)), env=eGUI)})
 
    
    frame3.entry4 <- tkentry(frame3, textvariable = varsvd,
                             width = 15, bg=colorentry)
    
    tkbind(frame3.entry4, "<Tab>",  function() {
      varsvd.local <- as.character(tclvalue(varsvd))
      varsvdparse <- as.numeric(varsvd.local)
      assign("svdtol",varsvdparse, env=eGUI)
      assign("svdtol", varsvdparse, env=get("ewho", env=eGUI))
      })
    
    tkconfigure(frame3.entry1, state=tclvalue(varst),bg=colorentry)
    tkconfigure(frame3.entry2, state=tclvalue(varst), bg=colorentry)
    tkconfigure(frame3.entry3, state=tclvalue(varst), bg=colorentry)
    
    tkgrid(frame3.label0, sticky="w")
    tkgrid(frame3.label1, frame3.entry1, sticky = "w")
    tkgrid(frame3.label2, frame3.entry2, sticky = "w")
    tkgrid(frame3.label3, frame3.entry3, sticky = "w")
    tkgrid(frame3.label4, frame3.entry4, sticky= "w")
###    tkgrid(frame0, frame3, sticky="w")
 ##   tkgrid(frame0, sticky="w")
 ##   tkgrid(frame3, sticky="w")
   
    tkpack(frame3,fill="x")
    
    frame4.but1 <- tkbutton(frame4, textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = standard.close)
    
    frame4.but2 <- tkbutton(frame4, text = "Apply", padx = 15,command = standard.init)
  
    tkgrid(frame4.but2, frame4.but1, sticky = "w")     
    
    tkpack(frame4, fill="x")  
 
   return(tkstandard)
}

##
## DESCRIPTION:  Creates a GUI for covariates with three text boxes,
##               two combo boxes and three buttoms.  One text box is for entering your own
##               covariate name and the accompanying combo box  for the selection of the
##               covaraite from a drop down list.  The combo box has covaraites stored in the array
##               covString of set.defaults. Two other text boxes to enter the maximum power
##               of the covarite selected, which will be included in the model and its lower powers
##               For example, if you enter Power of Cov=5, the model will have the powers
##               cov^5,cov^4,cov^3,cov^2 and cov.  Logarithmic power a single entry box, such as
##               log(cov)^3.  The selection of the covariate type is done with the
##               drop down combo box, Select Cov Type, where five types are available and are
##               stored in the vector or array  covtypeString of set.defaults(). Three buttoms,
##               the Apply buttom, covtype.init, will write into memory the newly
##               selected parameters either from textboxes or from drop down comboboxes.  
##               The Edit buttom, covtype.edit,  will bring the data editor,
##               which is the builtin R-GUI invoked with data.entry(mat).
##               You may change the paramters chosen for any of the
##               covariates, such as maximum power or the log power, and also have a list
##               of your selections wich may also be edited.  
##               The buttom Close, covtype.close,  quits the application
##               and writes new selections in memory. 
##               Defaults values for cov names, covs types are in in namelists().
##               New values are written in the environmnet env.who(ewho) and the calling environmnet.
##                 
## FORMAT: covtype(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the radio buttons and two list boxes.
##
## IMPORTED functions:comboBox(), trim.blanks(), reconstruct(), checktypes()
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, the parameters,covs, power of cov, log power of cov and cov.type 
##         can be changed or newly added with the GUI and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


covtype <- function(base, textcov="Enter Cov Name ", textOR ="OR",
                    textpower = "Power ",
                    textype="Select Cov Type: ",
                    title.column ="Cov Included",   
                    textlog = "Logarithmic Power", mxwidth = 30, 
                    textCov1 = "Select Covariate:      ", textna = "<NA>")
                    {
    ewho <- get("ewho", env=parent.frame())
    cov <- get("cov", env=ewho)
    localcov <- unlist(sort(cov))
    cov.type <- get("cov.type", env=ewho)
    cov.type <- unlist(cov.type)
   
    if(length(cov.type) < 2 && all(is.na(cov.type)) ){ 
      localcov.type <- rep(NA, length(cov))
      names(localcov.type) <- localcov
###      print(localcov.type)
    }else{
      localcov.type <- cov.type
      ii <- order(names(localcov.type))
      localcov.type <- localcov.type[ii]}
       
    cbg <- "white"
    covString <- get("covString", env=ewho)
    dthString <- get("dthString", env=ewho)
    covdthRead <- get("covdthRead", env=ewho)
    covString <- c(covString, "cnst", "time")
    covString <- c(covString, dthString)
    covtypeString <- get("covtypeString", env=ewho)
    var1 <- tclVar()
    tclObj(var1) <- textna ##or gdp
    var2 <- tclVar( covtypeString[1])
    varpower <- tclVar("1")
    defpower <- 1
    deflog <- 0
    if(length(covdthRead) > 0)
      var3 <- tclVar(covdthRead[1])
    else
      var3 <- tclVar(" ")
    
    eGUI <- environment()
    defvar1 <- NULL
    done <- tclVar(0)
    defvar2 <- NULL
    powerVec <- rep(defpower, length(localcov))
    names(powerVec) <- localcov
    logVec <- rep(deflog,length(localcov))
    names(logVec) <- localcov
    lst.todisplay <- list(cov=localcov, cov.type= unlist(localcov.type),
                              pow=powerVec, log.pow= logVec)
    rbValue1 <- tclVar("True")
    rbPower1 <- tclVar("True")
    
 ### button Close
 covtype.close <- function(...) {
   
     ewho <- get("ewho", env =eGUI)
     
     assign("pow", powerVec, env=ewho)
     assign("log.pow", logVec, env=ewho)
     
     cov <- reconstruct(cov=localcov, cov.type=localcov.type,
                 pow =powerVec, log=logVec) 
  
     cov <- na.omit(cov$covres)
    
     cov <- na.omit(cov)
    
     indx <- grep(NA, names(cov.type))
     if(length(indx) > 0)
       cov.type <- cov.type[-indx]
     
     cov.type <- checktypes(type=localcov.type)
     assign("cov",cov, env=ewho)
     assign("cov.type", cov.type, env=ewho)
   
         
           tkdestroy(base)
    }
    
### button Apply: doing all work of adding and removing covs and their powers  
 covtype.init <- function(...) {
     
       rPow1 <- as.character(tclvalue(rbPower1))
     
       if(trim.blanks(tclvalue(var1)) != textna){ 
         ##         as.character(tclvalue(var1)) != comboValCov ){
         defvar1 <- tclvalue(tclObj(var1))
         tclObj(var1) <- textna
       }else{
         tclObj(var1) <- textna
         e1 <- get("e1", env=eGUI)
         defvar1 <- get("comboValue",env=e1)
       }
     
     
       chk <- F
       if (length(defvar1) > 0)
         chk <- (identical(trim.blanks(defvar1), textna) 
                 || identical(trim.blanks(defvar1), "N/A") 
                 || length(na.omit(defvar1)) <= 0)
     

       if (length(defvar1) <= 0 || chk)
         {
          
           return(list()); ## get out of this function call 
         }
               
       assign("defvar1", defvar1, env=eGUI)
       comboEntryCov <- get("comboEntry", env=e1)
   
       defvar2 <- get("comboValue",env=get("e2", env=eGUI))
       if(length(defvar2) <= 0 )
         defvar2 <- NA
   
       assign("defvar2", defvar2, env=eGUI)
           
       comboEntryType <- get("comboEntry", env=e2)
       comboEntryType[comboEntryType == textna] <- NA
           
       localcov <- get("localcov", env=eGUI)
       localcov.type <- get("localcov.type", env=eGUI)
   
       powerVec <- get("powerVec", env=eGUI)
       logVec <- get("logVec", env=eGUI)

##       cat("................................", "\n", "localcov = ")
##       print(localcov)        
##       cat("localcov.type = ")
##       print(localcov.type)
##       cat("powerVec = ")
##       print(powerVec)
##       cat("logVec = ")
##       print(logVec)
##       cat(".........................................", "\n")

       nmpct <- names(localcov.type)
       ix1 <- grep(defvar1, localcov)
       ix2 <- grep(defvar1, names(localcov.type))
       
       if(length(ix1) > 0)
         localcov <- localcov[-ix1]
       if(length(ix2) > 0)
         localcov.type <- localcov.type[-ix2]
           
       localcov <- c(defvar1, localcov)
     
       assign("localcov", localcov, env=eGUI)
       nmpct <- names(localcov.type)
       localcov.type <- c(defvar2, localcov.type)
       
       names(localcov.type) <- c(defvar1, nmpct) 
       assign("localcov.type",localcov.type, env=eGUI)
       rPow1 <- as.character(tclvalue(rbPower1))
    
       if(rPow1 == "True")
         {
           varpowerparse <- as.numeric(tclvalue(varpower))
           assign("defpower", varpowerparse, env=eGUI)
           varlogparse <- NULL
         }
       else
         {
           varlogparse <-  as.numeric(tclvalue(varpower))
           assign("deflog", varlogparse, env=eGUI)
           varpowerparse <-  NULL
         }

       pwn <- names(powerVec)
       pln <- names(logVec)
       
       if(length(varpowerparse) > 0)
         {
       
           defv <- paste("^",defvar1, sep="")
           defvp <- paste("^\\(", defvar1, sep="")
           ix1 <- grep(defv, pwn)
           ix2 <- grep(defvp, pwn)
           ix1 <- sort(c(ix1, ix2))
           if(length(ix1) > 0 )
               powerVec <- powerVec[-ix1]                    
           pwn <- names(powerVec)
           powerVec <- c( varpowerparse, powerVec)
           names(powerVec) <- c(defvar1,pwn)
          
    
         }
       
      
       if(length(varlogparse) > 0)
         {
           defv <- paste("^ln\\(", defvar1,sep="")
           ix1 <- grep(defv, pln)
           ix2 <- grep(defvar1, pln)
           if(length(ix1) > 0 )
             logVec <- logVec[-ix1]
           if(length(ix2) > 0)
             logVec <- logVec[-ix2]
         
           pln <- names(logVec)
           logVec <- c( varlogparse, logVec)
           names(logVec) <- c(defvar1,pln)
           ix1 <- grep(defv, pwn)
          
           if(length(ix1) > 0 )
             powerVec <- powerVec[-ix1]
                    
           pwn <- names(powerVec)
           
         }
       assign("powerVec", powerVec, env=eGUI)
       assign("logVec", logVec, env=eGUI)
    
##       cat("localcov = ")
##       print(localcov)        
##       cat("localcov.type = ")
##       print(localcov.type)
##       cat("powerVec = ")
##       print(powerVec)
##       cat("logVec = ")
##       print(logVec)
   
       ewho <- get("ewho", env =eGUI)
       assign("localcov",localcov, env=ewho)
       assign("cov.type", localcov.type, env=ewho)
       assign("pow", powerVec, env=ewho)
       assign("log.pow", logVec, env=ewho)
       tclvalue(done) <- 1
       lst.todisplay  <- list(cov=localcov, cov.type= localcov.type,
                                  pow=powerVec, log.pow= logVec)
###    print(paste("lst.todisplay ", lst.todisplay))
       assign("lst.todisplay", lst.todisplay, env=eGUI)
       covlst <- reconstruct(localcov, localcov.type,
                             powerVec, logVec)
##       print(covlst)
       vectodisplay <- covlst$vectodisplay
       cov <-  covlst$cov
       assign("cov", cov, env=ewho)
       
       len.text <- nchar(vectodisplay)
       names(vectodisplay) <- "cov = "
      
       dataframe <- as.data.frame(vectodisplay)
       len.title.col <- nchar(title.column)
       diff.len <- len.text - len.title.col
       diff.len <- min(abs(diff.len[,1])) 
       if (diff.len > 0){
         for(i in 1:diff.len)
           title.column <- paste(title.column, " ", sep="")
       }

       ln <- length(dataframe)
       if(ln > 1){
         vec <- rep("  ", (ln - 1))
         vec <- c(title.column, vec)
         names(dataframe) <- vec
       }
     
       
       dataframe <- showCovs(dataframe, base=frame23,titletext= "",
                             colname.bgcolor = "lightblue",
                             titlename.bgcolor = "lightgrey", 
                             colname.textcolor = "darkred",
                             maxwidth = mxwidth)
       
     }
    
      
           
    tkcovs <- tkframe(base, relief = "groove", borderwidth = 2)
   
    frameradios <- tkframe(tkcovs, relief = "groove", borderwidth = 1)
   
    frame2 <- tkframe(tkcovs, relief = "groove", borderwidth = 0)
    frame23 <- tkframe(tkcovs, relief="groove", borderwidth = 1)
    frame3 <- tkframe(tkcovs, relief = "groove", borderwidth = 1)
    framec <- tkframe(tkcovs, relief = "groove", borderwidth = 1)
    framefull <- tkframe(frameradios, relief = "groove", borderwidth = 0)
  
    framec.label <- tklabel(framec, textvariable = tclVar(textCov1),
                              fg="blue")  
    e1 <- new.env(hash=T, parent=parent.frame())
 
    if(length(covdthRead) <= 0)
      covdthRead <- "<NA>"
    comboCov <- comboBox(base=framec,
                        fruits=covdthRead,
                        fruit.selection=-1, text=textCov1, ##text="      ",   
                        env.towrite= e1)
##    tkgrid(framec.label, comboCov, sticky="e")
    tkgrid(comboCov, sticky="e")
    tkpack(framec, fill="x")
    comboValCov   <- get("comboValue", env=e1)
    comboEntryCov <- get("comboEntry", env=e1)
    assign("comboValCov", comboValCov, env=ewho)
    assign("comboEntryCov", comboEntryCov, env=ewho)             
    
### how to use the comboBox, with function comboBox()
### that returns a frame, and pack it somewhere   
    frame2.spacer <- tklabel(frame2, text = "   ")   
    frame2.label2 <- tklabel(frame2, textvariable = tclVar(textpower),
                             fg="blue")
    frame2.label1 <- tklabel(frame2, textvariable = tclVar(textlog),
                             fg="blue")
      
    frame2.entry1 <- tkentry(frame2, textvariable = varpower,
                             width = 5, bg=cbg)
    rb1 <- tkradiobutton(frame2)
    rb2 <- tkradiobutton(frame2)
    tkconfigure(rb1, variable= rbPower1, value="False")
    tkconfigure(rb2, variable= rbPower1, value="True")
  
###    tkgrid(frame2.label1, frame2.entry1, sticky = "w")
###    tkgrid(tklabel(frame2, textvariable = tclVar("  ")))    
###    tkgrid(frame2.label2, frame2.entry2, sticky = "w")
    
    tkgrid(frame2.label1,sticky="nsew")   
    tkgrid(tklabel(frame2, text = "yes"), rb1, sticky="w")
    tkgrid(tklabel(frame2, text = "no"), rb2, sticky="w")
###           tklabel(frame2, textvariable = tclVar(" ")),
    tkgrid(frame2.label2, frame2.entry1, sticky = "w")
 ###    tkgrid(tklabel(frame2, text = "   "),sticky="nsew")   
 ##   tkpack(frame2, fill = "x")
 
    tkpack(frame2)
###    tkgrid(frame2, framefull)
###    tkpack(frameradios)
   
    e2 <- new.env(hash=T, parent=parent.frame())
    comboType <- comboBox(base=tkcovs,
                          fruits=covtypeString,
                          fruit.selection=-1, text=textype, 
                          env.towrite= e2)
 
    tkpack(comboType, fill="x")  
    comboValType   <- get("comboValue", env=e2)
    comboEntryType <- get("comboEntry", env=e2)
    assign("comboValType", comboValType, env=ewho)
    assign("comboEntryType", comboEntryType, env=ewho)
    vectodisplay <- form.display(cov)
    len.text <- nchar(vectodisplay)
    names(vectodisplay) <- "cov = "
    dataframe <- as.data.frame(vectodisplay)
   
    len.title.col <- nchar(title.column)
    diff.len <- len.text - len.title.col
    diff.len <- min(abs(diff.len[,1])) 
    if (diff.len > 0){
        for(i in 1:diff.len)
        title.column <- paste(title.column, " ", sep="")
    }
    ln <- length(dataframe)
    if(ln > 0){
      vec <- rep("  ", (ln - 1))
      vec <- c(title.column, vec)
  ###    print(vec)
      names(dataframe) <- vec
    }
  
    dataframe <- showCovs(dataframe, base=frame23,titletext= "",
                          colname.bgcolor = "lightblue",
                          titlename.bgcolor = "lightgrey", 
                          colname.textcolor = "darkred",
                          maxwidth= mxwidth)
    tkpack(dataframe, fill="x")                   
    frame3.spacer <- tklabel(frame3, text = "   ") 
      
    frame3.but2 <- tkbutton(frame3,  textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = covtype.close)
    
    frame3.but3 <- tkbutton(frame3, text = "Apply", padx = 20,                                                              command = covtype.init)
    tkgrid(frame3.spacer,sticky="nsew") 
    tkgrid(frame3.but2, frame3.but3, sticky = "w")
    tkpack(frame3, fill="x")
    return(tkcovs)
}
##
## DESCRIPTION: it takes a list whose elements are vectors
##              lst$cov = vector of covariates,
##              lst$cov.type their types for each element of cov
##              lst$pow, lst$logpow vectors of powers and log powers
##              All vectors should have same length
##              Finds missing values from lst$cov and omit them
##              then updates the other three components of list lst
##              with the missing value of cov removed from vectors
##
## Input & output are lists.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 08/04/2005
##
###########################################################
 check.miss.values <- function(lst)
        {
        ind <- !is.na(lst$cov)
        
        lst$cov <- lst$cov[ind]
        lst$cov.type <- lst$cov.type[ind]
        lst$pow <-lst$pow[ind]
        lst$log.pow <- lst$log.pow[ind]
      
        return(lst)
    }

## ************************************************************************
##
## FUNCTION NAME:      trim.blanks
##
## IMPORTED functions: none
##
##
## DESCRIPTION: It returns a string of characters with blanks eliminated  
##              at the beginning or end of the word only.
##
## FORMAT:  trim.blanks(word), with word a character string
##
## OUTPUT: word with the blanks at the beginning and end eliminated
##         For example word <- " my house in Concord "
##         trim.blanks(word) <- "my house in Concord". 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************


  
    trim.blanks <- function(x) {
     x <- gsub("^ ", "", x)
     x <- gsub(" $", "", x)
     return(x)
    }
## ************************************************************************
##
## FUNCTION NAME:      form.vector
##
## IMPORTED functions: none
##
##
## DESCRIPTION: It takes a vector and construct the R syntax for display   
##              For example vec of three dimensions, c(v1, v2, v3)
##
## FORMAT: form.vector(v), with v a vector or array 
##
## OUTPUT: a string of the form of R-vector: c(v1, v2, v3, ...,vn)
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

   form.vector <- function(v){
     
     if(length(v) > 1){
       ff <- "c("
       for(n in (1:length(v))){
         vx <- v[n]
         if(n <= 1)
           ff <- paste(ff,vx, sep="")
         else if (n < length(v))
           ff <- paste(ff,", ",vx, sep="")
         else
           ff <- paste(ff,", ", vx,")", sep="")
       }}else
          ff <- as.character(v)
       return(ff)
   }

## ************************************************************************
##
## FUNCTION NAME:    reconstruct 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env.who
##
## DESCRIPTION: Returns vector with selected covariates, their max powers and logs 
##              that will pass to namelists varaible cov.
##              For example c((gdp)5, log(gdp)3, hc, tfr, (tobacco)3))
##              Built from names gdp, hc, tfr and tobacco and the
##              powers 5, 3 for gdp and tobacco and log powers 3 for log(gdp)
##
## FORMAT:  reconstruct(cov, cov.type, pow, log)
##         
##
## INPUT:   covaraites covs, their cov.type which is a named vector(optional) string,
##          a vector pow for their max power or 1. and the powers of logs for the covaraites

## OUTPUT: Construct the R-vector to pass to namelists() and yourcast with
##         the covaraites to include in the run their powers andd logs of powers. 
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

   reconstruct <- function(cov, cov.type, pow, log, display=T, ncl=2) {
  
   cov   <- names(cov.type)
   cov   <- unlist(sapply(cov,FUN=trim.blanks))
    
   nmpow <- names(pow)
   if(length(nmpow) > 0)
     nmpow <- unlist(sapply(nmpow, FUN=trim.blanks))
   names(pow) <- nmpow
   
   nmlog <- names(log)
   if(length(nmlog) > 0)
     nmlog <- unlist(sapply(nmlog, FUN=trim.blanks))
   names(log) <- nmlog
      
   upow  <- unique.default(nmpow)
   ulog <-  unique.default(nmlog)
    
   if(length(upow) < length(names(pow)))
      {
        vecpow <- sapply(upow, function(nm, pow, nmpow){
          ind  <- grep(nm, nmpow)
          powmax <- max(pow[ind])
    
          return(powmax)},pow,nmpow)
        names(vecpow) <- upow
      }else
        vecpow <- pow
   
    if(length(ulog) < length(names(log)))
      {
   
        veclog <- sapply(ulog, function(nm, log, nmlog){
          ind  <- grep(nm, nmlog)
          if (length(ind) >0 )   
            powmax <- max(log[ind])
          else
            powmax <- NaN
                  
          return(powmax)},log,nmlog)
        names(veclog) <- ulog
      }else
        veclog <- log
  
  
       covres <- sapply(1:length(vecpow), function(x, vecpow){
         nm <- names(vecpow)[x]
         pp <- vecpow[x]
         if(!is.na(pp) && length(pp) > 0){
           if (pp > 1 && length(grep("\\(", nm)) <= 0){
             build <- paste("(",nm,")",pp, sep="")
             return(build)
           }else if (pp >1 ){
             return(paste(nm,pp, sep=""))
           }else if (pp == 1)
             return(nm)
           else{
             ## print("Powers of covs 0 or negative are not allowed") 
             return(NULL)}
         }
       }, vecpow)
       covres <- unlist(covres)
  
    
     log <- veclog
    
     veclog <- sapply(1:length(log), function(x,log){
       nm <- names(log)[x]
       nm <- trim.blanks(nm)
       ind <- log[x]
       
       if (all(is.na(ind)))
           return(NULL);
       
       if (ind > 1 && length(grep("ln", nm)) <= 0)
         return(paste("ln(",nm,")", ind, sep=""))
       else if(ind > 1)
           return(paste(nm,ind,sep=""))
       else if(ind==1 && length(grep("ln", nm)) <= 0)
         return(paste("ln(",nm,")",sep=""))
       else if(ind == 1)
           return(nm)
       else
         return(NULL)}, log)

     
   veclog <- unlist(veclog)
   covres <- unique.default(c(unlist(covres), unlist(veclog)))
   lst <- list(covres)
   names(lst) <- "covres"
  
      if( display == T)
      {
          
         ln <- length(covres)
         norow <- ln%/%ncl 
         if( ln%%ncl > 0)
           norow <- norow + 1
         vectodisplay <- matrix("", nrow=norow, ncol=ncl)
         indx <- as.list(1:length(covres))
         
          for(x in 1:length(covres))
          {
              ch <- covres[x]
           
              if (is.na(ch))
                next;
              
              ch <- as.character(ch)
           
              if (trim.blanks(ch) == "NA" ||
                       trim.blanks(ch) =="<NA>")
                next;
               
              vectodisplay[x] <- paste(ch, ",   ", sep="")
          }
         
         
          lst <- c(lst, vectodisplay = list(vectodisplay))
      }
      return(lst)
 }


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    form.display 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## USED GLOBALS: none 
##
## DESCRIPTION: Returns a string with covariate vector to put in text field.  
##              For example: cov <- c("gdp", "(fat)3", "ln(tobacco)", "cnst", "time")
##              becomes the string 
##              "c(gdp, (fat)3, ln(tobacco), cnst, time)"
##
## FORMAT:  a strin with covaraite vector (one element)
##         
##
## INPUT:   covariate selections vector. 
##
## OUTPUT:  text to display with covariates.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

form.display <- function(vecov, ncl = 2){

  x <- 0
          
  ln <- length(vecov)
  norow <- ln%/%ncl 
  if( ln%%ncl > 0)
    norow <- norow + 1
  vectodisplay <- matrix("", nrow=norow, ncol=ncl)
  for(ch in vecov)
    {
      x <- x + 1; 
      ch <- as.character(ch)
      vectodisplay[x] <- paste(ch, ",   ", sep="")                 
            
    }
          
          return(vectodisplay)
}
         
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    checktype(type) 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env.who
##
## DESCRIPTION: Returns vector with types for covaraites.  
##              Make sure that if you enter the name of the same covarite twice or more
##              you are consistent with the selection of cov.type otherwise
##              stops the simulation and returns error message, each covarite can only
##              have one type. A consistency check. 
##
## FORMAT:  cehcktype(type=cov.type)
##         
##
## INPUT:   the types enter in the GUI for the covarite selections. 
##
## OUTPUT: The unique types for each covarites or error messages.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

      
   checktypes <- function(type){
     
     utype <- unique.default(names(type))
    
     uvalue <- unique.default(type)
    
     if(length(utype) > 0 && length(uvalue) > 0 &&
        length(utype) < length(uvalue))
     stop("You enter two different types for same covariate. Pls fix it")
     
     if (length(utype) < length(type) && length(utype) >0)
       {
       for( n in (1:length(utype))){
         ind <- grep(utype[n],names(type))
         vec <- unique.default(type[ind])
         vnm <- unique.default(names(type)[ind])
         
         if (length(vec) != length(vnm) && unique.default(vnm) > 1){
           
          tkmessageBox(message="Two types for same covariate. Pls fix it!!!")}
       }
     }
     nmtype <- sapply(names(type), FUN=trim.blanks)
     indtokeep <- sapply(unique.default(nmtype), match, nmtype)
     typetoret <- type[indtokeep]

     return(typetoret)
   }

## DESCRIPTION:  Creates the GUI with textboxes for the depvariable, allcauses of death,
##               population, tarnsformation of depvar. Also two list boxes with the 
##               selections for the depvar and transformations.  Only one list box may
##               be selected at a time. Two buttons, the close button (depvar.close)
##               to cancel the frame and the  apply botton (depvar.init), which 
##               writes into memory any of the selected or entry items in the text boxes. 
##               Textboxes are for Dependent variable and Transformation,
##               the selections from the lists, which Apply registers them into memory
##               as well as the text boxes entries.  
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##
## FORMAT: depvar(base, textvalues).  Here base is the tktoplevel container to build the GUI
##         and textvalues are character strings with the texts for the entry boxes of the GUI
##         and for the list boxes containing the arrays or vectors stored in setdefaults
##         with dthString and transString of available death causes and trnasformations.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container, base.
##         In addition, some of the default values for the entry text boxes,depvar, all causes, 
##         population, and transformation, may have been changed from
##         their default values stored in namelist()and their new values are written in memory
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

directory.input.output <- function(){
  ewho <- get("ewho", env=parent.frame())
  input  <- get("data.path", env=ewho) 
  output <- get("out.path", env=ewho)
  destpath  <- paste(getwd(),"/",output,"/", sep="")
  readpath  <- paste(getwd(),"/", input, "/", sep="")
  if (!file.exists(readpath)){
            tkmessageBox(message=
                         "Creating directory  INPUT/ in your working directory"); 
            dir.create(path=readpath);
          }
  if (!file.exists(destpath)){
            tkmessageBox(message =
                         "Creating directory  OUTPUT/ in your working directory"); 
            dir.create(path= destpath);

          }
}

master.GUI <- function(base, txtoptions="Data",
                       txtmodel="Model",
                       txtoutput="Save Simulation Output",
                       txtreuse="Load Pre-processed Data",
                       txtoutfile="Save GUI-options",
                       txtmanual="Read Manual",
                       txtinfile="Supplied Userfile")
  
  {
###    tkwm.title(base,"YourCast")
###    env.who <- set.defaults()
###    ewho <- env.who
    eGUI <- environment()
    ewho <- set.defaults()
    modelString <- get("modelString", env =ewho)
    categoryString <- get("categoryString", env=ewho)
    covdthRead <- get("covdthRead", env=ewho)
    model <- try(get("model", env=ewho), silent = T)
     in.list <- get("in.list", env=ewho)    
    if(class(model) == "try-error")
        model <-  ""
    data.path <- get("data.path", env=ewho)
    out.path  <- get("out.path", env=ewho)
    cbg <- "white"
    modelList <- tclVar()
    categoryList <- tclVar()
    tclObj(modelList) <- modelString
    tclObj(categoryList) <- categoryString
    
    chkSave <- ifelse(get("save.output", env=ewho) == F, "0","1")
    chkSave <- tclVar(chkSave)
    chkReuse <- ifelse(get("reuse.data", env=ewho) == F, "0", "1")
    chkReuse <- tclVar(chkReuse)
    save.GUI <- get("save.GUI", env=ewho)
    chkGUI <- tclVar(save.GUI)
    
    rbValfile <- tclVar("True")
    tops.open <- list()
 
    GUI.selections <- function(...) {
      ewho <- get("ewho", env=eGUI)
      save.GUI <- get("save.GUI", env=ewho)
      depvar <- get("depvar", env=ewho)
      strata <- get("strata", env=ewho)
      model <- get("model", env=ewho)
      in.list <- get("in.list", env=ewho)
      data.path <- get("data.path", env=ewho)
      out.path <- get("out.path", env=ewho)
      upper.moda <- get("model.available", env=ewho)
      lower.moda <- sapply(upper.moda, FUN= tolower)
      
      args <- names(in.list)
      n.input <- length(in.list)
      ind <- as.list(1:n.input)
      names(ind) <- args
      file.GUI <- NULL
   
      if(as.character(tclvalue(chkGUI)) == "0")
        return(list())
      
    
      if(as.character(tclvalue(chkGUI)) == "1")
        {
   
          results.path <- paste(getwd(),"/", out.path, sep="" )
          ch1 <- is.element(model, upper.moda)
          ch2 <- is.element(model, lower.moda)
       ##   print(ch1); print(ch2)
          ##  if(is.character(model)&& length(na.omit(as.numeric(model))) <= 0 )
          if( ch1 || ch2)
             file.GUI <- paste(depvar, ".",strata,".",
                               tolower(as.character(model)),"_GUI.dat", sep="")
          else 
             file.GUI <- paste(depvar, ".",strata,".", "data_GUI.dat", sep="")
          
             file.GUI <- paste(results.path,file.GUI, sep="")
        }
      
      in.list <- lapply(ind, function(x, in.list, eGUI){
        ch <- names(ind)[x]
        val <- try(eval(as.symbol(ch), envir=get("ewho", env=eGUI)), silent=T)
        if (class(val)!= "try-error" && !is.null(val))
          return(val)
        else
          return(in.list[[x]])
      }, in.list, eGUI)

###Now we have to save all list elements into the file line by line 
      eclose <- environment()
      for (i in (1:length(args))){
###         print(args[i])
###         print(in.list[[i]])
        assign(args[i], in.list[[i]], env=eclose)}
###      cat("save.GUI and args...")
###      print(file.GUI)
###      print(args)
      save(list=args, file=file.GUI, compress=T)
    }
    
    master.close <- function(...) {
     
      if(as.character(tclvalue(chkGUI))=="1"){
     if(file.exists(data.path) && file.exists(out.path))
        GUI.selections()
      }
      ln <- length(tops.open)
    
###    print(tops.open)
      if(length(tops.open) > 0){
        for(i in 1:ln){
          if(length(tops.open[[i]]) > 0)
            tkdestroy(tops.open[[i]])}
      }
      tkdestroy(base)
    }
    master.init <- function(...) {
      if(length(as.numeric(tkcurselection(frame1.lstbox2))) >0){
        ret <- click.on.model(frame1.lstbox2)
        
        frm <- ret$top
        tops.open <- c(tops.open, list(frm))
        assign("tops.open", tops.open, env=eGUI)
      }
      
      if(length(as.numeric(tkcurselection(frame1.lstbox1))) >0){
        ret <- click.on.frame(frame1.lstbox1, ewho, model)
 
        frm <- ret$top
        tops.open <- c(tops.open, list(frm))
        assign("tops.open", tops.open, env=eGUI)
      }
    }
    
    master.clear <- function(){
      ewho <- set.defaults()

      assign("ewho",ewho, env=eGUI)
      vec <- ls(env=ewho)
      
      txtReuse <- ifelse(get("reuse.data", env=ewho) == F, "0", "1")
      chkReuse <- tclVar(txtReuse)
     
      txtSave <- ifelse(get("save.output", env=ewho) == F, "0", "1" )
      chkSave <-  tclVar(txtSave)
      
      txtGUI <- ifelse(get("save.GUI", env=ewho) == F, "0", "1" )
      chkGUI <-  tclVar(txtGUI)
         
      assign("chkReuse", chkReuse, env=eGUI)
      assign("chkSave", chkSave, env=eGUI)
      assign("chkGUI", chkGUI, env=eGUI)
      
      tkconfigure(frame21.chkReuse, variable=chkReuse)
      tkconfigure(frame22.chkSave, variable=chkSave)
      tkconfigure(frame23.chkGUI, variable=chkGUI)
  
         
      tkmessageBox(message="Setting globals to default values in namelists()")
    }
    
    soft.manual <- function(){
      strURL <- get("strURL", env=get("ewho", env=eGUI))
      browseURL(strURL)
      
    }

    retDir <-  NULL
    open.dirs <- function(...){
      ewho <- get("ewho", env=eGUI)
        if(length(retDir) <= 0)
          {
            datap <- get("data.path", env=ewho)
            covp <- get("cov.path", env=ewho)
            priorp <- get("prior.path", env=ewho)
            outp <- get("out.path", env=ewho)
            prep <- get("reuse.path", env=ewho)
            in.list <- get("in.list", env=ewho)
            retDir <- list(data.path = datap, cov.path = covp,
                           prior.path=priorp, out.path = outp, reuse.pah=prep)
          }
                      
      retDir <- model.dialog(textDef=unlist(retDir))
      assign("retDir", retDir, env=eGUI)
      param <- names(retDir)
###      print(retDir)
       
     for( n in 1:length(param))
        {
          assign(param[n],retDir[[n]], env=eGUI)
          assign(param[n],retDir[[n]], env=ewho)
          in.list[[param[n]]] <- retDir[[n]]
          if(identical(param[n], "data.path"))
            {
              covdthRead <- read.dir(data.path)
       
              if(length(covdthRead) <= 0 && file.exists(data.path)){
 ###               tkmessageBox(message=paste("No files found in dir ", data.path))
                assign("covdthRead", covdthRead, env=ewho)
                return(list())
              }
              assign("covdthRead", covdthRead, env=ewho)
            }
        }
 
    
  
      assign("in.list", in.list, env=ewho)         
    }
    retFile <-  NULL
    
    open.files <- function(...){
      ewho <- get("ewho", env=eGUI) 
###      cat("inside open.files...")
      in.list <- get("in.list", env=ewho)
      
      if(length(retFile) <= 0){
        cod  <- get("codes.names", env=ewho)
        adj  <- get("Hct.c.deriv", env=ewho)
        zero <- get("zero.mean", env=ewho)
        allc <- get("allcauses", env=ewho) ### to get ages group from csid
        if(zero== T || zero == F)
          zero <- ""
        retFile = c(user.file = "", codes.names=cod,
          Hct.c.deriv=adj, allcauses = " ")
      }
###     cat("Before any assignment ", "\n") 
###     print(cod);  print(adj);  print(zero)
      retFile <- model.buttons(textDef=unlist(retFile))
      filepath  <- retFile$filepath
      filenames <- retFile$filenames
###       print(retFile)
###      cat("inside open.files ", "\n")

###      print(filepath); print(filenames)
      assign("filepath", filepath, env=eGUI)
      param <- names(retFile$filepath)
      data.path <- get("data.path", env= ewho)
      input <- data.path
      for(n in (1:length(param)))
        {
          filename <- filenames[n]
          fpath <- filepath[[n]]
###          print(fpath) 
          type.def <- ""
 
        
          if(trim.blanks(filename) != ""&& length(filename)>0
             && !is.na(filename) )
            type.def <- strsplit(filename, "\\.")[[1]] ##either txt or dat
          ln <- length(type.def)
          type.def <- type.def[ln]
         
###       cat("OPEN FILES...filename","\n")
###       print(filename); print(param[n])
         
          nn <-  nchar(filename)
###        print(nn)
       
          if (nn <= 0)
            next;
###          print(param[n])
          filename <- trim.blanks(filename)
          if(identical(param[n], "codes.names") )
            {
###              cat("Inside open.files and codes.names....", "\n")
###                print(data.path)
              file <- parse.files(filepath=fpath,
                                 directory.def=data.path)
###              cat("after parse...........") ; print(file )
              str <- strsplit(file, "\\.txt")[[1]]
              str <- file
    
              assign("codes.names",str, env=get("ewho", env=eGUI))
              assign("codes.names",str, env=eGUI)
              in.list[["codes.names"]] <- str
    
###           cat("after assigmnet ...") 
###           print(str)
            }
          else if (identical(param[n], "Hct.c.deriv") )
            {
###           cat("Inside open.files and Hct.c.deriv....", "\n")
              data.path <- get("prior.path", env=ewho)
###           cat("in Hct.c.deriv....\n")
###           print(data.path)
               if(trim.blanks(fpath) == "")
                 next; 
              file <- parse.files(filepath=fpath,
                                 directory.def=data.path, typedef =type.def, dir=input)
              assign("Hct.c.deriv",file, env=get("ewho", env=eGUI))
              assign("Hct.c.deriv",file, env=eGUI)
               in.list[["Hct.c.deriv"]] <- file
            }
          else if(identical(param[n], "age.file") )
            {
  ###          cat("Inside open.files and age.file....", "\n")
              data.path <- get("data.path", env=ewho)
 
              if(trim.blanks(fpath) == "")
                 next; 
              file <- parse.files(filepath=fpath,
                                 directory.def=data.path, typedef = type.def, dir=input)
              
              assign("age.file", file, env=get("ewho", env=eGUI))
              assign("age.file", file, env=ewho)
              age.file <- file
              in.list[["age.file"]] <- file
              
  ###            ff <- paste(getwd(),"/",data.path,fpath, sep="")


              if(file.exists(fpath)){
                age.digits  <- get("age.digits", env=get("ewho", env=eGUI))
                year.digits <- get("year.digits", env=ewho)
                agesRead <- find.ages(datap=fpath, file=NULL,
                                      aged = age.digits, yeard = year.digits)
                mx <- max(agesRead)
                ln <- floor(log10(mx)) + 1
                agesRead <- unlist(sapply(agesRead, formatC, width=ln,flag="0"))
###                print(agesRead)
                assign("agesRead", agesRead, env=get("ewho", env=eGUI))
                assign("agesRead", agesRead, env=eGUI)
              }
            } 
          else if(identical(param[n],"user.file"))
            {
###           cat("Inside open.files and user.file....", "\n")
###            print(fpath)
           if(trim.blanks(fpath) == "")
             next; 
           if(identical(type.def, "txt") )
             in.userfile(fpath)
           else if(identical(type.def, "dat") )
             in.GUIfile(fpath)
           else
             tkmessage(message="Not known file extension for user.file")
         }
 
     
        }
      assign("in.list", in.list, env=ewho)
      assign("in.list", in.list, env=eGUI)
    }
        
    linkfiles <- function() {
      path.to.harvard <- "/nfs/where/export/data/death/WHOdata/Jun2002_data/*"
      destfile <- "INPUT"
      ret <- modaldiag2(harvardpath= path.to.harvard, destpath= destfile)
      codesfile <- ret$harvard
      destpath <- paste(getwd(),"/",ret$input, sep="" )
              
      res <- readLines(pipe(paste("ln -s", codesfile, destfile)))
    }
    
    in.userfile <- function(userfile){
      ewho <- get("ewho", env = eGUI)
      in.list <- get("in.list",env=ewho)
      n.input <- length(in.list)

### the exact address of userfile
      assign("userfile", userfile, env=eGUI)
      assign("userfile", userfile, env=ewho)
   
      ff <- strsplit(userfile,"/")[[1]]
      usfile <- NULL
      if(length(ff) > 0)
        usfile <- ff[length(ff)]
      ftext <- usfile
### just the name of the file ftext
      userfile.chk <- T
      assign("userfile.chk", T, env=eGUI)
      tkmessageBox(message="Updating global with the user file parameters")
      source(userfile,local=T)
      args <- names(in.list)
     
      for(i in 1:n.input ){
        val <- try(eval(as.symbol(args[i])), silent=T)
        if (class(val)!= "try-error" && !is.null(val)){
          
          assign(args[i], val, env=ewho)
          assign(args[i], val, env=eGUI)
          in.list[[i]] <- val
        } else {
          assign(args[i], in.list[[i]], env=ewho)
          assign(args[i], in.list[[i]], env=eGUI)
        }
      }
      if(get("reuse.data", env=eGUI) == F) 
        chkReuse <-  tclVar("0")
      else
        chkReuse <- tclVar("1")
      
      if(get("save.output", env=eGUI) == F) 
        chkSave <-  tclVar("0")
      else
        chkSave <- tclVar("1")
      
      assign("chkReuse", chkReuse, env=eGUI)
      assign("chkSave", chkSave, env=eGUI)
      
      tkconfigure(frame22.chkSave, variable=chkSave)
   
      tkconfigure(frame21.chkReuse, variable=chkReuse)
      
    }
    
    in.GUIfile <- function(filename){
           
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        retreive.GUI <- filename
###        print(retreive.GUI)
        
### the exact address of userfile
        tkmessageBox(message=paste("Updating global with GUI-file parameters ",retreive.GUI, "\n"))
        assign("retreive.GUI", filename, env=eGUI)
        assign("retreive.GUI", filename, env=ewho)
        ff <- strsplit(retreive.GUI,"/")[[1]]
        guifile <- NULL
        if(length(ff) > 0)
          guifile <- ff[length(ff)]
        ftext <- guifile
### just the name of the file
        load(file=filename, envir=get("ewho", env=eGUI))
        
      }
    
    
    
    out.GUIfile <- function(...){
      depvar <- get("depvar", env=ewho)
      strata <- get("strata", env=ewho)
      model  <- get("model", env=ewho)
      data.path <- get("data.path", env=ewho)
      out.path <- get("out.path", env=ewho)
      results.path <- paste(getwd(), "/",out.path, sep="" )
      
      save.GUI <- paste(depvar,".",strata,".",
                        tolower(as.character(model)),"_GUI.dat",sep="")
      save.GUI <- paste(results.path,save.GUI, sep="")
      mess <- paste("Your GUI selections are saved in the file, \n",save.GUI, sep="")
      ##            depvar,".",strata,".",tolower(model),"_GUI.dat",sep="") 
      retVal <- tkmessageBox(message=mess, icon="info")
      if(tolower(as.character((tclvalue(retVal)))) =="ok"){
        
        assign("save.GUI",save.GUI, env=eGUI)
        assign("save.GUI", save.GUI,env=ewho)
      }
      
    }
    sim.output <- function(){  
      filename <- tclvalue(tkgetOpenFile())
      if (!nchar(filename))
        tkmessageBox(message="No file selected")
      else{
        tkmessageBox(message=paste("File selected is\n",filename ))
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        save.output <- filename
### the exact address of userfile
###        print(save.output)
        assign("save.output", filename, env=eGUI)
        assign("save.output", filename, env=get("ewho", env=eGUI))
        chkSave <-  tclVar("1")
        assign("chkSave", chkSave, env=eGUI)
        tkconfigure(frame21.chkSave, variable=chkSave,value="True")
    
        varzero <- tclVar(lst[ix])
        ff <- strsplit(save.output,"/")[[1]]
        usfile <- NULL
        if(length(ff) > 0)
          usfile <- ff[length(ff)]
        ftext <- usfile
### just the name of the file
###        print(ftext)
        savefile.chk <- T
        assign("savefile.chk", T, env=eGUI)
      }
    }
    mastercast <- function(){
      
      ewho <- get("ewho", env=eGUI)
      
      for(i in (1:length(ls(env=ewho)))){
        ch <- ls(env=ewho)[i]
        x <- get(ch, env=ewho)
        if(is.environment(x)){
###     print(ewho)
          ## rm(ch, env=ewho)
          
        }
      }
     tkconfigure(base, cursor="watch") 
     conn <- textConnection("outp", "w")
     sink(conn)
     m <- yourcast(env.who=ewho)
     sink()
     close(conn)
          tkconfigure(base, cursor="arrow") 
     assign("outp", outp, env=.GlobalEnv)
      assign("m", m, env=eGUI)
      assign("m", m, env=ewho)
    ###  GUI.selections(); 
      
    }
    
    
    
    graphcast <- function(){
      m <- get("m",env=eGUI)
      
      ret <- yourgraph.new(input.data=m)
    }
    sumcast <- function(){ }
    
    
    topmenu <- tkmenu(base)
    tkconfigure(base, menu=topmenu)
    dirmenu <- tkmenu(topmenu, tearoff=F)
    filemenu <- tkmenu(topmenu, tearoff=F)
    
    tkadd(dirmenu, "command", label= "Open...", command=open.dirs)
###    tkadd(dirmenu, "command", label= "link...", command=linkfiles)
    tkadd(dirmenu, "command", label="Quit",
          command=function() tkdestroy(base))
    
    tkadd(filemenu, "command", label= "Input Files...",
          command= open.files)
   
###    tkadd(openfile, "command", label= "Sim save.output...",
###          command= sim.output)
###    tkadd(filemenu, "command", label= "GUI-selections...",
###          command= out.GUIfile)
  
    exemenu <- tkmenu(topmenu, tearoff = F)
    runmenu <- tkmenu(exemenu, tearoff=F)
    summenu <- tkmenu(exemenu, tearoff = F)
    tkadd(runmenu, "command", label="yourcast...",
          command=mastercast)
    tkadd(runmenu, "command", label="yourgraph...",
          command=graphcast)
    
    tkadd(summenu, "command", label="Summary...", command= sumcast)
    tkadd(exemenu, "cascade", label="Run..",menu=runmenu)
    tkadd(exemenu,"cascade", label="Statistics...", menu=summenu)
    
    tkadd(topmenu, "cascade", label="Data-directory", menu=dirmenu)
    tkadd(topmenu, "command", label="Parameter-file", command=open.files)
###    tkadd(topmenu, "cascade", label="Parameter-file", menu=filemenu)
    tkadd(topmenu, "cascade", label="Execute", menu=exemenu)
### end of menu bar
    
    tkmaster <-  tkframe(base, relief = "groove", borderwidth = 1)
    
    frame1  <- tkframe(tkmaster, relief = "groove", borderwidth = 1)
    frame2 <- tkframe(tkmaster, relief = "groove", borderwidth = 0)
    
    frame3 <- tkframe(tkmaster, relief = "groove", borderwidth = 1)
    
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(txtoptions),fg="blue")
    frame1.label2 <- tklabel(frame1, textvariable = tclVar(txtmodel),fg="blue")
    frame1.label0 <-  tklabel(frame1, text = "  ")
    
    scr <- tkscrollbar(frame1, repeatinterval=6,
                       command=function(...)tkyview(frame1.lstbox1, ...))
    frame1.lstbox1 <- tklistbox(frame1, height=6, selectmode="single",
                                yscrollcommand=function(...)tkset(scr,...),
                                listvariable= categoryList, background="white")
    
    scr2 <- tkscrollbar(frame1, repeatinterval=4,
                        command=function(...)tkyview(frame1.lstbox2, ...))
    frame1.lstbox2 <- tklistbox(frame1, height=6, selectmode="single",
                                yscrollcommand=function(...)tkset(scr2,...),
                                listvariable= modelList, background="white")
    
    tkgrid(frame1.label1, frame1.label0, frame1.label2, sticky = "w")
    tkgrid(frame1.lstbox1, scr,frame1.lstbox2, scr2,sticky = "e")
    tkgrid.configure(scr, rowspan=5, sticky="nsw")
    tkgrid.configure(scr2, rowspan=5, sticky="nsw")
       
    tkbind(frame1.lstbox2, "<Double-Button-1>", function() {
      ret <- click.on.model(frame1.lstbox2)
      frm <- ret$top
      tops.open <- c(tops.open, list(frm))
      assign("tops.open", tops.open, env=eGUI)
    })
           
    tkbind(frame1.lstbox1, "<Double-Button-1>", function() {
      ewho <- get("ewho", env=eGUI)
      ret <- click.on.frame(frame1.lstbox1, ewho, model)
      frm <- ret$top
      tops.open <- c(tops.open, list(frm))
      assign("tops.open", tops.open, env=eGUI)})
    
    tkpack(frame1)
    frame21.separator <- tklabel(frame2,text="")
    frame21.label1 <- tklabel(frame2,text=txtoutput,fg="blue")
    frame22.separator <- tklabel(frame2,text="")
    frame22.label1 <- tklabel(frame2,text=txtreuse,fg="blue")
    frame23.label1 <- tklabel(frame2,text=txtoutfile,fg="blue")
    
    frame21.chkReuse   <- tkcheckbutton(frame2)
    frame22.chkSave   <- tkcheckbutton(frame2)
    frame23.chkGUI <- tkcheckbutton(frame2)
    
    tkconfigure(frame21.chkReuse, variable=chkReuse)
    tkconfigure(frame22.chkSave, variable=chkSave)
    tkconfigure(frame23.chkGUI, variable=chkGUI)
   
    
    tkbind(frame21.chkReuse,"<Button-1>", function(...){
      on.off <- as.character(tclvalue(chkReuse))
###      print(on.off)
      reuse.data <- ifelse(on.off == "0", T, F)
###      print(reuse.data)
      assign("reuse.data", reuse.data, env=eGUI)
      assign("reuse.data", reuse.data, env=ewho)
      assign("chkReuse", chkReuse, env=eGUI)
    })
   
    
    tkbind(frame22.chkSave,"<Button-1>", function(){
      on.off <- as.character(tclvalue(chkSave))
      save.output <- ifelse(on.off == "0", T, F)
      assign("save.output", save.output, env=eGUI)
      assign("save.output", save.output, env=ewho)
      assign("chkSave", chkSave,env=eGUI)
    })

      tkbind(frame23.chkGUI,"<Button-1>", function(...){
      on.off <- as.character(tclvalue(chkGUI))
###      print(on.off)
      save.GUI <- ifelse(on.off == "0", T, F)
###      print(reuse.data)
      assign("save.GUI", save.GUI, env=eGUI)
      assign("save.GUI", save.GUI, env=ewho)
      assign("chkGUI", chkGUI, env=eGUI)
    })
    
    tkgrid(frame22.label1,frame22.chkSave, sticky="e")
    tkgrid(frame21.label1, frame21.chkReuse, sticky="e")
    tkgrid(frame23.label1, frame23.chkGUI, sticky="e")
    tkpack(frame2)
    frame3.but0 <- tkbutton(frame3, textvariable =tclVar("Manual"),
                            padx = 20, command = soft.manual)
    
    frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"),
                            fg="red",padx = 20, command = master.close)
    
    frame3.but12 <- tkbutton(frame3, textvariable =tclVar("Clear"),
                             fg="blue",padx = 20, command = master.clear)
    
    frame3.but2 <- tkbutton(frame3, text = "Apply", padx = 20,command = master.init)   
    tkgrid(frame3.but0, frame3.but1, frame3.but12, frame3.but2, sticky = "w")
    tkpack(frame3)
###  tkpack(tkmaster)
    lst <- list(frame = tkmaster, envr = ewho)
    return(lst)
    
      }

yourcast.GUI <- function(){

  ewho <- set.defaults()

###  dirs <- directory.input.output();    
  base10 <- tktoplevel()
##  cat("Before anything...")
##  print(base10)
##  print(is.environment(base10))
  tkwm.title(base10,"YourCast")
  ret <- master.GUI(base10)
  frame10 <- ret$frame
  ewho <- ret$envr
  tkpack(frame10)
 return(ewho)
 }
   click.on.model <- function(lstbox) {
     ewho <- get("ewho", env=parent.frame())
     env.who <- ewho
     ret <-  -1
     
     if(length(as.numeric(tkcurselection(lstbox))) >0){
       ind.to.display <- as.numeric(tkcurselection(lstbox)) +1
    
        if(ind.to.display <= 1){
#### Model and years selection          
          base1 <- tktoplevel()
          frame1 <- fore(base1)
          tkwm.title(base1, "Forecasting Selections")
          tkpack(frame1)
          lst <- list(index=1, top=base1)
          return(lst)
          
        }else if(ind.to.display <= 2){
### CSTSID structure or digits container#####################
          base2 <- tktoplevel()
          frame2 <- digits(base2)
          tkwm.title(base2, "Index Variable")
          tkpack(frame2)  
          lst <- list(index=2, top=base2)
          return(lst)
          
        }else if(ind.to.display <= 3){
### choice of smoothing and Bayesian parameters
          base9 <- tktoplevel()
          frame9 <- bayes(base9)
          tkwm.title(base9,
                     "Bayesian Parameters")
          tkpack(frame9)
           lst <- list(index=3, top=base9)
          return(lst)    
        }else{
             print("No other selections")
          
           }
                          
     }
     lst <- list(index=ret, top=NULL)
     return(ret)
   }

click.on.frame <- function(lstbox, ewho,model){
  env.who <- ewho
  ewho <- get("ewho", env= parent.frame())
  ret  <- -1
  covdthRead <- get("covdthRead", env=ewho)
###  print(get("codes.names", env=ewho))
    if(length(as.numeric(tkcurselection(lstbox))) > 0){
        ind.to.display <- as.numeric(tkcurselection(lstbox)) +1
        if(ind.to.display <= 1){
### for depvar container
          base3 <- tktoplevel()
          frame3 <- depvar(base3)
          tkwm.title(base3, "Dependent Variable Selections")
          tkpack(frame3)
          lst <- list(index=1, top=base3)
          return(lst)
          
        }else if(ind.to.display <= 2){

### for country container
          data.path <- get("data.path", env=ewho)
          codes.names <- get("codes.names", env=ewho)
###          filename <- paste(data.path,codes.names,".txt", sep="")
          filename <- paste(data.path,codes.names, sep="")
###          print(filename)
###          if (!file.exists(filename)){
###            tkmessageBox(message=
###                         paste("File codes.names does not exist in", data.path));
###            return(0);
###          }
          base4 <- tktoplevel()
          frame4 <- cntryLst(base4)
          tkwm.title(base4, "Country Selections")
          tkpack(frame4)
          lst <- list(index=2, top=base4)
          return(lst)
                
        }else if(ind.to.display <= 3){
### for strata container
          base5 <- tktoplevel()
          frame5 <- strata.select(base5)
          tkwm.title(base5, "Strata & Agelike-group Selections")
          tkpack(frame5)
          lst <- list(index=3, top=base5)
          return(lst)
          
        }else if(ind.to.display <= 4){
### choice of covs and types
###          if (length(covdthRead) <= 0){
###              tkmessageBox(message="No files available")
###          return(list())
###        }
          base6 <-  tktoplevel()
          frame6 <- covtype(base6)
          tkwm.title(base6,
                     "Covariate Selection")
          tkpack(frame6)
          lst <- list(index=4, top=base6)
          return(lst)
           
        }else if(ind.to.display <= 5){
          ##covs and ages
 ###         if (length(covdthRead) <= 0){
 ###           tkmessageBox(message="No files available")
 ###           return(list())
 ###         }
          base7 <- tktoplevel()
          frame7 <- covage(base7)
          tkwm.title(base7, "Age Exclusion from Covariates")
          tkpack(frame7)
          lst <- list(index=5, top=base7)
          return(lst)
          
        }else if(ind.to.display <= 6){
### choice of parameters for covs      
          base8 <- tktoplevel()
          frame8 <- standard.cov(base8)
          tkwm.title(base8,
                     "Covariate Processing")
          tkpack(frame8)
          lst <- list(index=6, top=base8)
          return(lst)
          
        }else {
          print("No selection available")
        }       
       ret <- ind.to.display 
      }
  lst <- list(index=ret, top=NULL)
return(ret)
}


##
## FUNCTION NAME:    convert.to.vector 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## USED GLOBALS:
##
## DESCRIPTION: It gets a string of the form "c(1, 10, 20)" and converts into a vector.
##
## FORMAT:  convert.to.vector(string)
##         
##
## OUTPUT: Construct the R-vector to pass to GUI environmnet.
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 17/02/2005
## 
## ************************************************************************
## ************************************************************************

convert.to.vector <- function( str){
  str <- strsplit(str, "c\\(")[[1]][2]
  str <- strsplit(str, ")")[[1]]
  str <- strsplit(str, ",")[[1]]
  return(as.numeric(str))
}
  
                         
### Calling functions for all built frames.  Creates toplevel container to
### display all GUI's for each of the different selections and gives titles. 
     
   yourcast.GUI.old <- function(){
                         env.who <- set.defaults()
                         ewho <- env.who
                 ### for forecasting container
                         base1 <- tktoplevel()
                         frame1 <- fore(base1)
                         tkwm.title(base1, "Forecasting Selections")
                         tkpack(frame1)
                 ### for digits container
                         base2 <- tktoplevel()
                         frame2 <- digits(base2)
                         tkwm.title(base2, "CSTS Identifiers")
                         tkpack(frame2)
                  ### for depvar container
                         base3 <- tktoplevel()
                         frame3 <- depvar(base3)
                         tkwm.title(base3, "Dependent Variable Selections")
                         tkpack(frame3)
                  ### for country container
                         base4 <- tktoplevel()
                         frame4 <- cntryLst(base4)
                         tkwm.title(base4, "Country Selections")
                         tkpack(frame4)
                  ### for strata container
                         base5 <- tktoplevel()
                         frame5 <- strata.select(base5)
                         tkwm.title(base5, "Strata & Age Selections")
                         tkpack(frame5)
                   ### for cov age selection container
                         base6 <- tktoplevel()
                         frame6 <- covage(base6)
                    ##     frame6 <- get("tkcovage", env=ecov)
                         tkwm.title(base6, "Covariate & Age Selections")
                         tkpack(frame6)
                    ### choice of parameters for covs      
                         base7 <- tktoplevel()
                         frame7 <- standard.cov(base7)
                         tkwm.title(base7,
                                    "Processing Covariates Parameters")
                         tkpack(frame7)
                   ### choice of covs and types        
                         base8 <- tktoplevel()
                         frame8 <- covtype(base8)
                         tkwm.title(base8,
                                    "Choosing the Covariates")
                         tkpack(frame8)
                    ### choice of smoothing and Bayesian parameters
                         base9 <- tktoplevel()
                         frame9 <- bayes(base9)
                         tkwm.title(base9,
                                    "Bayesian Parameters")
                         tkpack(frame9)
                     ### master GUI
                         base10 <- tktoplevel()
                         frame10 <- master(base10)
                         tkwm.title(base10,
                                    "YourCast")
                         tkpack(frame10)
                         return(ewho)
                       }
  

