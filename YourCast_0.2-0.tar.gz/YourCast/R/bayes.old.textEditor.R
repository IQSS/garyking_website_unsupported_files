##
## DESCRIPTION:  Creates a GUI for Bayesian (Girosi-King models) parameters.
##               It has a top level menu bar with File as a choice.  The user
##               brings file menus dialog for zero.mean, bayes.zeromean,
##               and for Hct.c.deriv, bayes.adjacency.
##               After choosing a file for any of them it will displayed in a text box
##               for zero-mean and in the footer of the text area for Hct.c.deriv.
##               The apply buttom will copy the files to the directory prior.path or datapath,
##               if they are in a different directories so they can be found by yourcast. 
##               It has four check boxes that are turned on and off indicating whether 
##               smoothing is done for age (Ha.sigma), time (Hat.sigma), age-time (Hat.sigma),
##               and country-time (Hct.sigma).  They can all be on at the same time.
##               If any is off then the corresponding smoothing parameters is set to NA;
##               if it is turned on then the smoothing parameters takes a default value, which
##               presently is set to defVal=0.1.
##               The two radio buttons and the text box are for the parameter zero.mean,
##               which takes values True, False or the name of a file. The file name is
##               chosen with the File menu bar on the top of the GUI. 
##               The text display area from function showCovs() has a header with the
##               title and value of parameters (Scalar/Vector)
##               It has two columns displaying the names of Parameters,
##               and their values and, for the case of the BAYES model, it has
##               a footer for Hct.c.deriv, which displays the name of the file, default
##               adjacency.txt, which can be chosen with the File menu bar on the top of the GUI.
##               The text display area only shows those parameters that
##               are relevant to the smoothing choices.  For example, if Ha.sigma = 0.1
##               but Ht.sigma= NA, then text area only displays Ha.deriv, Ha.age.weight,
##               Ha.time.weight, and Ha.sigma.sd but it will not displayed any of
##               of the Ht.* parameters. The GUI has  three buttoms,
##               the Apply buttom, bayes.init, will write into memory the names of files 
##               chosen with the File menu and copy them in the prior.path or
##               datapath directories if they are located somewhere else.  
##               The Edit buttom, bayes.edit,  will bring the data editor,
##               which is the builtin R-GUI invoked with data.entry(mat).
##               You may change the parameters chosen for any of the
##               smoothing varaibles if they are turn on,
##               such Ha.deriv or Ha.age.weigth or any of the others, including Ha.sigma,
##               Ht.sigma, Hat.sigma, Hct.sigma which are always part of the data.entry.  
##               The editor has 4 columns, one for the name of the parameter, and three
##               for each of the component of the three dimensional vector. User may
##               enter each component in a different column or all in one as c(1, 4, 5).
##               Column that have no entries are ignored in the data processing or st to NA.\
##               Ther text for NA that is used for any of the (Ha|Ht|Hat|Hct.sigma) is also <NA>
##               The buttom Close, bayes.close,  quits the application
##               and writes new selections in memory.
##               You may also quit application with the menu bar, choice Quit..
##               Defaults values for smoothing parameters , anf files are in namelists().
##               New values are written in the environmnet env.who(ewho) and the calling environmnet.
##                 
## FORMAT: bayes(base, textvalues, defVal=0.1).  Here base is the tktoplevel container
##         to build the GUI, and textvalues are strings with the texts for the radio buttons,
##         check buttons, text boxes and areas and the buttons. The parameter defVal is the default
##         value assigned to Ha|Ht|Hat|Hct.sigma when their check boxes are turned on.
##         The parameter textna = <NA> is the default for NA. 
##
## IMPORTED functions:comboBox(), trim.blanks(), showCovs(),
##                    form.vector, vecloc, buildparameters, 
##                    construct.ha, construct.ht, construct.hat, construct.hct
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, any of the smoothing parameters or name of files  
##         can be changed or newly added with the GUI and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


 bayes.data.entry <- function(base, textsmooth = "Smooth Dependent Variable Over: ", 
                   textage ="Age Groups",
                   textime ="Time Trends",
                   textimeage = "Age & Time",
                   textcntry = "Geographical Index", 
                   textna = "<NA>", defVal=0.1,
                   zerotext = "Zero-mean Options ",
                   graphtext="Adjacency Matrix ")
                   {
    ewho <- get("ewho", env=parent.frame())
    Ha.sigma <- get("Ha.sigma", env=ewho)
    Ht.sigma <- get("Ht.sigma", env=ewho)
    Hat.sigma <- get("Hat.sigma", env=ewho)
    Hct.sigma <- get("Hct.sigma", env=ewho)
    zero.mean <- get("zero.mean", env=ewho)
    zero.mean0 <- zero.mean
    Ha.sigma.sd <- get("Ha.sigma.sd", env=ewho)
    Ha.sigma.sd0 <- Ha.sigma.sd
    Ha.deriv <- get("Ha.deriv", env=ewho)
    Ha.deriv0 <- Ha.deriv 
    Ha.age.weight   <- get("Ha.age.weight", env=ewho)
    Ha.age.weight0 <-  Ha.age.weight 
    Ha.time.weight  <- get("Ha.time.weight", env=ewho)
    Ha.time.weight0 <- Ha.time.weight
    Ht.sigma.sd <- get("Ht.sigma.sd", env=ewho)
    Ht.sigma.sd0 <-  Ht.sigma.sd
    Ht.deriv <- get("Ht.deriv", env=ewho)
    Ht.deriv0 <-  Ht.deriv
    Ht.age.weight   <- get("Ht.age.weight", env=ewho)
    Ht.age.weight0 <- Ht.age.weight 
    Ht.time.weight  <- get("Ht.time.weight", env=ewho)
    Ht.time.weight0 <-  Ht.time.weight 
    Hat.sigma.sd <- get("Hat.sigma.sd", env=ewho)
    Hat.sigma.sd0 <-  Hat.sigma.sd 
    Hat.a.deriv <- get("Hat.a.deriv", env=ewho)
    Hat.a.deriv0 <-  Hat.a.deriv 
    Hat.t.deriv <- get("Hat.t.deriv", env=ewho)
    Hat.t.deriv0 <- Hat.t.deriv
    Hat.age.weight   <- get("Hat.age.weight", env=ewho)
    Hat.age.weight0 <-   Hat.age.weight
    Hat.time.weight  <- get("Hat.time.weight", env=ewho)
    Hat.time.weight0 <-  Hat.time.weight
    Hct.sigma.sd <- get("Hct.sigma.sd", env=ewho)
    Hct.sigma.sd0 <-  Hct.sigma.sd 
    Hct.c.deriv <- get("Hct.c.deriv", env=ewho)
    Hct.c.deriv0 <- Hct.c.deriv
    Hct.t.deriv <- get("Hct.t.deriv", env=ewho)
    Hct.t.deriv0 <-  Hct.t.deriv 
    Hct.time.weight   <- get("Hct.time.weight", env=ewho)
    Hct.time.weight0 <-  Hct.time.weight 
    lnchar <- nchar("Hct.time.weight")
    model <- get("model", env=ewho)
    nsample  <- get("nsample", env=ewho)
    LI.sigma.mean <- get("LI.sigma.mean", env=ewho)
    LI.sigma.sd <- get("LI.sigma.sd", env=ewho)
    prior.path <- get("prior.path", env=ewho)
    data.path <- get("data.path", env=ewho)
    vargraph <- tclVar("adjacency.txt")
    restore.defaults <- F
    ft <- ifelse(toupper(trim.blanks(model)) != "MAP", T, F)
    if (toupper(trim.blanks(model)) != "MAP")
      colnamebar <- c("top", "bottom")
    else
      colnamebar <- "top"
      
    fentry <- "Hct.c.deriv"
    ftext <- as.character(tclvalue(vargraph))
    zero.mean.chk <- F
    adjacency.chk <- F
    ha  <- ifelse(is.na(Ha.sigma),textna, Ha.sigma)
    ht  <- ifelse(is.na(Ht.sigma),textna, Ht.sigma)
    hat <- ifelse(is.na(Hat.sigma),textna, Hat.sigma)
    hct <- ifelse(is.na(Hct.sigma),textna, Hct.sigma)
    varzero <- tclVar("")
  
    
    rbValue <- tclVar("True")
    localpar <- list(Ha.sigma=ha, Ht.sigma=ht,Hat.sigma=hat)
    if(toupper(trim.blanks(model)) != "MAP") 
     localpar <- c(localpar, list(Hct.sigma=hct))
                          
    V1 <- vecloc(1, par=localpar) 
    V2 <- vecloc(2, par=localpar)
    V3 <- vecloc(3, par=localpar)
        
    lst.todisplay <- list(Parameters=names(localpar),
                          V1=V1 , V2=V2 , V3=V3 )
    if(toupper(trim.blanks(model)) == "MAP")
       Hct.sigma <- NA
    
    eGUI <- environment()
    datamat <- ncol(2)
    
    bayes.close <- function(...) {
      lst.todisplay <- get("lst.todisplay", env=eGUI)
      Ha.sigma <- get("Ha.sigma", env=eGUI)
      Ht.sigma <- get("Ht.sigma", env=eGUI)
      Hat.sigma <- get("Hat.sigma", env=eGUI)
      Hct.sigma <- get("Hct.sigma", env=eGUI)
      Ha.sigma.sd <- get("Ha.sigma.sd", env=eGUI)
      Ha.deriv <- get("Ha.deriv", env=eGUI)
      Ha.age.weight   <- get("Ha.age.weight", env=eGUI)
      Ha.time.weight  <- get("Ha.time.weight", env=eGUI)
      Ht.sigma.sd <- get("Ht.sigma.sd", env=eGUI)                        
      Ht.deriv <- get("Ht.deriv", env=eGUI)
      Ht.age.weight   <- get("Ht.age.weight", env=eGUI)
      Ht.time.weight  <- get("Ht.time.weight", env=eGUI)
      Hat.sigma.sd <- get("Hat.sigma.sd", env=eGUI)                        
      Hat.a.deriv <- get("Hat.a.deriv", env=eGUI)
      Hat.t.deriv <- get("Hat.t.deriv", env=eGUI)
      Hat.age.weight   <- get("Hat.age.weight", env=eGUI)
      Hat.time.weight  <- get("Hat.time.weight", env=eGUI)
      Hct.sigma.sd <- get("Hct.sigma.sd", env=eGUI)
      Hct.c.deriv <- get("Hct.c.deriv", env=eGUI)
      Hct.t.deriv <- get("Hct.t.deriv", env=eGUI)
      Hct.time.weight   <- get("Hct.time.weight", env=eGUI)
      nsample <- get("nsample", env=eGUI)
      LI.sigma.mean <- get("LI.sigma.mean", env=eGUI)
      LI.sigma.sd <- get("LI.sigma.sd", env=eGUI)
      assign("Hct.c.deriv", Hct.c.deriv, env=ewho)
      assign("zero.mean", zero.mean, env=ewho)

      vecnames <- lst.todisplay$Parameters
      v1 <- lst.todisplay$V1
      v2 <- lst.todisplay$V2
      v3 <- lst.todisplay$V3
      lst <- buildparameters(param=vecnames, v1=v1, v2=v2, v3=v3,
                               miss=textna)
  
      localpar <- names(lst.todisplay$Parameters)
      count <- 0
           
      for(ch in vecnames){
        count <-  count + 1
        chm   <- paste("^",ch,"$",sep="")
        indx  <- grep(chm, names(lst))
        val   <- lst[[count]]
        for(i in (1:length(val))){
          x <- trim.blanks(val[i])
          if(x== "")
           val[i] <- NA
        }
        val <- na.omit(val)
        inc <- unlist(sapply("c",grep,val))
        if(length(val) <= 0 )
          val <- NA
        else if(length(val) <= 1 && length(inc) <= 0)
          val <- as.numeric(val[1])
        else if (length(val) <= 1){
          val <- gsub("c.", "", val)
          val <- gsub(".$", "", val)
          val <- as.numeric(strsplit(val,",")[[1]])
        } else{
        vec <-  NULL
        for(i in (1:length(val)))
          vec <- c(vec, as.numeric(val[i]))
        val <- vec}
      if(identical(trim.blanks(ch), "Hct.c.deriv")){
        assign(eval(ch),Hct.c.deriv,envir=environment())
        assign(eval(ch),Hct.c.deriv,envir=eGUI)
        assign(eval(ch),Hct.c.deriv,envir=get("ewho", env=eGUI))
      }else{
        assign(eval(ch),val,envir=environment())
        assign(eval(ch),val,envir=eGUI)
        assign(eval(ch),val,envir=get("ewho", env=eGUI))
      }
          
      }
   ### good order for NA's
      
      if (restore.defaults && is.na(Ha.sigma)){
        assign("Ha.sigma.sd", Ha.sigma.sd0, env=ewho)
        assign("Ha.deriv", Ha.deriv0, env=ewho)
        assign("Ha.age.weight",Ha.age.weight0, env=ewho)
        assign("Ha.time.weight",  Ha.time.weight0, env=ewho)}
       if (restore.defaults && is.na(Ht.sigma)){
        assign("Ht.sigma.sd", Ht.sigma.sd0, env=ewho)
        assign("Ht.deriv", Ht.deriv0, env=ewho)
        assign("Ht.age.weight",Ht.age.weight0, env=ewho)
        assign("Ht.time.weight",  Ht.time.weight0, env=ewho)}
       if (restore.defaults && is.na(Hat.sigma)){
        assign("Hat.sigma.sd", Hat.sigma.sd0, env=ewho)
        assign("Hat.a.deriv", Hat.a.deriv0, env=ewho)
        assign("Hat.t.deriv", Hat.t.deriv0, env=ewho)
        assign("Hat.age.weight",Hat.age.weight0, env=ewho)
        assign("Hat.time.weight",  Hat.time.weight0, env=ewho)}
       if (restore.defaults && is.na(Hct.sigma)){
        assign("Hct.sigma.sd", Hct.sigma.sd0, env=ewho)
        assign("Hct.c.deriv", Hat.c.deriv0, env=ewho)
        assign("Hct.t.deriv", Hct.t.deriv0, env=ewho)
        assign("Hct.time.weight",  Hct.time.weight0, env=ewho)}
                
      tkdestroy(base)
    }

    bayes.init <- function(...) {
      prior.path <- get("prior.path", env=eGUI)
      
      if (zero.mean.chk){
        filezero.mean <- get("filezero.mean", env=eGUI)
        ff <- strsplit(filezero.mean,"/")[[1]]
        zerofile <- ff[length(ff)]
        destfile <- paste(prior.path,zerofile, sep="")
        res <- readLines(pipe(paste("cp", filezero.mean, destfile)))
        zero.mean.chk <- F
        assign("zero.mean.chk", zero.mean.chk, env=eGUI) 
        assign("zero.mean", zerofile, env=eGUI)
        assign("zero.mean", zerofile,envir=get("ewho", env=eGUI))}
      
      if (adjacency.chk){  
        filadjacency <-  get("filadjacency", env=eGUI)
        ff <- strsplit(filadjacency,"/")[[1]]
        adjfile <- ff[length(ff)]
        destfile <- paste(prior.path,adjfile, sep="")
        res <- readLines(pipe(paste("cp", filadjacency, destfile)))
        adjacency.chk <- F
        assign("adjacency.chk", adjacency.chk, env=eGUI)
        assign("ftext", adjfile, env=eGUI)
        assign("Hct.c.deriv", adjfile, env=eGUI)
        assign("Hct.c.deriv", adjfile, envir=get("ewho", env=eGUI))
      }
###      cat("zero.mean is ", get("zero.mean", env=eGUI), "\n")
###      cat("Hct.c.deriv is ", get("Hct.c.deriv", env=eGUI), "\n")
    }
    
    bayes.edit <- function(...){
        ewho <- get("ewho", env=eGUI)
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        model <- get("model", env=get("ewho", env=eGUI))
        
        indx <- grep("^Hct.c.deriv$", lst.todisplay$Parameters)
        if(length(indx) > 0){
         lst.todisplay$Parameters <- lst.todisplay$Parameters[-indx]
         lst.todisplay$V1 <-  lst.todisplay$V1[-indx]
         lst.todisplay$V2 <-  lst.todisplay$V2[-indx]
         lst.todisplay$V3 <-  lst.todisplay$V3[-indx]
       }
        param <- lst.todisplay$Parameters
        v1 <-  lst.todisplay$V1
        ind <- grep("^Ha.sigma$", param)
        old.ha.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Ht.sigma$", param)
        old.ht.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Hat.sigma$", param)
        old.hat.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Hct.sigma$", param)
        old.hct.sigma <- trim.blanks(v1[ind])
        if( model == "BAYES"){
        ind <- grep("LI.sigma.mean", param)
        old.LI.sigma.mean <- trim.blanks(v1[ind])
        ind <- grep("LI.sigma.sd", param)
        old.LI.sigma.sd <- trim.blanks(v1[ind])
         ind <- grep("nsample", param)
        old.nsample <- trim.blanks(v1[ind])}
#### Display it !!!        
         data.entry(lst.todisplay)
### now lst.todisplay in in the .GlobalEnv, get it from there
        lst.todisplay <- get("lst.todisplay", env=.GlobalEnv)
       
        pos <- match(".GlobalEnv", search())
        rm(lst.todisplay, envir=as.environment(pos))
    
        param <- lst.todisplay$Parameters
        v1 <-  lst.todisplay$V1
        v2 <-  lst.todisplay$V2
        v3 <-  lst.todisplay$V3
        
      vecnames <- lst.todisplay$Parameters
   
      lst <- buildparameters(param=vecnames, v1=v1, v2=v2, v3=v3,
                               miss=textna)
  
      localpar <- names(lst.todisplay$Parameters)
      count <- 0
           
      for(ch in vecnames){
        count <-  count + 1
        chm   <- paste("^",ch,"$",sep="")
        indx  <- grep(chm, names(lst))
        val   <- lst[[count]]
        for(i in (1:length(val))){
          x <- trim.blanks(val[i])
          if(x== "")
           val[i] <- NA
        }
        val <- na.omit(val)
        inc <- unlist(sapply("c",grep,val))
        if(length(val) <= 0 )
          val <- NA
        else if(length(val) <= 1 && length(inc) <= 0)
          val <- as.numeric(val[1])
        else if (length(val) <= 1){
          
          val <- gsub("c.", "", val)
          val <- gsub(".$", "", val)
          val <- as.numeric(strsplit(val,",")[[1]])
        } else{
        vec <-  NULL
        for(i in (1:length(val)))
          vec <- c(vec, as.numeric(val[i]))
        val <- vec}
      
      assign(ch,val,envir=environment())
      assign(ch,val,envir=eGUI)
      assign(ch,val,envir=get("ewho", env=eGUI)) 
      }
     
     
        ind <- grep("^Ha.sigma$", param)
        new.ha.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Ht.sigma$", param)
        new.ht.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Hat.sigma$", param)
        new.hat.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Hct.sigma$", param)
        new.hct.sigma <- trim.blanks(v1[ind])
        ind <- grep("^LI.sigma.mean$", param)
        if(model == "BAYES") {
           ind <- grep("^LI.sigma.mean$", param)
          new.LI.sigma.mean <- trim.blanks(v1[ind])
            ind <- grep("^LI.sigma.sd$", param)
          new.LI.sigma.sd <- trim.blanks(v1[ind])
            ind <- grep("^nsample$", param)
          new.nsample <- trim.blanks(v1[ind])
         }

      new.ha.sigma <- ifelse(identical(new.ha.sigma, textna), NA,new.ha.sigma)
      new.ha.sigma <- ifelse(identical(new.ha.sigma, "NA"), NA,new.ha.sigma)
      old.ha.sigma <- ifelse(identical(old.ha.sigma, textna), NA,old.ha.sigma)
      old.ha.sigma <- ifelse(identical(old.ha.sigma, "NA"), NA,old.ha.sigma)
        
      iguales <- identical(new.ha.sigma, old.ha.sigma)
      na.new.ha <- (length(new.ha.sigma) <= 0 || is.na(new.ha.sigma))
      na.old.ha <- (length(old.ha.sigma) <= 0 || is.na(old.ha.sigma))
        if( na.new.ha && !iguales){
            chk1Value <- tclVar("0")
            assign("chk1Value", chk1Value, env=eGUI)
            assign("Ha.sigma", NA, env=eGUI)
            assign("Ha.sigma", NA, env=ewho)
            tkconfigure(frame1.chk1, variable=chk1Value)
            indx <- sapply("^Ha.",grep,param)
            noix <- sapply("^Hat",grep,param)    
            noix <- sapply(paste("^",as.character(noix),"$",sep=""),grep,
                     as.character(indx))
            if(length(noix) > 0)
              indx <- indx[-noix]
            if(length(indx) > 0)
              indx <- indx[-1]
            if(length(indx) > 0){
              param <- param[-indx]
              v1 <- v1[-indx]
              v2 <- v2[-indx]
              v3 <- v3[-indx]}
          
            lst.todisplay$Parameters <- param
            lst.todisplay$V1 <- v1
            lst.todisplay$V2 <- v2 
            lst.todisplay$V3 <- v3
      
            V1 <-  lst.todisplay$V1
            V2 <-  lst.todisplay$V2
            V3 <-  lst.todisplay$V3
            lst <- as.list(1:length(param))
            names(lst) <- param
            localpar <- lapply(lst, function(n,V1,V2,V3){
              v1 <- V1[n]
              v2 <- V2[n]
              v3 <- V3[n]
              return(c(v1,v2,v3))},V1,V2,V3)
               
            assign("localpar",localpar, env=eGUI) 
          }
        if(!na.new.ha) {
          chk1Value <- tclVar("1")
          assign("chk1Value", chk1Value, env=eGUI)
          assign("Ha.sigma", as.numeric(new.ha.sigma), env=eGUI)
          assign("Ha.sigma", as.numeric(new.ha.sigma), env=ewho)
          tkconfigure(frame1.chk1, variable=chk1Value)
          construct.ha(eGUI)
                   
          localpar <- get("localpar", env=eGUI)
          lst.todisplay <- get("lst.todisplay", env=eGUI)
          datamat <- get("datamat", env=eGUI)
      
        }
       
      
      new.ht.sigma <- ifelse(identical(new.ht.sigma, textna), NA,new.ht.sigma)
      new.ht.sigma <- ifelse(identical(new.ht.sigma, "NA"), NA,new.ht.sigma)
      old.ht.sigma <- ifelse(identical(old.ht.sigma, textna), NA,old.ht.sigma)
      old.ht.sigma <- ifelse(identical(old.ht.sigma, "NA"), NA,old.ht.sigma)
      iguales <- identical(new.ht.sigma, old.ht.sigma)
      na.new.ht <- (length(new.ht.sigma) <= 0 || is.na(new.ht.sigma))
      na.old.ht <- (length(old.ht.sigma) <= 0 || is.na(old.ht.sigma))
    if (na.new.ht && !iguales){
            chk2Value <- tclVar("0")
            assign("chk2Value", chk2Value, env=eGUI)
            assign("Ht.sigma", NA, env=eGUI)
            tkconfigure(frame1.chk2, variable=chk2Value)
            indx <- sapply("^Ht.",grep,param)
            if(length(indx) > 0)
              indx <- indx[-1]
            if(length(indx) > 0){
              param <- param[-indx]
              v1 <- v1[-indx]
              v2 <- v2[-indx]
              v3 <- v3[-indx]}
            lst.todisplay$Parameters <- param
            lst.todisplay$V1 <- v1
            lst.todisplay$V2 <- v2 
            lst.todisplay$V3 <- v3
          
            V1 <-  lst.todisplay$V1
            V2 <-  lst.todisplay$V2
            V3 <-  lst.todisplay$V3
            lst <- as.list(1:length(param))
            names(lst) <- param
            localpar <- lapply(lst, function(n,V1,V2,V3){
              v1 <- V1[n]
              v2 <- V2[n]
              v3 <- V3[n]
              return(c(v1,v2,v3))},V1,V2,V3)
               
            assign("localpar",localpar, env=eGUI) 
          }
      if(!na.new.ht){

            chk2Value <- tclVar("1")
            assign("chk2Value", chk2Value, env=eGUI)
            assign("Ht.sigma", as.numeric(new.ht.sigma), env=eGUI)
            assign("Ht.sigma", as.numeric(new.ht.sigma), env=ewho)
            tkconfigure(frame1.chk2, variable=chk2Value)
            datamat <- construct.ht(eGUI)
            assign("datamat", datamat, env=eGUI)
            localpar <- get("localpar", env=eGUI)
            lst.todisplay <- get("lst.todisplay", env=eGUI)
          }
 
 
    new.hat.sigma <- ifelse(identical(new.hat.sigma, textna), NA,new.hat.sigma)
    new.hat.sigma <- ifelse(identical(new.hat.sigma, "NA"), NA,new.hat.sigma)
    old.hat.sigma <- ifelse(identical(old.hat.sigma, textna), NA,old.hat.sigma)
    old.hat.sigma <- ifelse(identical(old.hat.sigma, "NA"), NA,old.hat.sigma)
    iguales <- identical(new.hat.sigma, old.hat.sigma)
    na.new.hat <- (length(new.hat.sigma) <= 0 || is.na(new.hat.sigma))
    na.old.hat <- (length(old.hat.sigma) <= 0 || is.na(old.hat.sigma))
    if (na.new.hat && !iguales){
                  
          chk3Value <- tclVar("0")
          assign("chk3Value", chk3Value, env=eGUI)
          assign("Hat.sigma", NA, env=eGUI)
          tkconfigure(frame1.chk3, variable=chk3Value)
          indx <- sapply("^Hat.",grep,param)
          if(length(indx) > 0)
            indx <- indx[-1]
        
          if(length(indx) > 0 && !is.na(indx)){
              param <- param[-indx]
              v1 <- v1[-indx]
              v2 <- v2[-indx]
              v3 <- v3[-indx]}
          
          lst.todisplay$Parameters <- param
          lst.todisplay$V1 <- v1
          lst.todisplay$V2 <- v2 
          lst.todisplay$V3 <- v3
          V1 <-  lst.todisplay$V1
          V2 <-  lst.todisplay$V2
          V3 <-  lst.todisplay$V3
          
          lst <- as.list(1:length(param))
          names(lst) <- param
          localpar <- lapply(lst, function(n,V1,V2,V3){
            v1 <- V1[n]
            v2 <- V2[n]
            v3 <- V3[n]
            return(c(v1,v2,v3))},V1,V2,V3)
               
          assign("localpar",localpar, env=eGUI) 
        }
      if(!na.new.hat){
         
          chk3Value <- tclVar("1")
          assign("chk3Value", chk3Value, env=eGUI)
          assign("Hat.sigma", as.numeric(new.hat.sigma), env=eGUI)
          assign("Hat.sigma", as.numeric(new.hat.sigma), env=ewho)
          tkconfigure(frame1.chk3, variable=chk3Value)
          datamat <- construct.hat(eGUI)
          assign("datamat", datamat, env=eGUI)
          localpar <- get("localpar", env=eGUI)
          lst.todisplay <- get("lst.todisplay", env=eGUI)
        } 
 
    new.hct.sigma <- ifelse(identical(new.hct.sigma, textna), NA,new.hct.sigma)
    new.hct.sigma <- ifelse(identical(new.hct.sigma, "NA"), NA,new.hct.sigma)
    old.hct.sigma <- ifelse(identical(old.hct.sigma, textna), NA,old.hct.sigma)
    old.hct.sigma <- ifelse(identical(old.hct.sigma, "NA"), NA,old.hct.sigma)
    iguales <- identical(new.hct.sigma, old.hct.sigma)
    na.new.hct <- (length(new.hct.sigma) <= 0 || is.na(new.hct.sigma))
    na.old.hct <- (length(old.hct.sigma) <= 0 || is.na(old.hct.sigma))
        
    if(na.new.hct &&!iguales){
         
          chk4Value <- tclVar("0")
          assign("chk4Value", chk4Value, env=eGUI)
          assign("Hct.sigma", NA, env=eGUI)
          tkconfigure(frame1.chk4, variable=chk4Value)
          indx <- sapply("^Hct.",grep,param)
          if(length(indx) > 0)
            indx <- indx[-1]
          if(length(indx) > 0){
          param <- param[-indx]
          v1 <- v1[-indx]
          v2 <- v2[-indx]
          v3 <- v3[-indx]}
          lst.todisplay$Parameters <- param
          lst.todisplay$V1 <- v1
          lst.todisplay$V2 <- v2 
          lst.todisplay$V3 <- v3
          V1 <-  lst.todisplay$V1
          V2 <-  lst.todisplay$V2
          V3 <-  lst.todisplay$V3
          lst <- as.list(1:length(param))
          names(lst) <- param
          localpar <- lapply(lst, function(n,V1,V2,V3){
            v1 <- V1[n]
            v2 <- V2[n]
            v3 <- V3[n]
            return(c(v1,v2,v3))},V1,V2,V3)
               
          assign("localpar",localpar, env=eGUI) 
        }
   if(!na.new.hct){
         
          chk4Value <- tclVar("1")
          assign("chk4Value", chk4Value, env=eGUI)
          assign("Hct.sigma", as.numeric(new.hct.sigma), env=eGUI)
          assign("Hct.sigma", as.numeric(new.hct.sigma), env=ewho)
          tkconfigure(frame1.chk4, variable=chk4Value)
          datamat <- construct.hct(eGUI)
          assign("datamat", datamat, env=eGUI)
          localpar <- get("localpar", env=eGUI)
          lst.todisplay <- get("lst.todisplay", env=eGUI)
        }
        if(identical(toupper(trim.blanks(model)),"BAYES"))
          {
          datamat <- construct.LI.sigma.nsample(eGUI)
          assign("datamat", datamat, env=eGUI)
          localpar <- get("localpar", env=eGUI)
          lst.todisplay <- get("lst.todisplay", env=eGUI)
        }
              
                                
        vecnames <- lst.todisplay$Parameters
        v1 <- lst.todisplay$V1
        v2 <- lst.todisplay$V2
        v3 <- lst.todisplay$V3
        lst <- buildparameters(param=vecnames, v1=v1, v2=v2, v3=v3,
                               miss=textna)
  
        localpar <- names(lst.todisplay$Parameters)
        
        count <- 0
        totix <- vector(mode="integer", length=0)
       
        for(ch in vecnames){
          count <-  count + 1
          chm   <- paste("^",ch,"$",sep="")
          indx  <- grep(chm, names(lst))
          val   <- lst[[count]]
          for(i in (1:length(val))){
         x <- trim.blanks(val[i])
         if(x== "")
           val[i] <- NA
         }
          val <- na.omit(val)
         if(length(val) <= 0 )
           val <- NA
         else if(length(val) <= 1)
           val <- val[1]
         else {
            res <-  "c("
            for(i in (1:length(val)))
              if(i < length(val))
                res <- paste(res,val[i],", ",sep="")
              else
                val <- paste(res,val[i],")")
          }
        
          ix <- grep(chm, datamat[,1])
          if(length(ix) > 0){
            totix <- c(totix,ix)
            datamat[ix,2] <- ifelse(is.na(val),textna,val)
          }
          
          assign(eval(ch),val)
          assign(eval(ch),val,envir=eGUI)
          assign(eval(ch),val,envir=get("ewho", env=eGUI))
        }
     
     
         datamat <- datamat[totix,];

         cnames <- c("Parameters", "Values")
         colnames(datamat) <- cnames
         namerows <- datamat[,1]
         dataframe <- data.frame(datamat)
         row.names(dataframe) <- namerows
         colnames(dataframe) <- c("Parameters", "Scalar/Vector")
         ftext <- get("ftext", env=eGUI)
         fentry <- get("fentry", env=eGUI)
       
         dataframe <- showCovs(dataframe[-1], base=frame2,
                          titletext= colnames(dataframe)[1], vechar =lnchar,
                          footer=ft, footerentry=fentry,
                          footertext=ftext,
                          colname.bar=colnamebar)
             
        assign("dataframe", dataframe, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)
        
      }
    bayes.zeromean <- function(...){
      filename <- tclvalue(tkgetOpenFile())
      if (!nchar(filename))
        tkmessageBox(message="No file selected")
      else{
        tkmessageBox(message=paste("File selected is\n",filename ))
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        filezero.mean <- filename 
        assign("filezero.mean", filename, env=eGUI)
        varzero <- tclVar(lst[ix])
        tkconfigure(frame12.entry, bg="white",textvariable=varzero )
        zero.mean.chk <- T
        assign("zero.mean.chk", T, env=eGUI)
      }
    }
    bayes.adjacency <- function(...){
      filename <- tclvalue(tkgetOpenFile())
      if (!nchar(filename))
        tkmessageBox(message="No file selected")
      else{
        tkmessageBox(message=paste("File selected is\n",filename ))
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        filadjacency <- filename 
        assign("filadjacency", filename, env=eGUI)
        varzero <- tclVar(lst[ix])
        datamat <- get("datamat", env=eGUI)
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        ff <- strsplit(filadjacency,"/")[[1]]
        adjfile <- NULL
        if(length(ff) > 0)
          adjfile <- ff[length(ff)]
        ftext <- adjfile
        fentry <- get("fentry", env=eGUI)
        dataframe <- showCovs(dataframe[-1], base=frame2,
                          titletext= colnames(dataframe)[1], vechar =lnchar,
                          footer=ft, footerentry=fentry,
                          footertext=ftext,
                          colname.bar=colnamebar)
        adjacency.chk <- T
        assign("adjacency.chk", T, env=eGUI)
       
      }
    }
   
    
### adding a menu bar to the top of the container  
    topmenu <- tkmenu(base)
    tkconfigure(base, menu=topmenu)
    filemenu <- tkmenu(topmenu, tearoff=F)
    openfiles <- tkmenu(filemenu,  tearoff=F)
    savefiles <- tkmenu(filemenu, tearoff=F)
  
    tkadd(openfiles, "command", label= "Open Zero-mean...",
          command=bayes.zeromean)
    tkadd(openfiles, "command", label= "Open Adjacency-matrix...",
          command=bayes.adjacency)
   
    tkadd(savefiles, "command", label="Save Files ", command=bayes.edit)
  
    tkadd(filemenu, "cascade", label= "Open...", menu=openfiles)
    tkadd(filemenu, "cascade", label= "Save...", menu=savefiles)
    tkadd(filemenu, "command", label="Quit",
          command=function() tkdestroy(base))
    tkadd(topmenu, "cascade", label="File", menu=filemenu)
### end of menu bar
    
    tkbayes <- tkframe(base, relief = "groove", borderwidth = 2)

    frame1 <- tkframe(tkbayes, relief = "groove", borderwidth = 0)
    frame2 <- tkframe(tkbayes, relief = "groove", borderwidth = 1)
    frame3 <- tkframe(tkbayes, relief = "groove", borderwidth = 1)
    frame23 <- tkframe(tkbayes, relief = "groove", borderwidth = 1)
    frame12 <- tkframe(tkbayes, relief = "groove", borderwidth = 2)
    frame1.label0 <- tklabel(frame1, textvariable = tclVar(textsmooth),
                             fg="blue")
    tkgrid(frame1.label0, sticky="w")
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(textage),
                             fg="black")
    frame1.chk1 <- tkcheckbutton(frame1)
    if (is.na(Ha.sigma) || length(Ha.sigma) <= 0)
      chk1Value <- tclVar("0")
    else
      chk1Value <- tclVar("1")
    
    chk1 <- as.numeric(tclvalue(chk1Value))
    tkbind(frame1.chk1, "<Button-1>",  function() {
        
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        datamat <- get("datamat", env=eGUI)
        Ha.sigma <- get("Ha.sigma", env=eGUI)
        model <- get("model", env=eGUI)
        frame2 <- get("frame2", env=eGUI)   
        chk1Value <- get("chk1Value", env=eGUI)
        localpar <- get("localpar",env=eGUI)
        
        chk1 <- as.numeric(tclvalue(chk1Value))
        chk1 <- ifelse(chk1 <= 0,1,0)
        Ha.sigma <- ifelse(chk1  >= 1, defVal, NA)
        assign("Ha.sigma", Ha.sigma, env=eGUI)
        ix <- grep("^Ha.sigma$", datamat[,1])
        if(!is.na(Ha.sigma))
          datamat[ix,2] <- form.vector(Ha.sigma)
        else
          datamat[ix,2] <- textna
      
        if ( !is.na(Ha.sigma)){
            Ha.deriv <- get("Ha.deriv", env=eGUI)
            Ha.age.weight <- get("Ha.age.weight", env=eGUI)
            Ha.time.weight <- get("Ha.time.weight", env=eGUI)
            Ha.sigma.sd <- get("Ha.sigma.sd", env=eGUI)
          
            if(toupper(trim.blanks(model)) != "MAP")
            datamat <- rbind(datamat,
                         c("Ha.sigma.sd",form.vector(Ha.sigma.sd)))
            datamat <- rbind(datamat, c("Ha.deriv",
                                        form.vector(Ha.deriv)))
            datamat <- rbind(datamat, c("Ha.age.weight",
                                        form.vector(Ha.age.weight)))
            datamat <- rbind(datamat, c("Ha.time.weight",
                                        form.vector(Ha.time.weight)))
            localpar <- c(localpar, list(Ha.deriv=Ha.deriv),
                          list(Ha.age.weight=Ha.age.weight),
                          list(Ha.time.weight=Ha.time.weight))
       
            if(toupper(trim.blanks(model)) != "MAP")
              localpar <- c(localpar, list(Ha.sigma.sd=Ha.sigma.sd))
         
          }else{
            ixtodelete <- grep("^Ha.sigma.sd$", names(localpar))
            if(length(ixtodelete) > 0)
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ha.deriv", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ha.age.weight", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ha.time.weight", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            
            ixtodelete <- grep("^Ha.sigma.sd$", datamat[,1])
            if(length(ixtodelete) > 0)
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ha.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ha.age.weight", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ha.time.weight", datamat[,1])
            if(!is.na(ixtodelete))
               datamat <- datamat[-ixtodelete,]
          }
        
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
        lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("Ha.sigma", lst.todisplay$Parameters)
        if(length(indx) > 0){
          localpar[indx] <- ifelse(chk1  >= 1, defVal,NA)
          lst.todisplay$V1[indx] <- ifelse(chk1  >= 1, defVal,textna)
        }else
          print("Index for Ha.sigma not found in lst.todisplay")
        
        cnames <- c("Parameters", "Values")
        colnames(datamat) <- cnames
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        ftext <- get("ftext", env=eGUI)
        fentry <- get("fentry", env=eGUI)
        dataframe <- showCovs(dataframe[-1], base=frame2,
                          titletext= colnames(dataframe)[1], vechar =lnchar,
                          footer=ft, footerentry=fentry,
                          footertext=ftext,
                          colname.bar=colnamebar)
             
        assign("dataframe", dataframe, env=eGUI)
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)
        
      })
 
 
    tkconfigure(frame1.chk1, variable=chk1Value)
    tkgrid(frame1.label1, frame1.chk1, sticky = "w")
    
    frame1.label2 <-  tklabel(frame1, textvariable = tclVar(textime),
                             fg="black")
    frame1.chk2 <- tkcheckbutton(frame1)
    chk2 <- 0
    if (is.na(Ht.sigma) || length(Ht.sigma) <= 0)
      chk2Value <- tclVar("0")
    else{
      chk2Value <- tclVar("1")
      chk2 <- 1}
    
    tkbind(frame1.chk2, "<Button-1>",  function() {
        
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        datamat <- get("datamat", env=eGUI)
        Ht.sigma <- get("Ht.sigma", env=eGUI)
        model <- get("model", env=eGUI)
        frame2 <- get("frame2", env=eGUI)   
        chk2Value <- get("chk2Value", env=eGUI)
     
        param <- lst.todisplay$Parameters
        V1 <-  lst.todisplay$V1
        V2 <-  lst.todisplay$V2
        V3 <-  lst.todisplay$V3
        lst <- as.list(1:length(param))
        names(lst) <- param
        localpar <- lapply(lst, function(n,V1,V2,V3){
                v1 <- V1[n]
                v2 <- V2[n]
                v3 <- V3[n]
                return(c(v1,v2,v3))},V1,V2,V3)
               
        
        chk2 <- as.numeric(tclvalue(chk2Value))
        chk2 <- ifelse(chk2 <= 0,1,0)
        Ht.sigma <- ifelse(chk2  >= 1, defVal, NA)
        assign("Ht.sigma", Ht.sigma, env=eGUI)
        ix <- grep("^Ht.sigma$", datamat[,1])
        if(!is.na(Ht.sigma))
          datamat[ix,2] <- form.vector(Ht.sigma)
        else
          datamat[ix,2] <- textna
      
        if ( !is.na(Ht.sigma)){
            Ht.deriv <- get("Ht.deriv", env=eGUI)
            Ht.age.weight <- get("Ht.age.weight", env=eGUI)
            Ht.time.weight <- get("Ht.time.weight", env=eGUI)
            Ht.sigma.sd <- get("Ht.sigma.sd", env=eGUI)
          
            if(toupper(trim.blanks(model)) != "MAP")
            datamat <- rbind(datamat,
                         c("Ht.sigma.sd",form.vector(Ht.sigma.sd)))
            datamat <- rbind(datamat, c("Ht.deriv",
                                        form.vector(Ht.deriv)))
            datamat <- rbind(datamat, c("Ht.age.weight",
                                        form.vector(Ht.age.weight)))
            datamat <- rbind(datamat, c("Ht.time.weight",
                                        form.vector(Ht.time.weight)))
            localpar <- c(localpar, list(Ht.deriv=Ht.deriv),
                          list(Ht.age.weight=Ht.age.weight),
                          list(Ht.time.weight=Ht.time.weight))
       
            if(toupper(trim.blanks(model)) != "MAP")
              localpar <- c(localpar, list(Ht.sigma.sd=Ht.sigma.sd))
         
          }else{
            ixtodelete <- grep("^Ht.sigma.sd$", names(localpar))
            if(length(ixtodelete) > 0)
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ht.deriv", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ht.age.weight", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ht.time.weight", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            
            ixtodelete <- grep("^Ht.sigma.sd$", datamat[,1])
            if(length(ixtodelete) > 0)
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ht.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ht.age.weight", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ht.time.weight", datamat[,1])
            if(!is.na(ixtodelete))
               datamat <- datamat[-ixtodelete,]
          }
        
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
        lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("Ht.sigma", lst.todisplay$Parameters)
        if(length(indx) > 0){
          localpar[indx] <- ifelse(chk2  >= 1, defVal,NA)
          lst.todisplay$V1[indx] <- ifelse(chk2  >= 1, defVal,textna)
        }else
          print("Index for Ht.sigma not found in lst.todisplay")
         
        cnames <- c("Parameters", "Values")
        colnames(datamat) <- cnames
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        ftext <- get("ftext", env=eGUI)
        fentry <- get("fentry", env=eGUI)
        dataframe <- showCovs(dataframe[-1], base=frame2,
                          titletext= colnames(dataframe)[1], vechar =lnchar,
                          footer=ft, footerentry=fentry,
                          footertext=ftext,
                          colname.bar=colnamebar)
             
                  
        assign("dataframe", dataframe, env=eGUI)
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)
        
      })
 
    
    tkconfigure(frame1.chk2, variable=chk2Value)
    tkgrid(frame1.label2, frame1.chk2, sticky = "w")
    
    frame1.label3 <- tklabel(frame1, textvariable = tclVar(textimeage),
                              fg="black")
    frame1.chk3 <- tkcheckbutton(frame1)
     if (is.na(Hat.sigma) || length(Hat.sigma) <= 0)
      chk3Value <- tclVar("0")
    else
      chk3Value <- tclVar("1")
    
     tkbind(frame1.chk3, "<Button-1>",  function() {
        
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        datamat <- get("datamat", env=eGUI)
        Hat.sigma <- get("Hat.sigma", env=eGUI)
        model <- get("model", env=eGUI)
        frame2 <- get("frame2", env=eGUI)   
        chk3Value <- get("chk3Value", env=eGUI)
        param <- lst.todisplay$Parameters
        V1 <-  lst.todisplay$V1
        V2 <-  lst.todisplay$V2
        V3 <-  lst.todisplay$V3
        lst <- as.list(1:length(param))
        names(lst) <- param
        localpar <- lapply(lst, function(n,V1,V2,V3){
                v1 <- V1[n]
                v2 <- V2[n]
                v3 <- V3[n]
                return(c(v1,v2,v3))},V1,V2,V3)
               
        
        chk3 <- as.numeric(tclvalue(chk3Value))
        chk3 <- ifelse(chk3 <= 0,1,0)
        Hat.sigma <- ifelse(chk3  >= 1, defVal, NA)
        assign("Hat.sigma", Hat.sigma, env=eGUI)
        ix <- grep("^Hat.sigma$", datamat[,1])
        if(!is.na(Hat.sigma))
          datamat[ix,2] <- form.vector(Hat.sigma)
        else
          datamat[ix,2] <- textna
      
       
        if ( !is.na(Hat.sigma)){
            Hat.a.deriv <- get("Hat.a.deriv", env=eGUI)
            Hat.t.deriv <- get("Hat.t.deriv", env=eGUI)
            Hat.age.weight <- get("Hat.age.weight", env=eGUI)
            Hat.time.weight <- get("Hat.time.weight", env=eGUI)
            Hat.sigma.sd <- get("Hat.sigma.sd", env=eGUI)
            if(toupper(trim.blanks(model)) != "MAP")
              datamat <- rbind(datamat,
                               c("Hat.sigma.sd",form.vector(Hat.sigma.sd)))
            datamat <- rbind(datamat, c("Hat.a.deriv",
                                        form.vector(Hat.a.deriv)))
            datamat <- rbind(datamat, c("Hat.t.deriv",
                                        form.vector(Hat.t.deriv)))
            datamat <- rbind(datamat, c("Hat.age.weight",
                                        form.vector(Hat.age.weight)))
            datamat <- rbind(datamat, c("Hat.time.weight",
                                        form.vector(Hat.time.weight)))
            localpar <- c(localpar, list(Hat.a.deriv=Hat.a.deriv),
                          list(Hat.t.deriv=Hat.t.deriv),
                          list(Hat.age.weight=Hat.age.weight),
                          list(Hat.time.weight=Hat.time.weight))
       
            if(toupper(trim.blanks(model)) != "MAP")
              localpar <- c(localpar, list(Hat.sigma.sd=Hat.sigma.sd))
         
          }else{
            ixtodelete <- grep("^Hat.sigma.sd$", names(localpar))
            if(length(ixtodelete) > 0)
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hat.a.deriv", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hat.t.deriv", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hat.age.weight", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hat.time.weight", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]

            
            ixtodelete <- grep("^Hat.sigma.sd$", datamat[,1])
            if(length(ixtodelete) > 0)
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hat.a.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hat.t.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hat.age.weight", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hat.time.weight", datamat[,1])
            if(!is.na(ixtodelete))
               datamat <- datamat[-ixtodelete,]
          }
        
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
        lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("Hat.sigma", lst.todisplay$Parameters)
        if(length(indx) > 0){
          localpar[indx] <- ifelse(chk3  >= 1, defVal,NA)
          lst.todisplay$V1[indx] <- ifelse(chk3  >= 1, 0.1,textna)
        }else
          print("Index for Hat.sigma not found in lst.todisplay")
         
        cnames <- c("Parameters", "Values")
        colnames(datamat) <- cnames
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        ftext <- get("ftext", env=eGUI)
        fentry <- get("fentry", env=eGUI)        
        dataframe <- showCovs(dataframe[-1], base=frame2,
                     titletext= colnames(dataframe)[1], vechar =lnchar,
                     footer=ft, footerentry=fentry,
                     footertext=ftext,
                     colname.bar=colnamebar)
        
        assign("dataframe", dataframe, env=eGUI)
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)      
      })
 
   
    tkconfigure(frame1.chk3, variable=chk3Value)
    tkgrid(frame1.label3, frame1.chk3, sticky="w")
    
    frame1.label4 <- tklabel(frame1, textvariable = tclVar(textcntry),
                              fg="black")
    if(toupper(trim.blanks(model)) != "MAP")
      frame1.chk4 <- tkcheckbutton(frame1)
    else{
       frame1.chk4 <- tkcheckbutton(frame1, state="disable")
     
     }
    
    
    if (is.na(Hct.sigma) ||  length(Hct.sigma) <= 0)
      chk4Value <- tclVar("0")
    else if (toupper(trim.blanks(model)) != "MAP" && !is.na(Hct.sigma))
      chk4Value <- tclVar("1")

   
      tkbind(frame1.chk4, "<Button-1>",  function() {
      if(toupper(trim.blanks(model)) != "MAP"){
         fentry <- get("fentry", env=eGUI)
         ftext <- get("ftext", env=eGUI)
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        datamat <- get("datamat", env=eGUI)
        Hct.sigma <- get("Hct.sigma", env=eGUI)
        model <- get("model", env=eGUI)
        frame2 <- get("frame2", env=eGUI)   
        chk4Value <- get("chk4Value", env=eGUI)
           param <- lst.todisplay$Parameters
        V1 <-  lst.todisplay$V1
        V2 <-  lst.todisplay$V2
        V3 <-  lst.todisplay$V3
        lst <- as.list(1:length(param))
        names(lst) <- param
        localpar <- lapply(lst, function(n,V1,V2,V3){
                v1 <- V1[n]
                v2 <- V2[n]
                v3 <- V3[n]
                return(c(v1,v2,v3))},V1,V2,V3)
               
        
        chk4 <- as.numeric(tclvalue(chk4Value))
        chk4 <- ifelse(chk4 <= 0,1,0)
        Hct.sigma <- ifelse(chk4  >= 1, defVal, NA)
        assign("Hct.sigma", Hct.sigma, env=eGUI)
        ix <- grep("^Hct.sigma$", datamat[,1])
        if(!is.na(Hct.sigma))
          datamat[ix,2] <- form.vector(Hct.sigma)
        else
          datamat[ix,2] <- textna
      
        if ( !is.na(Hct.sigma)){
            Hct.c.deriv <- get("Hct.c.deriv", env=eGUI)
            Hct.t.deriv <- get("Hct.t.deriv", env=eGUI)
            Hct.time.weight <- get("Hct.time.weight", env=eGUI)
            Hct.sigma.sd <- get("Hct.sigma.sd", env=eGUI)
            if(toupper(trim.blanks(model)) != "MAP")
            datamat <- rbind(datamat,
                         c("Hct.sigma.sd",form.vector(Hct.sigma.sd)))
###            datamat <- rbind(datamat, c("Hct.c.deriv",
###                                        form.vector(Hct.c.deriv)))
            datamat <- rbind(datamat, c("Hct.t.deriv",
                                        form.vector(Hct.t.deriv)))
            datamat <- rbind(datamat, c("Hct.time.weight",
                                        form.vector(Hct.time.weight)))
            fentry <- "Hct.c.deriv"
            ftext <- tclvalue(vargraph)
            localpar <- c(localpar, list(Hct.c.deriv=Hct.c.deriv),
                          list(Hct.t.deriv=Hct.t.deriv),
                          list(Hct.time.weight=Hct.time.weight))
         
            if(toupper(trim.blanks(model)) != "MAP")
              localpar <- c(localpar, list(Hct.sigma.sd=Hct.sigma.sd))
         
          }else{
            ixtodelete <- grep("^Hct.sigma.sd$", names(localpar))
            if(length(ixtodelete) > 0)
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hct.c.deriv", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hct.t.deriv", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hct.time.weight", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            
            ixtodelete <- grep("^Hct.sigma.sd$", datamat[,1])
            if(length(ixtodelete) > 0)
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hct.c.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hct.t.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hct.time.weight", datamat[,1])
            if(!is.na(ixtodelete))
               datamat <- datamat[-ixtodelete,]
          
            fentry <- ""
            ftext <- ""
          
          }
        
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
        lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("Hct.sigma", lst.todisplay$Parameters)
        if(length(indx) > 0){
          localpar[indx] <- ifelse(chk4  >= 1, defVal,NA)
          lst.todisplay$V1[indx] <- ifelse(chk4  >= 1, defVal,textna)
        }else
          print("Index for Hct.sigma not found in lst.todisplay")
        
        
         assign("fentry", fentry, env=eGUI)
         assign("ftext", ftext, env=eGUI)
         
        cnames <- c("Parameters", "Values")
        colnames(datamat) <- cnames
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        
         dataframe <- showCovs(dataframe[-1], base=frame2,
                     titletext= colnames(dataframe)[1], vechar =lnchar,
                     footer=ft, footerentry=fentry,
                     footertext=ftext,
                     colname.bar=colnamebar)
             
        assign("dataframe", dataframe, env=eGUI)
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)
        
      }  else
      returnval <- tkmessageBox(title="Checkbox Geographical Index",
                              message=paste("This option is not available ",
                             "\n", "with the MAP model"),icon="info")
      })
   
 
    tkconfigure(frame1.chk4, variable=chk4Value)
    tkgrid(frame1.label4, frame1.chk4, sticky="w")
    tkpack(frame1, fill = "x")
###*****
    frame12.label <- tklabel(frame12, textvariable = tclVar(zerotext),
                             fg="blue")
    frame12.entry <- tkentry(frame12, textvariable = varzero, width = 15)
    frame12.rb1   <- tkradiobutton(frame12)
    frame12.rb2   <- tkradiobutton(frame12)
    tkgrid(frame12.label, frame12.entry, sticky="w")
    tkconfigure(frame12.rb1, variable=rbValue,value="True")
    tkconfigure(frame12.rb2, variable=rbValue,value="False")
    tkgrid(frame12.label, frame12.entry)
    tkgrid(tklabel(frame12, text="True "), frame12.rb1)
    tkgrid(tklabel(frame12, text="False "), frame12.rb2)
    tkpack(frame12, fill="x")
###****    
   if(!is.na(Ha.sigma))
     datamat <- rbind(datamat, c("Ha.sigma",form.vector(Ha.sigma)))
   else
     datamat <- rbind(datamat, c("Ha.sigma",textna))
   if(!is.na(Ht.sigma))
     datamat <- rbind(datamat, c("Ht.sigma",form.vector(Ht.sigma)))
   else
     datamat <- rbind(datamat, c("Ht.sigma",textna))
   if(!is.na(Hat.sigma))
     datamat <- rbind(datamat, c("Hat.sigma",form.vector(Hat.sigma)))
   else
     datamat <- rbind(datamat, c("Hat.sigma",textna))
   if(!is.na(Hct.sigma) && toupper(trim.blanks(model)) !=  "MAP")
     datamat <- rbind(datamat, c("Hct.sigma",form.vector(Hct.sigma)))
   else if ( toupper(trim.blanks(model)) !=  "MAP")
     datamat <- rbind(datamat, c("Hct.sigma",textna))
    
    if(as.numeric(tclvalue(chk1Value)) > 0){
     construct.ha(eGUI)
     datamat <- get("datamat", env=eGUI)
     localpar <- get("localpar", env=eGUI)
     }
     
 
    if(as.numeric(tclvalue(chk2Value)) > 0){
     datamat <- construct.ht(eGUI)
     localpar <- get("localpar", env=eGUI)
     
    }
    
    if(as.numeric(tclvalue(chk3Value)) > 0){
     datamat <- construct.hat(eGUI)
     localpar <- get("localpar", env=eGUI)
     
    }
    
    if(as.numeric(tclvalue(chk4Value)) > 0){
     datamat <- construct.hct(eGUI)
     localpar <- get("localpar", env=eGUI)
    
    }
    if(toupper(trim.blanks(model)) != "MAP"){
      LI.sigma.mean <- get("LI.sigma.mean", env=ewho)
      LI.sigma.sd <- get("LI.sigma.sd", env=ewho)
      datamat <- rbind(datamat,
                       c("LI.sigma.mean", form.vector(LI.sigma.mean)))
      datamat <- rbind(datamat, c("LI.sigma.sd", form.vector(LI.sigma.sd)))
      datamat <- rbind(datamat, c("nsample", form.vector(nsample)))
      localpar <- c(localpar, list(LI.sigma.mean=LI.sigma.mean),
                          list(LI.sigma.sd=LI.sigma.sd),
                          list(nsample=nsample))
    }
    V1 <- vecloc(1, par=localpar) 
    V2 <- vecloc(2, par=localpar)
    V3 <- vecloc(3, par=localpar)
        
    lst.todisplay <- list(Parameters=names(localpar),
                          V1=V1 , V2=V2 , V3=V3 )

    cnames <- c("Parameters", "Values")
    colnames(datamat) <- cnames
    namerows <- datamat[,1]
    dataframe <- as.data.frame(datamat)
    row.names(dataframe) <- namerows
    colnames(dataframe) <- c("Parameters", "Scalar/Vector")
   dataframe <- showCovs(dataframe[-1], base=frame2,
                     titletext= colnames(dataframe)[1], vechar =lnchar,
                     footer=ft, footerentry=fentry,
                     footertext=ftext,
                     colname.bar=colnamebar)
             
   
    tkpack(frame2, fill = "x")
##****
    frame23.label <- tklabel(frame23, textvariable=tclVar(graphtext),
                             fg="blue")
    frame23.entry <- tkentry(frame23, textvariable = vargraph,
                             width = 15, bg="white")
    tkgrid(frame23.label, frame23.entry)
###    tkpack(frame23, fill="x")
##***    
    frame3.spacer <- tklabel(frame3, text = "   ")
    
    frame3.but1 <- tkbutton(frame3,  textvariable =tclVar("Edit"),
                            padx = 20, command = bayes.edit)
    
    frame3.but2 <- tkbutton(frame3,  textvariable =tclVar("Close"),
                            fg="red", padx = 20, command = bayes.close)
    
    frame3.but3 <- tkbutton(frame3, text = "Apply", padx = 20,                                     command = bayes.init)
    tkgrid(frame3.spacer,sticky="nsew") 
    tkgrid(frame3.but1, frame3.but2, frame3.but3, sticky = "w")
    tkpack(frame3, fill="x")
    return(tkbayes)
}
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      vecloc(ix=index, param= vec) 
##
## IMPORTED functions: used in bayes GUI
##
##
## DESCRIPTION: It takes a an index (i.e.,ix= 1, 2,3) and a named list of vectors whose elements
##              are vectors with 1,2 or 3 components, text=<NA> to mark or label NA's
##              for parameters. It will select one of
##              those components corresponding to index=ix, for each and all elements of param. 
##
##
## OUTPUT: the component ix of all elements of param. Thus select one element of the vectors for
##         all list components. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************


    vecloc <- function(ix, par,textna="<NA>"){
      nm <- names(par)
      count <-  0
      V <- sapply(par, function(x){
        count <-  count + 1
        ln <- length(x)
        x <- na.omit(x)
        x <- trim.blanks(x)
        flag <- F
        if (trim.blanks(nm[count]) == "Ha.sigma" ||
            trim.blanks(nm[count]) == "Ht.sigma" ||
            trim.blanks(nm[count]) == "Hat.sigma"||
            trim.blanks(nm[count]) == "Hct.sigma")
          flag <- T
        if(ix > 1)
          flag <- F
        if(length(x) > (ix-1))
          return(x[ix])
        else if(flag)
          return(textna)
        else
          return("")})
      return(V)}
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      builparameters(param,v1, v2,v3,miss) 
##
## IMPORTED functions: none
##
##
## DESCRIPTION: It takes  param vector of string characters and thre numeric
##              or characters vectors v1, v2, v3, which may also take missing values  
##              as represented with miss, the text for NA or <NA>,
##              It will construct the vector for every element of param whoise elements
##              are the corresponding elements of v1, v2, and v3. 
##
##
## OUTPUT: the named list with param as names and each element a vector, whose
##         components are taken from vectors v1, v2, v3 for first, second and third components. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************


   buildparameters <- function(param, v1,v2,v3,miss){
     lst <- list()
     for(n in 1:length(param)){
       nm <- param[n]
       p1 <- v1[n]
       if(p1==miss)
         p1 <- NA
       else if(length(trim.blanks(p1)) <= 0)
         p1 <- NA
       
       p2 <- v2[n]
       p2 <- ifelse(p2==miss,NA,p2)
       p3 <- v3[n]
       p3 <- ifelse(p3==miss,NA,p3)
       nm <- c(p1,p2,p3)
       if(length(na.omit(nm)) < 1)
         nm <- NA
       else
         nm <- na.omit(nm)
       lst <- c(lst, list(nm))
     }
       names(lst) <- param
     return(lst)
   }
## ************************************************************************
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.LI.sigma.mean(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to LI.sigma.mean, LI.sigma.sd, nsample
##           of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. If model== BAYES,
##              it takes only parameters LI.sigma.mean, LI.sigma.sd, nsample. 
##              The relevant parameters are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay.
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Return datamat. Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to age smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 24/02/2005
## 
## ************************************************************************
## ************************************************************************
          
   construct.LI.sigma.nsample <- function(eGUI){
     LI.sigma.mean <- get("LI.sigma.mean", env=eGUI)
     datamat <- get("datamat", env=eGUI)
     ix <- grep("^LI.sigma.mean$", datamat[,1])
     datamat[ix,2] <- LI.sigma.mean
     model <- get("model", env=eGUI)
     LI.sigma.sd <- get("LI.sigma.sd", env=eGUI)
     ix <- grep("^LI.sigma.sd$", datamat[,1])
     datamat[ix,2] <- LI.sigma.sd
     nsample <- get("nsample", env=eGUI)
     ix <- grep("^nsample$", datamat[,1])
     datamat[ix,2] <- nsample
     localpar <- get("localpar", env=eGUI)
   
   
 if (! identical(toupper(trim.blanks(model)), "BAYES"))
   return(0); 

   ind <- grep("LI.sigma.mean",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat,
                      c("LI.sigma.mean",form.vector(LI.sigma.mean)))
   else
     datamat[ind,2] <- form.vector(LI.sigma.mean)
 
   ind <- grep("LI.sigma.sd",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat, c("LI.sigma.sd",
                                 form.vector(LI.sigma.sd)))
   else
     datamat[ind,2] <- form.vector(LI.sigma.sd)
         
   ind <- grep("nsample",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat, c("nsample",
                                 form.vector(nsample)))
   else
     datamat[ind,2] <- form.vector(nsample)
           

 
   ind <- grep("LI.sigma.mean", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(LI.sigma.mean=LI.sigma.mean))
   else
     localpar[[ind]] <- LI.sigma.mean
        
   ind <- grep("LI.sigma.sd", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar,
                   list(LI.sigma.sd=form.vector(LI.sigma.sd)))
   else
     localpar[[ind]] <- form.vector(LI.sigma.sd)
     
   ind <- grep("nsample", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(nsample=
                                        form.vector(nsample)))
   else
     localpar[[ind]] <- form.vector(nsample) 
         
   
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
     lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
     
     indx <- grep("^LI.sigma.mean$", lst.todisplay$Parameters)
        
     localpar[indx] <- LI.sigma.mean
     lst.todisplay$V1[indx] <- LI.sigma.mean
     indx <- grep("^LI.sigma.sd$", lst.todisplay$Parameters)
        
     localpar[indx] <- LI.sigma.sd
     lst.todisplay$V1[indx] <- LI.sigma.sd
     indx <- grep("^nsample$", lst.todisplay$Parameters)
        
     localpar[indx] <- nsample
        lst.todisplay$V1[indx] <- nsample
   
   
     assign("localpar", localpar, env=eGUI)
     assign("lst.todisplay",lst.todisplay, env=eGUI)
  return(datamat)      
 }
## ************************************************************************
## ************************************************************************

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.ha(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to Ha.sigma of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. It takes only parameters
##              associated with age smoothing Ha.sigma. If Ha.sigma!= NA
##              then relevant parameters are Ha.age.weight, Ha.time.weight,
##              Ha.deriv and Ha.sigma.sd, which are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay. If Ha.sigma is changing values, but none of old or new is NA, 
##              then, it simply modifies both datamat and lst.todisplay reflecting new values
##              of age smoothing parameters if they are different from previous assignments.
##              Note that if Ha.sigma=NA then none of the Ha. related parameters are in 
##              datamat or lst.todisplay editors, and need to be
##              added or rbinded to the list or matrix, if Ha.sigma becomes != NA
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to age smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

 construct.ha <- function(eGUI){
   Ha.sigma <- get("Ha.sigma", env=eGUI)
   datamat <- get("datamat", env=eGUI)
   ix <- grep("^Ha.sigma$", datamat[,1])
   datamat[ix,2] <- Ha.sigma
   model <- get("model", env=eGUI)
   localpar <- get("localpar", env=eGUI)
   Ha.deriv <- get("Ha.deriv", env=eGUI)
   Ha.age.weight <- get("Ha.age.weight", env=eGUI)
   Ha.time.weight <- get("Ha.time.weight", env=eGUI)
   Ha.sigma.sd <- get("Ha.sigma.sd", env=eGUI)
 
   
 if ( !is.na(Ha.sigma)){

            if(toupper(trim.blanks(model)) != "MAP"){
              ind <- grep("Ha.sigma.sd",datamat[,1])
              if(length(ind) <= 0)
                datamat <- rbind(datamat,
                                 c("Ha.sigma.sd",form.vector(Ha.sigma.sd)))
              else
                datamat[ind,2] <- form.vector(Ha.sigma.sd)
            }
            ind <- grep("Ha.deriv",datamat[,1])
            if(length(ind) <= 0)
              datamat <- rbind(datamat, c("Ha.deriv",
                                        form.vector(Ha.deriv)))
            else
              datamat[ind,2] <- form.vector(Ha.deriv)
         
            ind <- grep("Ha.age.weight",datamat[,1])
            if(length(ind) <= 0)
              datamat <- rbind(datamat, c("Ha.age.weight",
                                        form.vector(Ha.age.weight)))
            else
               datamat[ind,2] <- form.vector(Ha.age.weight)
            ind <- grep("Ha.time.weight",datamat[,1])
            if(length(ind) <= 0)
            datamat <- rbind(datamat, c("Ha.time.weight",
                                        form.vector(Ha.time.weight)))
            else
              datamat[ind,2] <-  form.vector(Ha.time.weight)

 
         ind <- grep("Ha.deriv", names(localpar))
         if(length(ind) <= 0)
           localpar <- c(localpar, list(Ha.deriv=Ha.deriv))
         else
           localpar[[ind]] <- Ha.deriv
        
         ind <- grep("Ha.age.weight", names(localpar))
         if(length(ind) <= 0)
           localpar <- c(localpar,
                         list(Ha.age.weight=form.vector(Ha.age.weight)))
         else
           localpar[[ind]] <- form.vector(Ha.age.weight)
           ind <- grep("Ha.time.weight", names(localpar))
         if(length(ind) <= 0)
           localpar <- c(localpar, list(Ha.time.weight=
                                        form.vector(Ha.time.weight)))
         else
           localpar[[ind]] <- form.vector(Ha.time.weight) 
         
         
         if(toupper(trim.blanks(model)) != "MAP"){
           ind <- grep("Ha.sigma.sd", names(localpar))
           if(length(ind) <= 0)
             localpar <- c(localpar, list(Ha.sigma.sd=
                                        form.vector(Ha.sigma.sd)))
           else
             localpar[[ind]] <- form.vector(Ha.sigma.sd) 
                   
         }
          }
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
       lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("^Ha.sigma$", lst.todisplay$Parameters)
        
        localpar[indx] <- Ha.sigma
        lst.todisplay$V1[indx] <- Ha.sigma
   
        assign("datamat", datamat,env=eGUI)   
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        
 }
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.ht(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to Ht.sigma of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. It takes only parameters
##              associated with time smoothing Ht.sigma. If Ht.sigma!= NA
##              then relevant parameters are Ht.age.weight, Ht.time.weight,
##              Ht.deriv and Ht.sigma.sd, which are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay. If Ht.sigma is changing values, but none of old or new is NA, 
##              then, it simply modifies both datamat and lst.todisplay reflecting new values
##              of time smoothing parameters if they are different from previous assignments.
##              Note that if Ht.sigma=NA then none of the Ht.* related parameters are in 
##              datamat or lst.todisplay editors, and need to be
##              added or rbinded to the list or matrix, if Ht.sigma becomes != NA
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to time smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. Returns datamat. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

 
construct.ht <- function(eGUI){
  Ht.sigma <- get("Ht.sigma", env=eGUI)
  datamat <- get("datamat", env=eGUI)
  ix <- grep("^Ht.sigma$", datamat[,1])
  datamat[ix,2] <- Ht.sigma
  model <- get("model", env=eGUI)
  localpar <- get("localpar", env=eGUI)
  Ht.deriv <- get("Ht.deriv", env=eGUI)
  Ht.age.weight <- get("Ht.age.weight", env=eGUI)
  Ht.time.weight <- get("Ht.time.weight", env=eGUI)
  Ht.sigma.sd <- get("Ht.sigma.sd", env=eGUI)
  
  if ( !is.na(Ht.sigma)){
    
    if(toupper(trim.blanks(model)) != "MAP"){
      ind <- grep("Ht.sigma.sd",datamat[,1])
      if(length(ind) <= 0)
        datamat <- rbind(datamat,
                         c("Ht.sigma.sd",form.vector(Ht.sigma.sd)))
      else
        datamat[ind,2] <- form.vector(Ht.sigma.sd)
    }
    ind <- grep("Ht.deriv",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Ht.deriv",
                                  form.vector(Ht.deriv)))
    else
      datamat[ind,2] <- form.vector(Ht.deriv)
    ind <- grep("Ht.age.weight",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Ht.age.weight",
                                  form.vector(Ht.age.weight)))
    else
      datamat[ind,2] <- form.vector(Ht.age.weight)
    ind <- grep("Ht.time.weight",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Ht.time.weight",
                                  form.vector(Ht.time.weight)))
    else
      datamat[ind,2] <-  form.vector(Ht.time.weight)
    
 
    ind <- grep("Ht.deriv", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Ht.deriv=form.vector(Ht.deriv)))
    else
      localpar[[ind]] <- form.vector(Ht.deriv)
    ind <- grep("Ht.age.weight", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar,
                    list(Ht.age.weight=form.vector(Ht.age.weight)))
    else
      localpar[[ind]] <- form.vector(Ht.age.weight)
    ind <- grep("Ht.time.weight", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Ht.time.weight=
                                   form.vector(Ht.time.weight)))
    else
      localpar[[ind]] <- form.vector(Ht.time.weight) 
         
    
    if(toupper(trim.blanks(model)) != "MAP"){
      ind <- grep("Ht.sigma.sd", names(localpar))
      if(length(ind) <= 0)
        localpar <- c(localpar, list(Ht.sigma.sd=
                                     form.vector(Ht.sigma.sd)))
      else
        localpar[[ind]] <- form.vector(Ht.sigma.sd) 
                   
    }
  }

  V1 <- vecloc(1, par=localpar) 
  V2 <- vecloc(2, par=localpar)
  V3 <- vecloc(3, par=localpar)
        
  lst.todisplay <- list(Parameters=names(localpar),
                        V1=V1 , V2=V2 , V3=V3 )
       
  indx <- grep("^Ht.sigma$", lst.todisplay$Parameters)
        
  localpar[indx] <- Ht.sigma
  lst.todisplay$V1[indx] <- Ht.sigma
           
  assign("localpar", localpar, env=eGUI)
  assign("lst.todisplay",lst.todisplay, env=eGUI)
  return(datamat)
        
}
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.hat(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to Hat.sigma of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. It takes only parameters
##              associated with age-time smoothing Hat.sigma. If Hat.sigma!= NA
##              then relevant parameters are Hat.age.weight, Hat.time.weight,
##              Hat.a.deriv, Hat.t.deriv,  and Hat.sigma.sd,
##              which are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay. If Hat.sigma is changing values, but none of old or new is NA, 
##              then, it simply modifies both datamat and lst.todisplay reflecting new values
##              of age-time smoothing parameters if they are different from previous assignments.
##              Note that if Hat.sigma=NA then none of the Hat.* related parameters are in 
##              datamat or lst.todisplay editors, and need to be
##              added or rbinded to the list or matrix, if Hat.sigma becomes != NA
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to age-time smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. Returns datamat. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

construct.hat <- function(eGUI){
   Hat.sigma <- get("Hat.sigma", env=eGUI)
   datamat <- get("datamat", env=eGUI)
   ix <- grep("^Hat.sigma$", datamat[,1])
   datamat[ix,2] <- Hat.sigma
   model <- get("model", env=eGUI)
   localpar <- get("localpar", env=eGUI)
   Hat.a.deriv <- get("Hat.a.deriv", env=eGUI)
   Hat.t.deriv <- get("Hat.t.deriv", env=eGUI)
   Hat.age.weight <- get("Hat.age.weight", env=eGUI)
   Hat.time.weight <- get("Hat.time.weight", env=eGUI)
   Hat.sigma.sd <- get("Hat.sigma.sd", env=eGUI)
   
 if ( !is.na(Hat.sigma)){
    
    if(toupper(trim.blanks(model)) != "MAP"){
      ind <- grep("Hat.sigma.sd",datamat[,1])
      if(length(ind) <= 0)
        datamat <- rbind(datamat,
                         c("Hat.sigma.sd",form.vector(Hat.sigma.sd)))
      else
        datamat[ind,2] <- form.vector(Hat.sigma.sd)
    }
    ind <- grep("Hat.a.deriv",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Hat.a.deriv",
                                  form.vector(Hat.a.deriv)))
    else
      datamat[ind,2] <- form.vector(Hat.a.deriv)
    ind <- grep("Hat.t.deriv",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Hat.t.deriv",
                                  form.vector(Hat.t.deriv)))
    else
      datamat[ind,2] <- form.vector(Hat.t.deriv)
    ind <- grep("Hat.age.weight",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Hat.age.weight",
                                  form.vector(Hat.age.weight)))
    else
      datamat[ind,2] <- form.vector(Hat.age.weight)
    ind <- grep("Hat.time.weight",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Hat.time.weight",
                                  form.vector(Hat.time.weight)))
    else
      datamat[ind,2] <-  form.vector(Hat.time.weight)
    
 
    ind <- grep("Hat.a.deriv", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Hat.a.deriv=form.vector(Hat.a.deriv)))
    else
      localpar[[ind]] <- form.vector(Hat.a.deriv)
    ind <- grep("Hat.t.deriv", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Hat.t.deriv=form.vector(Hat.t.deriv)))
    else
      localpar[[ind]] <- form.vector(Hat.t.deriv)
    ind <- grep("Hat.age.weight", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar,
                    list(Hat.age.weight=form.vector(Hat.age.weight)))
    else
      localpar[[ind]] <- form.vector(Hat.age.weight)
    ind <- grep("Hat.time.weight", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Hat.time.weight=
                                   form.vector(Hat.time.weight)))
    else
      localpar[[ind]] <- form.vector(Hat.time.weight) 
         
    
    if(toupper(trim.blanks(model)) != "MAP"){
      ind <- grep("Hat.sigma.sd", names(localpar))
      if(length(ind) <= 0)
        localpar <- c(localpar, list(Hat.sigma.sd=
                                     form.vector(Hat.sigma.sd)))
      else
        localpar[[ind]] <- form.vector(Hat.sigma.sd) 
                   
    }
          
  }
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
       lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("^Hat.sigma$", lst.todisplay$Parameters)
        
        localpar[indx] <- Hat.sigma
        lst.todisplay$V1[indx] <- Hat.sigma
           
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
   return(datamat)
        
          }
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.hct(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to Hct.sigma of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. It takes only parameters
##              associated with contry-time smoothing Hct.sigma. If Hct.sigma!= NA
##              then relevant parameters are Hct.time.weight,
##              Hct.c.deriv, Hct.t.deriv,  and Hct.sigma.sd,
##              which are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay. If Hct.sigma is changing values, but none of old or new is NA, 
##              then, it simply modifies both datamat and lst.todisplay reflecting new values
##              of cntry-time smoothing parameters if they are different from previous assignments.
##              Note that if Hct.sigma=NA then none of the Hct.* related parameters are in 
##              datamat or lst.todisplay editors, and need to be
##              added or rbinded to the list or matrix, if Hct.sigma becomes != NA
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to cntry-time smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. Returns datamat. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

construct.hct <- function(eGUI, lst=T){
   Hct.sigma <- get("Hct.sigma", env=eGUI)
   datamat <- get("datamat", env=eGUI)
   ix <- grep("^Hct.sigma$", datamat[,1])
   datamat[ix,2] <- Hct.sigma
   model <- get("model", env=eGUI)
   localpar <- get("localpar", env=eGUI)
   Hct.c.deriv <- get("Hct.c.deriv", env=eGUI)
   Hct.t.deriv <- get("Hct.t.deriv", env=eGUI)
   Hct.time.weight <- get("Hct.time.weight", env=eGUI)
   Hct.sigma.sd <- get("Hct.sigma.sd", env=eGUI)
          
 if ( !is.na(Hct.sigma)){
   if(toupper(trim.blanks(model)) != "MAP"){
     ind <- grep("Hct.sigma.sd",datamat[,1])
      if(length(ind) <= 0)
        datamat <- rbind(datamat,
                         c("Hct.sigma.sd",form.vector(Hct.sigma.sd)))
      else
        datamat[ind,2] <- form.vector(Hct.sigma.sd)
    }
   ind <- grep("Hct.c.deriv",datamat[,1])
   
###   if(length(ind) <= 0)
###     datamat <- rbind(datamat, c("Hct.c.deriv",
###                                 form.vector(Hct.c.deriv)))
###   else
###     datamat[ind,2] <- form.vector(Hct.c.deriv)
   
   ind <- grep("Hct.t.deriv",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat, c("Hct.t.deriv",
                                 form.vector(Hct.t.deriv)))
   else
     datamat[ind,2] <- form.vector(Hct.t.deriv)
   
   ind <- grep("Hct.time.weight",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat, c("Hct.time.weight",
                                 form.vector(Hct.time.weight)))
   else
     datamat[ind,2] <-  form.vector(Hct.time.weight)
    
   
   ind <- grep("Hct.c.deriv", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(Hct.c.deriv=form.vector(Hct.c.deriv)))
   else
     localpar[[ind]] <- form.vector(Hct.c.deriv)
   ind <- grep("Hct.t.deriv", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(Hct.t.deriv=form.vector(Hct.t.deriv)))
   else
     localpar[[ind]] <- form.vector(Hct.t.deriv)
   
   ind <- grep("Hct.time.weight", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(Hct.time.weight=
                                  form.vector(Hct.time.weight)))
   else
     localpar[[ind]] <- form.vector(Hct.time.weight) 
         
   
   if(toupper(trim.blanks(model)) != "MAP"){
     ind <- grep("Hct.sigma.sd", names(localpar))
     if(length(ind) <= 0)
       localpar <- c(localpar, list(Hct.sigma.sd=
                                    form.vector(Hct.sigma.sd)))
     else
       localpar[[ind]] <- form.vector(Hct.sigma.sd) 
                   
   }
 }
  
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
       lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("^Hct.sigma$", lst.todisplay$Parameters)
        
        localpar[indx] <- Hct.sigma
        lst.todisplay$V1[indx] <- Hct.sigma
           
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
   return(datamat)
        
 }
##
