
##
## DESCRIPTION:  reads default values in function namelists(), which is the master file
##               setting all defaults. Creates new stings and arrays with defaults
##               age groups, covaraites, death causes and death transformation.
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: set.defaults()
##
## VALUE:  An environment, which stores the relevamnt parameters and vectors.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


set.defaults <- function()
{
  ewho <- namelists()
  in.list <- list()
  model  <- try(get("model", env=ewho), silent = T)
  if(class(model) == "try-error")
    model = ""
 
  in.list <- c(in.list, list(model=model))
  fore   <- get("fore", env=ewho)
  in.list <- c(in.list, list(fore=fore))
  yrest  <- get("yrest", env=ewho)
  in.list <- c(in.list, list(yrest=yrest))
  lag    <-  get("lag", env=ewho)
  in.list <- c(in.list, list(lag=lag))
  svdtol <- get("svdtol", env=ewho)
  in.list <- c(in.list, list(svdtol=svdtol))
  cntry.digits <- get("cntry.digits", env=ewho)
  in.list <- c(in.list, list(cntry.digits=cntry.digits))
  year.digits  <- get("year.digits", env=ewho)
  in.list <- c(in.list, list(year.digits=year.digits))    
  age.digits   <- get("age.digits", env=ewho)
  in.list <- c(in.list, list(age.digits=age.digits))
  digit.first  <- get("digit.first", env=ewho)
  in.list <- c(in.list, list(digit.first=digit.first))
  depvar <- get("depvar", env=ewho)
  in.list <- c(in.list, list(depvar=depvar))
  allcauses  <-  get("allcauses", env=ewho)
  in.list <- c(in.list, list(allcauses=allcauses))
  population <-  get("population", env=ewho)
  in.list <- c(in.list, list(population=population))    
  transform <- get("transform", env=ewho)
  in.list <- c(in.list, list(transform=transform))
  skip <- get("skip", env=ewho)
  in.list <- c(in.list, list(skip=skip))
  usercntrylist <- get("usercntrylist", env=ewho)
  in.list <- c(in.list, list(usercntrylist=usercntrylist))
  data.path <- get("data.path", env=ewho);
  in.list <- c(in.list, list(data.path=data.path) )
  out.path <- get("out.path", env=ewho);
  in.list <- c(in.list, list(out.path=out.path))
  cov.path <- get("cov.path", env=ewho);
  in.list <- c(in.list, list(cov.path=cov.path))
  prior.path <- get("prior.path", env=ewho)
  in.list <- c(in.list, list(prior.path=prior.path))
  reuse.path <- get("reuse.path", env=ewho)
  in.list <- c(in.list, list(reuse.path=reuse.path))
  
  codes.names <- get("codes.names", env=ewho)
  in.list <- c(in.list, list(codes.names=codes.names))
  strata <- get("strata", env=ewho)
  in.list <- c(in.list, list(strata=strata))
  userages <- get("userages", env=ewho)
  in.list <- c(in.list, list(userages=userages))
  cov.select <- get("cov.select", env=ewho)
  in.list <- c(in.list, list(cov.select=cov.select))    
  age.select <- get("age.select", env=ewho)
  in.list <- c(in.list, list(age.select=age.select))
  elim.collinear <- get("elim.collinear", env=ewho)
  in.list <- c(in.list, list(elim.collinear=elim.collinear))
  standardize <- get("standardize", env=ewho)
  in.list <- c(in.list, list(standardize=standardize))
  lag.cutoff <- get("lag.cutoff", env=ewho)
  in.list <- c(in.list, list(lag.cutoff=lag.cutoff))
  tol <- get("tol", env=ewho)
  in.list <- c(in.list, list(tol=tol))
  delta.tol <- get("delta.tol", env=ewho)
  in.list <- c(in.list, list(delta.tol=delta.tol))
  solve.tol <- get("solve.tol", env=ewho)
  in.list <- c(in.list, list(solve.tol=solve.tol))
  cov <- get("cov", env=ewho)
  in.list <- c(in.list, list(cov=cov))
  cov.type <- get("cov.type", env=ewho)
  in.list <- c(in.list, list(cov.type=cov.type))
  zero.mean <- get("zero.mean", env=ewho)
  in.list <- c(in.list, list(zero.mean=zero.mean))
  Ha.sigma <- get("Ha.sigma", env=ewho)
  in.list <- c(in.list, list(Ha.sigma=Ha.sigma))
  Ht.sigma <- get("Ht.sigma", env=ewho)
  in.list <- c(in.list, list(Ht.sigma=Ht.sigma))    
  Hat.sigma <- get("Hat.sigma", env=ewho)
  in.list <- c(in.list, list(Hat.sigma=Hat.sigma))
  Hct.sigma <- get("Hct.sigma", env=ewho)
  in.list <- c(in.list, list(Hct.sigma=Hct.sigma))
  Ha.sigma.sd <- get("Ha.sigma.sd", env=ewho)
  in.list <- c(in.list, list(Ha.sigma.sd=Ha.sigma.sd))
  Ha.deriv <- get("Ha.deriv", env=ewho)
  in.list <- c(in.list, list(Ha.deriv=Ha.deriv))
  Ha.age.weight   <- get("Ha.age.weight", env=ewho)
  in.list <- c(in.list, list(Ha.age.weight=Ha.age.weight))
  Ha.time.weight  <- get("Ha.time.weight", env=ewho)
  in.list <- c(in.list, list(Ha.time.weight=Ha.time.weight))
  Ht.sigma.sd <- get("Ht.sigma.sd", env=ewho)
  in.list <- c(in.list, list(Ht.sigma.sd=Ht.sigma.sd))
  Ht.deriv <- get("Ht.deriv", env=ewho)
  in.list <- c(in.list, list(Ht.deriv=Ht.deriv))
  Ht.age.weight   <- get("Ht.age.weight", env=ewho)
  in.list <- c(in.list, list(Ht.age.weight=Ht.age.weight))
  Ht.time.weight  <- get("Ht.time.weight", env=ewho)
  in.list <- c(in.list, list(Ht.time.weight=Ht.time.weight))
  Hat.sigma.sd <- get("Hat.sigma.sd", env=ewho)
  in.list <- c(in.list, list(Hat.sigma.sd=Hat.sigma.sd))
  Hat.a.deriv <- get("Hat.a.deriv", env=ewho)
  in.list <- c(in.list, list(Hat.a.deriv=Hat.a.deriv))
  Hat.t.deriv <- get("Hat.t.deriv", env=ewho)
  in.list <- c(in.list, list(Hat.t.deriv= Hat.t.deriv))
  Hat.age.weight   <- get("Hat.age.weight", env=ewho)
  in.list <- c(in.list, list(Hat.age.weight=Hat.age.weight))
  Hat.time.weight  <- get("Hat.time.weight", env=ewho)
  in.list <- c(in.list, list(Hat.time.weight=Hat.time.weight))
  Hct.sigma.sd <- get("Hct.sigma.sd", env=ewho)
  in.list <- c(in.list, list(Hct.sigma.sd=Hct.sigma.sd))
  Hct.c.deriv <- get("Hct.c.deriv", env=ewho)
  in.list <- c(in.list, list(Hct.c.deriv=Hct.c.deriv))
  Hct.t.deriv <- get("Hct.t.deriv", env=ewho)
  in.list <- c(in.list, list(Hct.t.deriv=Hct.t.deriv))
  Hct.time.weight  <- get("Hct.time.weight", env=ewho)
  in.list <- c(in.list, list(Hct.time.weight=Hct.time.weight))
  nsample <- get("nsample", env=ewho)
  in.list <- c(in.list, list(nsample=nsample))
  
  LI.sigma.mean <- get("LI.sigma.mean", env=ewho)
  in.list <- c(in.list, list(LI.sigma.mean=LI.sigma.mean))
  LI.sigma.sd <- get("LI.sigma.sd", env=ewho)
  in.list <- c(in.list, list(LI.sigma.sd=LI.sigma.sd))
  save.FULL <- get("save.FULL", env=ewho)
  in.list <- c(in.list, list(save.FULL=save.FULL))
  save.output <- get("save.output", env=ewho)
  in.list <- c(in.list, list(save.output=save.output))
  reuse.data <-  get("reuse.data", env=ewho)
  in.list <- c(in.list, list(reuse.data=reuse.data))
  save.GUI <-  NULL
  agesString <- c("00", "05", "10", "15", "20", "25",
                  "30", "35","40", "45", "50", "55",
                  "60", "65", "70", "75","80")
  covString <- c("gdp", "fat", "hc", "tfr", "tobacco", "<NA>")
  covtypeString <- c("<NA>", "strata.independent", "age.independent",
                     "age.strata.independent", "depvar.like")
  dthString <- c("allc", "malr","aids","tubr", "otin", 
                 "lung", "molp","livc", "stom", "brst",
                 "cerv", "omal", "rspi", "rspc", "cvds",
                 "dgst", "matc", "pern", "allo", "trns", 
                 "unin", "suic", "homi","ward");
  transString <- c("sqrt(depvar)", "log(depvar)", "log(depvar + 1)", "<NA>")
  modelString <- c("Model & Years", "Index Variable", "Bayesian Parameters")
  
  categoryString <- c("Dependent Variable", "Country Selection",
                      "Strata & Age Groups",
                      "Covariate Selections",  "Covariates & Ages",
                      "Collinear Covariates")
  
  strURL <- "http://gking.harvard.edu/yourcast"
  
  
  return(environment())
}
##
## DESCRIPTION:  Creates the GUI with textboxes for the model, year to forecast, lag of covs, 
##               yrest for the insample period, and the svdtol (a tolerance parameter).
##               Defaults values as described in namelist(). Also, two buttons.
##               Upon pressing the button apply changed parameters are written
##               into memory (fore.init). The button close (fore.close), quits the application.
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: fore(base, textvalues).  Here base is the tktoplevel container to build the GUI
##         and textvalues are character strings with the texts for each of the five entry boxes.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, model, year forecast,
##         year insample, covs lag and svdtol, might have been changed and their
##         new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

fore <- function(base, model=NULL, modelo="Forecasting Model",
                 lyear ="Last Forecast Year (fore)",
                 inyear = "Last Year In-sample (yrest)",
                 tol = "SVD Tolerance (svdtol)"){
      
  ewho <- get("ewho", env=parent.frame())
  eGUI <- environment()
  if(length(model) <= 0)
    {     
      model <- get("model", env=ewho)
      defvar1 <- model
    }else {
      defvar1 <- model
    }
    
    defvar2 <- get("fore", env=ewho)
    defvar3 <- get("yrest", env=ewho)
    defvar5 <- get("svdtol", env=ewho)
    colorbox <- "white"
    disabox <- "lightgrey"
    disabox <- "lightblue"
    rbValue <- tclVar(defvar1) ## radio button default value
    
 fore.close <- function(...) {
     
   fore.init()
   tkdestroy(base)
 }
 fore.init <- function(...) {
        
        defvar1 <- as.character(tclvalue(rbValue)) 
        var2.local <- as.character(tclvalue(var2))
        var2parse <- var2.local
        var3.local <- as.character(tclvalue(var3))
        var3parse <- var3.local
  ##      var5.local <- as.character(tclvalue(var5))
  ##      var5parse <- var5.local
        if(identical(trim.blanks(defvar1), "DATA" ) == T)
          defvar1 <- 3
        assign("model",defvar1, env=ewho)
        assign("fore",as.numeric(var2parse), env=ewho)
        assign("yrest", as.numeric(var3parse), env=ewho)
    ##    assign("svdtol", as.numeric(var5parse), env=ewho)    
#        cat("model = ", var1.local, "\n")
#        cat("fore = ", var2.local, "\n")
#        cat("yrest = ", var3.local, "\n")
#        cat("svdtol = ", var5.local, "\n")      
      
        
    }

    tkforecast <- tkframe(base, relief = "groove", borderwidth = 1)
    frame0 <- tkframe(tkforecast, relief = "groove", borderwidth = 1)
    frame1 <- tkframe(tkforecast, relief = "groove", borderwidth = 0)
    frame2 <- tkframe(tkforecast, relief = "groove", borderwidth = 1)
  
 
    var2 <- tclVar(defvar2)
    var3 <- tclVar(defvar3)
    var5 <- tclVar(defvar5)
    
    frame0.label1 <- tklabel(frame0, textvariable = tclVar(modelo),fg="blue")
    rb1 <- tkradiobutton(frame0)
    rb2 <- tkradiobutton(frame0)
    rb3 <- tkradiobutton(frame0)
    rb4 <- tkradiobutton(frame0)
    rb5 <- tkradiobutton(frame0)
    rb6 <- tkradiobutton(frame0)
    arr.model <- c("MAP", "BAYES", "OLS", "POISSON", "LC", "DATA")
    rb.lst <- list(rb1=rb1,rb2=rb2,rb3=rb3, rb4=rb4,rb5=rb5,rb6=rb6)
    ##  action listeners; click of the button  
      
        tkbind(rb1,"<Button-1>", function(){
          var1 <- arr.model[1] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
     tkbind(rb2,"<Button-1>", function(){
          var1 <- arr.model[2] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
     tkbind(rb3,"<Button-1>", function(){
          var1 <- arr.model[3] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
     tkbind(rb4,"<Button-1>", function(){
          var1 <- arr.model[4] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
    tkbind(rb5,"<Button-1>", function(){
          var1 <- arr.model[5] 
          rbValue <- tclVar(var1)
          assign("defvar1", var1, env=eGUI)
          assign("model", var1, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
    
     tkbind(rb6,"<Button-1>", function(){
          var1 <- arr.model[6] ### should be DATA
          rbValue <- tclVar(var1)
          assign("defvar1", 3, env=eGUI) ###give number to indicate only data 
          assign("model", 3, env=ewho)
          assign("rbValue", tclVar(var1), env=eGUI)
        })
      
  tkconfigure(rb1, variable= rbValue, value="MAP")
  tkconfigure(rb2, variable= rbValue, value="BAYES")
  tkconfigure(rb3, variable= rbValue, value="OLS")
  tkconfigure(rb4, variable= rbValue, value="POISSON")
  tkconfigure(rb5, variable= rbValue, value="LC")
  tkconfigure(rb6, variable= rbValue, value="DATA")
  tkgrid(frame0.label1, sticky="w")
  tkgrid(tklabel(frame0, text = "MAP"),rb1,
         tklabel(frame0, text = "Bayes"), rb2,sticky="w")
  tkgrid(tklabel(frame0, text = "Least Squares"), rb3, 
         tklabel(frame0, text = "Poisson"),rb4,sticky="w")
  tkgrid(tklabel(frame0, text = "Lee & Carter"), rb5,
         tklabel(frame0, text = "Data"),rb6,sticky="w")
  tkpack(frame0)
    
  frame1.label2 <- tklabel(frame1, textvariable = tclVar(lyear),fg="blue")
  frame1.label3 <- tklabel(frame1, textvariable = tclVar(inyear),fg="blue")
  
  frame1.label5 <- tklabel(frame1, textvariable = tclVar(tol),fg="blue")
    
  
###    tkconfigure(frame1.entry1, state = "disabled") 
  frame1.entry2 <- tkentry(frame1, textvariable = var2, width = 10, bg=colorbox)
  ## action listener for the entry box: Tab
  tkbind(frame1.entry2, "<Tab>",  function() {
    var2.local <- as.character(tclvalue(var2))
    var2parse <- as.numeric(var2.local)
    assign("fore",var2parse, env=eGUI)
    assign("fore", var2parse, env=get("ewho", env=eGUI))
  })
    frame1.entry3 <- tkentry(frame1, textvariable = var3, width = 10, bg=colorbox)
    tkbind(frame1.entry3, "<Tab>",  function() {
      var3.local <- as.character(tclvalue(var3))
      var3parse <- as.numeric(var3.local)
      assign("yrest",var3parse, env=eGUI)
      assign("yrest", var3parse, env=get("ewho", env=eGUI))
    }) 
    
    frame1.entry5 <- tkentry(frame1, textvariable = var5,
                             width = 10, bg="lightgrey")
    tkbind(frame1.entry5, "<Tab>",  function() {
      var5.local <- as.character(tclvalue(var5))
      var5parse <- as.numeric(var5.local)
      assign("svdtol",var5parse, env=eGUI)
      assign("svdtol", var5parse, env=get("ewho", env=eGUI))
      }) 

    tkgrid(frame1.label2, frame1.entry2, sticky = "w")
    tkgrid(frame1.label3, frame1.entry3, sticky = "w")
###      tkgrid(frame1.label5, frame1.entry5, sticky = "w")
    tkpack(frame1, fill = "x")
 
    frame2.but1 <- tkbutton(frame2,  textvariable =tclVar("Close"), fg="red",
                            padx = 20, command =fore.close)
   
    frame2.but2 <- tkbutton(frame2, text = "Apply", padx = 20,command = fore.init)   
    tkgrid(frame2.but1, frame2.but2, sticky = "w")
    tkpack(frame2)
    return(tkforecast)
}
 

##
## DESCRIPTION:  Creates the GUI with textboxes for the country, year, age, discard digits 
##               These are the number of digits for the CSTDID identifiers of the code.
##               Say 2450451989, will have 4 digits (2450) for cntry;
##               2 digits for age groups (45) and another 4 digits for the year (1989), and
##               we do not discard any digits at the beginning of the string identifier.
##               Defaults values as described in namelist(). Upon pressing the button apply
##               (digits.init) changes values are written into memory.
##               The button close (digits.close), quits the application.
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: digits(base, textvalues).  Here base is the tktoplevel container to build the GUI
##         and textvalues are character strings with the texts for the entry boxes for
##         cntrty, year, age and discard digits. 
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container, base.
##         In addition, some of the default values for the entry text boxes,cntry, year, 
##         age, and discard, may have been changed and their
##         new values are written in memory
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************
 digits <- function(base, cdigit="Country Digits", ydigit ="Year Digits",
               adigit = "Age Digits", dsdigit = "Digits to Discard")
             {
    ewho <- get("ewho", env=parent.frame())
    defvar1 <- get("cntry.digits", env=ewho)
    defvar2 <- get("year.digits", env=ewho)
    defvar3 <- get("age.digits", env=ewho)
    defvar4 <- get("digit.first", env=ewho)
    cbg <- "lightgrey"
    textodisplay <- paste("Example index: 2450401995   \n",  
                          "First  4  digits 2450 (USA)    \n", 
                          "Next 2  digits 40 (age group) \n",
                          "Last 4  digits  1995 (year)    ")
    
 digits.close <- function(...) {
    var1parse <- as.character(tclvalue(var1))
    var2parse <- as.character(tclvalue(var2))
    var3parse <- as.character(tclvalue(var3))
    var4parse <- as.character(tclvalue(var4))
       
    assign("cntry.digits", as.numeric(var1parse), env=ewho)
    assign("year.digits", as.numeric(var2parse), env=ewho)
    assign("age.digits", as.numeric(var3parse), env=ewho)
    assign("digit.first", as.numeric(var4parse), env=ewho)
            
        tkdestroy(base)
    }
 digits.init <- function(...) {
        var1.local <- as.character(tclvalue(var1))
        var1parse <- var1.local
        var2.local <- as.character(tclvalue(var2))
        var2parse <- var2.local
        var3.local <- as.character(tclvalue(var3))
        var3parse <- var3.local
        var4.local <- as.character(tclvalue(var4))
        var4parse <- var4.local
       
        assign("cntry.digits",as.numeric(var1parse), env=ewho)
        assign("year.digits",as.numeric(var2parse), env=ewho)
        assign("age.digits", as.numeric(var3parse), env=ewho)
        assign("digit.first", as.numeric(var4parse), env=ewho)
            
###        cat("cntry.digits = ", var1.local, "\n")
###        cat("year.digits = ", var2.local, "\n")
###        cat("age.digits = ", var3.local, "\n")
###        cat("digit.first = ", var4.local, "\n")
              
              
    }

    tkdigits <-  tkframe(base, relief = "groove", borderwidth = 2)
 
    frame1 <- tkframe(tkdigits, relief = "groove", borderwidth = 2)
    frame2 <- tkframe(tkdigits, relief = "groove", borderwidth = 2)
  
    var1 <- tclVar(defvar1)
    var2 <- tclVar(defvar2)
    var3 <- tclVar(defvar3)
    var4 <- tclVar(defvar4)
   
    frame1.label2 <- tklabel(frame1, textvariable = tclVar(cdigit), fg="blue")
    frame1.label4 <- tklabel(frame1, textvariable = tclVar(ydigit),fg="blue")
    frame1.label3 <- tklabel(frame1, textvariable = tclVar(adigit),fg="blue")
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(dsdigit),fg="blue")
    frame1.label5 <- tklabel(frame1,
                             textvariable = tclVar(textodisplay ),fg="black")
    
    frame1.entry2 <- tkentry(frame1, textvariable = var1, width = 10,bg=cbg)
    frame1.entry4 <- tkentry(frame1, textvariable = var2, width = 10, bg=cbg)
    frame1.entry3 <- tkentry(frame1, textvariable = var3, width = 10, bg=cbg)
    frame1.entry1 <- tkentry(frame1, textvariable = var4, width = 10, bg=cbg)
   
    tkgrid(frame1.label1, frame1.entry1, sticky = "w")
    tkgrid(frame1.label2, frame1.entry2, sticky = "w")
    tkgrid(frame1.label3, frame1.entry3, sticky = "w")
    tkgrid(frame1.label4, frame1.entry4, sticky = "w")
    tkgrid(frame1.label5, sticky = "e")
    tkpack(frame1, fill = "x")
  
    frame2.but1 <- tkbutton(frame2,  textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = digits.close)
  
    frame2.but2 <- tkbutton(frame2, text = "Apply", padx = 20,command = digits.init)   
    tkgrid(frame2.but1, frame2.but2, sticky = "w")
    tkpack(frame2)
    return(tkdigits)
}

##
## DESCRIPTION:  Creates the GUI with textboxes for the depvariable, allcauses of death,
##               population, tarnsformation of depvar. Also two list boxes with the 
##               selections for the depvar and transformations.  Only one list box may
##               be selected at a time. Two buttons, the close button (depvar.close)
##               to cancel the frame and the  apply botton (depvar.init), which 
##               writes into memory any of the selected or entry items in the text boxes. 
##               Textboxes are for Dependent variable and Transformation,
##               the selections from the lists, which Apply registers them into memory
##               as well as the text boxes entries.  
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##
## FORMAT: depvar(base, textvalues).  Here base is the tktoplevel container to build the GUI
##         and textvalues are character strings with the texts for the entry boxes of the GUI
##         and for the list boxes containing the arrays or vectors stored in setdefaults
##         with dthString and transString of available death causes and trnasformations.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container, base.
##         In addition, some of the default values for the entry text boxes,depvar, all causes, 
##         population, and transformation, may have been changed from
##         their default values stored in namelist()and their new values are written in memory
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

trans.tonumber <-  function(defvar="log(depvar)")
    {
      if(is.na(defvar)|| defvar == "NA")
        var3parse <- NA
      else if(defvar == "log(depvar)")
        var3parse <- 1
      else if(defvar =="sqrt(depvar)" )
        var3parse <- 2
      else if(defvar == "log(depvar + 1)" )
        var3parse <- 3
      else
        stop(message="transformation no available")
   
       return(var3parse)
    }

 depvar <- function(base, morte="Dependent Variable", poblacion ="Population",
                    transtext ="Transformations: ",  
                    combdepvar= "Choose from",
                    poputrans ="Divide by: ")
  {
             
    ewho <- get("ewho", env=parent.frame())
    eGUI <- environment()
    defvar1 <- get("depvar", env=ewho)
    defvar2 <- get("population", env=ewho)
    defvar3 <- get("transform", env=ewho)
    dthString <- get("dthString", env =ewho)
    transString <- get("transString", env=ewho)
    cbg <- "white"
    combdepvar <- paste(combdepvar, "\n", "\n", "\n", "\n")
    var1parse <- defvar1
    var2parse <- defvar2
    var3parse <- defvar3
    
    depvar.close <- function(...) {

      var1parse <- as.character(tclvalue(var1))
      var2parse <- as.character(tclvalue(var2))
      rVal <- as.character(tclvalue(rbValue))
      var3parse <- trans.tonumber(defvar=rVal)
      assign("depvar",var1parse, env=ewho)
      assign("population", var2parse, env=ewho)
      assign("transform", as.numeric(var3parse), env=ewho)         
      tkdestroy(base)
    }
    depvar.init <- function(...) {
      var1parse <- as.character(tclvalue(var1))
      var2parse <- as.character(tclvalue(var2))
      rVal <- as.character(tclvalue(rbValue))
      var3parse <- trans.tonumber(defvar=rVal)
    
      if(length(as.numeric(tkcurselection(frame1.lstbox1))) >0){
        lst1choice <- dthString[as.numeric(tkcurselection(frame1.lstbox1))+1]
        defvar1 <- lst1choice
        tclvalue(var1) <- defvar1
        lst1choice <- tclVar(lst1choice)
        var1parse <- as.character(tclvalue(lst1choice))
      }
      assign("depvar",var1parse, env=ewho)
      assign("population", var2parse, env=ewho)
      assign("transform", as.numeric(var3parse), env=ewho)
      assign("depvar",var1parse, env=eGUI)
      assign("population", var2parse, env=eGUI)
      assign("transform", as.numeric(var3parse), env=eGUI)
###      cat("depvar = ", var1parse, "\n")
###      cat("population = ", var2parse, "\n")
###      cat("transform = ", as.numeric(var3parse), "\n")
             
    }

      
######
        
                        
 
    popu.select <- function()
      {
        depvar.file(popu=T); ##population that divides depvar
      }
    depvar.select <- function()
      {
        depvar.file(popu=F) ##depvar
      }
    
    depvar.file <- function(popu = F)
      {
        
        filename <- tclvalue(tkgetOpenFile())
        if (!nchar(filename))
          {
            tkmessageBox(message="No file selected")
            return(list()); 
          }
        
        tkmessageBox(message=paste("File selected is\n",filename ))
        
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        retreive.dth <- filename
### the exact address of userfile
          
        ff <- strsplit(retreive.dth,"/")[[1]]
        dthfile <- NULL
        if(length(ff) > 0){
          dthfile <- ff[length(ff)]
          ftext <- strsplit(dthfile, "\\.")[[1]][1]
        }
### just the name of the file
        if(length(dthfile) > 0 )
          defvar1 <- ftext
        else 
          defvar1 <- ""
        if(popu == F)
          {
            tclvalue(var1) <- defvar1
            var1.local <- as.character(defvar1)
            var1parse  <- var1.local
          }
        else
          {
            tclvalue(var2) <- defvar1
            var2.local <- as.character(defvar1)
            var2parse  <- var1.local
            
          }
      }
      
    
   ### main frame 
    tkdepvar <-  tkframe(base, relief = "groove", borderwidth = 2)
    topmenu <- tkmenu(base)
    tkconfigure(base, menu=topmenu)
    filemenu <- tkmenu(topmenu, tearoff=F)
  ### files menu for depvar and population
    tkadd(filemenu, "command", label= "depvar...", command= depvar.select)
    tkadd(filemenu, "command", label= "denominator...", command= popu.select) 
    tkadd(filemenu, "command", label="Quit",
          command=function() tkdestroy(base))
    
    tkadd(topmenu, "cascade", label="File", menu=filemenu)
### frame1 contains textboxes for depvar, population and radio buttons for transformations
    frame1  <- tkframe(tkdepvar, relief = "groove", borderwidth = 1)
    frame3  <- tkframe(tkdepvar, relief = "groove", borderwidth = 0) ## buttons only
    
    rbValue <- tclVar("log(depvar)") ## radio button default value
    var1 <- tclVar(defvar1) ## text box for depvar
    var2 <- tclVar(defvar2) ## text box for population
    var3 <- tclVar(defvar3) ## radio button choice

    frame1.label1 <- tklabel(frame1, textvariable = tclVar(morte),fg="blue")
    frame1.label2 <- tklabel(frame1, text =combdepvar)
    ## entry boxes for depvar, population   
    frame1.entry1 <- tkentry(frame1, textvariable = var1, width = 15, bg=cbg)
    frame1.entry2 <- tkentry(frame1, textvariable = var2, width = 15, bg=cbg)
   
    tkgrid(frame1.label1, frame1.entry1, sticky = "w")  
    ## list box for depvar selection
    scr <- tkscrollbar(frame1, repeatinterval=5,
                       command=function(...)tkyview(frame1.lstbox1, ...))
    frame1.lstbox1 <- tklistbox(frame1, height=4, selectmode="single",
                               yscrollcommand=function(...)tkset(scr,...),
                               background="white")
        
    for (i in 1:length(dthString))
    tkinsert(frame1.lstbox1, "end", dthString[i])
    tkselection.set(frame1.lstbox1, 5)
    ## bind event double click
    tkbind(frame1.lstbox1, "<Double-Button-1>", function() {
        if(length(as.numeric(tkcurselection(frame1.lstbox1))) >0){
            lst1choice <- dthString[as.numeric(tkcurselection(frame1.lstbox1))+1]
            defvar1 <- lst1choice
            tclvalue(var1) <- defvar1
            lst1choice <- tclVar(lst1choice)
            var1.local <- as.character(tclvalue(lst1choice))
            var1parse  <- var1.local}
        })      
          
    tkgrid(frame1.label2, frame1.lstbox1, scr,  sticky = "w")
    tkgrid.configure(scr, rowspan=4, sticky="nsw")
    
    frame1.label0 <-  tklabel(frame1, text = "   ") ##spacer for nice fitting
    frame1.label3 <- tklabel(frame1, text = transtext, fg="blue") ## Transformations
    frame1.label4 <- tklabel(frame1, text = poputrans) ## denominator or population
    frame1.entry2 <- tkentry(frame1, textvariable = var2, width = 15, bg=cbg) ##ppu box entry

    tkbind(frame1.entry2,"<Tab>", function(){
      assign("population", tclvalue(var2), env=ewho)
      assign("population", tclvalue(var2), env=eGUI)})

    tkgrid(frame1.label3, frame1.label0,sticky = "w")
    tkgrid(frame1.label4, frame1.entry2, sticky = "w")
    
    rb1 <- tkradiobutton(frame1)
    rb2 <- tkradiobutton(frame1)
    rb3 <- tkradiobutton(frame1)
    rb4 <- tkradiobutton(frame1)
    
    tkconfigure(rb1, variable= rbValue, value="log(depvar)")
    tkconfigure(rb2, variable= rbValue, value="sqrt(depvar)")
    tkconfigure(rb3, variable= rbValue, value="log(depvar + 1)")
    tkconfigure(rb4, variable= rbValue, value="NA")
    tkgrid(tklabel(frame1, text = "log(depvar)"),rb1,sticky="w")
    tkgrid(tklabel(frame1, text = "sqrt(depvar)"), rb2,sticky="w")
    tkgrid(tklabel(frame1, text = "log(depvar + 1)"), rb3,sticky="w")
    tkgrid(tklabel(frame1, text = "NA"),rb4,sticky="w")
    
    tkpack(frame1, fill = "x")

      
    frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"),
                            fg="red",padx = 20, command = depvar.close)
  
    frame3.but2 <- tkbutton(frame3, text = "Apply", padx = 20,command = depvar.init)   
    tkgrid(frame3.but1, frame3.but2, sticky = "w")
     tkpack(frame3)
    return(tkdepvar)
}


##
## DESCRIPTION:  Creates the GUI with a textbox for the skip parameters or minimum observations,
##               and tw list boxes. The list box labeled Codes & Name has the list of
##               available cntrys and their associated codes as read from the file code.names
##               in the datapath directory. The list box labeled Selected Countries
##               takes the selectin from the former list (Codes & Names) and display the user
##               selections of cntrys for the run. Three buttons at the bottom of the panel.
##               The Apply bottom, cntry.init, pick up the multiple selections from the
##               list box Codes & Names and displayed them in the list box to the right.
##               The Remove bottom, cntry.remove, takes the
##               multiple or single selection of the list with the Selected countries
##               and removed them, in case the user changes his mind and decide not to include
##               some of the countries.  The buttom Close, cntry.close, quits the application. 
##               Defaults values for cntry.list and skip are as described in namelist().
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: cntryLst(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the entry and two list boxes.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, cntry.list and skip
##         may be changed and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************
cntryLst <- function(base,lstcntry="Codes  & Names",
                     selectcntry="Selected Countries",
                     objtxt=  "Minimum Observations",
                     codestxt="File for codes.names" ){
  ewho <- get("ewho", env=parent.frame())
  defvar1 <- get("skip", env=ewho)
  defvar2 <- get("usercntrylist", env=ewho)
  datapath <- get("data.path", env=ewho);
  cntry.digits <- get("cntry.digits", env=ewho)
  data.path <- get("data.path", env=ewho)
  codes.names <- get("codes.names", env=ewho)
  filename <- paste(data.path,codes.names,".txt", sep="")
###  cat("in cntryLst   ")
###  print(filename)
  eGUI <- environment()
  var1 <- tclVar(defvar1)
  tmp <- scan(file=filename,what=c(integer(0),character(0)),
              quiet=T,multi.line=T, sep="\t",quote="\"")
  tmp <- matrix(tmp,ncol=2,byrow=T)
  cod <- as.integer(tmp[,1])
  codn <- length(cod)
  cntryString <- sapply(1:codn, function(n) {
    paste(as.character(tmp[n,1]),"       ", as.character(tmp[n,2]),sep="")})
  
  cntryString <- unlist(cntryString)
  cntrysubString <- NULL
  if(any(!is.na(defvar2)))
    {
      indx <- match(defvar2,tmp[,1])
      tmpsub <- tmp[indx,]
    
    if(length(indx) > 1)
      {
        cntrysubString <- sapply(1:length(indx), function(n) {
          paste(as.character(tmpsub[n,1]),"       ",
                as.character(tmpsub[n,2]),sep="")})
      }
    else
      cntrysubString <- paste(as.character(tmpsub[1]),"       ",
                              as.character(tmpsub[2]),sep="")
  }
  outputlist <- tclVar()
  if (length(cntrysubString) > 0)
    tclObj(outputlist) <- cntrysubString
  
  cbg = "white"
  
  cntry.close <- function(...) {
    var1parse <- as.character(tclvalue(var1))
    defvar2 <- get("defvar2", env=eGUI)
    assign("usercntrylist", defvar2, env=ewho)
    assign("skip", as.numeric(var1parse),env=ewho)
    tkdestroy(base)
  }
  cntry.init <- function(...) {

    cntrysubString <- get("cntrysubString", env =eGUI)
    defvar2 <- get("defvar2", env=eGUI)
    
    if(length(as.numeric(tkcurselection(frame2.lstbox1))) >0){
      
      lst1choice <- cntryString[as.numeric(tkcurselection(frame2.lstbox1))+1]
      cntrysubString <- c(cntrysubString,lst1choice)
      cntrysubString <- unique.default(cntrysubString)
      assign("cntrysubString", cntrysubString, env=eGUI)  
      if(!all(is.na(defvar2)))
        defvar2 <- c(defvar2,
                     as.numeric(sapply(lst1choice,substr,1, cntry.digits)))
      else
        defvar2 <- as.numeric(sapply(lst1choice,substr,1, cntry.digits))
      
      defvar2 <- unique.default(defvar2)
      assign("defvar2", defvar2,env=eGUI)
      assign("usercntrylist", defvar2, env=ewho)

      tclObj(outputlist) <- cntrysubString
       
      ##  if(!is.na(lst1choice[i]) ||lst1choice[i]!="NA" )
      ##   tkinsert(frame2.lstbox2,"end",lst1choice[i])      
      
    }
  }
  
  var1.local <- as.character(tclvalue(var1))
  var1parse  <- var1.local
  assign("skip", as.numeric(var1parse),env=ewho)
###           cat("skip = ", var1.local, "\n")
###           cat("usercntrylst = ", defvar2,"\n")      
  
  cntry.remove <- function(...) {
###      cat("first print...", cntrysubString,"...\n")
    if(length(as.numeric(tkcurselection(frame2.lstbox2))) >0){
      ind.to.delete <- as.numeric(tkcurselection(frame2.lstbox2)) +1
 
      cntrysubString <- cntrysubString[-ind.to.delete]
      
      assign("cntrysubString", cntrysubString, env=eGUI)
      
      tclObj(outputlist) <- cntrysubString
      if(length(cntrysubString) > 0)
        {
          defvar2 <- as.numeric(sapply(cntrysubString,substr,1, cntry.digits))
          defvar2 <- unique.default(defvar2)
        }else{
          defvar2 <- NA
        }
      
      assign("defvar2", defvar2,env=eGUI)
      assign("usercntrylist", defvar2, env=ewho)
      tkselection.set(frame2.lstbox2, length(cntrysubString) + 1)
###         cat("usercntrylst = ", defvar2,"\n")       
      
##print(tclObj(outputlist))
      
      
    }
  }
 
        
 
  tkcntry <-  tkframe(base, relief = "groove", borderwidth = 2)
  
  frame1  <- tkframe(tkcntry, relief = "groove", borderwidth = 2)
  frame2  <- tkframe(tkcntry, relief = "groove", borderwidth = 2)
  frame3  <- tkframe(tkcntry, relief = "groove", borderwidth = 2)
  var1 <- tclVar(defvar1)
  frame1.label1 <- tklabel(frame1, textvariable = tclVar(objtxt),
                           fg="blue", anchor="w")
  frame1.entry1 <- tkentry(frame1, textvariable = var1, width = 5, bg=cbg)
 
  tkgrid(frame1.label1, frame1.entry1, sticky = "w")

  tkpack(frame1, fill = "x",anchor="w")
  
  frame2.label1 <- tklabel(frame2, text = lstcntry)
  frame2.label2 <-  tklabel(frame2, text = selectcntry)
  frame2.label3 <-  tklabel(frame2, text = "   ")
  
  scr1 <- tkscrollbar(frame2, repeatinterval=5,
                      command=function(...)tkyview(frame2.lstbox1, ...))
  frame2.lstbox1 <- tklistbox(frame2, height=4, selectmode="extended",
                              yscrollcommand=function(...)tkset(scr1,...),
                              background="white")
  scr2 <- tkscrollbar(frame2, repeatinterval=5,
                      command=function(...)tkyview(frame2.lstbox2, ...))
  for (i in 1:codn)
    tkinsert(frame2.lstbox1, "end", cntryString[i])
  
 
  tkselection.set(frame2.lstbox1, -1)
  
  
  frame2.lstbox2 <- tklistbox(frame2, height=4, selectmode="extended",
                              yscrollcommand=function(...)tkset(scr2,...),
                              background="white",listvariable=outputlist)
  
 ### if(length(cntrysubString) > 0)
    ###  tkinsert(frame2.lstbox2, "end", cntrysubString)   
  
  tkgrid(frame2.label1,frame2.label3,frame2.label2,sticky="w")
  tkgrid(frame2.lstbox1,scr1,frame2.lstbox2,scr2,sticky="e")
  tkgrid.configure(scr1, rowspan=4, sticky="nsw")
  tkgrid.configure(scr2, rowspan=4, sticky="nsw")
  tkpack(frame2)
  
  
  frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"), fg="red",
                          padx = 20, command = cntry.close)
  
  frame3.but2 <- tkbutton(frame3, text = "Apply   >>", padx = 15, command = cntry.init)
  frame3.but3 <- tkbutton(frame3, text = "<<  Remove", padx = 15, command = cntry.remove)
  frame3.label1 <- tklabel(frame3, text = " ")
  tkgrid(frame3.but2, frame3.but1, frame3.but3, sticky = "w")
  ##  tkgrid(frame3.label1,frame3.but1)
  tkpack(frame3)
  return(tkcntry)
}

##
## DESCRIPTION:  Creates the GUI with a radio buttoms for the strata (or gender), 
##               and two list boxes. The list box labeled Age Groups has the list of
##               age groups as in the vector agesString of set.defaults.
##               The list box labeled Selected Ages takes the selection from the
##               former list (Ages Groups) and display the user
##               selections of ages  for this  run. Three buttons at the bottom of the panel.
##               The Apply bottom, strata.init, pick up the multiple selections from the
##               list box Ages Groups and displayed them in the list box to the right.
##               The Remove bottom, strata.remove, takes the
##               multiple or single selection of the list with the Selected Ages 
##               and removed them, in case the user changes his mind and decide not to include
##               some of the groups.  The buttom Close, strata.close,  quits the application. 
##               Defaults values for strata, userages are as described in namelist().
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: strata.select(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the radio buttons and two list boxes.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, strata and userages 
##         may be changed and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

 strata.select <- function(base,textStrata="Strata Variable",
                           textStrataVal="Strata Value", 
                           textAge1 ="Age Groups",
                           textAge2= "Selected Ages")
             {
    ewho <- get("ewho", env=parent.frame())
    defvar1 <- get("strata", env=ewho)
    defvar2 <- get("userages", env=ewho)
    defvar  <- get("depvar", env=ewho)
    agesString <- get("agesString", env=ewho)
    agesList <- tclVar()
    tclObj(agesList) <- agesString
    varg <- tclVar("gender")
    var1 <- tclVar(defvar1)
    cbg = "white"
    
    outputlist <- tclVar(defvar2)
    if (all(is.na(defvar2)))
      tclObj(outputlist) <- "<NA>"
    agesubString <- NULL
    
    eGUI <- environment()
    
    strata.close <- function(...) {
       
      defvar1 <- as.numeric(tclvalue(var1))    
      
      defvar2 <- get("defvar2", env=eGUI)
      if (length(defvar2) <= 0)
        defvar2 <- NA
      assign("userages", as.numeric(defvar2), env=ewho)
      assign("strata", as.numeric(defvar1), env=ewho)
      
      tkdestroy(base)
    }
     strata.init <- function(...) {
     agesubString <- get("agesubString", env =eGUI)
     defvar2 <- get("defvar2", env=eGUI)
       
       if(length(as.numeric(tkcurselection(frame2.lstbox1))) >0){
        
       lst1choice <- agesString[as.numeric(tkcurselection(frame2.lstbox1))+1]
       agesubString <- c(agesubString,lst1choice)
       agesubString <- unique.default(agesubString)
       assign("agesubString", agesubString, env=eGUI)  
         if(!all(is.na(defvar2)))
           defvar2 <- c(defvar2, as.numeric(lst1choice))
         else
           defvar2 <- as.numeric(lst1choice)
         
         defvar2 <- unique.default(defvar2)
         assign("defvar2", defvar2,env=eGUI)
         assign("userages", defvar2, env=ewho)
         
       
           tclObj(outputlist) <- agesubString
                  
      }        
       
###      cat("userages = ", defvar2,"\n")
          
        
    }
      strata.remove <- function(...) {
###      cat("first print...", agesubString,"...\n")
      if(length(as.numeric(tkcurselection(frame2.lstbox2))) >0){
        ind.to.delete <- as.numeric(tkcurselection(frame2.lstbox2)) +1
        if(length(agesubString) > 0)
          {   
            agesubString <- agesubString[-ind.to.delete]
            assign("agesubString", agesubString, env=eGUI)
          }
        else
          {
           agesubString <- tclvalue(outputlist)
           agesubString <- unlist(strsplit(agesubString, " "))
           agesubString <- agesubString[-ind.to.delete]
           if(length(agesubString) <= 0){
             agesuString <- NA
             userages <- NA
           }
          
         }
           
        tclObj(outputlist) <- agesubString
        defvar2 <- as.numeric(agesubString)
        defvar2 <- unique.default(defvar2)
        if(length(defvar2) <= 0)
          defvar2 <- NA
        assign("defvar2", defvar2,env=eGUI)
        assign("userages", defvar2, env=ewho)
        assign("agesubString", agesubString, env=eGUI)
        assign("userages",defvar2, env=eGUI)
       
         tkselection.set(frame2.lstbox2, length(agesubString) + 1)
###         cat("userages = ", defvar2,"\n")       
       
        ##print(tclObj(outputlist))
      
  
      }
    }

    tkstrata <-  tkframe(base, relief = "groove", borderwidth = 2)
  
    frame1  <- tkframe(tkstrata, relief = "groove", borderwidth = 2)
    frame2 <- tkframe(tkstrata, relief = "groove", borderwidth = 2)
    frame3 <- tkframe(tkstrata, relief = "groove", borderwidth = 2)
           
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(textStrata),
                             fg="blue")
    frame1.entry1 <- frame1.entry1 <- tkentry(frame1, textvariable = varg,
                                             width = 15, bg=cbg)
    frame1.label2 <- tklabel(frame1, textvariable = tclVar(textStrataVal),
                             fg="black")
    
    frame1.entry2 <- tkentry(frame1, textvariable = var1,
                                             width = 8, bg=cbg)
    tkgrid(frame1.label1,frame1.entry1, sticky="w")
    tkgrid(frame1.label2,frame1.entry2, sticky="w")
                         

    tkbind(frame1.entry2,"<Tab>", function(){
     assign("strata", as.numeric(tclvalue(var1)), env=ewho)
     assign("defvar1", as.numeric(tclvalue(var1)), env=eGUI)})
    
    
    scr1 <- tkscrollbar(frame2, repeatinterval=5,
                       command=function(...)tkyview(frame2.lstbox1, ...))
    frame2.lstbox1 <- tklistbox(frame2, height=4, selectmode="extended",
                               yscrollcommand=function(...)tkset(scr1,...),
                               background="white", listvariable =agesList)
    scr2 <- tkscrollbar(frame2, repeatinterval=5,
                       command=function(...)tkyview(frame2.lstbox2, ...))
    
    tkselection.set(frame2.lstbox1, -1)
    frame2.lstbox2 <- tklistbox(frame2, height=4, selectmode="extended",
                               yscrollcommand=function(...)tkset(scr2,...),
                               background="white",listvariable=outputlist)
    frame2.label1 <- tklabel(frame2, textvariable = tclVar(textAge1),
                             fg="blue")
    frame2.label2 <- tklabel(frame2, textvariable = tclVar(textAge2),
                             fg="blue")
    frame2.label3 <- tklabel(frame2, textvariable = tclVar("   "))
    tkgrid(frame2.label1,frame2.label3,frame2.label2,sticky="w")
    tkgrid(frame2.lstbox1,scr1,frame2.lstbox2,scr2,sticky="e")
    tkgrid.configure(scr1, rowspan=4, sticky="nsw")
    tkgrid.configure(scr2, rowspan=4, sticky="nsw")
    
    frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = strata.close)
    
    frame3.but2 <- tkbutton(frame3, text = "Apply   >>", padx = 15,command = strata.init)
    frame3.but3 <- tkbutton(frame3, text = "<<  Remove", padx = 15,command = strata.remove)
    frame3.label1 <- tklabel(frame3, text = " ")
    tkgrid(frame3.but2, frame3.but1, frame3.but3, sticky = "w")
   
    combFrame <- comboBox(base=tkstrata)
   
     tkpack(frame1, fill = "x")
### how to use the comboBox, with function comboBox()
### that returns a frame, and pack it somewhere 
###    tkpack(combFrame,fill="x")  
    tkpack(frame2,fill="x")
    tkpack(frame3, fill="x")  
   
   return(tkstrata)
}
##
## DESCRIPTION:  Creates the GUI with tthe text box for the covariate name, or otherwise
##               select the name from a combo box dropdown list (Select from:).
##               The covariate selected or selected will not be considered for all age groups.  
##               The age groups that will be excluded from the study for selected covaraites are
##               chosen with the two list boxes. The list box labeled Age Groups has the list of
##               age groups as in the vector agesString of set.defaults.
##               The list box labeled Selected Ages takes the selection from the
##               former list (Ages Groups) and display the user
##               selections of ages  for this  run. Three buttons at the bottom of the panel.
##               The Apply bottom, covage.init, pick up the multiple selections from the
##               list box Ages Groups and displayed them in the list box to the right.
##               The Remove bottom, covage.remove, takes the
##               multiple or single selection of the list with the Selected Ages 
##               and removed them, in case the user changes his mind and decide not to include
##               some of the groups.  The buttom Close, covage.close,  quits the application. 
##               Defaults values for strata, userages are as described in namelist().
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##                 
## FORMAT: covage(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the entry text, combo box,  
##         buttons and two list boxes.
##
## IMPORTED functions:it uses function comboBox that builds the drop down lsit box,
##            also set.defaults with ageString. 
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, age.select and cov.select,   
##         may be changed and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

 covage <- function(base,textCov="Enter Excluded Covariate",
                    textOR ="OR", textna = "<NA>", 
                    textCov1 = "Select From:    ", 
                    textAge1 ="Age Groups", textAge2= "Selected Ages")
             {
    ewho <- get("ewho", env=parent.frame())
    defvar1 <- unlist(get("cov.select", env=ewho))
    defvar2 <- unlist(get("age.select", env=ewho))
    agesubString <- defvar2
    names(agesubString) <- rep(defvar1, length(agesubString))
  
    agesString <- get("agesString", env=ewho)
    covString  <- get("covString", env=ewho)
    
    agesList <- tclVar()
    tclObj(agesList) <- agesString
    outputlist <- tclVar()
    tclObj(outputlist) <- textna
    
    covlst <- tclVar()
    tclObj(covlst) <- covString
  
    var3 <- tclVar()
    tclObj(var3) <- textna
    
    eGUI <- environment()
    if(is.na(defvar1)){ 
      cov.exclude <- NULL
      age.exclude <- NULL
    }else{
      cov.exclude <- defvar1
      age.exclude <- defvar2
     
    }
    nages <- length(age.exclude)
    names(age.exclude) <- rep(cov.exclude, nages)
    cbg <- "white"
   
    
    covage.close <- function(...) {
       
       tkdestroy(base)
       age.select <- get("age.select", env=get("ewho",env=eGUI))
       cov.select <- get("cov.select", env=get("ewho",env=eGUI))
       age.select <- sort(na.omit(age.select))
       cov.select <- na.omit(cov.select)
###       print(age.select)
###       print(cov.select)
### programs are written so that all covariets in cov.select
### have same age groups excluded, so we need to find
       age.select <- unique.default(age.select)
       names(age.select) <- NULL
       cov.select <- unique.default(unlist(cov.select))
       assign("age.select", as.numeric(age.select),env=ewho)
       assign("cov.select", cov.select,env=ewho)       
    }
     covage.init <- function(...) {
  
     age.exclude <- get("age.exclude", env=eGUI)
     cov.exclude <- get("cov.exclude", env=eGUI)
## if entering a name for covariate in the entry field,
## then ignore the selection for the ComboBox
     comboValue <-  get("comboEntry", env=ewho)[1]
     if( trim.blanks(tclvalue(var3)) != textna && 
         as.character(trim.blanks(tclvalue(var3))) != comboValue  ){
         defvar1 <- tclvalue(tclObj(var3))
         tclObj(var3) <- textna
     }else{
         tclObj(var3) <- textna
         defvar1 <- get("comboEntry", env=get("ewho", env=eGUI))[1]
       }
     assign("defvar1", defvar1, env=eGUI)
     ind.exclude <- grep(defvar1, names(age.exclude))
     if(length(ind.exclude) > 0){
       age.exclude <- age.exclude[-ind.exclude]
       cov.exclude <- cov.exclude[-grep(defvar1,cov.exclude)]
     }
     if(length(as.numeric(tkcurselection(frame2.lstbox1))) >0){    
       lst1choice <- agesString[as.numeric(tkcurselection(frame2.lstbox1))+1]
       agesubString <- unique.default(lst1choice)
       names(agesubString) <- rep(defvar1,length(agesubString))
    
       age.exclude  <- c(agesubString,age.exclude)    
       cov.exclude  <- unique.default(c(defvar1, cov.exclude))
        
###         print(age.exclude)
###         print(cov.exclude)
       
       }else{
         lst1choice  <- c(NA)
         names(lst1choice) <- defvar1
         agesubString <- textna
         age.exclude <- c(lst1choice, age.exclude)
         cov.exclude <- c(defvar1, cov.exclude)
       }
    
    assign("age.exclude", age.exclude, env=eGUI)
    assign("cov.exclude", cov.exclude, env=eGUI)
    assign("agesubString", agesubString, env=eGUI)
     
         age.select <- as.numeric(age.exclude)
         names(age.select) <- names(age.exclude)
         cov.select <-  unique.default(names(age.exclude))
         assign("age.select", age.select,env=ewho)
         assign("cov.select", cov.select, env=ewho)
         tclObj(outputlist) <- agesubString
                            
     }        
            
      covage.remove <- function(...) {
        
        age.exclude <- get("age.exclude", env=eGUI)
        cov.exclude <- get("cov.exclude", env=eGUI)
         if( tclvalue(var3) != textna &&
           as.character(tclvalue(var3)) != get("comboEntry", env=ewho)[1] ){
          defvar1 <- tclvalue(tclObj(var3))
          tclObj(var3) <- textna
        }else
          defvar1 <- get("comboEntry", env=get("ewho", env=eGUI))[1]
        
      if(length(as.numeric(tkcurselection(frame2.lstbox2))) >0){
        ind.to.delete <- as.numeric(tkcurselection(frame2.lstbox2)) +1
        agesubString <- agesubString[-ind.to.delete]
        defvar2 <- as.numeric(agesubString)
        names(defvar2) <- names(agesubString)
        assign("agesubString", agesubString, env=eGUI)
        tclObj(outputlist) <- agesubString                      
        ind.exclude <- grep(defvar1, names(age.exclude))
        if(length(ind.exclude) > 0){
          age.exclude <- age.exclude[-ind.exclude]
          cov.exclude <- cov.exclude[-grep(defvar1,cov.exclude)]
          age.exclude <- c(agesubString, age.exclude)
          cov.exclude  <- unique.default(c(defvar1, cov.exclude)) }
         
        }else{
          agesubString <- textna
          defvar2 <- as.numeric(agesubString)
          names(defvar2) <- names(agesubString)
          assign("agesubString", agesubString, env=eGUI)
          tclObj(outputlist) <- agesubString
           ind.exclude <- grep(defvar1, names(age.exclude))
        if(length(ind.exclude) > 0){
          age.exclude <- age.exclude[-ind.exclude]
          cov.exclude <- cov.exclude[-grep(defvar1,cov.exclude)]
          age.exclude <- c(agesubString, age.exclude)
          cov.exclude  <- unique.default(c(defvar1, cov.exclude)) }
        }
          assign("age.exclude", age.exclude, env=eGUI)
          assign("cov.exclude", cov.exclude, env=eGUI)
          age.select <- as.numeric(age.exclude)
          names(age.select) <- names(age.exclude)
          cov.select <-  unique.default(names(age.exclude))
          assign("age.select", age.select,env=ewho)
          assign("cov.select", cov.select, env=ewho)
      
              
         tkselection.set(frame2.lstbox2, length(agesubString) + 1)
###         print(age.select)
###         cat("cov.select = ", cov.select,"\n")
       
###       print(tclObj(outputlist))
    }  
      
    
    
    tkcovage <-  tkframe(base, relief = "groove", borderwidth = 2)
    frame1   <- tkframe(tkcovage, relief = "groove", borderwidth = 2)
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(textCov),
                             fg="blue")
   
    frame1.entry1 <- tkentry(frame1, textvariable = var3, width = 15, bg=cbg)
##  frame1.entry1 <- tkentry(frame1, width = 15)
    tkgrid(frame1.label1, frame1.entry1, sticky = "w")
    frame1.label2 <-  tklabel(frame1, textvariable = tclVar(textOR),
                             fg="red")
 
    frame1.label3 <- tklabel(frame1, textvariable = tclVar("  "),
                              fg="blue")
    tkgrid(frame1.label2, frame1.label3, sticky="w")
    
    tkpack(frame1, fill = "x")
  ###*****
  ind <- grep(defvar1, covString)
    if(is.na(ind) || length(ind) <= 0)
      ind <- -1
  combFrame <- comboBox(base=tkcovage,
                        fruits=covString,
                        fruit.selection=ind, text=textCov1, 
                        env.towrite= ewho)
    if(!all(is.na(defvar2)))
      tclObj(outputlist) <- sapply(defvar2, formatC,width=2, format="d",flag="0")

### how to use the comboBox, with function comboBox()
### that returns a frame, and pack it somewhere
   
    tkpack(combFrame,fill="x")
  
    frame2 <- tkframe(tkcovage, relief = "groove", borderwidth = 2)
    frame3 <- tkframe(tkcovage, relief = "groove", borderwidth = 2)
  
    scr1 <- tkscrollbar(frame2, repeatinterval=5,
                       command=function(...)tkyview(frame2.lstbox1, ...))
    frame2.lstbox1 <- tklistbox(frame2, height=4, selectmode="extended",
                               yscrollcommand=function(...)tkset(scr1,...),
                               background="white", listvariable =agesList)
    scr2 <- tkscrollbar(frame2, repeatinterval=5,
                       command=function(...)tkyview(frame2.lstbox2, ...))
    
    tkselection.set(frame2.lstbox1, -1)
    frame2.lstbox2 <- tklistbox(frame2, height=4, selectmode="extended",
                               yscrollcommand=function(...)tkset(scr2,...),
                               background="white",listvariable=outputlist)
    frame2.label1 <- tklabel(frame2, textvariable = tclVar(textAge1),
                             fg="blue")
    frame2.label2 <- tklabel(frame2, textvariable = tclVar(textAge2),
                             fg="blue")
    frame2.label3 <- tklabel(frame2, textvariable = tclVar("   "))
    tkgrid(frame2.label1,frame2.label3,frame2.label2,sticky="w")
    tkgrid(frame2.lstbox1,scr1,frame2.lstbox2,scr2,sticky="e")
    tkgrid.configure(scr1, rowspan=4, sticky="nsw")
    tkgrid.configure(scr2, rowspan=4, sticky="nsw")
    
    frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = covage.close)
    
    frame3.but2 <- tkbutton(frame3, text = "Apply   >>", padx = 15,command = covage.init)
    frame3.but3 <- tkbutton(frame3, text = "<<  Remove", padx = 15,command = covage.remove)
    frame3.label1 <- tklabel(frame3, text = " ")
    tkgrid(frame3.but2, frame3.but1, frame3.but3, sticky = "w")
   
  
    tkpack(frame2,fill="x")
    tkpack(frame3, fill="x")  
     return(tkcovage)
 ###   return(environment())
}

##
## DESCRIPTION:  Creates the GUI with a radio buttoms for the standardization of covariates, and
##               for the testing of colliniarities among selected covs. Four text boxes, one
##               for the percentage of data to loose, lag.cutoff, when the covariate is
##               included in the run due to the presence of missing values; a number <= 1 
##               Three text boxes for the tolerance parameters, tol, delta.tol and solve.tol
##               to detect collinearities among covariates. The buttom Apply has command   
##               with standard.init, and writes into memory the new values
##               enter in any of the text boxes or choices for collinearities or standardization. 
##               The buttom Close, standard.close,  quits the application. 
##               Defaults values for tolerances, lag.cutoff and radio buttoms are in namelists().
##               New values are written in the nevironmnet env.who(ewho) or the calling environmnet.
##                 
## FORMAT: standard.cov(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the radio buttons and two list boxes.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, some of the default values for the parameters, tol, delta.tol, solve.tol
##         and lag.cutoff, as well as the choice for standardization of covaraites (T or F), 
##         and for detection (T or F) of colliniarities, can be changed with the GUI  
##         and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


standard.cov <- function(base,textCollinear="Collinearity",
                    textMissing ="Missing Values (%) ",
                    textLag     = " Lag  Years", 
                    textStandard ="Standardization",
                    textTol = "Tolerance Parameters",
                    toltext = "SVD (svdtol)")
             {
    ewho <- get("ewho", env=parent.frame())
    elim.collinear <- get("elim.collinear", env=ewho)
    standardize <- get("standardize", env=ewho)
    lag.cutoff <- get("lag.cutoff", env=ewho)
    lag    <-  get("lag", env=ewho)
    tol <- get("tol", env=ewho)
    delta.tol <- get("delta.tol", env=ewho)
    solve.tol <- get("solve.tol", env=ewho)
    svdtol <- get("svdtol", env=ewho)
    if(standardize ) 
      rbValue1 <- tclVar("True")
    else
       rbValue1 <- tclVar("False")
    if(elim.collinear)  
      rbValue2 <- tclVar("True")
    else
       rbValue2 <- tclVar("False")
    var1 <- tclVar()
    tclObj(var1) <- lag.cutoff
    varlag <- tclVar()
    tclObj(varlag) <- lag
    var2 <- tclVar()
    tclObj(var2) <- tol
    var3 <- tclVar()
    tclObj(var3) <- delta.tol
    var4 <- tclVar()
    tclObj(var4) <- solve.tol
    varst <- tclVar()
    varsvd <- tclVar()
    tclObj(varsvd) <- svdtol
    colorentry <- "white"
    if(elim.collinear)
      tclObj(varst) <- "normal"
    else{
       tclObj(varst) <- "disable"
       colorentry <- "grey"
     }
    var1parse <- as.character(tclvalue(var1))
    varlagparse <- as.character(tclvalue(varlag))
    var2parse <- as.character(tclvalue(var2))
    var3parse <- as.character(tclvalue(var3))
    var4parse <- as.character(tclvalue(var4))
    varsvdparse <- tclvalue(varsvd)
    
    eGUI <- environment()
    
    standard.close <- function(...) {
     
     standard.init()
     tkdestroy(base)
    }
    standard.init <- function(...) {
      
      rVal1 <- as.character(tclvalue(rbValue1))
      
      if(rVal1 == "True")
        standardize <- T
      else
        standardize <- F
    
      rVal2 <- as.character(tclvalue(rbValue2))
            
      if(rVal2 == "True"){
        elim.collinear <- T
        tclObj(varst) <- "normal"
        tkconfigure(frame3.entry1, state=tclvalue(varst),bg="white")
        tkconfigure(frame3.entry2, state=tclvalue(varst), bg="white")
        tkconfigure(frame3.entry3, state="normal", bg="white")
      }else{ 
        elim.collinear <- F
        tclObj(varst) <- "disabled"
        tkconfigure(frame3.entry1, state=tclvalue(varst),bg="lightgray")
        tkconfigure(frame3.entry2, state=tclvalue(varst), bg="lightgray")
        tkconfigure(frame3.entry3, state="disabled", bg="lightgray")
      }
        
      ##
       
      
      assign("lag.cutoff",as.numeric(tclvalue(var1)), env=ewho)
      assign("lag",as.numeric(tclvalue(varlag)), env=ewho)
      assign("tol",as.numeric(tclvalue(var2)), env=ewho)
      assign("delta.tol", as.numeric(tclvalue(var3)), env=ewho)
      assign("solve.tol", as.numeric(tclvalue(var4)), env=ewho)
           assign("svdtol", as.numeric(tclvalue(varsvd)), env=ewho)
      
###      cat("lag.cutoff = ", var1parse, "\n")
###      cat("lag = ", varlagparse, "\n")
###      cat("tol = ", var2parse, "\n")
###      cat("delta.tol = ", var3parse, "\n")
###      cat("solve.tol = ", var4parse, "\n")
                       
      }        
    
    
    tkstandard <-  tkframe(base, relief = "groove", borderwidth = 2)
    frame03 <- tkframe(tkstandard, relief = "groove", borderwidth = 2)
    frame0 <- tkframe(tkstandard, relief = "groove", borderwidth = 2)
    
    frame12 <-  tkframe(tkstandard, relief = "groove", borderwidth = 2)
    frame1 <- tkframe(frame12, relief = "groove", borderwidth = 2)
    frame2 <- tkframe(frame12, relief = "groove", borderwidth = 2)
    frame3 <- tkframe(tkstandard, relief = "groove", borderwidth = 2)
    frame4 <- tkframe(tkstandard, relief = "groove", borderwidth = 2)
### filling frame0
    frame0.label0 <-  tklabel(frame0, textvariable = tclVar(textLag), fg="blue")
    frame0.label1 <- tklabel(frame0, textvariable  = tclVar(textMissing),
                             fg="blue")
    frame0.label2 <- tklabel(frame0, textvariable = tclVar("lag.cutoff"))
    frame0.label3 <- tklabel(frame0, textvariable = tclVar("  lag(= fore - yrest)   "))
    frame0.entry1 <- tkentry(frame0, textvariable = var1,
                             width =8, bg="white")

    tkbind(frame0.entry1,"<Tab>", function(){
      var1parse <- tclvalue(var1)
      assign("lag.cutoff", as.numeric(var1parse), env=ewho)
      assign("lag.cutoff", as.numeric(var1parse), env=eGUI)})
    
    frame0.entry2 <- tkentry(frame0, textvariable = varlag,
                             width =8, bg="white")
    tkbind(frame0.entry2,"<Tab>", function(){
     varlagparse <- tclvalue(varlag)
     assign("lag", as.numeric(varlagparse), env=ewho)
     assign("lag", as.numeric(varlagparse), env=eGUI)})
   
    tkgrid(frame0.label1, tklabel(frame0, text ="        "), frame0.label0,sticky="w")
    tkgrid(frame0.label2, frame0.entry1, frame0.label3, frame0.entry2, sticky = "w")
    tkpack(frame0)
    
### filling frame1
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(textStandard),
                             fg="blue")
    frame1.label2 <- tklabel(frame1, textvariable = tclVar("Standardize"))
 ### for standard bottons
    rb11 <- tkradiobutton(frame1)
    rb12 <- tkradiobutton(frame1)
    tkconfigure(rb11, variable= rbValue1, value="True")
    tkconfigure(rb12, variable= rbValue1, value="False")
      
    tkbind(rb11,"<Button-1>", function(){
      standardize <- T
      rbValue1 <- tclVar("True")
      assign("standardize", standardize, env=eGUI)
       assign("standardize", standardize, env=ewho)
      assign("rbValue1", rbValue1, env=eGUI)
         })
    
    tkbind(rb12,"<Button-1>", function(){
      standardize <- F
       rbValue1 <- tclVar("False")
      assign("standardize", standardize, env=eGUI)
       assign("standardize", standardize, env=ewho)
        assign("rbValue1", rbValue1, env=eGUI)
         })
    
    
  
    tkgrid(frame1.label1,sticky="w")
##    tkgrid(tklabel(frame1, text="True"), rb11,sticky="w")
##    tkgrid(tklabel(frame1, text="False"), rb12,sticky="w")
    tkgrid(tklabel(frame1, text="True"), rb11,tklabel(frame1, text="False"), rb12,sticky="w")
   
    frame2.label1 <- tklabel(frame2, textvariable = tclVar(textCollinear),
                             fg="blue")
### collinearities radio buttons
    rb21 <- tkradiobutton(frame2)
     tkconfigure(rb21, variable= rbValue2, value="True")
    tkbind(rb21,"<Button-1>", function(){
       elim.collinear <- T
       rbValue2 <- tclVar("True")
       assign("elim.collinear", elim.collinear, env=eGUI)
       assign("elim.collinear", elim.collinear, env=ewho)
       tclObj(varst) <- "normal"
        tkconfigure(frame3.entry1, state=tclvalue(varst),bg="white")
        tkconfigure(frame3.entry2, state=tclvalue(varst), bg="white")
        tkconfigure(frame3.entry3, state="normal", bg="white")
      assign("standardize", standardize, env=eGUI)
       assign("standardize", standardize, env=ewho)
         assign("rbValue2", rbValue2, env=eGUI)
         })
    
    rb22 <- tkradiobutton(frame2)
    tkconfigure(rb22, variable= rbValue2, value="False")
    tkbind(rb22,"<Button-1>", function(){
      elim.collinear <- F
      rbValue2 <- tclVar("False")
      assign("elim.collinear", elim.collinear, env=eGUI)
      assign("elim.collinear", elim.collinear, env=ewho)
      assign("rbValue2", rbValue2, env=eGUI)
      tclObj(varst) <- "disable"
      tkconfigure(frame3.entry1, state=tclvalue(varst),bg="lightgrey")
      tkconfigure(frame3.entry2, state=tclvalue(varst), bg="lightgrey")
      tkconfigure(frame3.entry3, state="normal", bg="lightgrey")
      
    })
    
    tkgrid(frame2.label1,sticky="w")
    tkgrid(tklabel(frame2, text="True"), rb21,
           tklabel(frame2, text="False"), rb22,sticky="w")
    
    tkgrid(frame1, frame2, sticky="w")
    ## tkgrid(frame12)
    tkpack(frame12, fill="x")
    frame3.label0 <- tklabel(frame3, textvariable = tclVar(textTol),fg="blue")
    frame3.label1 <- tklabel(frame3, textvariable = tclVar("tol"))
    
    frame3.label2 <- tklabel(frame3, textvariable = tclVar("delta.tol"))
    frame3.label3 <- tklabel(frame3, textvariable = tclVar("solve.tol"))
    frame3.label4 <-  tklabel(frame3, textvariable = tclVar(toltext),fg="black")
  
    frame3.entry1 <- tkentry(frame3, textvariable = var2, width = 15)
     tkbind(frame3.entry1,"<Tab>", function(){
       assign("tol", as.numeric(tclvalue(var2)), env=ewho)
       assign("tol", as.numeric(tclvalue(var2)), env=eGUI)})
    
    frame3.entry2 <- tkentry(frame3, textvariable = var3, width = 15)
    tkbind(frame3.entry2,"<Tab>", function(){
      assign("delta.tol", as.numeric(tclvalue(var3)), env=ewho)
      assign("delta.tol", as.numeric(tclvalue(var3)), env=eGUI)})
    
    frame3.entry3 <- tkentry(frame3, textvariable = var4, width = 15)
    tkbind(frame3.entry3,"<Tab>", function(){
      assign("solve.tol", as.numeric(tclvalue(var4)), env=ewho)
      assign("solve.tol", as.numeric(tclvalue(var4)), env=eGUI)})
 
    
    frame3.entry4 <- tkentry(frame3, textvariable = varsvd,
                             width = 15, bg=colorentry)
    
    tkbind(frame3.entry4, "<Tab>",  function() {
      varsvd.local <- as.character(tclvalue(varsvd))
      varsvdparse <- as.numeric(varsvd.local)
      assign("svdtol",varsvdparse, env=eGUI)
      assign("svdtol", varsvdparse, env=get("ewho", env=eGUI))
      })
    
    tkconfigure(frame3.entry1, state=tclvalue(varst),bg=colorentry)
    tkconfigure(frame3.entry2, state=tclvalue(varst), bg=colorentry)
    tkconfigure(frame3.entry3, state=tclvalue(varst), bg=colorentry)
    
    tkgrid(frame3.label0, sticky="w")
    tkgrid(frame3.label1, frame3.entry1, sticky = "w")
    tkgrid(frame3.label2, frame3.entry2, sticky = "w")
    tkgrid(frame3.label3, frame3.entry3, sticky = "w")
    tkgrid(frame3.label4, frame3.entry4, sticky= "w")
###    tkgrid(frame0, frame3, sticky="w")
 ##   tkgrid(frame0, sticky="w")
 ##   tkgrid(frame3, sticky="w")
   
    tkpack(frame3,fill="x")
    
    frame4.but1 <- tkbutton(frame4, textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = standard.close)
    
    frame4.but2 <- tkbutton(frame4, text = "Apply", padx = 15,command = standard.init)
  
    tkgrid(frame4.but2, frame4.but1, sticky = "w")     
    
    tkpack(frame4, fill="x")  
 
   return(tkstandard)
}

##
## DESCRIPTION:  Creates a GUI for covariates with three text boxes,
##               two combo boxes and three buttoms.  One text box is for entering your own
##               covariate name and the accompanying combo box  for the selection of the
##               covaraite from a drop down list.  The combo box has covaraites stored in the array
##               covString of set.defaults. Two other text boxes to enter the maximum power
##               of the covarite selected, which will be included in the model and its lower powers
##               For example, if you enter Power of Cov=5, the model will have the powers
##               cov^5,cov^4,cov^3,cov^2 and cov.  Logarithmic power a single entry box, such as
##               log(cov)^3.  The selection of the covariate type is done with the
##               drop down combo box, Select Cov Type, where five types are available and are
##               stored in the vector or array  covtypeString of set.defaults(). Three buttoms,
##               the Apply buttom, covtype.init, will write into memory the newly
##               selected parameters either from textboxes or from drop down comboboxes.  
##               The Edit buttom, covtype.edit,  will bring the data editor,
##               which is the builtin R-GUI invoked with data.entry(mat).
##               You may change the paramters chosen for any of the
##               covariates, such as maximum power or the log power, and also have a list
##               of your selections wich may also be edited.  
##               The buttom Close, covtype.close,  quits the application
##               and writes new selections in memory. 
##               Defaults values for cov names, covs types are in in namelists().
##               New values are written in the environmnet env.who(ewho) and the calling environmnet.
##                 
## FORMAT: covtype(base, textvalues).  Here base is the tktoplevel container to build the GUI, 
##         and textvalues are strings with the texts for the radio buttons and two list boxes.
##
## IMPORTED functions:comboBox(), trim.blanks(), reconstruct(), checktypes()
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, the parameters,covs, power of cov, log power of cov and cov.type 
##         can be changed or newly added with the GUI and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


covtype <- function(base, textcov="Enter Cov Name ", textOR ="OR",
                    textpower = "Power ", textsave="Save Expanded Cov", 
                    textype="Select Cov Type: ",
                    title.column ="Covariates Vector",  
                    textlog = "Logarithmic Power", mxwidth = 30, 
                    textCov1 = "Select From:      ", textna = "<NA>")
                    {
    ewho <- get("ewho", env=parent.frame())
    cov <- get("cov", env=ewho)
    localcov <- unlist(sort(cov))
    cov.type <- get("cov.type", env=ewho)
    cov.type <- unlist(cov.type)
    save.FULL <- get("save.FULL", env=ewho)
    
    if(length(cov.type) < 2 && is.na(cov.type) ){ 
      localcov.type <- rep(NA, length(cov))
      names(localcov.type) <- localcov
###      print(localcov.type)
    }else{
      localcov.type <- cov.type
      ii <- order(names(localcov.type))
      localcov.type <- localcov.type[ii]}
       
    cbg <- "white"
    covString <- get("covString", env=ewho)
    dthString <- get("dthString", env=ewho)
    covString <- c(covString, "cnst", "time")
    covString <- c(covString, dthString)
    covtypeString <- get("covtypeString", env=ewho)
    var1 <- tclVar()
    tclObj(var1) <- textna ##or gdp
    var2 <- tclVar( covtypeString[1])
    varpower <- tclVar("1")
    defpower <- 1
    deflog <- 0 
    var3 <- tclVar(covString[1])
    eGUI <- environment()
    defvar1 <- NULL
    done <- tclVar(0)
    defvar2 <- NULL
    powerVec <- rep(defpower, length(localcov))
    names(powerVec) <- localcov
    logVec <- rep(deflog,length(localcov))
    names(logVec) <- localcov
    lst.todisplay <- list(cov=localcov, cov.type= unlist(localcov.type),
                              pow=powerVec, log.pow= logVec)
    rbValue1 <- tclVar("True")
    rbPower1 <- tclVar("True")
    
 ### button Close
 covtype.close <- function(...) {
   
     ewho <- get("ewho", env =eGUI)
     
     assign("pow", powerVec, env=ewho)
     assign("log.pow", logVec, env=ewho)
     
     cov <- reconstruct(cov=localcov, cov.type=localcov.type,
                 pow =powerVec, log=logVec) 
  
     cov <- na.omit(cov$covres)
    
     cov <- na.omit(cov)
    
     indx <- grep(NA, names(cov.type))
     if(length(indx) > 0)
       cov.type <- cov.type[-indx]
     
     cov.type <- checktypes(type=localcov.type)
     assign("cov",cov, env=ewho)
     assign("cov.type", cov.type, env=ewho)
     rVal1 <- as.character(tclvalue(rbValue1))

    save.FULL <- ifelse(rVal1 == "True", T, F)
    assign("save.FULL", save.FULL, env=ewho)
         
           tkdestroy(base)
    }
    
### button Apply: doing all work of adding and removing covs and their powers  
 covtype.init <- function(...) {
       rVal1 <- as.character(tclvalue(rbValue1))
    
       save.FULL <- ifelse(rVal1 == "True", T, F)
    
       assign("save.FULL", save.FULL, env=ewho)
       assign("save.FULL", save.FULL, env=eGUI)
       rPow1 <- as.character(tclvalue(rbPower1))
     
       if(trim.blanks(tclvalue(var1)) != textna){ 
         ##         as.character(tclvalue(var1)) != comboValCov ){
         defvar1 <- tclvalue(tclObj(var1))
         tclObj(var1) <- textna
       }else{
         tclObj(var1) <- textna
         e1 <- get("e1", env=eGUI)
         defvar1 <- get("comboValue",env=e1)
       }
     
     
       chk <- F
       if (length(defvar1) > 0)
         chk <- (identical(trim.blanks(defvar1), textna) 
                 || identical(trim.blanks(defvar1), "N/A") 
                 || is.na(defvar1))
     

       if (length(defvar1) <= 0 || chk)
         {
          
           return(list()); ## get out of this function call 
         }
               
       assign("defvar1", defvar1, env=eGUI)
       comboEntryCov <- get("comboEntry", env=e1)
   
       defvar2 <- get("comboValue",env=get("e2", env=eGUI))
       if(length(defvar2) <= 0 )
         defvar2 <- NA
   
       assign("defvar2", defvar2, env=eGUI)
           
       comboEntryType <- get("comboEntry", env=e2)
       comboEntryType[comboEntryType == textna] <- NA
           
       localcov <- get("localcov", env=eGUI)
       localcov.type <- get("localcov.type", env=eGUI)
   
       powerVec <- get("powerVec", env=eGUI)
       logVec <- get("logVec", env=eGUI)

##       cat("................................", "\n", "localcov = ")
##       print(localcov)        
##       cat("localcov.type = ")
##       print(localcov.type)
##       cat("powerVec = ")
##       print(powerVec)
##       cat("logVec = ")
##       print(logVec)
##       cat(".........................................", "\n")

       nmpct <- names(localcov.type)
       ix1 <- grep(defvar1, localcov)
       ix2 <- grep(defvar1, names(localcov.type))
       
       if(length(ix1) > 0)
         localcov <- localcov[-ix1]
       if(length(ix2) > 0)
         localcov.type <- localcov.type[-ix2]
           
       localcov <- c(defvar1, localcov)
     
       assign("localcov", localcov, env=eGUI)
       nmpct <- names(localcov.type)
       localcov.type <- c(defvar2, localcov.type)
       
       names(localcov.type) <- c(defvar1, nmpct) 
       assign("localcov.type",localcov.type, env=eGUI)
       rPow1 <- as.character(tclvalue(rbPower1))
    
       if(rPow1 == "True")
         {
           varpowerparse <- as.numeric(tclvalue(varpower))
           assign("defpower", varpowerparse, env=eGUI)
           varlogparse <- NULL
         }
       else
         {
           varlogparse <-  as.numeric(tclvalue(varpower))
           assign("deflog", varlogparse, env=eGUI)
           varpowerparse <-  NULL
         }

       pwn <- names(powerVec)
       pln <- names(logVec)
       
       if(length(varpowerparse) > 0)
         {
       
           defv <- paste("^",defvar1, sep="")
           defvp <- paste("^\\(", defvar1, sep="")
           ix1 <- grep(defv, pwn)
           ix2 <- grep(defvp, pwn)
           ix1 <- sort(c(ix1, ix2))
           if(length(ix1) > 0 )
               powerVec <- powerVec[-ix1]                    
           pwn <- names(powerVec)
           powerVec <- c( varpowerparse, powerVec)
           names(powerVec) <- c(defvar1,pwn)
          
    
         }
       
      
       if(length(varlogparse) > 0)
         {
           defv <- paste("^ln\\(", defvar1,sep="")
           ix1 <- grep(defv, pln)
           if(length(ix1) > 0 )
             logVec <- logVec[-ix1]
           pln <- names(logVec)
           logVec <- c( varlogparse, logVec)
           names(logVec) <- c(defvar1,pln)
           ix1 <- grep(defv, pwn)
          
           if(length(ix1) > 0 )
             powerVec <- powerVec[-ix1]
                    
           pwn <- names(powerVec)
        

           
         }
       assign("powerVec", powerVec, env=eGUI)
       assign("logVec", logVec, env=eGUI)
   
##       cat("localcov = ")
##       print(localcov)        
##       cat("localcov.type = ")
##       print(localcov.type)
##       cat("powerVec = ")
##       print(powerVec)
##       cat("logVec = ")
##       print(logVec)
   
       ewho <- get("ewho", env =eGUI)
       assign("localcov",localcov, env=ewho)
       assign("cov.type", localcov.type, env=ewho)
       assign("pow", powerVec, env=ewho)
       assign("log.pow", logVec, env=ewho)
       tclvalue(done) <- 1
       lst.todisplay  <- list(cov=localcov, cov.type= localcov.type,
                                  pow=powerVec, log.pow= logVec)
###    print(paste("lst.todisplay ", lst.todisplay))
       assign("lst.todisplay", lst.todisplay, env=eGUI)
       covlst <- reconstruct(localcov, localcov.type,
                             powerVec, logVec)  
       vectodisplay <- covlst$vectodisplay
       cov <-  covlst$cov
       assign("cov", cov, env=ewho)
       
       len.text <- nchar(vectodisplay)
       names(vectodisplay) <- "cov = "
       dataframe <- as.data.frame(vectodisplay)
       len.title.col <- nchar(title.column)
       diff.len <- len.text - len.title.col
       
       if (diff.len > 0){
         for(i in 1:diff.len)
           title.column <- paste(title.column, " ", sep="")
       }
       
       names(dataframe) <- title.column

       
       dataframe <- showCovs(dataframe, base=frame23,titletext= "",
                             colname.bgcolor = "lightblue",
                             titlename.bgcolor = "lightgrey", 
                             colname.textcolor = "darkred",
                             maxwidth = mxwidth)
       
     }
    
#### Not in use anymore, button for Edit Not part of the GUI
#### Useless function 
    covtype.edit <- function(...){
      ewho <- get("ewho", env=eGUI)      
      
      lst.todisplay <- get("lst.todisplay", env=eGUI)
      lst.todisplay <- check.miss.values(lst.todisplay)
           
      data.entry(lst.todisplay)
      
### now lst.todisplay in in the .GlobalEnv, get it from there
      lst.todisplay <- get("lst.todisplay", env=.GlobalEnv)
      lst.todisplay <- check.miss.values(lst.todisplay)
      localcov <- lst.todisplay$cov
      localcov <-  unlist(sapply(localcov, trim.blanks))
      localcov.type <- lst.todisplay$cov.type
      localcov.type  <-  unlist(sapply(localcov.type, trim.blanks))
      ln.type <- length(localcov.type)
      ln.cov  <- length(localcov)
      
      if (ln.type < ln.cov)
        localcov.type <- c(localcov.type, rep(NA, ln.cov - ln.type))
      names( localcov.type ) <- localcov
    
      powerVec <- lst.todisplay$pow
      ln.pow <- length(powerVec)
      if (ln.pow < ln.cov)
        powerVec <- c(powerVec, rep(0, ln.cov - ln.pow))
      names(powerVec) <-  localcov
        
      logVec <- lst.todisplay$log.pow
      ln.log <- length(logVec)
      if (ln.log < ln.cov)
        logVec <- c(logVec, rep(0, ln.cov - ln.log))
      names(logVec) <-  localcov
        
      assign("cov", localcov, env=ewho)
      assign("cov.type", localcov.type, env=ewho)
      assign("pow", powerVec, env=ewho)
      assign("log.pow", logVec, env=ewho)
      assign("localcov", localcov, env=eGUI)
      assign("localcov.type", localcov.type, env=eGUI)
      assign("powerVec", powerVec, env=eGUI)
      assign("logVec", logVec, env=eGUI)
      lst.todisplay <- list(cov=localcov, cov.type= localcov.type,
                            pow=powerVec, log.pow= logVec)
      assign("lst.todisplay", lst.todisplay, env=eGUI)
      pos <- match(".GlobalEnv", search())

      rm(lst.todisplay, envir=as.environment(pos))
      
      vectodisplay <- reconstruct(localcov, localcov.type,
                                  powerVec, logVec)$vectodisplay
      names(vectodisplay) <- "cov = "
      dataframe <- as.data.frame(vectodisplay)
      len.text <- nchar(vectodisplay)  
      
      len.title.col <- nchar(title.column)
      diff.len <- len.text - len.title.col
      
      if (diff.len > 0){
        for(i in 1:diff.len)
          title.column <- paste(title.column, " ", sep="")
      }
    
      names(dataframe) <- title.column
      
      dataframe <- showCovs(dataframe, base=frame23,titletext= "",
                            colname.bgcolor = "lightblue",
                            titlename.bgcolor = "lightgrey", 
                            colname.textcolor = "darkred",  maxwidth = mxwidth)
    }
    covs.file <- function()
      {
        filename <- tclvalue(tkgetOpenFile())
        if (!nchar(filename))
          {
            tkmessageBox(message="No file selected")
            return(0);
          }
        tkmessageBox(message=paste("File selected is\n",filename ))
        filecov <- strsplit(filename,"/")[[1]]
        ix <- length(filecov)
        covfile <- NULL
        if(ix > 0)
          {
            covfile <- filecov[ix]
            covtodisp <- strsplit(covfile,".txt")[[1]][1] 
            tclObj(var1) <- covtodisp
          }
      }
    
    topmenu <- tkmenu(base)
    tkconfigure(base, menu=topmenu)
    filemenu <- tkmenu(topmenu, tearoff=F)   
    tkadd(filemenu, "command", label= "Open...",
          command=covs.file)
    tkadd(topmenu, "cascade", label="File", menu=filemenu)
    
    
    tkcovs <- tkframe(base, relief = "groove", borderwidth = 2)
    frameradios <- tkframe(tkcovs, relief = "groove", borderwidth = 1)
    frame1 <- tkframe(tkcovs, relief = "groove", borderwidth = 0)
    frame2 <- tkframe(frameradios, relief = "groove", borderwidth = 1)
    frame23 <- tkframe(tkcovs, relief="groove", borderwidth = 1)
    frame3 <- tkframe(tkcovs, relief = "groove", borderwidth = 1)
    framec <- tkframe(tkcovs, relief = "groove", borderwidth = 1)
    framefull <- tkframe(frameradios, relief = "groove", borderwidth = 0)
  
    
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(textcov),
                             fg="blue")
   
    frame1.entry1 <- tkentry(frame1, textvariable = var1, width = 20, bg=cbg)
##  frame1.entry1 <- tkentry(frame1, width = 18)
    tkgrid(frame1.label1, frame1.entry1, sticky = "w")
    frame1.label2 <-  tklabel(frame1, textvariable = tclVar(textOR),
                             fg="red")
 
    frame1.label3 <- tklabel(frame1, textvariable = tclVar("  "),
                              fg="blue")
    tkgrid(frame1.label2, frame1.label3, sticky="w")
    tkpack(frame1, fill = "x")
###*****
    framec.label <- tklabel(framec, textvariable = tclVar(textCov1),
                              fg="blue")
    
    e1 <- new.env(hash=T, parent=parent.frame())
    comboCov <- comboBox(base=framec,
                        fruits=covString,
                        fruit.selection=-1, text=textCov1, ##text="      ",   
                        env.towrite= e1)
##    tkgrid(framec.label, comboCov, sticky="e")
    tkgrid(comboCov, sticky="e")
    tkpack(framec, fill="x")
    comboValCov   <- get("comboValue", env=e1)
    comboEntryCov <- get("comboEntry", env=e1)
    assign("comboValCov", comboValCov, env=ewho)
    assign("comboEntryCov", comboEntryCov, env=ewho)             
    
### how to use the comboBox, with function comboBox()
### that returns a frame, and pack it somewhere   
    frame2.spacer <- tklabel(frame2, text = "   ")   
    frame2.label2 <- tklabel(frame2, textvariable = tclVar(textpower),
                             fg="blue")
     frame2.label1 <- tklabel(frame2, textvariable = tclVar(textlog),
                             fg="blue")
      
    frame2.entry1 <- tkentry(frame2, textvariable = varpower,
                             width = 5, bg=cbg)
    rb1 <- tkradiobutton(frame2)
    rb2 <- tkradiobutton(frame2)
    tkconfigure(rb1, variable= rbPower1, value="False")
    tkconfigure(rb2, variable= rbPower1, value="True")
  
###    tkgrid(frame2.label1, frame2.entry1, sticky = "w")
###    tkgrid(tklabel(frame2, textvariable = tclVar("  ")))    
###    tkgrid(frame2.label2, frame2.entry2, sticky = "w")
    
    tkgrid(frame2.label1,sticky="nsew")   
    tkgrid(tklabel(frame2, text = "yes"), rb1, sticky="w")
    tkgrid(tklabel(frame2, text = "no"), rb2, sticky="w")
###           tklabel(frame2, textvariable = tclVar(" ")),
    tkgrid(frame2.label2, frame2.entry1, sticky = "w")
 ###    tkgrid(tklabel(frame2, text = "   "),sticky="nsew")   
 ##   tkpack(frame2, fill = "x")
     framefull.label1 <- tklabel(framefull,
                                 textvariable=tclVar(textsave), fg="blue")
    framefull.label2 <- tklabel(framefull,
                                 text="   (name: FULL.cov.txt)", fg="black")
    rb1 <- tkradiobutton(framefull)
    rb2 <- tkradiobutton(framefull)
    
    framefull.spacer <- tklabel(framefull, text = "       ")
    tkconfigure(rb1, variable= rbValue1, value="True")
    tkconfigure(rb2, variable= rbValue1, value="False")
    tkgrid(framefull.label1, framefull.spacer, sticky="w")
    tkgrid.configure(framefull.label1,sticky="w") 
    tkgrid(tklabel(framefull, text="  True"), rb1,sticky="w")
    tkgrid(tklabel(framefull, text="  False"), rb2,sticky="w")
    tkgrid(framefull.spacer, sticky="w")
    tkgrid(framefull.label2, sticky="w")
    tkgrid(frame2, framefull)
    tkpack(frameradios)
   
    e2 <- new.env(hash=T, parent=parent.frame())
    comboType <- comboBox(base=tkcovs,
                          fruits=covtypeString,
                          fruit.selection=-1, text=textype, 
                          env.towrite= e2)
 
    tkpack(comboType, fill="x")  
    comboValType   <- get("comboValue", env=e2)
    comboEntryType <- get("comboEntry", env=e2)
    assign("comboValType", comboValType, env=ewho)
    assign("comboEntryType", comboEntryType, env=ewho)
    vectodisplay <- form.display(cov)
    len.text <- nchar(vectodisplay)
    names(vectodisplay) <- "cov = "
    dataframe <- as.data.frame(vectodisplay)
   
    len.title.col <- nchar(title.column)
    diff.len <- len.text - len.title.col
    
    if (diff.len > 0){
        for(i in 1:diff.len)
        title.column <- paste(title.column, " ", sep="")
    }
    
    names(dataframe) <- title.column
  
    dataframe <- showCovs(dataframe, base=frame23,titletext= "",
                          colname.bgcolor = "lightblue",
                          titlename.bgcolor = "lightgrey", 
                          colname.textcolor = "darkred",
                          maxwidth= mxwidth)
    tkpack(dataframe, fill="x")                   
    frame3.spacer <- tklabel(frame3, text = "   ") 
    frame3.but1 <- tkbutton(frame3,  textvariable =tclVar("Edit"),
                            padx = 20, command = covtype.edit)
    
    frame3.but2 <- tkbutton(frame3,  textvariable =tclVar("Close"), fg="red",
                            padx = 20, command = covtype.close)
    
    frame3.but3 <- tkbutton(frame3, text = "Apply", padx = 20,                                                              command = covtype.init)
    tkgrid(frame3.spacer,sticky="nsew") 
    tkgrid(frame3.but2, frame3.but3, sticky = "w")
    tkpack(frame3, fill="x")
    return(tkcovs)
}
##
## DESCRIPTION: it takes a list whose elements are vectors
##              lst$cov = vector of covariates,
##              lst$cov.type their types for each element of cov
##              lst$pow, lst$logpow vectors of powers and log powers
##              All vectors should have same length
##              Finds missing values from lst$cov and omit them
##              then updates the other three components of list lst
##              with the missing value of cov removed from vectors
##
## Input & output are lists.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 08/04/2005
##
###########################################################
 check.miss.values <- function(lst)
        {
        ind <- !is.na(lst$cov)
        
        lst$cov <- lst$cov[ind]
        lst$cov.type <- lst$cov.type[ind]
        lst$pow <-lst$pow[ind]
        lst$log.pow <- lst$log.pow[ind]
      
        return(lst)
    }
##
## DESCRIPTION:  Creates a GUI for Bayesian (Girosi-King models) parameters.
##               It has a top level menu bar with File as a choice.  The user
##               brings file menus dialog for zero.mean, bayes.zeromean,
##               and for Hct.c.deriv, bayes.adjacency.
##               After choosing a file for any of them it will displayed in a text box
##               for zero-mean and in the footer of the text area for Hct.c.deriv.
##               The apply buttom will copy the files to the directory prior.path or datapath,
##               if they are in a different directories so they can be found by yourcast. 
##               It has four check boxes that are turned on and off indicating whether 
##               smoothing is done for age (Ha.sigma), time (Hat.sigma), age-time (Hat.sigma),
##               and country-time (Hct.sigma).  They can all be on at the same time.
##               If any is off then the corresponding smoothing parameters is set to NA;
##               if it is turned on then the smoothing parameters takes a default value, which
##               presently is set to defVal=0.1.
##               The two radio buttons and the text box are for the parameter zero.mean,
##               which takes values True, False or the name of a file. The file name is
##               chosen with the File menu bar on the top of the GUI. 
##               The text display area from function showCovs() has a header with the
##               title and value of parameters (Scalar/Vector)
##               It has two columns displaying the names of Parameters,
##               and their values and, for the case of the BAYES model, it has
##               a footer for Hct.c.deriv, which displays the name of the file, default
##               adjacency.txt, which can be chosen with the File menu bar on the top of the GUI.
##               The text display area only shows those parameters that
##               are relevant to the smoothing choices.  For example, if Ha.sigma = 0.1
##               but Ht.sigma= NA, then text area only displays Ha.deriv, Ha.age.weight,
##               Ha.time.weight, and Ha.sigma.sd but it will not displayed any of
##               of the Ht.* parameters. The GUI has  three buttoms,
##               the Apply buttom, bayes.init, will write into memory the names of files 
##               chosen with the File menu and copy them in the prior.path or
##               datapath directories if they are located somewhere else.  
##               The Edit buttom, bayes.edit,  will bring the data editor,
##               which is the builtin R-GUI invoked with data.entry(mat).
##               You may change the parameters chosen for any of the
##               smoothing varaibles if they are turn on,
##               such Ha.deriv or Ha.age.weigth or any of the others, including Ha.sigma,
##               Ht.sigma, Hat.sigma, Hct.sigma which are always part of the data.entry.  
##               The editor has 4 columns, one for the name of the parameter, and three
##               for each of the component of the three dimensional vector. User may
##               enter each component in a different column or all in one as c(1, 4, 5).
##               Column that have no entries are ignored in the data processing or st to NA.\
##               Ther text for NA that is used for any of the (Ha|Ht|Hat|Hct.sigma) is also <NA>
##               The buttom Close, bayes.close,  quits the application
##               and writes new selections in memory.
##               You may also quit application with the menu bar, choice Quit..
##               Defaults values for smoothing parameters , anf files are in namelists().
##               New values are written in the environmnet env.who(ewho) and the calling environmnet.
##                 
## FORMAT: bayes(base, textvalues, defVal=0.1).  Here base is the tktoplevel container
##         to build the GUI, and textvalues are strings with the texts for the radio buttons,
##         check buttons, text boxes and areas and the buttons. The parameter defVal is the default
##         value assigned to Ha|Ht|Hat|Hct.sigma when their check boxes are turned on.
##         The parameter textna = <NA> is the default for NA. 
##
## IMPORTED functions:comboBox(), trim.blanks(), showCovs(),
##                    form.vector, vecloc, buildparameters, 
##                    construct.ha, construct.ht, construct.hat, construct.hct
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container,i.e. base.
##         In addition, any of the smoothing parameters or name of files  
##         can be changed or newly added with the GUI and their new values are written in memory.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


 bayes.data.entry <- function(base, textsmooth = "Smooth Dependent Variable Over: ", 
                   textage ="Age Groups",
                   textime ="Time Trends",
                   textimeage = "Age & Time",
                   textcntry = "Geographical Index", 
                   textna = "<NA>", defVal=0.1,
                   zerotext = "Zero-mean Options ",
                   graphtext="Adjacency Matrix ")
                   {
    ewho <- get("ewho", env=parent.frame())
    Ha.sigma <- get("Ha.sigma", env=ewho)
    Ht.sigma <- get("Ht.sigma", env=ewho)
    Hat.sigma <- get("Hat.sigma", env=ewho)
    Hct.sigma <- get("Hct.sigma", env=ewho)
    zero.mean <- get("zero.mean", env=ewho)
    zero.mean0 <- zero.mean
    Ha.sigma.sd <- get("Ha.sigma.sd", env=ewho)
    Ha.sigma.sd0 <- Ha.sigma.sd
    Ha.deriv <- get("Ha.deriv", env=ewho)
    Ha.deriv0 <- Ha.deriv 
    Ha.age.weight   <- get("Ha.age.weight", env=ewho)
    Ha.age.weight0 <-  Ha.age.weight 
    Ha.time.weight  <- get("Ha.time.weight", env=ewho)
    Ha.time.weight0 <- Ha.time.weight
    Ht.sigma.sd <- get("Ht.sigma.sd", env=ewho)
    Ht.sigma.sd0 <-  Ht.sigma.sd
    Ht.deriv <- get("Ht.deriv", env=ewho)
    Ht.deriv0 <-  Ht.deriv
    Ht.age.weight   <- get("Ht.age.weight", env=ewho)
    Ht.age.weight0 <- Ht.age.weight 
    Ht.time.weight  <- get("Ht.time.weight", env=ewho)
    Ht.time.weight0 <-  Ht.time.weight 
    Hat.sigma.sd <- get("Hat.sigma.sd", env=ewho)
    Hat.sigma.sd0 <-  Hat.sigma.sd 
    Hat.a.deriv <- get("Hat.a.deriv", env=ewho)
    Hat.a.deriv0 <-  Hat.a.deriv 
    Hat.t.deriv <- get("Hat.t.deriv", env=ewho)
    Hat.t.deriv0 <- Hat.t.deriv
    Hat.age.weight   <- get("Hat.age.weight", env=ewho)
    Hat.age.weight0 <-   Hat.age.weight
    Hat.time.weight  <- get("Hat.time.weight", env=ewho)
    Hat.time.weight0 <-  Hat.time.weight
    Hct.sigma.sd <- get("Hct.sigma.sd", env=ewho)
    Hct.sigma.sd0 <-  Hct.sigma.sd 
    Hct.c.deriv <- get("Hct.c.deriv", env=ewho)
    Hct.c.deriv0 <- Hct.c.deriv
    Hct.t.deriv <- get("Hct.t.deriv", env=ewho)
    Hct.t.deriv0 <-  Hct.t.deriv 
    Hct.time.weight   <- get("Hct.time.weight", env=ewho)
    Hct.time.weight0 <-  Hct.time.weight 
    lnchar <- nchar("Hct.time.weight")
    model <- get("model", env=ewho)
    nsample  <- get("nsample", env=ewho)
    LI.sigma.mean <- get("LI.sigma.mean", env=ewho)
    LI.sigma.sd <- get("LI.sigma.sd", env=ewho)
    prior.path <- get("prior.path", env=ewho)
    data.path <- get("data.path", env=ewho)
    vargraph <- tclVar("adjacency.txt")
    restore.defaults <- F
    ft <- ifelse(toupper(trim.blanks(model)) != "MAP", T, F)
    if (toupper(trim.blanks(model)) != "MAP")
      colnamebar <- c("top", "bottom")
    else
      colnamebar <- "top"
      
    fentry <- "Hct.c.deriv"
    ftext <- as.character(tclvalue(vargraph))
    zero.mean.chk <- F
    adjacency.chk <- F
    ha  <- ifelse(is.na(Ha.sigma),textna, Ha.sigma)
    ht  <- ifelse(is.na(Ht.sigma),textna, Ht.sigma)
    hat <- ifelse(is.na(Hat.sigma),textna, Hat.sigma)
    hct <- ifelse(is.na(Hct.sigma),textna, Hct.sigma)
    varzero <- tclVar("")
  
    
    rbValue <- tclVar("True")
    localpar <- list(Ha.sigma=ha, Ht.sigma=ht,Hat.sigma=hat)
    if(toupper(trim.blanks(model)) != "MAP") 
     localpar <- c(localpar, list(Hct.sigma=hct))
                          
    V1 <- vecloc(1, par=localpar) 
    V2 <- vecloc(2, par=localpar)
    V3 <- vecloc(3, par=localpar)
        
    lst.todisplay <- list(Parameters=names(localpar),
                          V1=V1 , V2=V2 , V3=V3 )
    if(toupper(trim.blanks(model)) == "MAP")
       Hct.sigma <- NA
    
    eGUI <- environment()
    datamat <- ncol(2)
    
    bayes.close <- function(...) {
      lst.todisplay <- get("lst.todisplay", env=eGUI)
      Ha.sigma <- get("Ha.sigma", env=eGUI)
      Ht.sigma <- get("Ht.sigma", env=eGUI)
      Hat.sigma <- get("Hat.sigma", env=eGUI)
      Hct.sigma <- get("Hct.sigma", env=eGUI)
      Ha.sigma.sd <- get("Ha.sigma.sd", env=eGUI)
      Ha.deriv <- get("Ha.deriv", env=eGUI)
      Ha.age.weight   <- get("Ha.age.weight", env=eGUI)
      Ha.time.weight  <- get("Ha.time.weight", env=eGUI)
      Ht.sigma.sd <- get("Ht.sigma.sd", env=eGUI)                        
      Ht.deriv <- get("Ht.deriv", env=eGUI)
      Ht.age.weight   <- get("Ht.age.weight", env=eGUI)
      Ht.time.weight  <- get("Ht.time.weight", env=eGUI)
      Hat.sigma.sd <- get("Hat.sigma.sd", env=eGUI)                        
      Hat.a.deriv <- get("Hat.a.deriv", env=eGUI)
      Hat.t.deriv <- get("Hat.t.deriv", env=eGUI)
      Hat.age.weight   <- get("Hat.age.weight", env=eGUI)
      Hat.time.weight  <- get("Hat.time.weight", env=eGUI)
      Hct.sigma.sd <- get("Hct.sigma.sd", env=eGUI)
      Hct.c.deriv <- get("Hct.c.deriv", env=eGUI)
      Hct.t.deriv <- get("Hct.t.deriv", env=eGUI)
      Hct.time.weight   <- get("Hct.time.weight", env=eGUI)
      nsample <- get("nsample", env=eGUI)
      LI.sigma.mean <- get("LI.sigma.mean", env=eGUI)
      LI.sigma.sd <- get("LI.sigma.sd", env=eGUI)
      assign("Hct.c.deriv", Hct.c.deriv, env=ewho)
      assign("zero.mean", zero.mean, env=ewho)

      vecnames <- lst.todisplay$Parameters
      v1 <- lst.todisplay$V1
      v2 <- lst.todisplay$V2
      v3 <- lst.todisplay$V3
      lst <- buildparameters(param=vecnames, v1=v1, v2=v2, v3=v3,
                               miss=textna)
  
      localpar <- names(lst.todisplay$Parameters)
      count <- 0
           
      for(ch in vecnames){
        count <-  count + 1
        chm   <- paste("^",ch,"$",sep="")
        indx  <- grep(chm, names(lst))
        val   <- lst[[count]]
        for(i in (1:length(val))){
          x <- trim.blanks(val[i])
          if(x== "")
           val[i] <- NA
        }
        val <- na.omit(val)
        inc <- unlist(sapply("c",grep,val))
        if(length(val) <= 0 )
          val <- NA
        else if(length(val) <= 1 && length(inc) <= 0)
          val <- as.numeric(val[1])
        else if (length(val) <= 1){
          val <- gsub("c.", "", val)
          val <- gsub(".$", "", val)
          val <- as.numeric(strsplit(val,",")[[1]])
        } else{
        vec <-  NULL
        for(i in (1:length(val)))
          vec <- c(vec, as.numeric(val[i]))
        val <- vec}
      if(identical(trim.blanks(ch), "Hct.c.deriv")){
        assign(eval(ch),Hct.c.deriv,envir=environment())
        assign(eval(ch),Hct.c.deriv,envir=eGUI)
        assign(eval(ch),Hct.c.deriv,envir=get("ewho", env=eGUI))
      }else{
        assign(eval(ch),val,envir=environment())
        assign(eval(ch),val,envir=eGUI)
        assign(eval(ch),val,envir=get("ewho", env=eGUI))
      }
          
      }
   ### good order for NA's
      
      if (restore.defaults && is.na(Ha.sigma)){
        assign("Ha.sigma.sd", Ha.sigma.sd0, env=ewho)
        assign("Ha.deriv", Ha.deriv0, env=ewho)
        assign("Ha.age.weight",Ha.age.weight0, env=ewho)
        assign("Ha.time.weight",  Ha.time.weight0, env=ewho)}
       if (restore.defaults && is.na(Ht.sigma)){
        assign("Ht.sigma.sd", Ht.sigma.sd0, env=ewho)
        assign("Ht.deriv", Ht.deriv0, env=ewho)
        assign("Ht.age.weight",Ht.age.weight0, env=ewho)
        assign("Ht.time.weight",  Ht.time.weight0, env=ewho)}
       if (restore.defaults && is.na(Hat.sigma)){
        assign("Hat.sigma.sd", Hat.sigma.sd0, env=ewho)
        assign("Hat.a.deriv", Hat.a.deriv0, env=ewho)
        assign("Hat.t.deriv", Hat.t.deriv0, env=ewho)
        assign("Hat.age.weight",Hat.age.weight0, env=ewho)
        assign("Hat.time.weight",  Hat.time.weight0, env=ewho)}
       if (restore.defaults && is.na(Hct.sigma)){
        assign("Hct.sigma.sd", Hct.sigma.sd0, env=ewho)
        assign("Hct.c.deriv", Hat.c.deriv0, env=ewho)
        assign("Hct.t.deriv", Hct.t.deriv0, env=ewho)
        assign("Hct.time.weight",  Hct.time.weight0, env=ewho)}
                
      tkdestroy(base)
    }

    bayes.init <- function(...) {
      prior.path <- get("prior.path", env=eGUI)
      
      if (zero.mean.chk){
        filezero.mean <- get("filezero.mean", env=eGUI)
        ff <- strsplit(filezero.mean,"/")[[1]]
        zerofile <- ff[length(ff)]
        destfile <- paste(prior.path,zerofile, sep="")
        res <- readLines(pipe(paste("cp", filezero.mean, destfile)))
        zero.mean.chk <- F
        assign("zero.mean.chk", zero.mean.chk, env=eGUI) 
        assign("zero.mean", zerofile, env=eGUI)
        assign("zero.mean", zerofile,envir=get("ewho", env=eGUI))}
      
      if (adjacency.chk){  
        filadjacency <-  get("filadjacency", env=eGUI)
        ff <- strsplit(filadjacency,"/")[[1]]
        adjfile <- ff[length(ff)]
        destfile <- paste(prior.path,adjfile, sep="")
        res <- readLines(pipe(paste("cp", filadjacency, destfile)))
        adjacency.chk <- F
        assign("adjacency.chk", adjacency.chk, env=eGUI)
        assign("ftext", adjfile, env=eGUI)
        assign("Hct.c.deriv", adjfile, env=eGUI)
        assign("Hct.c.deriv", adjfile, envir=get("ewho", env=eGUI))
      }
###      cat("zero.mean is ", get("zero.mean", env=eGUI), "\n")
###      cat("Hct.c.deriv is ", get("Hct.c.deriv", env=eGUI), "\n")
    }
    
    bayes.edit <- function(...){
        ewho <- get("ewho", env=eGUI)
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        model <- get("model", env=get("ewho", env=eGUI))
        
        indx <- grep("^Hct.c.deriv$", lst.todisplay$Parameters)
        if(length(indx) > 0){
         lst.todisplay$Parameters <- lst.todisplay$Parameters[-indx]
         lst.todisplay$V1 <-  lst.todisplay$V1[-indx]
         lst.todisplay$V2 <-  lst.todisplay$V2[-indx]
         lst.todisplay$V3 <-  lst.todisplay$V3[-indx]
       }
        param <- lst.todisplay$Parameters
        v1 <-  lst.todisplay$V1
        ind <- grep("^Ha.sigma$", param)
        old.ha.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Ht.sigma$", param)
        old.ht.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Hat.sigma$", param)
        old.hat.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Hct.sigma$", param)
        old.hct.sigma <- trim.blanks(v1[ind])
        if( model == "BAYES"){
        ind <- grep("LI.sigma.mean", param)
        old.LI.sigma.mean <- trim.blanks(v1[ind])
        ind <- grep("LI.sigma.sd", param)
        old.LI.sigma.sd <- trim.blanks(v1[ind])
         ind <- grep("nsample", param)
        old.nsample <- trim.blanks(v1[ind])}
#### Display it !!!        
         data.entry(lst.todisplay)
### now lst.todisplay in in the .GlobalEnv, get it from there
        lst.todisplay <- get("lst.todisplay", env=.GlobalEnv)
       
        pos <- match(".GlobalEnv", search())
        rm(lst.todisplay, envir=as.environment(pos))
    
        param <- lst.todisplay$Parameters
        v1 <-  lst.todisplay$V1
        v2 <-  lst.todisplay$V2
        v3 <-  lst.todisplay$V3
        
      vecnames <- lst.todisplay$Parameters
   
      lst <- buildparameters(param=vecnames, v1=v1, v2=v2, v3=v3,
                               miss=textna)
  
      localpar <- names(lst.todisplay$Parameters)
      count <- 0
           
      for(ch in vecnames){
        count <-  count + 1
        chm   <- paste("^",ch,"$",sep="")
        indx  <- grep(chm, names(lst))
        val   <- lst[[count]]
        for(i in (1:length(val))){
          x <- trim.blanks(val[i])
          if(x== "")
           val[i] <- NA
        }
        val <- na.omit(val)
        inc <- unlist(sapply("c",grep,val))
        if(length(val) <= 0 )
          val <- NA
        else if(length(val) <= 1 && length(inc) <= 0)
          val <- as.numeric(val[1])
        else if (length(val) <= 1){
          
          val <- gsub("c.", "", val)
          val <- gsub(".$", "", val)
          val <- as.numeric(strsplit(val,",")[[1]])
        } else{
        vec <-  NULL
        for(i in (1:length(val)))
          vec <- c(vec, as.numeric(val[i]))
        val <- vec}
      
      assign(ch,val,envir=environment())
      assign(ch,val,envir=eGUI)
      assign(ch,val,envir=get("ewho", env=eGUI)) 
      }
     
     
        ind <- grep("^Ha.sigma$", param)
        new.ha.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Ht.sigma$", param)
        new.ht.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Hat.sigma$", param)
        new.hat.sigma <- trim.blanks(v1[ind])
        ind <- grep("^Hct.sigma$", param)
        new.hct.sigma <- trim.blanks(v1[ind])
        ind <- grep("^LI.sigma.mean$", param)
        if(model == "BAYES") {
           ind <- grep("^LI.sigma.mean$", param)
          new.LI.sigma.mean <- trim.blanks(v1[ind])
            ind <- grep("^LI.sigma.sd$", param)
          new.LI.sigma.sd <- trim.blanks(v1[ind])
            ind <- grep("^nsample$", param)
          new.nsample <- trim.blanks(v1[ind])
         }

      new.ha.sigma <- ifelse(identical(new.ha.sigma, textna), NA,new.ha.sigma)
      new.ha.sigma <- ifelse(identical(new.ha.sigma, "NA"), NA,new.ha.sigma)
      old.ha.sigma <- ifelse(identical(old.ha.sigma, textna), NA,old.ha.sigma)
      old.ha.sigma <- ifelse(identical(old.ha.sigma, "NA"), NA,old.ha.sigma)
        
      iguales <- identical(new.ha.sigma, old.ha.sigma)
      na.new.ha <- (length(new.ha.sigma) <= 0 || is.na(new.ha.sigma))
      na.old.ha <- (length(old.ha.sigma) <= 0 || is.na(old.ha.sigma))
        if( na.new.ha && !iguales){
            chk1Value <- tclVar("0")
            assign("chk1Value", chk1Value, env=eGUI)
            assign("Ha.sigma", NA, env=eGUI)
            assign("Ha.sigma", NA, env=ewho)
            tkconfigure(frame1.chk1, variable=chk1Value)
            indx <- sapply("^Ha.",grep,param)
            noix <- sapply("^Hat",grep,param)    
            noix <- sapply(paste("^",as.character(noix),"$",sep=""),grep,
                     as.character(indx))
            if(length(noix) > 0)
              indx <- indx[-noix]
            if(length(indx) > 0)
              indx <- indx[-1]
            if(length(indx) > 0){
              param <- param[-indx]
              v1 <- v1[-indx]
              v2 <- v2[-indx]
              v3 <- v3[-indx]}
          
            lst.todisplay$Parameters <- param
            lst.todisplay$V1 <- v1
            lst.todisplay$V2 <- v2 
            lst.todisplay$V3 <- v3
      
            V1 <-  lst.todisplay$V1
            V2 <-  lst.todisplay$V2
            V3 <-  lst.todisplay$V3
            lst <- as.list(1:length(param))
            names(lst) <- param
            localpar <- lapply(lst, function(n,V1,V2,V3){
              v1 <- V1[n]
              v2 <- V2[n]
              v3 <- V3[n]
              return(c(v1,v2,v3))},V1,V2,V3)
               
            assign("localpar",localpar, env=eGUI) 
          }
        if(!na.new.ha) {
          chk1Value <- tclVar("1")
          assign("chk1Value", chk1Value, env=eGUI)
          assign("Ha.sigma", as.numeric(new.ha.sigma), env=eGUI)
          assign("Ha.sigma", as.numeric(new.ha.sigma), env=ewho)
          tkconfigure(frame1.chk1, variable=chk1Value)
          construct.ha(eGUI)
                   
          localpar <- get("localpar", env=eGUI)
          lst.todisplay <- get("lst.todisplay", env=eGUI)
          datamat <- get("datamat", env=eGUI)
      
        }
       
      
      new.ht.sigma <- ifelse(identical(new.ht.sigma, textna), NA,new.ht.sigma)
      new.ht.sigma <- ifelse(identical(new.ht.sigma, "NA"), NA,new.ht.sigma)
      old.ht.sigma <- ifelse(identical(old.ht.sigma, textna), NA,old.ht.sigma)
      old.ht.sigma <- ifelse(identical(old.ht.sigma, "NA"), NA,old.ht.sigma)
      iguales <- identical(new.ht.sigma, old.ht.sigma)
      na.new.ht <- (length(new.ht.sigma) <= 0 || is.na(new.ht.sigma))
      na.old.ht <- (length(old.ht.sigma) <= 0 || is.na(old.ht.sigma))
    if (na.new.ht && !iguales){
            chk2Value <- tclVar("0")
            assign("chk2Value", chk2Value, env=eGUI)
            assign("Ht.sigma", NA, env=eGUI)
            tkconfigure(frame1.chk2, variable=chk2Value)
            indx <- sapply("^Ht.",grep,param)
            if(length(indx) > 0)
              indx <- indx[-1]
            if(length(indx) > 0){
              param <- param[-indx]
              v1 <- v1[-indx]
              v2 <- v2[-indx]
              v3 <- v3[-indx]}
            lst.todisplay$Parameters <- param
            lst.todisplay$V1 <- v1
            lst.todisplay$V2 <- v2 
            lst.todisplay$V3 <- v3
          
            V1 <-  lst.todisplay$V1
            V2 <-  lst.todisplay$V2
            V3 <-  lst.todisplay$V3
            lst <- as.list(1:length(param))
            names(lst) <- param
            localpar <- lapply(lst, function(n,V1,V2,V3){
              v1 <- V1[n]
              v2 <- V2[n]
              v3 <- V3[n]
              return(c(v1,v2,v3))},V1,V2,V3)
               
            assign("localpar",localpar, env=eGUI) 
          }
      if(!na.new.ht){

            chk2Value <- tclVar("1")
            assign("chk2Value", chk2Value, env=eGUI)
            assign("Ht.sigma", as.numeric(new.ht.sigma), env=eGUI)
            assign("Ht.sigma", as.numeric(new.ht.sigma), env=ewho)
            tkconfigure(frame1.chk2, variable=chk2Value)
            datamat <- construct.ht(eGUI)
            assign("datamat", datamat, env=eGUI)
            localpar <- get("localpar", env=eGUI)
            lst.todisplay <- get("lst.todisplay", env=eGUI)
          }
 
 
    new.hat.sigma <- ifelse(identical(new.hat.sigma, textna), NA,new.hat.sigma)
    new.hat.sigma <- ifelse(identical(new.hat.sigma, "NA"), NA,new.hat.sigma)
    old.hat.sigma <- ifelse(identical(old.hat.sigma, textna), NA,old.hat.sigma)
    old.hat.sigma <- ifelse(identical(old.hat.sigma, "NA"), NA,old.hat.sigma)
    iguales <- identical(new.hat.sigma, old.hat.sigma)
    na.new.hat <- (length(new.hat.sigma) <= 0 || is.na(new.hat.sigma))
    na.old.hat <- (length(old.hat.sigma) <= 0 || is.na(old.hat.sigma))
    if (na.new.hat && !iguales){
                  
          chk3Value <- tclVar("0")
          assign("chk3Value", chk3Value, env=eGUI)
          assign("Hat.sigma", NA, env=eGUI)
          tkconfigure(frame1.chk3, variable=chk3Value)
          indx <- sapply("^Hat.",grep,param)
          if(length(indx) > 0)
            indx <- indx[-1]
        
          if(length(indx) > 0 && !is.na(indx)){
              param <- param[-indx]
              v1 <- v1[-indx]
              v2 <- v2[-indx]
              v3 <- v3[-indx]}
          
          lst.todisplay$Parameters <- param
          lst.todisplay$V1 <- v1
          lst.todisplay$V2 <- v2 
          lst.todisplay$V3 <- v3
          V1 <-  lst.todisplay$V1
          V2 <-  lst.todisplay$V2
          V3 <-  lst.todisplay$V3
          
          lst <- as.list(1:length(param))
          names(lst) <- param
          localpar <- lapply(lst, function(n,V1,V2,V3){
            v1 <- V1[n]
            v2 <- V2[n]
            v3 <- V3[n]
            return(c(v1,v2,v3))},V1,V2,V3)
               
          assign("localpar",localpar, env=eGUI) 
        }
      if(!na.new.hat){
         
          chk3Value <- tclVar("1")
          assign("chk3Value", chk3Value, env=eGUI)
          assign("Hat.sigma", as.numeric(new.hat.sigma), env=eGUI)
          assign("Hat.sigma", as.numeric(new.hat.sigma), env=ewho)
          tkconfigure(frame1.chk3, variable=chk3Value)
          datamat <- construct.hat(eGUI)
          assign("datamat", datamat, env=eGUI)
          localpar <- get("localpar", env=eGUI)
          lst.todisplay <- get("lst.todisplay", env=eGUI)
        } 
 
    new.hct.sigma <- ifelse(identical(new.hct.sigma, textna), NA,new.hct.sigma)
    new.hct.sigma <- ifelse(identical(new.hct.sigma, "NA"), NA,new.hct.sigma)
    old.hct.sigma <- ifelse(identical(old.hct.sigma, textna), NA,old.hct.sigma)
    old.hct.sigma <- ifelse(identical(old.hct.sigma, "NA"), NA,old.hct.sigma)
    iguales <- identical(new.hct.sigma, old.hct.sigma)
    na.new.hct <- (length(new.hct.sigma) <= 0 || is.na(new.hct.sigma))
    na.old.hct <- (length(old.hct.sigma) <= 0 || is.na(old.hct.sigma))
        
    if(na.new.hct &&!iguales){
         
          chk4Value <- tclVar("0")
          assign("chk4Value", chk4Value, env=eGUI)
          assign("Hct.sigma", NA, env=eGUI)
          tkconfigure(frame1.chk4, variable=chk4Value)
          indx <- sapply("^Hct.",grep,param)
          if(length(indx) > 0)
            indx <- indx[-1]
          if(length(indx) > 0){
          param <- param[-indx]
          v1 <- v1[-indx]
          v2 <- v2[-indx]
          v3 <- v3[-indx]}
          lst.todisplay$Parameters <- param
          lst.todisplay$V1 <- v1
          lst.todisplay$V2 <- v2 
          lst.todisplay$V3 <- v3
          V1 <-  lst.todisplay$V1
          V2 <-  lst.todisplay$V2
          V3 <-  lst.todisplay$V3
          lst <- as.list(1:length(param))
          names(lst) <- param
          localpar <- lapply(lst, function(n,V1,V2,V3){
            v1 <- V1[n]
            v2 <- V2[n]
            v3 <- V3[n]
            return(c(v1,v2,v3))},V1,V2,V3)
               
          assign("localpar",localpar, env=eGUI) 
        }
   if(!na.new.hct){
         
          chk4Value <- tclVar("1")
          assign("chk4Value", chk4Value, env=eGUI)
          assign("Hct.sigma", as.numeric(new.hct.sigma), env=eGUI)
          assign("Hct.sigma", as.numeric(new.hct.sigma), env=ewho)
          tkconfigure(frame1.chk4, variable=chk4Value)
          datamat <- construct.hct(eGUI)
          assign("datamat", datamat, env=eGUI)
          localpar <- get("localpar", env=eGUI)
          lst.todisplay <- get("lst.todisplay", env=eGUI)
        }
        if(identical(toupper(trim.blanks(model)),"BAYES"))
          {
          datamat <- construct.LI.sigma.nsample(eGUI)
          assign("datamat", datamat, env=eGUI)
          localpar <- get("localpar", env=eGUI)
          lst.todisplay <- get("lst.todisplay", env=eGUI)
        }
              
                                
        vecnames <- lst.todisplay$Parameters
        v1 <- lst.todisplay$V1
        v2 <- lst.todisplay$V2
        v3 <- lst.todisplay$V3
        lst <- buildparameters(param=vecnames, v1=v1, v2=v2, v3=v3,
                               miss=textna)
  
        localpar <- names(lst.todisplay$Parameters)
        
        count <- 0
        totix <- vector(mode="integer", length=0)
       
        for(ch in vecnames){
          count <-  count + 1
          chm   <- paste("^",ch,"$",sep="")
          indx  <- grep(chm, names(lst))
          val   <- lst[[count]]
          for(i in (1:length(val))){
         x <- trim.blanks(val[i])
         if(x== "")
           val[i] <- NA
         }
          val <- na.omit(val)
         if(length(val) <= 0 )
           val <- NA
         else if(length(val) <= 1)
           val <- val[1]
         else {
            res <-  "c("
            for(i in (1:length(val)))
              if(i < length(val))
                res <- paste(res,val[i],", ",sep="")
              else
                val <- paste(res,val[i],")")
          }
        
          ix <- grep(chm, datamat[,1])
          if(length(ix) > 0){
            totix <- c(totix,ix)
            datamat[ix,2] <- ifelse(is.na(val),textna,val)
          }
          
          assign(eval(ch),val)
          assign(eval(ch),val,envir=eGUI)
          assign(eval(ch),val,envir=get("ewho", env=eGUI))
        }
     
     
         datamat <- datamat[totix,];

         cnames <- c("Parameters", "Values")
         colnames(datamat) <- cnames
         namerows <- datamat[,1]
         dataframe <- data.frame(datamat)
         row.names(dataframe) <- namerows
         colnames(dataframe) <- c("Parameters", "Scalar/Vector")
         ftext <- get("ftext", env=eGUI)
         fentry <- get("fentry", env=eGUI)
       
         dataframe <- showCovs(dataframe[-1], base=frame2,
                          titletext= colnames(dataframe)[1], vechar =lnchar,
                          footer=ft, footerentry=fentry,
                          footertext=ftext,
                          colname.bar=colnamebar)
             
        assign("dataframe", dataframe, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)
        
      }
    bayes.zeromean <- function(...){
      filename <- tclvalue(tkgetOpenFile())
      if (!nchar(filename))
        tkmessageBox(message="No file selected")
      else{
        tkmessageBox(message=paste("File selected is\n",filename ))
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        filezero.mean <- filename 
        assign("filezero.mean", filename, env=eGUI)
        varzero <- tclVar(lst[ix])
        tkconfigure(frame12.entry, bg="white",textvariable=varzero )
        zero.mean.chk <- T
        assign("zero.mean.chk", T, env=eGUI)
      }
    }
    bayes.adjacency <- function(...){
      filename <- tclvalue(tkgetOpenFile())
      if (!nchar(filename))
        tkmessageBox(message="No file selected")
      else{
        tkmessageBox(message=paste("File selected is\n",filename ))
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        filadjacency <- filename 
        assign("filadjacency", filename, env=eGUI)
        varzero <- tclVar(lst[ix])
        datamat <- get("datamat", env=eGUI)
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        ff <- strsplit(filadjacency,"/")[[1]]
        adjfile <- NULL
        if(length(ff) > 0)
          adjfile <- ff[length(ff)]
        ftext <- adjfile
        fentry <- get("fentry", env=eGUI)
        dataframe <- showCovs(dataframe[-1], base=frame2,
                          titletext= colnames(dataframe)[1], vechar =lnchar,
                          footer=ft, footerentry=fentry,
                          footertext=ftext,
                          colname.bar=colnamebar)
        adjacency.chk <- T
        assign("adjacency.chk", T, env=eGUI)
       
      }
    }
   
    
### adding a menu bar to the top of the container  
    topmenu <- tkmenu(base)
    tkconfigure(base, menu=topmenu)
    filemenu <- tkmenu(topmenu, tearoff=F)
    openfiles <- tkmenu(filemenu,  tearoff=F)
    savefiles <- tkmenu(filemenu, tearoff=F)
  
    tkadd(openfiles, "command", label= "Open Zero-mean...",
          command=bayes.zeromean)
    tkadd(openfiles, "command", label= "Open Adjacency-matrix...",
          command=bayes.adjacency)
   
    tkadd(savefiles, "command", label="Save Files ", command=bayes.edit)
  
    tkadd(filemenu, "cascade", label= "Open...", menu=openfiles)
    tkadd(filemenu, "cascade", label= "Save...", menu=savefiles)
    tkadd(filemenu, "command", label="Quit",
          command=function() tkdestroy(base))
    tkadd(topmenu, "cascade", label="File", menu=filemenu)
### end of menu bar
    
    tkbayes <- tkframe(base, relief = "groove", borderwidth = 2)

    frame1 <- tkframe(tkbayes, relief = "groove", borderwidth = 0)
    frame2 <- tkframe(tkbayes, relief = "groove", borderwidth = 1)
    frame3 <- tkframe(tkbayes, relief = "groove", borderwidth = 1)
    frame23 <- tkframe(tkbayes, relief = "groove", borderwidth = 1)
    frame12 <- tkframe(tkbayes, relief = "groove", borderwidth = 2)
    frame1.label0 <- tklabel(frame1, textvariable = tclVar(textsmooth),
                             fg="blue")
    tkgrid(frame1.label0, sticky="w")
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(textage),
                             fg="black")
    frame1.chk1 <- tkcheckbutton(frame1)
    if (is.na(Ha.sigma) || length(Ha.sigma) <= 0)
      chk1Value <- tclVar("0")
    else
      chk1Value <- tclVar("1")
    
    chk1 <- as.numeric(tclvalue(chk1Value))
    tkbind(frame1.chk1, "<Button-1>",  function() {
        
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        datamat <- get("datamat", env=eGUI)
        Ha.sigma <- get("Ha.sigma", env=eGUI)
        model <- get("model", env=eGUI)
        frame2 <- get("frame2", env=eGUI)   
        chk1Value <- get("chk1Value", env=eGUI)
        localpar <- get("localpar",env=eGUI)
        
        chk1 <- as.numeric(tclvalue(chk1Value))
        chk1 <- ifelse(chk1 <= 0,1,0)
        Ha.sigma <- ifelse(chk1  >= 1, defVal, NA)
        assign("Ha.sigma", Ha.sigma, env=eGUI)
        ix <- grep("^Ha.sigma$", datamat[,1])
        if(!is.na(Ha.sigma))
          datamat[ix,2] <- form.vector(Ha.sigma)
        else
          datamat[ix,2] <- textna
      
        if ( !is.na(Ha.sigma)){
            Ha.deriv <- get("Ha.deriv", env=eGUI)
            Ha.age.weight <- get("Ha.age.weight", env=eGUI)
            Ha.time.weight <- get("Ha.time.weight", env=eGUI)
            Ha.sigma.sd <- get("Ha.sigma.sd", env=eGUI)
          
            if(toupper(trim.blanks(model)) != "MAP")
            datamat <- rbind(datamat,
                         c("Ha.sigma.sd",form.vector(Ha.sigma.sd)))
            datamat <- rbind(datamat, c("Ha.deriv",
                                        form.vector(Ha.deriv)))
            datamat <- rbind(datamat, c("Ha.age.weight",
                                        form.vector(Ha.age.weight)))
            datamat <- rbind(datamat, c("Ha.time.weight",
                                        form.vector(Ha.time.weight)))
            localpar <- c(localpar, list(Ha.deriv=Ha.deriv),
                          list(Ha.age.weight=Ha.age.weight),
                          list(Ha.time.weight=Ha.time.weight))
       
            if(toupper(trim.blanks(model)) != "MAP")
              localpar <- c(localpar, list(Ha.sigma.sd=Ha.sigma.sd))
         
          }else{
            ixtodelete <- grep("^Ha.sigma.sd$", names(localpar))
            if(length(ixtodelete) > 0)
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ha.deriv", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ha.age.weight", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ha.time.weight", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            
            ixtodelete <- grep("^Ha.sigma.sd$", datamat[,1])
            if(length(ixtodelete) > 0)
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ha.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ha.age.weight", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ha.time.weight", datamat[,1])
            if(!is.na(ixtodelete))
               datamat <- datamat[-ixtodelete,]
          }
        
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
        lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("Ha.sigma", lst.todisplay$Parameters)
        if(length(indx) > 0){
          localpar[indx] <- ifelse(chk1  >= 1, defVal,NA)
          lst.todisplay$V1[indx] <- ifelse(chk1  >= 1, defVal,textna)
        }else
          print("Index for Ha.sigma not found in lst.todisplay")
        
        cnames <- c("Parameters", "Values")
        colnames(datamat) <- cnames
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        ftext <- get("ftext", env=eGUI)
        fentry <- get("fentry", env=eGUI)
        dataframe <- showCovs(dataframe[-1], base=frame2,
                          titletext= colnames(dataframe)[1], vechar =lnchar,
                          footer=ft, footerentry=fentry,
                          footertext=ftext,
                          colname.bar=colnamebar)
             
        assign("dataframe", dataframe, env=eGUI)
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)
        
      })
 
 
    tkconfigure(frame1.chk1, variable=chk1Value)
    tkgrid(frame1.label1, frame1.chk1, sticky = "w")
    
    frame1.label2 <-  tklabel(frame1, textvariable = tclVar(textime),
                             fg="black")
    frame1.chk2 <- tkcheckbutton(frame1)
    chk2 <- 0
    if (is.na(Ht.sigma) || length(Ht.sigma) <= 0)
      chk2Value <- tclVar("0")
    else{
      chk2Value <- tclVar("1")
      chk2 <- 1}
    
    tkbind(frame1.chk2, "<Button-1>",  function() {
        
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        datamat <- get("datamat", env=eGUI)
        Ht.sigma <- get("Ht.sigma", env=eGUI)
        model <- get("model", env=eGUI)
        frame2 <- get("frame2", env=eGUI)   
        chk2Value <- get("chk2Value", env=eGUI)
     
        param <- lst.todisplay$Parameters
        V1 <-  lst.todisplay$V1
        V2 <-  lst.todisplay$V2
        V3 <-  lst.todisplay$V3
        lst <- as.list(1:length(param))
        names(lst) <- param
        localpar <- lapply(lst, function(n,V1,V2,V3){
                v1 <- V1[n]
                v2 <- V2[n]
                v3 <- V3[n]
                return(c(v1,v2,v3))},V1,V2,V3)
               
        
        chk2 <- as.numeric(tclvalue(chk2Value))
        chk2 <- ifelse(chk2 <= 0,1,0)
        Ht.sigma <- ifelse(chk2  >= 1, defVal, NA)
        assign("Ht.sigma", Ht.sigma, env=eGUI)
        ix <- grep("^Ht.sigma$", datamat[,1])
        if(!is.na(Ht.sigma))
          datamat[ix,2] <- form.vector(Ht.sigma)
        else
          datamat[ix,2] <- textna
      
        if ( !is.na(Ht.sigma)){
            Ht.deriv <- get("Ht.deriv", env=eGUI)
            Ht.age.weight <- get("Ht.age.weight", env=eGUI)
            Ht.time.weight <- get("Ht.time.weight", env=eGUI)
            Ht.sigma.sd <- get("Ht.sigma.sd", env=eGUI)
          
            if(toupper(trim.blanks(model)) != "MAP")
            datamat <- rbind(datamat,
                         c("Ht.sigma.sd",form.vector(Ht.sigma.sd)))
            datamat <- rbind(datamat, c("Ht.deriv",
                                        form.vector(Ht.deriv)))
            datamat <- rbind(datamat, c("Ht.age.weight",
                                        form.vector(Ht.age.weight)))
            datamat <- rbind(datamat, c("Ht.time.weight",
                                        form.vector(Ht.time.weight)))
            localpar <- c(localpar, list(Ht.deriv=Ht.deriv),
                          list(Ht.age.weight=Ht.age.weight),
                          list(Ht.time.weight=Ht.time.weight))
       
            if(toupper(trim.blanks(model)) != "MAP")
              localpar <- c(localpar, list(Ht.sigma.sd=Ht.sigma.sd))
         
          }else{
            ixtodelete <- grep("^Ht.sigma.sd$", names(localpar))
            if(length(ixtodelete) > 0)
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ht.deriv", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ht.age.weight", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Ht.time.weight", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            
            ixtodelete <- grep("^Ht.sigma.sd$", datamat[,1])
            if(length(ixtodelete) > 0)
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ht.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ht.age.weight", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Ht.time.weight", datamat[,1])
            if(!is.na(ixtodelete))
               datamat <- datamat[-ixtodelete,]
          }
        
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
        lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("Ht.sigma", lst.todisplay$Parameters)
        if(length(indx) > 0){
          localpar[indx] <- ifelse(chk2  >= 1, defVal,NA)
          lst.todisplay$V1[indx] <- ifelse(chk2  >= 1, defVal,textna)
        }else
          print("Index for Ht.sigma not found in lst.todisplay")
         
        cnames <- c("Parameters", "Values")
        colnames(datamat) <- cnames
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        ftext <- get("ftext", env=eGUI)
        fentry <- get("fentry", env=eGUI)
        dataframe <- showCovs(dataframe[-1], base=frame2,
                          titletext= colnames(dataframe)[1], vechar =lnchar,
                          footer=ft, footerentry=fentry,
                          footertext=ftext,
                          colname.bar=colnamebar)
             
                  
        assign("dataframe", dataframe, env=eGUI)
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)
        
      })
 
    
    tkconfigure(frame1.chk2, variable=chk2Value)
    tkgrid(frame1.label2, frame1.chk2, sticky = "w")
    
    frame1.label3 <- tklabel(frame1, textvariable = tclVar(textimeage),
                              fg="black")
    frame1.chk3 <- tkcheckbutton(frame1)
     if (is.na(Hat.sigma) || length(Hat.sigma) <= 0)
      chk3Value <- tclVar("0")
    else
      chk3Value <- tclVar("1")
    
     tkbind(frame1.chk3, "<Button-1>",  function() {
        
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        datamat <- get("datamat", env=eGUI)
        Hat.sigma <- get("Hat.sigma", env=eGUI)
        model <- get("model", env=eGUI)
        frame2 <- get("frame2", env=eGUI)   
        chk3Value <- get("chk3Value", env=eGUI)
        param <- lst.todisplay$Parameters
        V1 <-  lst.todisplay$V1
        V2 <-  lst.todisplay$V2
        V3 <-  lst.todisplay$V3
        lst <- as.list(1:length(param))
        names(lst) <- param
        localpar <- lapply(lst, function(n,V1,V2,V3){
                v1 <- V1[n]
                v2 <- V2[n]
                v3 <- V3[n]
                return(c(v1,v2,v3))},V1,V2,V3)
               
        
        chk3 <- as.numeric(tclvalue(chk3Value))
        chk3 <- ifelse(chk3 <= 0,1,0)
        Hat.sigma <- ifelse(chk3  >= 1, defVal, NA)
        assign("Hat.sigma", Hat.sigma, env=eGUI)
        ix <- grep("^Hat.sigma$", datamat[,1])
        if(!is.na(Hat.sigma))
          datamat[ix,2] <- form.vector(Hat.sigma)
        else
          datamat[ix,2] <- textna
      
       
        if ( !is.na(Hat.sigma)){
            Hat.a.deriv <- get("Hat.a.deriv", env=eGUI)
            Hat.t.deriv <- get("Hat.t.deriv", env=eGUI)
            Hat.age.weight <- get("Hat.age.weight", env=eGUI)
            Hat.time.weight <- get("Hat.time.weight", env=eGUI)
            Hat.sigma.sd <- get("Hat.sigma.sd", env=eGUI)
            if(toupper(trim.blanks(model)) != "MAP")
              datamat <- rbind(datamat,
                               c("Hat.sigma.sd",form.vector(Hat.sigma.sd)))
            datamat <- rbind(datamat, c("Hat.a.deriv",
                                        form.vector(Hat.a.deriv)))
            datamat <- rbind(datamat, c("Hat.t.deriv",
                                        form.vector(Hat.t.deriv)))
            datamat <- rbind(datamat, c("Hat.age.weight",
                                        form.vector(Hat.age.weight)))
            datamat <- rbind(datamat, c("Hat.time.weight",
                                        form.vector(Hat.time.weight)))
            localpar <- c(localpar, list(Hat.a.deriv=Hat.a.deriv),
                          list(Hat.t.deriv=Hat.t.deriv),
                          list(Hat.age.weight=Hat.age.weight),
                          list(Hat.time.weight=Hat.time.weight))
       
            if(toupper(trim.blanks(model)) != "MAP")
              localpar <- c(localpar, list(Hat.sigma.sd=Hat.sigma.sd))
         
          }else{
            ixtodelete <- grep("^Hat.sigma.sd$", names(localpar))
            if(length(ixtodelete) > 0)
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hat.a.deriv", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hat.t.deriv", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hat.age.weight", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hat.time.weight", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]

            
            ixtodelete <- grep("^Hat.sigma.sd$", datamat[,1])
            if(length(ixtodelete) > 0)
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hat.a.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hat.t.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hat.age.weight", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hat.time.weight", datamat[,1])
            if(!is.na(ixtodelete))
               datamat <- datamat[-ixtodelete,]
          }
        
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
        lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("Hat.sigma", lst.todisplay$Parameters)
        if(length(indx) > 0){
          localpar[indx] <- ifelse(chk3  >= 1, defVal,NA)
          lst.todisplay$V1[indx] <- ifelse(chk3  >= 1, 0.1,textna)
        }else
          print("Index for Hat.sigma not found in lst.todisplay")
         
        cnames <- c("Parameters", "Values")
        colnames(datamat) <- cnames
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        ftext <- get("ftext", env=eGUI)
        fentry <- get("fentry", env=eGUI)        
        dataframe <- showCovs(dataframe[-1], base=frame2,
                     titletext= colnames(dataframe)[1], vechar =lnchar,
                     footer=ft, footerentry=fentry,
                     footertext=ftext,
                     colname.bar=colnamebar)
        
        assign("dataframe", dataframe, env=eGUI)
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)      
      })
 
   
    tkconfigure(frame1.chk3, variable=chk3Value)
    tkgrid(frame1.label3, frame1.chk3, sticky="w")
    
    frame1.label4 <- tklabel(frame1, textvariable = tclVar(textcntry),
                              fg="black")
    if(toupper(trim.blanks(model)) != "MAP")
      frame1.chk4 <- tkcheckbutton(frame1)
    else{
       frame1.chk4 <- tkcheckbutton(frame1, state="disable")
     
     }
    
    
    if (is.na(Hct.sigma) ||  length(Hct.sigma) <= 0)
      chk4Value <- tclVar("0")
    else if (toupper(trim.blanks(model)) != "MAP" && !is.na(Hct.sigma))
      chk4Value <- tclVar("1")

   
      tkbind(frame1.chk4, "<Button-1>",  function() {
      if(toupper(trim.blanks(model)) != "MAP"){
         fentry <- get("fentry", env=eGUI)
         ftext <- get("ftext", env=eGUI)
        lst.todisplay <- get("lst.todisplay", env=eGUI)
        datamat <- get("datamat", env=eGUI)
        Hct.sigma <- get("Hct.sigma", env=eGUI)
        model <- get("model", env=eGUI)
        frame2 <- get("frame2", env=eGUI)   
        chk4Value <- get("chk4Value", env=eGUI)
           param <- lst.todisplay$Parameters
        V1 <-  lst.todisplay$V1
        V2 <-  lst.todisplay$V2
        V3 <-  lst.todisplay$V3
        lst <- as.list(1:length(param))
        names(lst) <- param
        localpar <- lapply(lst, function(n,V1,V2,V3){
                v1 <- V1[n]
                v2 <- V2[n]
                v3 <- V3[n]
                return(c(v1,v2,v3))},V1,V2,V3)
               
        
        chk4 <- as.numeric(tclvalue(chk4Value))
        chk4 <- ifelse(chk4 <= 0,1,0)
        Hct.sigma <- ifelse(chk4  >= 1, defVal, NA)
        assign("Hct.sigma", Hct.sigma, env=eGUI)
        ix <- grep("^Hct.sigma$", datamat[,1])
        if(!is.na(Hct.sigma))
          datamat[ix,2] <- form.vector(Hct.sigma)
        else
          datamat[ix,2] <- textna
      
        if ( !is.na(Hct.sigma)){
            Hct.c.deriv <- get("Hct.c.deriv", env=eGUI)
            Hct.t.deriv <- get("Hct.t.deriv", env=eGUI)
            Hct.time.weight <- get("Hct.time.weight", env=eGUI)
            Hct.sigma.sd <- get("Hct.sigma.sd", env=eGUI)
            if(toupper(trim.blanks(model)) != "MAP")
            datamat <- rbind(datamat,
                         c("Hct.sigma.sd",form.vector(Hct.sigma.sd)))
###            datamat <- rbind(datamat, c("Hct.c.deriv",
###                                        form.vector(Hct.c.deriv)))
            datamat <- rbind(datamat, c("Hct.t.deriv",
                                        form.vector(Hct.t.deriv)))
            datamat <- rbind(datamat, c("Hct.time.weight",
                                        form.vector(Hct.time.weight)))
            fentry <- "Hct.c.deriv"
            ftext <- tclvalue(vargraph)
            localpar <- c(localpar, list(Hct.c.deriv=Hct.c.deriv),
                          list(Hct.t.deriv=Hct.t.deriv),
                          list(Hct.time.weight=Hct.time.weight))
         
            if(toupper(trim.blanks(model)) != "MAP")
              localpar <- c(localpar, list(Hct.sigma.sd=Hct.sigma.sd))
         
          }else{
            ixtodelete <- grep("^Hct.sigma.sd$", names(localpar))
            if(length(ixtodelete) > 0)
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hct.c.deriv", names(localpar))
            if(!is.na(ixtodelete))
              localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hct.t.deriv", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            ixtodelete <- match("Hct.time.weight", names(localpar))
            if(!is.na(ixtodelete))
               localpar <- localpar[-ixtodelete]
            
            ixtodelete <- grep("^Hct.sigma.sd$", datamat[,1])
            if(length(ixtodelete) > 0)
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hct.c.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hct.t.deriv", datamat[,1])
            if(!is.na(ixtodelete))
              datamat <- datamat[-ixtodelete,]
            ixtodelete <- match("Hct.time.weight", datamat[,1])
            if(!is.na(ixtodelete))
               datamat <- datamat[-ixtodelete,]
          
            fentry <- ""
            ftext <- ""
          
          }
        
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
        lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("Hct.sigma", lst.todisplay$Parameters)
        if(length(indx) > 0){
          localpar[indx] <- ifelse(chk4  >= 1, defVal,NA)
          lst.todisplay$V1[indx] <- ifelse(chk4  >= 1, defVal,textna)
        }else
          print("Index for Hct.sigma not found in lst.todisplay")
        
        
         assign("fentry", fentry, env=eGUI)
         assign("ftext", ftext, env=eGUI)
         
        cnames <- c("Parameters", "Values")
        colnames(datamat) <- cnames
        namerows <- datamat[,1]
        dataframe <- as.data.frame(datamat)
        row.names(dataframe) <- namerows
        colnames(dataframe) <- c("Parameters", "Scalar/Vector")
        
         dataframe <- showCovs(dataframe[-1], base=frame2,
                     titletext= colnames(dataframe)[1], vechar =lnchar,
                     footer=ft, footerentry=fentry,
                     footertext=ftext,
                     colname.bar=colnamebar)
             
        assign("dataframe", dataframe, env=eGUI)
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        assign("datamat", datamat, env=eGUI)
        
      }  else
      returnval <- tkmessageBox(title="Checkbox Geographical Index",
                              message=paste("This option is not available ",
                             "\n", "with the MAP model"),icon="info")
      })
   
 
    tkconfigure(frame1.chk4, variable=chk4Value)
    tkgrid(frame1.label4, frame1.chk4, sticky="w")
    tkpack(frame1, fill = "x")
###*****
    frame12.label <- tklabel(frame12, textvariable = tclVar(zerotext),
                             fg="blue")
    frame12.entry <- tkentry(frame12, textvariable = varzero, width = 15)
    frame12.rb1   <- tkradiobutton(frame12)
    frame12.rb2   <- tkradiobutton(frame12)
    tkgrid(frame12.label, frame12.entry, sticky="w")
    tkconfigure(frame12.rb1, variable=rbValue,value="True")
    tkconfigure(frame12.rb2, variable=rbValue,value="False")
    tkgrid(frame12.label, frame12.entry)
    tkgrid(tklabel(frame12, text="True "), frame12.rb1)
    tkgrid(tklabel(frame12, text="False "), frame12.rb2)
    tkpack(frame12, fill="x")
###****    
   if(!is.na(Ha.sigma))
     datamat <- rbind(datamat, c("Ha.sigma",form.vector(Ha.sigma)))
   else
     datamat <- rbind(datamat, c("Ha.sigma",textna))
   if(!is.na(Ht.sigma))
     datamat <- rbind(datamat, c("Ht.sigma",form.vector(Ht.sigma)))
   else
     datamat <- rbind(datamat, c("Ht.sigma",textna))
   if(!is.na(Hat.sigma))
     datamat <- rbind(datamat, c("Hat.sigma",form.vector(Hat.sigma)))
   else
     datamat <- rbind(datamat, c("Hat.sigma",textna))
   if(!is.na(Hct.sigma) && toupper(trim.blanks(model)) !=  "MAP")
     datamat <- rbind(datamat, c("Hct.sigma",form.vector(Hct.sigma)))
   else if ( toupper(trim.blanks(model)) !=  "MAP")
     datamat <- rbind(datamat, c("Hct.sigma",textna))
    
    if(as.numeric(tclvalue(chk1Value)) > 0){
     construct.ha(eGUI)
     datamat <- get("datamat", env=eGUI)
     localpar <- get("localpar", env=eGUI)
     }
     
 
    if(as.numeric(tclvalue(chk2Value)) > 0){
     datamat <- construct.ht(eGUI)
     localpar <- get("localpar", env=eGUI)
     
    }
    
    if(as.numeric(tclvalue(chk3Value)) > 0){
     datamat <- construct.hat(eGUI)
     localpar <- get("localpar", env=eGUI)
     
    }
    
    if(as.numeric(tclvalue(chk4Value)) > 0){
     datamat <- construct.hct(eGUI)
     localpar <- get("localpar", env=eGUI)
    
    }
    if(toupper(trim.blanks(model)) != "MAP"){
      LI.sigma.mean <- get("LI.sigma.mean", env=ewho)
      LI.sigma.sd <- get("LI.sigma.sd", env=ewho)
      datamat <- rbind(datamat,
                       c("LI.sigma.mean", form.vector(LI.sigma.mean)))
      datamat <- rbind(datamat, c("LI.sigma.sd", form.vector(LI.sigma.sd)))
      datamat <- rbind(datamat, c("nsample", form.vector(nsample)))
      localpar <- c(localpar, list(LI.sigma.mean=LI.sigma.mean),
                          list(LI.sigma.sd=LI.sigma.sd),
                          list(nsample=nsample))
    }
    V1 <- vecloc(1, par=localpar) 
    V2 <- vecloc(2, par=localpar)
    V3 <- vecloc(3, par=localpar)
        
    lst.todisplay <- list(Parameters=names(localpar),
                          V1=V1 , V2=V2 , V3=V3 )

    cnames <- c("Parameters", "Values")
    colnames(datamat) <- cnames
    namerows <- datamat[,1]
    dataframe <- as.data.frame(datamat)
    row.names(dataframe) <- namerows
    colnames(dataframe) <- c("Parameters", "Scalar/Vector")
   dataframe <- showCovs(dataframe[-1], base=frame2,
                     titletext= colnames(dataframe)[1], vechar =lnchar,
                     footer=ft, footerentry=fentry,
                     footertext=ftext,
                     colname.bar=colnamebar)
             
   
    tkpack(frame2, fill = "x")
##****
    frame23.label <- tklabel(frame23, textvariable=tclVar(graphtext),
                             fg="blue")
    frame23.entry <- tkentry(frame23, textvariable = vargraph,
                             width = 15, bg="white")
    tkgrid(frame23.label, frame23.entry)
###    tkpack(frame23, fill="x")
##***    
    frame3.spacer <- tklabel(frame3, text = "   ")
    
    frame3.but1 <- tkbutton(frame3,  textvariable =tclVar("Edit"),
                            padx = 20, command = bayes.edit)
    
    frame3.but2 <- tkbutton(frame3,  textvariable =tclVar("Close"),
                            fg="red", padx = 20, command = bayes.close)
    
    frame3.but3 <- tkbutton(frame3, text = "Apply", padx = 20,                                     command = bayes.init)
    tkgrid(frame3.spacer,sticky="nsew") 
    tkgrid(frame3.but1, frame3.but2, frame3.but3, sticky = "w")
    tkpack(frame3, fill="x")
    return(tkbayes)
}
## ************************************************************************
##
## FUNCTION NAME:      trim.blanks
##
## IMPORTED functions: none
##
##
## DESCRIPTION: It returns a string of characters with blanks eliminated  
##              at the beginning or end of the word only.
##
## FORMAT:  trim.blanks(word), with word a character string
##
## OUTPUT: word with the blanks at the beginning and end eliminated
##         For example word <- " my house in Concord "
##         trim.blanks(word) <- "my house in Concord". 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************


  
    trim.blanks <- function(x) {
     x <- gsub("^ ", "", x)
     x <- gsub(" $", "", x)
     return(x)
    }
## ************************************************************************
##
## FUNCTION NAME:      form.vector
##
## IMPORTED functions: none
##
##
## DESCRIPTION: It takes a vector and construct the R syntax for display   
##              For example vec of three dimensions, c(v1, v2, v3)
##
## FORMAT: form.vector(v), with v a vector or array 
##
## OUTPUT: a string of the form of R-vector: c(v1, v2, v3, ...,vn)
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

   form.vector <- function(v){
     
     if(length(v) > 1){
       ff <- "c("
       for(n in (1:length(v))){
         vx <- v[n]
         if(n <= 1)
           ff <- paste(ff,vx, sep="")
         else if (n < length(v))
           ff <- paste(ff,", ",vx, sep="")
         else
           ff <- paste(ff,", ", vx,")", sep="")
       }}else
          ff <- as.character(v)
       return(ff)
   }
## ************************************************************************
##
## FUNCTION NAME:      vecloc(ix=index, param= vec) 
##
## IMPORTED functions: used in bayes GUI
##
##
## DESCRIPTION: It takes a an index (i.e.,ix= 1, 2,3) and a named list of vectors whose elements
##              are vectors with 1,2 or 3 components, text=<NA> to mark or label NA's
##              for parameters. It will select one of
##              those components corresponding to index=ix, for each and all elements of param. 
##
##
## OUTPUT: the component ix of all elements of param. Thus select one element of the vectors for
##         all list components. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************


    vecloc <- function(ix, par,textna="<NA>"){
      nm <- names(par)
      count <-  0
      V <- sapply(par, function(x){
        count <-  count + 1
        ln <- length(x)
        x <- na.omit(x)
        x <- trim.blanks(x)
        flag <- F
        if (trim.blanks(nm[count]) == "Ha.sigma" ||
            trim.blanks(nm[count]) == "Ht.sigma" ||
            trim.blanks(nm[count]) == "Hat.sigma"||
            trim.blanks(nm[count]) == "Hct.sigma")
          flag <- T
        if(ix > 1)
          flag <- F
        if(length(x) > (ix-1))
          return(x[ix])
        else if(flag)
          return(textna)
        else
          return("")})
      return(V)}
## ************************************************************************
##
## FUNCTION NAME:      builparameters(param,v1, v2,v3,miss) 
##
## IMPORTED functions: none
##
##
## DESCRIPTION: It takes  param vector of string characters and thre numeric
##              or characters vectors v1, v2, v3, which may also take missing values  
##              as represented with miss, the text for NA or <NA>,
##              It will construct the vector for every element of param whoise elements
##              are the corresponding elements of v1, v2, and v3. 
##
##
## OUTPUT: the named list with param as names and each element a vector, whose
##         components are taken from vectors v1, v2, v3 for first, second and third components. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************


   buildparameters <- function(param, v1,v2,v3,miss){
     lst <- list()
     for(n in 1:length(param)){
       nm <- param[n]
       p1 <- v1[n]
       if(p1==miss)
         p1 <- NA
       else if(length(trim.blanks(p1)) <= 0)
         p1 <- NA
       
       p2 <- v2[n]
       p2 <- ifelse(p2==miss,NA,p2)
       p3 <- v3[n]
       p3 <- ifelse(p3==miss,NA,p3)
       nm <- c(p1,p2,p3)
       if(length(na.omit(nm)) < 1)
         nm <- NA
       else
         nm <- na.omit(nm)
       lst <- c(lst, list(nm))
     }
       names(lst) <- param
     return(lst)
   }
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    reconstruct 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env.who
##
## DESCRIPTION: Returns vector with selected covariates, their max powers and logs 
##              that will pass to namelists varaible cov.
##              For example c((gdp)5, log(gdp)3, hc, tfr, (tobacco)3))
##              Built from names gdp, hc, tfr and tobacco and the
##              powers 5, 3 for gdp and tobacco and log powers 3 for log(gdp)
##
## FORMAT:  reconstruct(cov, cov.type, pow, log)
##         
##
## INPUT:   covaraites covs, their cov.type which is a named vector(optional) string,
##          a vector pow for their max power or 1. and the powers of logs for the covaraites

## OUTPUT: Construct the R-vector to pass to namelists() and yourcast with
##         the covaraites to include in the run their powers andd logs of powers. 
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

   reconstruct <- function(cov, cov.type, pow, log, display=T) {
  
   cov   <- names(cov.type)
   cov   <- unlist(sapply(cov,FUN=trim.blanks))
    
   nmpow <- names(pow)
   if(length(nmpow) > 0)
     nmpow <- unlist(sapply(nmpow, FUN=trim.blanks))
   names(pow) <- nmpow
   
   nmlog <- names(log)
   if(length(nmlog) > 0)
     nmlog <- unlist(sapply(nmlog, FUN=trim.blanks))
   names(log) <- nmlog
      
   upow  <- unique.default(nmpow)
   ulog <-  unique.default(nmlog)
    
   if(length(upow) < length(names(pow)))
      {
        vecpow <- sapply(upow, function(nm, pow, nmpow){
          ind  <- grep(nm, nmpow)
          powmax <- max(pow[ind])
    
          return(powmax)},pow,nmpow)
        names(vecpow) <- upow
      }else
        vecpow <- pow
   
    if(length(ulog) < length(names(log)))
      {
   
        veclog <- sapply(ulog, function(nm, log, nmlog){
          ind  <- grep(nm, nmlog)
          if (length(ind) >0 )   
            powmax <- max(log[ind])
          else
            powmax <- NaN
                  
          return(powmax)},log,nmlog)
        names(veclog) <- ulog
      }else
        veclog <- log
  
  
       covres <- sapply(1:length(vecpow), function(x, vecpow){
         nm <- names(vecpow)[x]
         pp <- vecpow[x]
         if(!is.na(pp) && length(pp) > 0){
           if (pp > 1 && length(grep("\\(", nm)) <= 0){
             build <- paste("(",nm,")",pp, sep="")
             return(build)
           }else if (pp >1 ){
             return(paste(nm,pp, sep=""))
           }else if (pp == 1)
             return(nm)
           else{
             ## print("Powers of covs 0 or negative are not allowed") 
             return(NULL)}
         }
       }, vecpow)
       covres <- unlist(covres)
  
    
     log <- veclog
    
     veclog <- sapply(1:length(log), function(x,log){
       nm <- names(log)[x]
       nm <- trim.blanks(nm)
       ind <- log[x]
       
       if (is.na(ind))
           return(NULL);
       
       if (ind > 1 && length(grep("ln", nm)) <= 0)
         return(paste("ln(",nm,")", ind, sep=""))
       else if(ind > 1)
           return(paste(nm,ind,sep=""))
       else if(ind==1 && length(grep("ln", nm)) <= 0)
         return(paste("ln(",nm,")",sep=""))
       else if(ind == 1)
           return(nm)
       else
         return(NULL)}, log)

     
   veclog <- unlist(veclog)
   covres <- unique.default(c(unlist(covres), unlist(veclog)))
   lst <- list(covres)
   names(lst) <- "covres"
  
      if( display == T)
      {
          indx <- as.list(1:length(covres))
        
          for(x in 1:length(covres))
          {
              ch <- covres[x]
           
              if(is.na(ch) && x==1)
                {
                  vectodisplay <- "c("
                  next;
                }
              else if(is.na(ch)&&x < length(covres) )
                {
                  next;
                }
              else if (is.na(ch))
                {
                  vectodisplay <- paste(vectodisplay, ")", sep="")
                  next;
                }
              
              ch <- as.character(ch)
              
              if(trim.blanks(ch) == "NA" ||
                 trim.blanks(ch) =="<NA>"  && x==1 )
                {
                  vectodisplay <- "c("
                  next;
                }
              else if(trim.blanks(ch) == "NA" ||
                       trim.blanks(ch) =="<NA>" && x < length(covres))
                {
                  next;
                }
              else if (trim.blanks(ch) == "NA" ||
                       trim.blanks(ch) =="<NA>")
                {
                  vectodisplay <- paste(vectodisplay, ")", sep="")
                  next;
                }
              
              if(x <= 1)
                  vectodisplay <- paste("c(",ch, sep="")
              else if (x  < length(indx)) 
                  vectodisplay <- paste(vectodisplay, ", ", ch, sep="")
              else if(x == length(indx))
                  vectodisplay <- paste(vectodisplay, ", ", ch, ")", sep="")
          }
         
         
          lst <- c(lst, vectodisplay = list(vectodisplay))
      }
      return(lst)
 }

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    form.display 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## USED GLOBALS: none 
##
## DESCRIPTION: Returns a string with covariate vector to put in text field.  
##              For example: cov <- c("gdp", "(fat)3", "ln(tobacco)", "cnst", "time")
##              becomes the string 
##              "c(gdp, (fat)3, ln(tobacco), cnst, time)"
##
## FORMAT:  a strin with covaraite vector (one element)
##         
##
## INPUT:   covariate selections vector. 
##
## OUTPUT:  text to display with covariates.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

form.display <- function(vecov){
          x <- 0
          for(ch in vecov)
          {
              x <- x + 1; 
              ch <- as.character(ch)
              if(x <= 1)
                  vectodisplay <- paste("c(",ch, ", ", sep="")
              else if (x  < length(vecov)) 
                  vectodisplay <- paste(vectodisplay, ch, ", ", sep="")
              else if(x == length(vecov))
                  vectodisplay <- paste(vectodisplay, ch, ")", sep="")
          }
          return(vectodisplay)
      }
         
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    checktype(type) 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env.who
##
## DESCRIPTION: Returns vector with types for covaraites.  
##              Make sure that if you enter the name of the same covarite twice or more
##              you are consistent with the selection of cov.type otherwise
##              stops the simulation and returns error message, each covarite can only
##              have one type. A consistency check. 
##
## FORMAT:  cehcktype(type=cov.type)
##         
##
## INPUT:   the types enter in the GUI for the covarite selections. 
##
## OUTPUT: The unique types for each covarites or error messages.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

      
   checktypes <- function(type){
     
     utype <- unique.default(names(type))
    
     uvalue <- unique.default(type)
    
     if(length(utype) > 0 && length(uvalue) > 0 &&
        length(utype) < length(uvalue))
     stop("You enter two different types for same covariate. Pls fix it")
     
     if (length(utype) < length(type) && length(utype) >0)
       {
       for( n in (1:length(utype))){
         ind <- grep(utype[n],names(type))
         vec <- unique.default(type[ind])
         vnm <- unique.default(names(type)[ind])
         
         if (length(vec) != length(vnm) && unique.default(vnm) > 1){
           
          print ("Two types for same covariate. Pls fix it!!!!!!!!")}
       }
     }
     nmtype <- sapply(names(type), FUN=trim.blanks)
     indtokeep <- sapply(unique.default(nmtype), match, nmtype)
     typetoret <- type[indtokeep]

     return(typetoret)
   }
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.LI.sigma.mean(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to LI.sigma.mean, LI.sigma.sd, nsample
##           of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. If model== BAYES,
##              it takes only parameters LI.sigma.mean, LI.sigma.sd, nsample. 
##              The relevant parameters are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay.
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Return datamat. Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to age smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 24/02/2005
## 
## ************************************************************************
## ************************************************************************
          
   construct.LI.sigma.nsample <- function(eGUI){
     LI.sigma.mean <- get("LI.sigma.mean", env=eGUI)
     datamat <- get("datamat", env=eGUI)
     ix <- grep("^LI.sigma.mean$", datamat[,1])
     datamat[ix,2] <- LI.sigma.mean
     model <- get("model", env=eGUI)
     LI.sigma.sd <- get("LI.sigma.sd", env=eGUI)
     ix <- grep("^LI.sigma.sd$", datamat[,1])
     datamat[ix,2] <- LI.sigma.sd
     nsample <- get("nsample", env=eGUI)
     ix <- grep("^nsample$", datamat[,1])
     datamat[ix,2] <- nsample
     localpar <- get("localpar", env=eGUI)
   
   
 if (! identical(toupper(trim.blanks(model)), "BAYES"))
   return(0); 

   ind <- grep("LI.sigma.mean",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat,
                      c("LI.sigma.mean",form.vector(LI.sigma.mean)))
   else
     datamat[ind,2] <- form.vector(LI.sigma.mean)
 
   ind <- grep("LI.sigma.sd",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat, c("LI.sigma.sd",
                                 form.vector(LI.sigma.sd)))
   else
     datamat[ind,2] <- form.vector(LI.sigma.sd)
         
   ind <- grep("nsample",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat, c("nsample",
                                 form.vector(nsample)))
   else
     datamat[ind,2] <- form.vector(nsample)
           

 
   ind <- grep("LI.sigma.mean", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(LI.sigma.mean=LI.sigma.mean))
   else
     localpar[[ind]] <- LI.sigma.mean
        
   ind <- grep("LI.sigma.sd", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar,
                   list(LI.sigma.sd=form.vector(LI.sigma.sd)))
   else
     localpar[[ind]] <- form.vector(LI.sigma.sd)
     
   ind <- grep("nsample", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(nsample=
                                        form.vector(nsample)))
   else
     localpar[[ind]] <- form.vector(nsample) 
         
   
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
     lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
     
     indx <- grep("^LI.sigma.mean$", lst.todisplay$Parameters)
        
     localpar[indx] <- LI.sigma.mean
     lst.todisplay$V1[indx] <- LI.sigma.mean
     indx <- grep("^LI.sigma.sd$", lst.todisplay$Parameters)
        
     localpar[indx] <- LI.sigma.sd
     lst.todisplay$V1[indx] <- LI.sigma.sd
     indx <- grep("^nsample$", lst.todisplay$Parameters)
        
     localpar[indx] <- nsample
        lst.todisplay$V1[indx] <- nsample
   
   
     assign("localpar", localpar, env=eGUI)
     assign("lst.todisplay",lst.todisplay, env=eGUI)
  return(datamat)      
 }
## ************************************************************************
## ************************************************************************

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.ha(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to Ha.sigma of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. It takes only parameters
##              associated with age smoothing Ha.sigma. If Ha.sigma!= NA
##              then relevant parameters are Ha.age.weight, Ha.time.weight,
##              Ha.deriv and Ha.sigma.sd, which are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay. If Ha.sigma is changing values, but none of old or new is NA, 
##              then, it simply modifies both datamat and lst.todisplay reflecting new values
##              of age smoothing parameters if they are different from previous assignments.
##              Note that if Ha.sigma=NA then none of the Ha. related parameters are in 
##              datamat or lst.todisplay editors, and need to be
##              added or rbinded to the list or matrix, if Ha.sigma becomes != NA
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to age smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

 construct.ha <- function(eGUI){
   Ha.sigma <- get("Ha.sigma", env=eGUI)
   datamat <- get("datamat", env=eGUI)
   ix <- grep("^Ha.sigma$", datamat[,1])
   datamat[ix,2] <- Ha.sigma
   model <- get("model", env=eGUI)
   localpar <- get("localpar", env=eGUI)
   Ha.deriv <- get("Ha.deriv", env=eGUI)
   Ha.age.weight <- get("Ha.age.weight", env=eGUI)
   Ha.time.weight <- get("Ha.time.weight", env=eGUI)
   Ha.sigma.sd <- get("Ha.sigma.sd", env=eGUI)
 
   
 if ( !is.na(Ha.sigma)){

            if(toupper(trim.blanks(model)) != "MAP"){
              ind <- grep("Ha.sigma.sd",datamat[,1])
              if(length(ind) <= 0)
                datamat <- rbind(datamat,
                                 c("Ha.sigma.sd",form.vector(Ha.sigma.sd)))
              else
                datamat[ind,2] <- form.vector(Ha.sigma.sd)
            }
            ind <- grep("Ha.deriv",datamat[,1])
            if(length(ind) <= 0)
              datamat <- rbind(datamat, c("Ha.deriv",
                                        form.vector(Ha.deriv)))
            else
              datamat[ind,2] <- form.vector(Ha.deriv)
         
            ind <- grep("Ha.age.weight",datamat[,1])
            if(length(ind) <= 0)
              datamat <- rbind(datamat, c("Ha.age.weight",
                                        form.vector(Ha.age.weight)))
            else
               datamat[ind,2] <- form.vector(Ha.age.weight)
            ind <- grep("Ha.time.weight",datamat[,1])
            if(length(ind) <= 0)
            datamat <- rbind(datamat, c("Ha.time.weight",
                                        form.vector(Ha.time.weight)))
            else
              datamat[ind,2] <-  form.vector(Ha.time.weight)

 
         ind <- grep("Ha.deriv", names(localpar))
         if(length(ind) <= 0)
           localpar <- c(localpar, list(Ha.deriv=Ha.deriv))
         else
           localpar[[ind]] <- Ha.deriv
        
         ind <- grep("Ha.age.weight", names(localpar))
         if(length(ind) <= 0)
           localpar <- c(localpar,
                         list(Ha.age.weight=form.vector(Ha.age.weight)))
         else
           localpar[[ind]] <- form.vector(Ha.age.weight)
           ind <- grep("Ha.time.weight", names(localpar))
         if(length(ind) <= 0)
           localpar <- c(localpar, list(Ha.time.weight=
                                        form.vector(Ha.time.weight)))
         else
           localpar[[ind]] <- form.vector(Ha.time.weight) 
         
         
         if(toupper(trim.blanks(model)) != "MAP"){
           ind <- grep("Ha.sigma.sd", names(localpar))
           if(length(ind) <= 0)
             localpar <- c(localpar, list(Ha.sigma.sd=
                                        form.vector(Ha.sigma.sd)))
           else
             localpar[[ind]] <- form.vector(Ha.sigma.sd) 
                   
         }
          }
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
       lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("^Ha.sigma$", lst.todisplay$Parameters)
        
        localpar[indx] <- Ha.sigma
        lst.todisplay$V1[indx] <- Ha.sigma
   
        assign("datamat", datamat,env=eGUI)   
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
        
 }
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.ht(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to Ht.sigma of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. It takes only parameters
##              associated with time smoothing Ht.sigma. If Ht.sigma!= NA
##              then relevant parameters are Ht.age.weight, Ht.time.weight,
##              Ht.deriv and Ht.sigma.sd, which are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay. If Ht.sigma is changing values, but none of old or new is NA, 
##              then, it simply modifies both datamat and lst.todisplay reflecting new values
##              of time smoothing parameters if they are different from previous assignments.
##              Note that if Ht.sigma=NA then none of the Ht.* related parameters are in 
##              datamat or lst.todisplay editors, and need to be
##              added or rbinded to the list or matrix, if Ht.sigma becomes != NA
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to time smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. Returns datamat. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

 
construct.ht <- function(eGUI){
  Ht.sigma <- get("Ht.sigma", env=eGUI)
  datamat <- get("datamat", env=eGUI)
  ix <- grep("^Ht.sigma$", datamat[,1])
  datamat[ix,2] <- Ht.sigma
  model <- get("model", env=eGUI)
  localpar <- get("localpar", env=eGUI)
  Ht.deriv <- get("Ht.deriv", env=eGUI)
  Ht.age.weight <- get("Ht.age.weight", env=eGUI)
  Ht.time.weight <- get("Ht.time.weight", env=eGUI)
  Ht.sigma.sd <- get("Ht.sigma.sd", env=eGUI)
  
  if ( !is.na(Ht.sigma)){
    
    if(toupper(trim.blanks(model)) != "MAP"){
      ind <- grep("Ht.sigma.sd",datamat[,1])
      if(length(ind) <= 0)
        datamat <- rbind(datamat,
                         c("Ht.sigma.sd",form.vector(Ht.sigma.sd)))
      else
        datamat[ind,2] <- form.vector(Ht.sigma.sd)
    }
    ind <- grep("Ht.deriv",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Ht.deriv",
                                  form.vector(Ht.deriv)))
    else
      datamat[ind,2] <- form.vector(Ht.deriv)
    ind <- grep("Ht.age.weight",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Ht.age.weight",
                                  form.vector(Ht.age.weight)))
    else
      datamat[ind,2] <- form.vector(Ht.age.weight)
    ind <- grep("Ht.time.weight",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Ht.time.weight",
                                  form.vector(Ht.time.weight)))
    else
      datamat[ind,2] <-  form.vector(Ht.time.weight)
    
 
    ind <- grep("Ht.deriv", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Ht.deriv=form.vector(Ht.deriv)))
    else
      localpar[[ind]] <- form.vector(Ht.deriv)
    ind <- grep("Ht.age.weight", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar,
                    list(Ht.age.weight=form.vector(Ht.age.weight)))
    else
      localpar[[ind]] <- form.vector(Ht.age.weight)
    ind <- grep("Ht.time.weight", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Ht.time.weight=
                                   form.vector(Ht.time.weight)))
    else
      localpar[[ind]] <- form.vector(Ht.time.weight) 
         
    
    if(toupper(trim.blanks(model)) != "MAP"){
      ind <- grep("Ht.sigma.sd", names(localpar))
      if(length(ind) <= 0)
        localpar <- c(localpar, list(Ht.sigma.sd=
                                     form.vector(Ht.sigma.sd)))
      else
        localpar[[ind]] <- form.vector(Ht.sigma.sd) 
                   
    }
  }

  V1 <- vecloc(1, par=localpar) 
  V2 <- vecloc(2, par=localpar)
  V3 <- vecloc(3, par=localpar)
        
  lst.todisplay <- list(Parameters=names(localpar),
                        V1=V1 , V2=V2 , V3=V3 )
       
  indx <- grep("^Ht.sigma$", lst.todisplay$Parameters)
        
  localpar[indx] <- Ht.sigma
  lst.todisplay$V1[indx] <- Ht.sigma
           
  assign("localpar", localpar, env=eGUI)
  assign("lst.todisplay",lst.todisplay, env=eGUI)
  return(datamat)
        
}
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.hat(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to Hat.sigma of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. It takes only parameters
##              associated with age-time smoothing Hat.sigma. If Hat.sigma!= NA
##              then relevant parameters are Hat.age.weight, Hat.time.weight,
##              Hat.a.deriv, Hat.t.deriv,  and Hat.sigma.sd,
##              which are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay. If Hat.sigma is changing values, but none of old or new is NA, 
##              then, it simply modifies both datamat and lst.todisplay reflecting new values
##              of age-time smoothing parameters if they are different from previous assignments.
##              Note that if Hat.sigma=NA then none of the Hat.* related parameters are in 
##              datamat or lst.todisplay editors, and need to be
##              added or rbinded to the list or matrix, if Hat.sigma becomes != NA
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to age-time smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. Returns datamat. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

construct.hat <- function(eGUI){
   Hat.sigma <- get("Hat.sigma", env=eGUI)
   datamat <- get("datamat", env=eGUI)
   ix <- grep("^Hat.sigma$", datamat[,1])
   datamat[ix,2] <- Hat.sigma
   model <- get("model", env=eGUI)
   localpar <- get("localpar", env=eGUI)
   Hat.a.deriv <- get("Hat.a.deriv", env=eGUI)
   Hat.t.deriv <- get("Hat.t.deriv", env=eGUI)
   Hat.age.weight <- get("Hat.age.weight", env=eGUI)
   Hat.time.weight <- get("Hat.time.weight", env=eGUI)
   Hat.sigma.sd <- get("Hat.sigma.sd", env=eGUI)
   
 if ( !is.na(Hat.sigma)){
    
    if(toupper(trim.blanks(model)) != "MAP"){
      ind <- grep("Hat.sigma.sd",datamat[,1])
      if(length(ind) <= 0)
        datamat <- rbind(datamat,
                         c("Hat.sigma.sd",form.vector(Hat.sigma.sd)))
      else
        datamat[ind,2] <- form.vector(Hat.sigma.sd)
    }
    ind <- grep("Hat.a.deriv",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Hat.a.deriv",
                                  form.vector(Hat.a.deriv)))
    else
      datamat[ind,2] <- form.vector(Hat.a.deriv)
    ind <- grep("Hat.t.deriv",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Hat.t.deriv",
                                  form.vector(Hat.t.deriv)))
    else
      datamat[ind,2] <- form.vector(Hat.t.deriv)
    ind <- grep("Hat.age.weight",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Hat.age.weight",
                                  form.vector(Hat.age.weight)))
    else
      datamat[ind,2] <- form.vector(Hat.age.weight)
    ind <- grep("Hat.time.weight",datamat[,1])
    if(length(ind) <= 0)
      datamat <- rbind(datamat, c("Hat.time.weight",
                                  form.vector(Hat.time.weight)))
    else
      datamat[ind,2] <-  form.vector(Hat.time.weight)
    
 
    ind <- grep("Hat.a.deriv", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Hat.a.deriv=form.vector(Hat.a.deriv)))
    else
      localpar[[ind]] <- form.vector(Hat.a.deriv)
    ind <- grep("Hat.t.deriv", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Hat.t.deriv=form.vector(Hat.t.deriv)))
    else
      localpar[[ind]] <- form.vector(Hat.t.deriv)
    ind <- grep("Hat.age.weight", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar,
                    list(Hat.age.weight=form.vector(Hat.age.weight)))
    else
      localpar[[ind]] <- form.vector(Hat.age.weight)
    ind <- grep("Hat.time.weight", names(localpar))
    if(length(ind) <= 0)
      localpar <- c(localpar, list(Hat.time.weight=
                                   form.vector(Hat.time.weight)))
    else
      localpar[[ind]] <- form.vector(Hat.time.weight) 
         
    
    if(toupper(trim.blanks(model)) != "MAP"){
      ind <- grep("Hat.sigma.sd", names(localpar))
      if(length(ind) <= 0)
        localpar <- c(localpar, list(Hat.sigma.sd=
                                     form.vector(Hat.sigma.sd)))
      else
        localpar[[ind]] <- form.vector(Hat.sigma.sd) 
                   
    }
          
  }
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
       lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("^Hat.sigma$", lst.todisplay$Parameters)
        
        localpar[indx] <- Hat.sigma
        lst.todisplay$V1[indx] <- Hat.sigma
           
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
   return(datamat)
        
          }
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    construct.hct(eGUI) 
##
## PLACE:    GUI for the yourcast frame, bayes, with selection smoothing parameters
##           related to Hct.sigma of the Girosi, King forecasting model. 
## 
## IMPORTED functions: none
##
## USED GLOBALS: in namelists() and  env=env.who and env=eGUI, the calling environmnet
##
## DESCRIPTION: Assigns relevant matrices and lists to the calling environmnet, eGUI, 
##              so they can be displayed with the GUI. It constructs the matrix datamat to
##              display in the text area of the GUI, built with function showCovs.
##              In addition it updates the list lst.todisplay for the data editor of
##              data.entry with values of new parameters. It takes only parameters
##              associated with contry-time smoothing Hct.sigma. If Hct.sigma!= NA
##              then relevant parameters are Hct.time.weight,
##              Hct.c.deriv, Hct.t.deriv,  and Hct.sigma.sd,
##              which are rbinded to datamat matrix and added 
##              to the list lst.todisplay, if they are not already part of datamat
##              and lst.todisplay. If Hct.sigma is changing values, but none of old or new is NA, 
##              then, it simply modifies both datamat and lst.todisplay reflecting new values
##              of cntry-time smoothing parameters if they are different from previous assignments.
##              Note that if Hct.sigma=NA then none of the Hct.* related parameters are in 
##              datamat or lst.todisplay editors, and need to be
##              added or rbinded to the list or matrix, if Hct.sigma becomes != NA
##
## INPUT:   the calling environmnet with parameters and their values to display in GUI 
##
## OUTPUT: Assigment into eGUI of datamat, lst.todisplay, and localpar used to
##         display parameters associated to cntry-time smoothing in the text area
##         and data entry editors of the GUI frame bayes with the Girosi-King
##         forecasting parameters. Returns datamat. 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 28/01/2005
## 
## ************************************************************************
## ************************************************************************

construct.hct <- function(eGUI, lst=T){
   Hct.sigma <- get("Hct.sigma", env=eGUI)
   datamat <- get("datamat", env=eGUI)
   ix <- grep("^Hct.sigma$", datamat[,1])
   datamat[ix,2] <- Hct.sigma
   model <- get("model", env=eGUI)
   localpar <- get("localpar", env=eGUI)
   Hct.c.deriv <- get("Hct.c.deriv", env=eGUI)
   Hct.t.deriv <- get("Hct.t.deriv", env=eGUI)
   Hct.time.weight <- get("Hct.time.weight", env=eGUI)
   Hct.sigma.sd <- get("Hct.sigma.sd", env=eGUI)
          
 if ( !is.na(Hct.sigma)){
   if(toupper(trim.blanks(model)) != "MAP"){
     ind <- grep("Hct.sigma.sd",datamat[,1])
      if(length(ind) <= 0)
        datamat <- rbind(datamat,
                         c("Hct.sigma.sd",form.vector(Hct.sigma.sd)))
      else
        datamat[ind,2] <- form.vector(Hct.sigma.sd)
    }
   ind <- grep("Hct.c.deriv",datamat[,1])
   
###   if(length(ind) <= 0)
###     datamat <- rbind(datamat, c("Hct.c.deriv",
###                                 form.vector(Hct.c.deriv)))
###   else
###     datamat[ind,2] <- form.vector(Hct.c.deriv)
   
   ind <- grep("Hct.t.deriv",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat, c("Hct.t.deriv",
                                 form.vector(Hct.t.deriv)))
   else
     datamat[ind,2] <- form.vector(Hct.t.deriv)
   
   ind <- grep("Hct.time.weight",datamat[,1])
   if(length(ind) <= 0)
     datamat <- rbind(datamat, c("Hct.time.weight",
                                 form.vector(Hct.time.weight)))
   else
     datamat[ind,2] <-  form.vector(Hct.time.weight)
    
   
   ind <- grep("Hct.c.deriv", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(Hct.c.deriv=form.vector(Hct.c.deriv)))
   else
     localpar[[ind]] <- form.vector(Hct.c.deriv)
   ind <- grep("Hct.t.deriv", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(Hct.t.deriv=form.vector(Hct.t.deriv)))
   else
     localpar[[ind]] <- form.vector(Hct.t.deriv)
   
   ind <- grep("Hct.time.weight", names(localpar))
   if(length(ind) <= 0)
     localpar <- c(localpar, list(Hct.time.weight=
                                  form.vector(Hct.time.weight)))
   else
     localpar[[ind]] <- form.vector(Hct.time.weight) 
         
   
   if(toupper(trim.blanks(model)) != "MAP"){
     ind <- grep("Hct.sigma.sd", names(localpar))
     if(length(ind) <= 0)
       localpar <- c(localpar, list(Hct.sigma.sd=
                                    form.vector(Hct.sigma.sd)))
     else
       localpar[[ind]] <- form.vector(Hct.sigma.sd) 
                   
   }
 }
  
        V1 <- vecloc(1, par=localpar) 
        V2 <- vecloc(2, par=localpar)
        V3 <- vecloc(3, par=localpar)
        
       lst.todisplay <- list(Parameters=names(localpar),
                                V1=V1 , V2=V2 , V3=V3 )
       
        indx <- grep("^Hct.sigma$", lst.todisplay$Parameters)
        
        localpar[indx] <- Hct.sigma
        lst.todisplay$V1[indx] <- Hct.sigma
           
        assign("localpar", localpar, env=eGUI)
        assign("lst.todisplay",lst.todisplay, env=eGUI)
   return(datamat)
        
 }
##
## DESCRIPTION:  Creates the GUI with textboxes for the depvariable, allcauses of death,
##               population, tarnsformation of depvar. Also two list boxes with the 
##               selections for the depvar and transformations.  Only one list box may
##               be selected at a time. Two buttons, the close button (depvar.close)
##               to cancel the frame and the  apply botton (depvar.init), which 
##               writes into memory any of the selected or entry items in the text boxes. 
##               Textboxes are for Dependent variable and Transformation,
##               the selections from the lists, which Apply registers them into memory
##               as well as the text boxes entries.  
##               New values are written in the environmnet env.who(ewho)
##               or the calling environmnet.
##
## FORMAT: depvar(base, textvalues).  Here base is the tktoplevel container to build the GUI
##         and textvalues are character strings with the texts for the entry boxes of the GUI
##         and for the list boxes containing the arrays or vectors stored in setdefaults
##         with dthString and transString of available death causes and trnasformations.
##
## VALUE:  a tkframe, which need to be included within a major (tktoplevel) container, base.
##         In addition, some of the default values for the entry text boxes,depvar, all causes, 
##         population, and transformation, may have been changed from
##         their default values stored in namelist()and their new values are written in memory
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

directory.input.output <- function(){
  input  <- "INPUT"
  output <- "OUTPUT"
  destpath  <- paste(getwd(),"/",output,"/", sep="")
  readpath  <- paste(getwd(),"/", input, "/", sep="")
  if (!file.exists(readpath)){
            tkmessageBox(message=
                         "Creating directory  INPUT/ in your working directory"); 
            dir.create(path=readpath);
          }
  if (!file.exists(destpath)){
            tkmessageBox(message =
                         "Creating directory  OUTPUT/ in your working directory"); 
            dir.create(path= destpath);

          }
}

master.GUI <- function(base, txtoptions="Subset Data",
                       txtmodel="Model & Parameters",
                       txtoutput="Save Simulation Output",
                       txtreuse="Load Pre-processed Data",
                       txtoutfile="Save GUI-options",
                       txtmanual="Read Manual",
                       txtinfile="Supplied Userfile")
  
  {
###    tkwm.title(base,"YourCast")
###    env.who <- set.defaults()
###    ewho <- env.who
    eGUI <- environment()
    ewho <- set.defaults()
    modelString <- get("modelString", env =ewho)
    categoryString <- get("categoryString", env=ewho)
    model <- try(get("model", env=ewho), silent = T)
     in.list <- get("in.list", env=ewho)    
    if(class(model) == "try-error")
        model <-  ""
    cbg <- "white"
    modelList <- tclVar()
    categoryList <- tclVar()
    tclObj(modelList) <- modelString
    tclObj(categoryList) <- categoryString
    if(get("save.output", env=ewho) == F) 
      rbValsave <-  tclVar("False")
    else
       rbValsave <-  tclVar("True")
    
    if(get("reuse.data", env=ewho) == F) 
      rbValreuse <-  tclVar("False")
    else
      rbValreuse <- tclVar("True")
    
    rbValfile <- tclVar("True")
       
 
    GUI.selections <- function(...) {
      ewho <- get("ewho", env=eGUI)
      save.GUI <- get("save.GUI", env=ewho)
      depvar <- get("depvar", env=ewho)
      strata <- get("strata", env=ewho)
      model <- get("model", env=ewho)
      in.list <- get("in.list", env=ewho)
      args <- names(in.list)
      n.input <- length(in.list)
      ind <- as.list(1:n.input)
      names(ind) <- args
      if(length(save.GUI) <= 0)
        {
          results.path <- paste(getwd(), "/OUTPUT/", sep="" )
          if(is.character(model))
            save.GUI <- paste(depvar, ".",strata,".",
                              tolower(model),"_GUI.dat", sep="")
          else
             save.GUI <- paste(depvar, ".",strata,".", "data_GUI.dat", sep="")
          
          save.GUI <- paste(results.path,save.GUI, sep="")
        }
      
      in.list <- lapply(ind, function(x, in.list, eGUI){
        ch <- names(ind)[x]
        val <- try(eval(as.symbol(ch), envir=get("ewho", env=eGUI)), silent=T)
        if (class(val)!= "try-error" && !is.null(val))
          return(val)
        else
          return(in.list[[x]])
      }, in.list, eGUI)

###Now we have to save all list elements into the file line by line 
      eclose <- environment()
      for (i in (1:length(args))){
###         print(args[i])
###         print(in.list[[i]])
        assign(args[i], in.list[[i]], env=eclose)}
      save(list=args, file=save.GUI, compress=T)
    }
    
     master.close <- function(...) {
       GUI.selections()
      tkdestroy(base)
  }
    master.init <- function(...) {
      if(length(as.numeric(tkcurselection(frame1.lstbox2))) >0)
        click.on.model(frame1.lstbox2)
      
      if(length(as.numeric(tkcurselection(frame1.lstbox1))) >0)
        click.on.frame(frame1.lstbox1, ewho, model)
    }
    
    master.clear <- function(){
      ewho <- set.defaults()
   
      assign("ewho",ewho, env=eGUI)
      
      if(get("reuse.data", env=ewho) == F) 
        rbValreuse <-  tclVar("False")
      else
        rbValreuse <- tclVar("True")
      
      if(get("save.output", env=ewho) == F) 
        rbValsave <-  tclVar("False")
      else
        rbValsave <- tclVar("True")
      
      assign("rbValreuse", rbValreuse, env=eGUI)
      assign("rbValsave", rbValsave, env=eGUI)
      
      tkconfigure(frame21.rbs1, variable=rbValsave,value="True")
      tkconfigure(frame21.rbs2, variable=rbValsave,value="False")
   
  
      tkconfigure(frame22.rbs1, variable=rbValreuse,value="True")
      tkconfigure(frame22.rbs2, variable=rbValreuse,value="False")
      
      tkmessageBox(message="Setting globals to default values in namelists()")
    }
    
    soft.manual <- function(){
      strURL <- get("strURL", env=get("ewho", env=eGUI))
      browseURL(strURL)
      
    }

    retDir <-  NULL
    open.dirs <- function(...){
      ewho <- get("ewho", env=eGUI)
        if(length(retDir) <= 0){
          datap <- get("data.path", env=ewho)
          covp <- get("cov.path", env=ewho)
          priorp <- get("prior.path", env=ewho)
          outp <- get("out.path", env=ewho)
          prep <- get("reuse.path", env=ewho)
          in.list <- get("in.list", env=ewho)
          retDir <- list(data.path = datap, cov.path = covp,
                          prior.path=priorp, out.path = outp, reuse.pah=prep)
        }
                      
      retDir <- model.dialog(textDef=unlist(retDir))
      assign("retDir", retDir, env=eGUI)
      param <- names(retDir)
 ###  print(retVal)
     
     for( n in 1:length(param))
        {
          assign(param[n],retDir[[n]], env=eGUI)
          assign(param[n],retDir[[n]], env=ewho)
          in.list[[param[n]]] <- retDir[[n]]
 
       }
  
      assign("in.list", in.list, env=ewho)         
    }
    retFile <-  NULL
    
    open.files <- function(...){
      ewho <- get("ewho", env=eGUI) 
 
      in.list <- get("in.list", env=ewho)
   
      if(length(retFile) <= 0){
        cod  <- get("codes.names", env=ewho)
        adj  <- get("Hct.c.deriv", env=ewho)
        zero <- get("zero.mean", env=ewho)
        if(zero== T || zero == F)
          zero <- ""
        retFile = c(user.file = "", codes.names=cod,
          Hct.c.deriv=adj, zero.mean = zero)
      }
###     cat("Before any assignmnt ", "\n") 
###    print(cod);  print(adj);  print(zero)
      retFile <- model.buttons(textDef=unlist(retFile))
      filepath  <- retFile$filepath
      filenames <- retFile$filenames
###      print(retFile)
###      cat("inside open.files ", "\n")
###      print(filepath); print(filenames)
      assign("filepath", filepath, env=eGUI)
      param <- names(retFile$filepath)
      data.path <- get("data.path", env= ewho)
      input <- data.path
      for(n in (1:length(param)))
        {
          filename <- filenames[n]
          fpath <- filepath[[n]]
           
          type.def <- ""
 
      
          if(trim.blanks(filename) != ""&& length(filename)>0
             && !is.na(filename) )
            type.def <- strsplit(filename, "\\.")[[1]] ##either txt or dat
          ln <- length(type.def)
          type.def <- type.def[ln]
         
###       cat("OPEN FILES...filename","\n")
###       print(filename); print(param[n])
         
          nn <-  nchar(filename)
###        print(nn)
       
          if (nn <= 0)
            next;
      
          filename <- trim.blanks(filename)
          if(identical(param[n], "codes.names") )
            {
###              cat("Inside open.files and codes.names....", "\n")
###                print(data.path)
              file <- parse.files(filepath=fpath,
                                 directory.def=data.path)
###              cat("after parse...........") ; print(file )
              str <- strsplit(file, "\\.txt")[[1]]
                           
              assign("codes.names",str, env=get("ewho", env=eGUI))
              assign("codes.names",str, env=eGUI)
              in.list[["codes.names"]] <- str
    
###           cat("after assigmnet ...") 
###           print(str)
            }
          else if (identical(param[n], "Hct.c.deriv") )
            {
###           cat("Inside open.files and Hct.c.deriv....", "\n")
              data.path <- get("prior.path", env=ewho)
###           cat("in Hct.c.deriv....\n")
###           print(data.path)
               if(trim.blanks(fpath) == "")
                 next; 
              file <- parse.files(filepath=fpath,
                                 directory.def=data.path, typedef =type.def, dir=input)
              assign("Hct.c.deriv",file, env=get("ewho", env=eGUI))
              assign("Hct.c.deriv",file, env=eGUI)
               in.list[["Hct.c.deriv"]] <- file
            }
          else if(identical(param[n], "zero.mean") )
            {
###              cat("Inside open.files and zero.mean....", "\n")
              data.path <- get("prior.path", env=ewho)
###           print(data.path)
               if(trim.blanks(fpath) == "")
                 next; 
              file <- parse.files(filepath=fpath,
                                 directory.def=data.path, typedef = type.def, dir=input)
              assign("zero.mean", file, env=get("ewho", env=eGUI))
              assign("zero.mean", file, env=ewho)
               in.list[["zero.mean"]] <- file
            }   
          else if(identical(param[n],"user.file"))
            {
###           cat("Inside open.files and user.file....", "\n")
###            print(fpath)
           if(trim.blanks(fpath) == "")
             next; 
           if(identical(type.def, "txt") )
             in.userfile(fpath)
           else if(identical(type.def, "dat") )
             in.GUIfile(fpath)
           else
             tkmessage(message="Not known file extension for user.file")
         }
 
     
        }
      assign("in.list", in.list, env=ewho)
      assign("in.list", in.list, env=eGUI)
    }
        
    linkfiles <- function() {
      path.to.harvard <- "/nfs/where/export/data/death/WHOdata/Jun2002_data/*"
      destfile <- "INPUT"
      ret <- modaldiag2(harvardpath= path.to.harvard, destpath= destfile)
      codesfile <- ret$harvard
      destpath <- paste(getwd(),"/",ret$input, sep="" )
              
      res <- readLines(pipe(paste("ln -s", codesfile, destfile)))
    }
    
    in.userfile <- function(userfile){
      ewho <- get("ewho", env = eGUI)
      in.list <- get("in.list",env=ewho)
      n.input <- length(in.list)

### the exact address of userfile
      assign("userfile", userfile, env=eGUI)
      assign("userfile", userfile, env=ewho)
   
      ff <- strsplit(userfile,"/")[[1]]
      usfile <- NULL
      if(length(ff) > 0)
        usfile <- ff[length(ff)]
      ftext <- usfile
### just the name of the file ftext
      userfile.chk <- T
      assign("userfile.chk", T, env=eGUI)
      cat("Updating global with the user file parameters\n")
      source(userfile,local=T)
      args <- names(in.list)
     
      for(i in 1:n.input ){
        val <- try(eval(as.symbol(args[i])), silent=T)
        if (class(val)!= "try-error" && !is.null(val)){
          
          assign(args[i], val, env=ewho)
          assign(args[i], val, env=eGUI)
          in.list[[i]] <- val
        } else {
          assign(args[i], in.list[[i]], env=ewho)
          assign(args[i], in.list[[i]], env=eGUI)
        }
      }
      if(get("reuse.data", env=eGUI) == F) 
        rbValreuse <-  tclVar("False")
      else
        rbValreuse <- tclVar("True")
      
      if(get("save.output", env=eGUI) == F) 
        rbValsave <-  tclVar("False")
      else
        rbValsave <- tclVar("True")
      
      assign("rbValreuse", rbValreuse, env=eGUI)
      assign("rbValsave", rbValsave, env=eGUI)
      
      tkconfigure(frame21.rbs1, variable=rbValsave,value="True")
      tkconfigure(frame21.rbs2, variable=rbValsave,value="False")
   
      
      tkconfigure(frame22.rbs1, variable=rbValreuse,value="True")
      tkconfigure(frame22.rbs2, variable=rbValreuse,value="False")
      
    }
    
    in.GUIfile <- function(filename){
           
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        retreive.GUI <- filename
### the exact address of userfile
        tkmessage(paste("Updating global with GUI-file parameters ",retreive.GUI, "\n"))
        assign("retreive.GUI", filename, env=eGUI)
        assign("retreive.GUI", filename, env=ewho)
        ff <- strsplit(retreive.GUI,"/")[[1]]
        guifile <- NULL
        if(length(ff) > 0)
          guifile <- ff[length(ff)]
        ftext <- guifile
### just the name of the file
        load(file=filename, envir=get("ewho", env=eGUI))
        
      }
    
    
    
    out.GUIfile <- function(){
      depvar <- get("depvar", env=ewho)
      strata <- get("strata", env=ewho)
      model  <- get("model", env=ewho)
      results.path <- paste(getwd(), "/INPUT/", sep="" )
      save.GUI <- paste(depvar,".",strata,".",
                        tolower(model),"_GUI.dat",sep="")
      save.GUI <- paste(results.path,save.GUI, sep="")
      mess <- paste("Your GUI selections are saved in the file, \n",save.GUI, sep="")
      ##            depvar,".",strata,".",tolower(model),"_GUI.dat",sep="") 
      retVal <- tkmessageBox(message=mess, icon="info")
      if(tolower(tclvalue(retVal))=="ok"){
        
        assign("save.GUI",save.GUI, env=eGUI)
        assign("save.GUI", save.GUI,env=ewho)
      }
      
    }
    sim.output <- function(){  
      filename <- tclvalue(tkgetOpenFile())
      if (!nchar(filename))
        tkmessageBox(message="No file selected")
      else{
        tkmessageBox(message=paste("File selected is\n",filename ))
        lst <- strsplit(filename,"/")[[1]]
        ix <- length(lst)
        save.output <- filename
### the exact address of userfile
###        print(save.output)
        assign("save.output", filename, env=eGUI)
        assign("save.output", filename, env=get("ewho", env=eGUI))
        rbValsave <-  tclVar("True")
        assign("rbValsave", rbValsave, env=eGUI)
        tkconfigure(frame21.rbs1, variable=rbValsave,value="True")
        tkconfigure(frame21.rbs2, variable=rbValsave,value="False")
        varzero <- tclVar(lst[ix])
        ff <- strsplit(save.output,"/")[[1]]
        usfile <- NULL
        if(length(ff) > 0)
          usfile <- ff[length(ff)]
        ftext <- usfile
### just the name of the file
###        print(ftext)
        savefile.chk <- T
        assign("savefile.chk", T, env=eGUI)
      }
    }
    mastercast <- function(){
      
      ewho <- get("ewho", env=eGUI)
      
      for(i in (1:length(ls(env=ewho)))){
        ch <- ls(env=ewho)[i]
        x <- get(ch, env=ewho)
        if(is.environment(x)){
###     print(ewho)
          ## rm(ch, env=ewho)
          
        }
      }
      
     conn <- textConnection("yourcast>", "w")
     sink(conn)
     m <- yourcast(env.who=ewho)
     sink()
     close(conn)
      assign("m", m, env=eGUI)
      assign("m", m, env=ewho)
      GUI.selections(); 
      
    }
    
    
    
    graphcast <- function(){
      m <- get("m",env=eGUI)
      
      ret <- yourgraph.new(input.data=m)
    }
    sumcast <- function(){ }
    
    
    topmenu <- tkmenu(base)
    tkconfigure(base, menu=topmenu)
    dirmenu <- tkmenu(topmenu, tearoff=F)
    filemenu <- tkmenu(topmenu, tearoff=F)
    
    tkadd(dirmenu, "command", label= "Open...", command=open.dirs)
###    tkadd(dirmenu, "command", label= "link...", command=linkfiles)
    tkadd(dirmenu, "command", label="Quit",
          command=function() tkdestroy(base))
    
    tkadd(filemenu, "command", label= "Input Files...",
          command= open.files)
   
##    tkadd(openfile, "command", label= "Sim save.output...",
##          command= sim.output)
    tkadd(filemenu, "command", label= "GUI-selections...",
          command= out.GUIfile)
  
    exemenu <- tkmenu(topmenu, tearoff = F)
    runmenu <- tkmenu(exemenu, tearoff=F)
    summenu <- tkmenu(exemenu, tearoff = F)
    tkadd(runmenu, "command", label="yourcast...",
          command=mastercast)
    tkadd(runmenu, "command", label="yourgraph...",
          command=graphcast)
    
    tkadd(summenu, "command", label="Summary...", command= sumcast)
    tkadd(exemenu, "cascade", label="Run..",menu=runmenu)
    tkadd(exemenu,"cascade", label="Statistics...", menu=summenu)
    
    tkadd(topmenu, "cascade", label="Data", menu=dirmenu)
    tkadd(topmenu, "cascade", label="Parameters", menu=filemenu)
    tkadd(topmenu, "cascade", label="Execute", menu=exemenu)
### end of menu bar
    
    tkmaster <-  tkframe(base, relief = "groove", borderwidth = 1)
    
    frame1  <- tkframe(tkmaster, relief = "groove", borderwidth = 1)
    frame2 <- tkframe(tkmaster, relief = "groove", borderwidth = 1)
    frame21 <- tkframe(frame2, relief = "groove", borderwidth = 0)
    frame22 <- tkframe(frame2, relief = "groove", borderwidth = 0)
    frame3 <- tkframe(tkmaster, relief = "groove", borderwidth = 1)
    
    frame1.label1 <- tklabel(frame1, textvariable = tclVar(txtoptions),fg="blue")
    frame1.label2 <- tklabel(frame1, textvariable = tclVar(txtmodel),fg="blue")
    frame1.label0 <-  tklabel(frame1, text = "  ")
    
    scr <- tkscrollbar(frame1, repeatinterval=4,
                       command=function(...)tkyview(frame1.lstbox1, ...))
    frame1.lstbox1 <- tklistbox(frame1, height=6, selectmode="single",
                                yscrollcommand=function(...)tkset(scr,...),
                                listvariable= categoryList, background="white")
    
    scr2 <- tkscrollbar(frame1, repeatinterval=4,
                        command=function(...)tkyview(frame1.lstbox2, ...))
    frame1.lstbox2 <- tklistbox(frame1, height=6, selectmode="single",
                                yscrollcommand=function(...)tkset(scr2,...),
                                listvariable= modelList, background="white")
    
    tkgrid(frame1.label1, frame1.label0, frame1.label2, sticky = "w")
    tkgrid(frame1.lstbox1, scr,frame1.lstbox2, scr2,sticky = "e")
    tkgrid.configure(scr, rowspan=5, sticky="nsw")
    tkgrid.configure(scr2, rowspan=5, sticky="nsw")
       
    tkbind(frame1.lstbox2, "<Double-Button-1>", function() {
      click.on.model(frame1.lstbox2)})
           
    tkbind(frame1.lstbox1, "<Double-Button-1>", function() {
      ewho <- get("ewho", env=eGUI)
      click.on.frame(frame1.lstbox1, ewho, model)})
    
    tkpack(frame1)
    frame21.separator <- tklabel(frame21,text="")
    frame21.label1 <- tklabel(frame21,text=txtoutput,fg="blue")
    frame22.separator <- tklabel(frame22,text="")
    frame22.label1 <- tklabel(frame22,text=txtreuse,fg="blue") 
    frame21.rbs1   <- tkradiobutton(frame21)
    frame21.rbs2   <- tkradiobutton(frame21)
    frame22.rbs1   <- tkradiobutton(frame22)
    frame22.rbs2   <- tkradiobutton(frame22)
    tkgrid(frame21.label1,sticky="w")
    tkgrid(frame22.label1, sticky="w")
    tkconfigure(frame21.rbs1, variable=rbValsave,value="True")
    tkconfigure(frame21.rbs2, variable=rbValsave,value="False")
    tkconfigure(frame22.rbs1, variable=rbValreuse,value="True")
    tkconfigure(frame22.rbs2, variable=rbValreuse,value="False")
    
    tkbind(frame21.rbs1,"<Button-1>", function(){
###      print( as.character(tclvalue(rbValsave)))
      rbValsave <-  tclVar("True")
      rvalsave <- as.character(tclvalue(rbValsave)) 
      save.output <- get("save.output", env=get("ewho", env=eGUI))
      assign("save.output", save.output, env=eGUI)
      assign("save.output", save.output, env=ewho)
      assign("rbValsave", rbValsave,env=eGUI)})
    
    tkbind(frame21.rbs2,"<Button-1>", function(){
###      print( as.character(tclvalue(rbValsave)))
      rbValsave <-  tclVar("False")
      rvalsave <- as.character(tclvalue(rbValsave)) 
      save.output <- F
      assign("save.output", save.output, env=eGUI)
      assign("save.output", save.output, env=ewho)
      assign("rbValsave", rbValsave,env=eGUI)
    })

    
    tkbind(frame22.rbs1,"<Button-1>", function(){
###      print( as.character(tclvalue(rbValsave)))
      rbValreuse <-  tclVar("True")
      rvalreuse <- as.character(tclvalue(rbValreuse)) 
      reuse.data <- T
      assign("reuse.data", reuse.data, env=eGUI)
      assign("reuse.data", reuse.data, env=ewho)
      assign("rbValreuse", rbValreuse,env=eGUI)})
    
    tkbind(frame22.rbs2,"<Button-1>", function(){
###      print( as.character(tclvalue(rbValsave)))
      rbValreuse <-  tclVar("False")
      rvalreuse <- as.character(tclvalue(rbValreuse)) 
      reuse.data <- F
      assign("reuse.data", reuse.data, env=eGUI)
      assign("reuse.data", reuse.data, env=ewho)
      assign("rbValreuse", rbValreuse,env=eGUI)
    })

    tkgrid(tklabel(frame21, text="True"), frame21.rbs1, sticky="e")
    tkgrid(tklabel(frame22, text="True"), frame22.rbs1,  sticky="e")
    tkgrid(tklabel(frame21, text="False"), frame21.rbs2, sticky="e")
    tkgrid(tklabel(frame22, text="False"), frame22.rbs2, sticky="e" )
    tkgrid(frame21, frame22)
    tkpack(frame2)
    frame3.but0 <- tkbutton(frame3, textvariable =tclVar("Manual"),
                            padx = 20, command = soft.manual)
    
    frame3.but1 <- tkbutton(frame3, textvariable =tclVar("Close"),
                            fg="red",padx = 20, command = master.close)
    
    frame3.but12 <- tkbutton(frame3, textvariable =tclVar("Clear"),
                             fg="blue",padx = 20, command = master.clear)
    
    frame3.but2 <- tkbutton(frame3, text = "Apply", padx = 20,command = master.init)   
    tkgrid(frame3.but0, frame3.but1, frame3.but12, frame3.but2, sticky = "w")
    tkpack(frame3)
###  tkpack(tkmaster)
    lst <- list(frame = tkmaster, envr = ewho)
    return(lst)
    
      }

yourcast.GUI <- function(){
  ewho <- set.defaults()

  dirs <- directory.input.output();    
  base10 <- tktoplevel()
  tkwm.title(base10,"YourCast")
  ret <- master.GUI(base10)
  frame10 <- ret$frame
  ewho <- ret$envr
  tkpack(frame10)
 return(ewho)
 }
   click.on.model <- function(lstbox) {
     ewho <- get("ewho", env=parent.frame())
     env.who <- ewho
     
     if(length(as.numeric(tkcurselection(lstbox))) >0){
       ind.to.display <- as.numeric(tkcurselection(lstbox)) +1
    
        if(ind.to.display <= 1){
#### Model and years selection          
          base1 <- tktoplevel()
          frame1 <- fore(base1)
          tkwm.title(base1, "Forecasting Selections")
          tkpack(frame1)

        
        }else if(ind.to.display <= 2){
### CSTSID structure or digits container#####################
          base2 <- tktoplevel()
          frame2 <- digits(base2)
          tkwm.title(base2, "Index Variable")
          tkpack(frame2)  
                
        }else if(ind.to.display <= 3){
### choice of smoothing and Bayesian parameters
          base9 <- tktoplevel()
          frame9 <- bayes(base9)
          tkwm.title(base9,
                     "Bayesian Parameters")
          tkpack(frame9)
              
        }else{
             print("No other selections")
          
           }
      
        
    
          return(  ind.to.display )
               
     }
   }

click.on.frame <- function(lstbox, ewho,model){
  env.who <- ewho
  ewho <- get("ewho", env= parent.frame())

###  print(get("codes.names", env=ewho))
    if(length(as.numeric(tkcurselection(lstbox))) >0){
        ind.to.display <- as.numeric(tkcurselection(lstbox)) +1
        if(ind.to.display <= 1){
### for depvar container
          base3 <- tktoplevel()
          frame3 <- depvar(base3)
          tkwm.title(base3, "Dependent Variable Selections")
          tkpack(frame3)
        
        }else if(ind.to.display <= 2){

### for country container
          base4 <- tktoplevel()
          frame4 <- cntryLst(base4)
          tkwm.title(base4, "Country Selections")
          tkpack(frame4)
                
        }else if(ind.to.display <= 3){
### for strata container
          base5 <- tktoplevel()
          frame5 <- strata.select(base5)
          tkwm.title(base5, "Strata & Age Selections")
          tkpack(frame5)
        
        }else if(ind.to.display <= 4){
### choice of covs and types        
          base6 <-  tktoplevel()
          frame6 <- covtype(base6)
          tkwm.title(base6,
                     "Choosing the Covariates")
          tkpack(frame6)
           
        }else if(ind.to.display <= 5){
          ##covs and ages
          base7 <- tktoplevel()
          frame7 <- covage(base7)
          tkwm.title(base7, "Covariate & Age Selections")
          tkpack(frame7)
        
        }else if(ind.to.display <= 6){
### choice of parameters for covs      
          base8 <- tktoplevel()
          frame8 <- standard.cov(base8)
          tkwm.title(base8,
                     "Processing Covariates Parameters")
          tkpack(frame8)

        }else {
          print("No selection available")
        }       
      }}


##
## FUNCTION NAME:    convert.to.vector 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## USED GLOBALS:
##
## DESCRIPTION: It gets a string of the form "c(1, 10, 20)" and converts into a vector.
##
## FORMAT:  convert.to.vector(string)
##         
##
## OUTPUT: Construct the R-vector to pass to GUI environmnet.
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 17/02/2005
## 
## ************************************************************************
## ************************************************************************

convert.to.vector <- function( str){
  str <- strsplit(str, "c\\(")[[1]][2]
  str <- strsplit(str, ")")[[1]]
  str <- strsplit(str, ",")[[1]]
  return(as.numeric(str))
}
  
                         
### Calling functions for all built frames.  Creates toplevel container to
### display all GUI's for each of the different selections and gives titles. 
     
   yourcast.GUI.old <- function(){
                         env.who <- set.defaults()
                         ewho <- env.who
                 ### for forecasting container
                         base1 <- tktoplevel()
                         frame1 <- fore(base1)
                         tkwm.title(base1, "Forecasting Selections")
                         tkpack(frame1)
                 ### for digits container
                         base2 <- tktoplevel()
                         frame2 <- digits(base2)
                         tkwm.title(base2, "CSTS Identifiers")
                         tkpack(frame2)
                  ### for depvar container
                         base3 <- tktoplevel()
                         frame3 <- depvar(base3)
                         tkwm.title(base3, "Dependent Variable Selections")
                         tkpack(frame3)
                  ### for country container
                         base4 <- tktoplevel()
                         frame4 <- cntryLst(base4)
                         tkwm.title(base4, "Country Selections")
                         tkpack(frame4)
                  ### for strata container
                         base5 <- tktoplevel()
                         frame5 <- strata.select(base5)
                         tkwm.title(base5, "Strata & Age Selections")
                         tkpack(frame5)
                   ### for cov age selection container
                         base6 <- tktoplevel()
                         frame6 <- covage(base6)
                    ##     frame6 <- get("tkcovage", env=ecov)
                         tkwm.title(base6, "Covariate & Age Selections")
                         tkpack(frame6)
                    ### choice of parameters for covs      
                         base7 <- tktoplevel()
                         frame7 <- standard.cov(base7)
                         tkwm.title(base7,
                                    "Processing Covariates Parameters")
                         tkpack(frame7)
                   ### choice of covs and types        
                         base8 <- tktoplevel()
                         frame8 <- covtype(base8)
                         tkwm.title(base8,
                                    "Choosing the Covariates")
                         tkpack(frame8)
                    ### choice of smoothing and Bayesian parameters
                         base9 <- tktoplevel()
                         frame9 <- bayes(base9)
                         tkwm.title(base9,
                                    "Bayesian Parameters")
                         tkpack(frame9)
                     ### master GUI
                         base10 <- tktoplevel()
                         frame10 <- master(base10)
                         tkwm.title(base10,
                                    "YourCast")
                         tkpack(frame10)
                         return(ewho)
                       }
  

