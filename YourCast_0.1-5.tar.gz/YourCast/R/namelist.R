##
## USED GLOBALS: env=env.base, our base environment, which for working purposes we
##               designated it to be the .GlobalEnv.  It is now the environment for function main()
##               that wraps up all programs and functions.
##               Also, env=env.who (an environment), which we create to stores all
##               static variables to be shared by all functions and programs.  
##               We assign env.who to the env.base as, assign("env.who", env=env.base)
##               if you want to see what is in env.who:  >  ls(env=get("env.who", env=env.base)); 
##
## DESCRIPTION:  The programs static variables, are given default values with
##               the function WHO(); variables are stored in the environment env.who,
##               which belongs to env.base. Any variables belonging to env.who,
##               may be retreived from env.base as:
##               get("whodisease",env=get("env.who", env=env.base)); 
##               and you may change its value as
#               assign("whodisease",newdisease, env=get("env.who", env=env.base))
##
## FORMAT: WHO(ebase=env.base) 
##
## VALUE: all variables used in the programs with their default values in WHO()
##
## WRITTEN BY: Elena Villalon & Federico Girosi
##             evillalon@latte.harvard.edu,fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 10/27/2003
## 
## 
## ************************************************************************
## ************************************************************************

### env.base is the environmnet for function main, which may be globalized 
### assign("env.base", env.base, env= get(".GlobalEnv", env=.GlobalEnv))
##ebase = get("env.base", env=.GlobalEnv)

namelists <- function(){
### we are not attaching ewho to env.base but returning it
### because we need to make it available to stand alone functions.
###  ebase <- get("env.base", env=parent.frame())
### find the environment to store variables
### the parent.frame() is env.base (driver environment),
### but if driver does not exist then default is .GlobalEnv
  env.who <- environment()
  
###  assign("env.who", env.who, env=ebase)
### Enter all variables as vectors; such as whousercntrylist <- c(2450, 4280)
### cause of death we want to predict
###
allcauses  <- "allc"
                        
depvar <- ifelse(length(allcauses) >0,
                 (ifelse(!is.na(allcauses),allcauses,"allc")), "allc") 
                        
  
### read two files for mortality such as the population 
### and death files (default case) or read only one for the
### dependent variable
  
population <-  "population"

### correspondance between cntry codes and names
### it is a string with name of file or NA.
### In case of NA we will assign the same codes
### as cntry names
codes.names <- "cntry.codes"
  
### gender: 2 for males, 3 for females
strata <- 2

### whocovariates: list of covariates to use.  At the moment the possible covariates
### are: gdp,hc,tfr.  Putting the prefix "ln" in front of the name of a covariate
### causes the algorithm to log that covariate.

cov <-  c("gdp","tobacco","time","cnst");
  
### specifying how to read the data files for covariates, such as
### strata.independent, age.independent, age/strata.independent or NA
  
cov.type <- NA
### the last year of the out of sample period
fore <- 2030

### the last year of the insample period
yrest <- 2000

### the lag of the covariates
lag <- 30

### The data available for covariates and dth expand a time series,
### which may not start at the same year. The maximum years, wholag.max,
### we may lag the covariates without neglecting any mortality data,
### is calculated after substracting the starting year of observation
### for any not missing covariates, and the first year of dth observation.
### The max years depend on any specific csid (cntry+age.group).
### For predictions beyond wholag.max use only "cnts" and "time".  
###
### maximum year of available data (say, beyond 2000).  
### whofore = whoyrest + wholag.max, with covariates data 
### usually, wholag.max <- 30
### otherwise you may only use as covariates
### if(wholag > wholag.max )
###  whocovariates <- c("cnst", "time")


### whousercntrylist: A list of country codes, used to select to set
### of countries you wish to analyze. If NA the program will look
### at the variable whousersubreg

usercntrylist <- NA
### whousercntrylist <- c(1430,2450,2020,2090,2310,4080,4085,4180,4280,3160,4308);

### this is the list of covariates that we want to exclude from the age groups
### specified by who.age.select
cov.select <- "tobacco";

########################### DEFINE STRUCTURES OF cstsid ###############################
###

 cntry.digits <- 4
 year.digits  <- 4
 digit.first  <- 0
 age.digits <- 2
 age.select <- c(0,5,10,15)
### the covariates specified in who.cov.select will be deleted from the
### age groups specified in who.age.select

########### END OF DEFINE STRUCTURES cstsid #########################

### the percentage of data we are willing to lose in order to include the covariates
### with missing values
### who.lag.cutoff <- 0.5 
lag.cutoff <- 1

### whoskip: skip all countries with less than whoskip observations
### in the insample period. If NA or 0 this option is not
### used. This option is used only if whousercntrylist is NA

skip <- 8;

### select specfic age groups (they must be adjacent to each other)

userages <- NA;
### userages <- 5*6:12 , which is the same as                         
###userages <- c(30,35,40,45,50,55,60); 
 
### if TRUE the program will attempt to re-utilize the global variables
### computed in the preprocessing stage by make.mortality.data and stored
### in a data file whose name matches cause of death and gender and
### is stored in the directory who.reuse.dir. If the
###+ data file does not exist in the directory whooutpath, a warning
### message is printed and the pre-processing function is invoked. If the
### data file exists a number of tests are run to make sure that the
### user-set global variables stored in the data file exactly match the
### user-set global variables in this file. If an exact match is not
### found a warning message is printed and the pre-processing function
### make.mortality.data is invoked.
reuse.data <- T;
  
### The output of the simulation may be saved into a file,
### if who.save.out.put=T; it is the return object (list)
### of mortality.driver, which is the driver of the simulation
  
save.output <- T
### The files for the covarites may be saved in the long format,
### which includes all age groups and strata values after reading
### the covarites' files either strata.age.independent, age.strata.independent, 
### age.independent, strata.independent and put into the long format and save
  save.FULL <- T

### the name of the directory where to look for data when who.reuse.data = TRUE
### usually this is the same as whooutpath
reuse.path <- "OUTPUT/";

### which model you want to use. Current options are "OLS", "LC", "POISSON". If not a string
### no forecast is produced, and the program only creates the data. 
model <- "OLS";

### if 1 the covariates (as stored in whocov) are standardized to zero mean and std 1
standardize <- TRUE;

### if 1 during the preprocessing we search for collinearities and delete redundant
### covariates if necessary
elim.collinear <- TRUE;

### transform the dependent variable with function f(x): if 1, f(x) = log(x),
### if 2, f(x) = sqrt(x) and if 3, f(x) = log(1+x), if NA or 0, then f(x) = x
transform <- 1

### directory where mortality data are
### "/nfs/where/export/data/death/WHOdata/Jun2002_data/"
### Unix command to create a soft link:
### ln -s /nfs/where/export/data/death/WHOdata/Jun2002_data/* .
                        
  data.path <-  try("INPUT/", silent=T)
  if(class(data.path) == "try-error")
    stop("I cannot find the directory to read input files")

### directory where covariates are
cov.path <- data.path
### name of directory where all the precomputed quantities relating to the prior are stored
prior.path <- data.path;

### directory where output files will be saved
### with the graphs
  out.path <- "OUTPUT/"

### tolerances and their dicrease in several iterations,
### for detecting linear dependencies of columns of whoinsampx, 
### which is matrix of covariates for a particular csid.
### Use by functions covdel in preproc.elim.collinear (tol <= 1)
### and eliminate.colinear. the delta.tol is dicrease from tol
### until solve can invert the matrix t(whoinsampx) %*% whoinsampx
### Built in function solve also has a tolerance, call solve.tol
### for elim.colinear as default to invert.                         
tol <- 0.9999
delta.tol <- .Machine$double.eps
solve.tol <- 1.e-10                      
                                                
### tolerance used in the inversion of a matrix using SVD
### used in gibbs.model() and  eliminate.colinear 
svdtol <- 10^(-10);

### BELOW WE HAVE QUANTITIES RELATED TO THE PRIORS
### If FALSE the prior  does not have zero mean
### and it is centered around who.mean.age.profile. Having a non-zero mean is achieved by
### subtracting the mean from the dependet variable and adding it back after the forecast
### has been done. If TRUE no action is taken.
zero.mean <- T;

############################ PRIOR OVER AGE GROUPS  ###############################
###
Ha.deriv <- c(0,0,1);

### If 0 or NA then all age groups are weighted equally. If scalar, then the weight
### of age group a is proportional to a^who.Ha.age.weight. If vector of length A
### then it is taken as the weight vector.
Ha.age.weight <- 0;
Ha.time.weight <- 0;

### the average standard deviation of the prior. If NA the prior is not used
### (it is like having an infinite standard deviation 
Ha.sigma <- 0.3
Ha.sigma.sd <- 0.1

############################ PRIOR OVER AGE AND TIME GROUPS  ###############################

### the "age part" of the age/time prior
Hat.a.deriv <- c(0,0,1);

### the "time part" of the age/time prior
Hat.t.deriv <- c(0,1);

### If 0 or NA then all age groups are weighted equally. If scalar, then the weight
### of age group a is proportional to a^who.Ha.age.weight. If vector of length A
### then it is taken as the weight vector.
Hat.age.weight <- 0;

Hat.time.weight <- 0;

Hat.sigma <- 0.2
Hat.sigma.sd <- 0.1

############################ PRIOR OVER  TIME GROUPS  ###############################

### 
Ht.deriv <- c(0,0,1);

Ht.age.weight <- 0;

Ht.time.weight <- 0;

Ht.sigma <- 0.3
Ht.sigma.sd <- 0.1
                                        #
############################ PRIOR OVER CNTRY GROUPS  ###############################
Hct.t.deriv <- 1; ### smooths trend over cntry's
### who.Hct.t.deriv <- c(1)  ### smooths mortality
### we do not offer the option of setting who.Hct.time.weight != NA
### because it gets messy when different countries have different
### length of time series.
### Uniform weighting is the only option we have now
Hct.time.weight <- 0
Hct.c.deriv <- "adjacency.txt"
### the following two parameter not implemented in the code
##Hct.cntry.weight <- NA

Hct.sigma <-  0.3
Hct.sigma.sd <- 0.1
##############################SIGMA PRIOR##########################

  LI.sigma.mean <- 0.2
  LI.sigma.sd   <- 0.1
###  LI.sigma.sd   <- 0.1
### number of times to run the gibbs sampler
  nsample <- 500
return(env.who)
} ## end WHO()


input.lst <- list("whodisease", "whogender","whocovariates","cov.type", "whofore","whoyrest",   
                  "wholag", "wholagdth","whogdp2","whodepvar","whousercntrylist",
                  "who.cov.select","forecast", "who.cntry.digits", 
                  "who.year.digits","who.digit.first","who.age.digits","who.age.select", 
                  "who.lag.cutoff","whousersubreg","whoskip", "whouserages", "who.reusedata", 
                  "who.reuse.path","who.save.output","whomodel", "whostandardize", "whoelim.collinear",
                  "whotransform", "datapath", "whodatapath", "whocovpath","whooutpath",
                  "whographdir", "tol", "svdtol", "whopriorpath", "who.zero.mean", 
                  "who.ols.sigma.param", "who.Ha.deriv", "who.Ha.age.weight", 
                  "who.Ha.time.weight", "who.Ha.sigma","who.Ha.sigma.sd",
                  "who.Hat.a.deriv","who.Hat.t.deriv",
                  "who.Hat.age.weight", "who.Hat.time.weight",
                  "who.Hat.sigma", "who.Hat.sigma.sd","who.Ht.deriv", 
                  "who.Ht.age.weight", "who.Ht.time.weight",
                  "who.Ht.sigma", "who.Ht.sigma.sd","who.Hct.t.deriv","who.Hct.time.weight",
                  "who.Hct.c.deriv","age.groups", "who.Hct.sigma","who.Hct.sigma.sd",
                  "LI.sigma.mean","LI.sigma.sd", "nsample")
###

check <- function(input = input.lst, ebase=env.base){
         ebase <- get("env.base", env=parent.frame());
          ewho <- get("env.who", env=ebase)
          ls(env=ewho)
          input <- unlist(input)
          vec <- ls(env=ewho)
          i1 <- match("ebase", vec)
          i2 <- match("env.who", vec)
          if(i1 > i2){
            vec <- vec[-i1]
            vec <- vec[-i2]
          }else{
            vec <- vec[-i2]
            vec <- vec[-i1]}

          indx <- sapply(input, function(y, ebase) {match(y,vec)},ebase)
          return(indx)}
                     
