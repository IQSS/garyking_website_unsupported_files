
 bayes <- function(base,
                   textsmooth = "Smooth Dependent Variable Parameters: ", 
                   textage ="Age Groups",
                   textime ="Time Trends",
                   textimeage = "Age & Time",
                   textcntry = "Geographical Index", 
                   textna = "<NA>", defVal=0.1,
                   zerotext = paste("Mean Adjustment", "\n", "Hct.c.deriv", sep=""))
                   {
    rowHa  <- c("Ha.sigma", "Ha.deriv",
                "Ha.age.weight", "Ha.time.weight", "Ha.sigma.sd")
    rowHa <- expand.char(rowHa)
     
    rowHat <- c("Hat.sigma", "Hat.a.deriv","Hat.t.deriv", 
                "Hat.age.weight", "Hat.time.weight", "Hat.sigma.sd")
    rowHat <- expand.char(rowHat)
    rowHt  <- c("Ht.sigma", "Ht.deriv",
                "Ht.age.weight", "Ht.time.weight", "Ht.sigma.sd")
    rowHt <- expand.char(rowHt)
    rowHct <- c("Hct.sigma", "Hct.t.deriv", "Hct.time.weight", "Hct.sigma.sd")
    rowHct <- expand.char(rowHct)    
            
    ewho <- get("ewho", env=parent.frame())
    Ha.sigma <- get("Ha.sigma", env=ewho)
      
    Ht.sigma <- get("Ht.sigma", env=ewho)
    Hat.sigma <- get("Hat.sigma", env=ewho)
    Hct.sigma <- get("Hct.sigma", env=ewho)
    zero.mean <- get("zero.mean", env=ewho)
    zero.mean0 <- zero.mean
    Ha.sigma.sd <- get("Ha.sigma.sd", env=ewho)
    Ha.sigma.sd0 <- Ha.sigma.sd
    Ha.deriv <- get("Ha.deriv", env=ewho)
    Ha.deriv0 <- Ha.deriv 
    Ha.age.weight   <- get("Ha.age.weight", env=ewho)
    Ha.age.weight0 <-  Ha.age.weight 
    Ha.time.weight  <- get("Ha.time.weight", env=ewho)
    Ha.time.weight0 <- Ha.time.weight

    Ht.sigma.sd <- get("Ht.sigma.sd", env=ewho)
    Ht.sigma.sd0 <-  Ht.sigma.sd
    Ht.deriv <- get("Ht.deriv", env=ewho)
    Ht.deriv0 <-  Ht.deriv
    Ht.age.weight   <- get("Ht.age.weight", env=ewho)
    Ht.age.weight0 <- Ht.age.weight 
    Ht.time.weight  <- get("Ht.time.weight", env=ewho)
    Ht.time.weight0 <-  Ht.time.weight 
    Hat.sigma.sd <- get("Hat.sigma.sd", env=ewho)
    Hat.sigma.sd0 <-  Hat.sigma.sd 
    Hat.a.deriv <- get("Hat.a.deriv", env=ewho)
    Hat.a.deriv0 <-  Hat.a.deriv 
    Hat.t.deriv <- get("Hat.t.deriv", env=ewho)
    Hat.t.deriv0 <- Hat.t.deriv
    Hat.age.weight   <- get("Hat.age.weight", env=ewho)
    Hat.age.weight0 <-   Hat.age.weight
    Hat.time.weight  <- get("Hat.time.weight", env=ewho)
    Hat.time.weight0 <-  Hat.time.weight
    Hct.sigma.sd <- get("Hct.sigma.sd", env=ewho)
    Hct.sigma.sd0 <-  Hct.sigma.sd 
    Hct.t.deriv <- get("Hct.t.deriv", env=ewho)
    Hct.t.deriv0 <-  Hct.t.deriv 
    Hct.time.weight   <- get("Hct.time.weight", env=ewho)
    Hct.time.weight0 <-  Hct.time.weight 
    lnchar <- nchar("Hct.time.weight")
    model <- get("model", env=ewho)
    nsample  <- get("nsample", env=ewho)
    LI.sigma.mean <- get("LI.sigma.mean", env=ewho)
    LI.sigma.sd <- get("LI.sigma.sd", env=ewho)
    prior.path <- get("prior.path", env=ewho)
    data.path <- get("data.path", env=ewho)
    restore.defaults <- F
    ft <- ifelse(toupper(trim.blanks(model)) != "MAP", T, F)
    
    ha  <- ifelse(is.na(Ha.sigma),textna, Ha.sigma)
    ht  <- ifelse(is.na(Ht.sigma),textna, Ht.sigma)
    hat <- ifelse(is.na(Hat.sigma),textna, Hat.sigma)
    hct <- ifelse(is.na(Hct.sigma),textna, Hct.sigma)
    varzero <- tclVar("")
    varLI.mean <- tclVar(LI.sigma.mean)
    varLI.sd <- tclVar(LI.sigma.sd)
    varsample <- tclVar(nsample)
    colorbox <- "white"
    
    rbValue <- tclVar("True")
    localpar <- list(Ha.sigma=ha, Ht.sigma=ht,Hat.sigma=hat)
    if(toupper(trim.blanks(model)) != "MAP") 
     localpar <- c(localpar, list(Hct.sigma=hct))
                          
   
    if(toupper(trim.blanks(model)) == "MAP")
       Hct.sigma <- NA
    
    varzer <- tclVar("") ## name of file for Hct.c.deriv
    eGUI <- environment()
                
    
    tkbayes <- tkframe(base, relief = "groove", borderwidth = 2)
    frame0  <-  tkframe(tkbayes, relief = "groove", borderwidth = 0)
    frame1  <-  tkframe(tkbayes, relief = "groove", borderwidth = 0)
    frame3  <-  tkframe(tkbayes, relief = "groove", borderwidth = 1)
    framemat1 <- tkframe(tkbayes, relief = "groove", borderwidth = 1)
    framemat2 <- tkframe(tkbayes, relief = "groove", borderwidth = 1)
    
    frame2  <-  tkframe(framemat1, relief = "groove", borderwidth = 0)
    frame21 <- tkframe(framemat1, relief = "groove", borderwidth = 0)
    frame22 <- tkframe(framemat2, relief = "groove", borderwidth = 0)
    frame23 <- tkframe(framemat2, relief = "groove", borderwidth = 0)
  
    frame12 <- tkframe(frame1, relief = "groove", borderwidth = 0)
    frame13 <- tkframe(frame1, relief = "groove", borderwidth = 0)
    frame0.label0 <- tklabel(frame0, textvariable = tclVar(textsmooth),
                             fg="blue")
    
    tkgrid(frame0.label0, sticky="w")
    tkgrid(tklabel(frame0, text="    "))
    tkpack(frame0, fill = "x")  
   
###*****
    load.file <- function()
      {      
        filepath <- tclvalue(tkgetOpenFile())
        if (!nchar(filepath)){
          tkmessageBox(message="No file selected from previous GUI's")
          return(0);
        }
        prior.path <- get("prior.path", env=get("ewho", env=eGUI))
        tkmessageBox(message=paste("File selected is\n",filepath ))
            
        fpath <- filepath
        lst <- strsplit(fpath,"/")[[1]]
        inx <- length(lst)
        userfile <- lst[inx]
        varzero <- tclVar(userfile)
###     cat("retVal is ....");  print(retVal)
        file <- parse.files(filepath=fpath,
                                 directory.def=prior.path, typedef = "txt", dir=prior.path)
        assign("zero.mean", file, env=get("ewho", env=eGUI))
        assign("zero.mean", file, env=ewho)
   ##     in.list[["zero.mean"]] <- file
     
             assign("varzero", varzero, env=eGUI) 
             tkconfigure(frame12.entry, textvariable = varzero)        
           
      }## 
    frame12.label <- tklabel(frame12, textvariable = tclVar(zerotext),
                             fg="blue")
    frame12.label1 <-  tklabel(frame12, textvariable = tclVar("Input File"),fg="black")
    frame12.entry <- tkentry(frame12, textvariable=varzero, width = 15, bg="white")
    frame12.butt <- tkbutton(frame12, textvariable =tclVar("Load"), fg="purple",
                             bg="gray", padx=2, borderwidth=2,command=load.file)
    frame12.rb1   <- tkradiobutton(frame12)
    frame12.rb2   <- tkradiobutton(frame12)
    tkgrid(frame12.label, sticky="w")
    tkconfigure(frame12.rb1, variable=rbValue,value="True")
    tkconfigure(frame12.rb2, variable=rbValue,value="False")
    tkgrid(tklabel(frame12, text="True (none)"), frame12.rb1, sticky="w")
    tkgrid(tklabel(frame12, text="False (empirical)"), frame12.rb2, sticky="w")
    tkgrid(frame12.label1, frame12.entry, frame12.butt, sticky="w")
    
    frame13.label1 <- tklabel(frame13, text="LI.sigma.mean",
                              fg ="blue")
    frame13.label2 <- tklabel(frame13, text="LI.sigma.sd  ",
                              fg ="blue")
    frame13.label3 <- tklabel(frame13, text="nsample (Gibbs algorithm)",
                              fg ="blue")
    frame13.entry1 <- tkentry(frame13, textvariable = varLI.mean,
                              width = 8, bg=colorbox)
    
    tkbind(frame13.entry1, "<Tab>",  function() {
      LI.mean.local <- as.numeric(as.character(tclvalue(varLI.mean)))
    
      assign("LI.sigma.mean",LI.mean.local, env=eGUI)
      assign("LI.sigma.mean", LI.mean.local, env=get("ewho", env=eGUI))
  })
    
    frame13.entry2 <- tkentry(frame13, textvariable = varLI.sd,
                              width = 8, bg=colorbox)
    tkbind(frame13.entry2, "<Tab>",  function() {
      LI.sd.local <- as.numeric(as.character(tclvalue(varLI.sd)))
      assign("LI.sigma.sd",LI.sd.local, env=eGUI)
      assign("LI.sigma.mean", LI.sd.local, env=get("ewho", env=eGUI))
  })
    frame13.entry3 <- tkentry(frame13, textvariable = varsample,
                              width = 12, bg=colorbox)
    tkbind(frame13.entry1, "<Tab>",  function() {
      nsample.local <- as.numeric(as.character(tclvalue(varsample)))
    
      assign("nsample",nsample.local, env=eGUI)
      assign("nsample", nsample.local, env=get("ewho", env=eGUI))
  })
    
    tkgrid(frame13.label1, frame13.entry1, sticky="w")
    tkgrid(frame13.label2, frame13.entry2, sticky="w")
    tkgrid(frame13.label3, frame13.entry3, sticky="w")
    
 
    tkgrid(frame12, frame13, padx=10, pady=10)
    
    tkpack(frame1, fill="x")
   
###****    
  
   bayes.init <- function(...) {
     varLI.mean <- get("varLI.mean", env=eGUI)
     LI.mean.local <- as.numeric(as.character(tclvalue(varLI.mean)))
     assign("LI.sigma.mean",LI.mean.local, env=eGUI)
     assign("LI.sigma.mean", LI.mean.local, env=get("ewho", env=eGUI))
    
     varLI.sd <- get("varLI.sd", env=eGUI)
     LI.sd.local <- as.numeric(as.character(tclvalue(varLI.sd)))

     assign("LI.sigma.sd",LI.sd.local, env=eGUI)
     assign("LI.sigma.mean", LI.sd.local, env=get("ewho", env=eGUI))
     
     nsample <- get("nsample", env=eGUI)
     nsample.local <- as.numeric(as.character(tclvalue(varsample)))
     assign("nsample",nsample.local, env=eGUI)
     assign("nsample", nsample.local, env=get("ewho", env=eGUI))
     
          
     Ha.mat <- try(get("mat", env=e1), silen=T)
     print(Ha.mat)
     if(class(Ha.mat) != "try-error"){
         Ha.dat <- convert.data.frame(Ha.mat, rowHa);
         print(Ha.dat)
       }
     
     Hat.mat <- try(get("mat", env=e2), silent = T)
     if(class(Ha.mat) != "try-error"){
       Hat.dat <-  convert.data.frame(Hat.mat, rowHat);
       print(Hat.dat)
     }
     Ht.mat <- try(get("mat", env=e3), silent =T)
     if(class(Ht.mat) != "try-error"){
       Ht.dat <-  convert.data.frame(Ht.mat, rowHt);
       print(Ht.dat)
     }
    
     Hct.mat <- try(get("mat", env=e4), silent =T)
     if(class(Hct.mat) != "try-error"){
       Hct.dat <-  convert.data.frame(Hct.mat, rowHct);
       print(Hct.dat)
     }
     
   }
     
##***
    bayes.close <- function(...) {
       bayes.init(); 
       tkdestroy(base)        
    }
    

    Ha.mat <- build.display(Ha.sigma, H.deriv1 = Ha.deriv, H.deriv2 = "",
                            Ha.age.weight, Ha.time.weight, Ha.sigma.sd)
###    cat("Ha.mat ...")
###    print(Ha.mat)
    e1 <- new.env(hash=T, parent=parent.frame())   
    lst.Ha <- matrix.display.GUI(frame2, nrows=5, ncols=5,
                                 rownames=rowHa, ptr=e1,defvar=Ha.mat, 
                                 title= paste("Age Groups", "\n"),
                                  grayout = T, whiterows=2 )
    frame2 <- lst.Ha$frame
    Ha.mat <- lst.Ha$mat


    Hat.mat <- build.display(Hat.sigma, H.deriv1 =Hat.a.deriv,
                             H.deriv2= Hat.t.deriv, Hat.age.weight,
                             Hat.time.weight, Hat.sigma.sd, width=5)
###    cat("Hat.mat ...")
###    print(Hat.mat)
    
    e2 <- new.env(hash=T, parent=parent.frame())

    lst.Hat <- matrix.display.GUI(frame21, nrows=6, ncols=5,
                                  rownames=rowHat, ptr=e2, defvar=Hat.mat, 
                                  title=paste("Age & Time Groups", "\n"),
                                  grayout = T, whiterows=2:3)
    frame21 <- lst.Hat$frame
    Hat.mat <- lst.Hat$mat 
   
    Ht.mat <- build.display(Ht.sigma, H.deriv1 =Ht.deriv,
                            H.deriv2= "", Ht.age.weight,
                            Ht.time.weight, Ht.sigma.sd, width=5)
###    cat("Ht.mat ...")
###    print(Ht.mat)
  
    
    e3 <- new.env(hash=T, parent=parent.frame())
   
    lst.Ht <- matrix.display.GUI(frame22, nrows=5, ncols=5, 
                                 rownames=rowHt, ptr=e3,defvar = Ht.mat,   
                                 title=paste("Time Trends", "\n"),
                                 grayout = T, whiterows = 2)
    frame22 <- lst.Ht$frame
    Ht.mat <- lst.Ht$mat
    
    Hct.mat <- build.display(Hct.sigma, H.deriv1 =Hct.t.deriv,
                            H.deriv2= "", H.age.weight =" ",
                            Hct.time.weight, Hct.sigma.sd, width=5)
###    cat("Hct.mat ...")
###    print(Hct.mat)
    
    
    e4 <- new.env(hash=T, parent=parent.frame())
 
    lst.Hct <- matrix.display.GUI(frame23, nrows=4,
                                  ncols=5, rownames = rowHct,
                                  ptr=e4,defvar =Hct.mat,   
                                  title=paste("Geographic Index", "\n"),
                                  grayout=T, whiterows=2 )
    frame23 <- lst.Hct$frame
    Hct.mat <- lst.Hct$mat
 
    tkgrid(frame2, frame21)
    tkpack(framemat1)
    tkgrid(frame22, frame23)
    tkpack(framemat2)

    
   
    frame3.spacer <- tklabel(frame3, text = "   ")
    
    frame3.but2 <- tkbutton(frame3,  textvariable =tclVar("Close"),
                            fg="red", padx = 20, command = bayes.close)
    
    frame3.but3 <- tkbutton(frame3, text = "Apply", padx = 20, command = bayes.init)
    tkgrid(frame3.spacer,sticky="nsew") 
###    tkgrid(frame3.but2, frame3.but3, sticky = "w")
    tkgrid(frame3.but2, sticky = "w")
    tkpack(frame3, fill="x")
    lst <- list(frame=tkbayes)
    return(tkbayes)
}
##
## DESCRIPTION:  Creates the GUI with textboxes for a matrix of nrows and ncols,
##               Each text box is a matrix element. We can give names to
##               the cols with colnames and to the rows with rownamnes. We can pass
##               a matrix to display with defvar and modify its elements in the
##               textboxes of the display; if no argument is passed for defvar
##               it defaults to a matrix of empty strings.
##               We can have a partial view of the matrix
##               The total number of rows is trows and the total number of columns is tcols
##               You may have a partial part of the matrix display by choosing
##               nrows (=vector) < trows and  ncols(=col1:col2) < tcols and
##               begin.col = col1 first column to show ; if no value is given to trows and
##               tcols then default to nrows and ncols. The names for all the  rows 
##               wether they are displayed or not, is townames. The names for all the
##               cols whether they are displayed or not is tolnames.  
##               Example choosing a range of cols for a larger matrix
###    col2 <- trim.blanks(tclvalue(var2))
##    col1 <- ifelse(length(col1) <= 0, 1, as.numeric(col1))
##    col2 <- ifelse(length(col2) <= 0, 12, as.numeric(col2))
##    ncol <- col1:col2
##    if(length(colnames) > 0)
##      colname = colnames[ncol] ## subset for cols names 
##    else
##      colname= NULL
## 
##    defvar <- matrix.display.GUI(base=tktoplevel(),nrows, ncols=ncol, colnames=colname,
##                        defvar =defvar,  begin.col = col1, tcols=ncols,
##                        trows=nrows,  
##                        tolnames=colnames, title = title);
##
## INPUT: columns and rows and their names, matrix defvar to display and modify
##        It may build on a frame or a toplevel.  In the implementation here
##        takes a frame and return a frame and the matrix
##        Make sure to set base to a tkframe
##
##
## VALUE:  returns tkframe, and matrix
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 05/23/2005
## 
## 
## ************************************************************************
## ************************************************************************


matrix.display.GUI <- function(base,nrows, ncols, colnames=NULL,
                      rownames=NULL, defvar = NULL,
                      begin.col = NULL, return.string =T,     
                      tcols=NULL, trows=NULL, tolnames=NULL,
                      townames=NULL, title="Smooth",
                      ptr=parent.frame(), grayout = F, whiterows = 0){

 
  ev <- environment()
  
  if(length(trows) <= 0) ## set all cols = ncols
    trows <- nrows
  
  if(length(tcols) <= 0) ## set all rows = nrows
    tcols <- ncols
  
  if(length(tolnames) <= 0)  ## set total names for cols
    tolnames <- colnames
  
  if(length(townames) <= 0)
    townames <- rownames
  
   if(length(begin.col) <= 0)
    begin.col= 1

  frame0 <- tkframe(base, relief = "groove", borderwidth = 0)
  separator <- tklabel(frame0, textvariable="     ");
  title.lable <- tklabel(frame0, textvariable=tclVar(title));
  tkgrid(title.lable,sticky="e");
  
  if(length(ncols)==1)
    ncols <- 1:ncols
  if(length(nrows) == 1)
    nrows <- 1:nrows

  if(length(defvar) <= 1)
    defvar <- matrix("", nrow=trows, ncol=tcols)
 
 
  lst <- list()
  vname <- matrix(,nrow=trows, ncol=tcols)
   
  count <- 0
  
   for(rr in 1:trows)
     for(cc in 1:tcols)
       { 
      count <- count + 1
      vname[rr, cc] <- paste("var[",rr,",",cc,"]", sep="")
    ##  print(vname[rr, cc])
      var <- tclVar(defvar[rr, cc])
  
      if (count <= 1)
        lst <- list(var)
      else
        lst <- c(lst, list(var))
    
    }

  names(lst) <- vname
  if(length(tolnames) <= 0)
    tolnames <-  unlist(sapply(as.list(1:tcols),
                               function(x) paste("var",x, sep="")))
  
  for(c in ncols)
    {
      frame.lbl <- tklabel(frame0,textvariable=tclVar(tolnames[c]),
                           fg="blue")
      tkgrid(frame.lbl,row = 0, col= c);
    }
  
  if(length(rownames) <= 0)
    rownames <- as.character(nrows)

  for(r in nrows)
    {
      frame.lbl <- tklabel(frame0,textvariable=tclVar(rownames[r]),
                           fg="blue")
      tkgrid(frame.lbl,row = r, col= 0, sticky="w");
    }

  
  lst.frame <- as.list(1:(trows*tcols))
  txt.lst   <- as.list(1:(trows*tcols))
  if(length(defvar) > 0)
    txt.lst <- as.list(as.vector(as.matrix(defvar)))
  ## defvar may be a matrix or data.frame 
  else 
    txt.lst <- lapply(txt.lst, function(x) "")

##  print(txt.lst)
  var.lst <- try(get("var.lst", env=.GlobalEnv), silent=T)
  
  if(class(var.lst) == "try-error")
    {
      var.lst <- list() 
      
      for(i in (1:length(txt.lst)))
        var.lst[[i]] <- tclVar(txt.lst[[i]])
    }

##    var.lst <<- var.lst
 

  count <- (begin.col -1) * trows 

  
  
  for(c in ncols){
    
    for(r in nrows){
      count=count + 1;
      
      interact <-  "disabled"
      colorbg <- "lightgray"
      
      frametmp <- tkframe(frame0,  relief = "groove", borderwidth = 0)
      var <- var.lst[[count]]   
      
        
      lst.frame[[count]] <- tkentry(frame0, textvariable =var.lst[[count]],
                             width=5, bg=colorbg, state= interact)
      
   if( (!is.element(r, whiterows)&& c== 1  && grayout == T ) ||
      (is.element(r, whiterows)) ) 
        {

          interact <- "normal"
          colorbg <- "white"
          tkconfigure(lst.frame[[count]], bg=colorbg, state=interact)
          
        }

      separator <- tklabel(frame0, textvariable="");
###   without separator looks better
###   tkgrid(frame.entry, separator,sticky ="w")
          
      tkgrid(lst.frame[[count]], row=r, col=c, sticky ="w")
      
###      tkgrid(frametmp, row = r, col=c ,sticky="w")
     }
  }
   
  
  frame1 <- tkframe(base)
  
  varbut <- tclVar("Apply")
  available <- T
  turn.on.off <- function(...) {
     ptr <- get("ptr", env=ev)
 ##    cat("first ev...") ; print(ev); cat("follow by ptr...") ; print(ptr)       
    if(available)
      {
        for(i in (1:(trows * tcols))) 
          defvar[i] <- tclvalue(var.lst[[i]])
        
        defvar <- matrix(defvar, nrow=trows, byrow = F)
        assign("defvar", defvar, env=ev)
        assign("defvar", defvar, env=ptr)
        mat <- defvar
        assign("mat", mat, env=ptr)
   
        if(tclvalue(var.lst[[1]]) == "NA" ||
           tclvalue(var.lst[[1]]) == "<NA>"||
           is.na(tclvalue(var.lst[[1]])) ||
           trim.blanks(tclvalue(var.lst[[1]])) == "" )
          {           
            assign("available", F, env=ev)            
            tkconfigure(frame1.but, textvariable=tclVar("OFF"))
              
            count <- (begin.col -1) * trows 
            for(c in ncols){
              for(r in nrows){
                count=count + 1;
                tkconfigure(lst.frame[[count]], bg="grey", state="disabled")}}
          }
      }else{ 
     
        for(i in (1:(trows * tcols))) 
          defvar[i] <- tclvalue(var.lst[[i]])
        
        defvar <- matrix(defvar, nrow=trows, byrow = F)
        assign("defvar", defvar, env=ev)
        assign("defvar", defvar, env=ptr)
        mat <- defvar
        assign("mat", mat, env=ptr)
        tkconfigure(frame1.but, textvariable=tclVar("Apply"))
        available <- T
        assign("available", T, env=ev)
        count <- (begin.col -1) * trows 
        for(c in ncols){
          for(r in nrows){
            count=count + 1;
            tkconfigure(lst.frame[[count]], bg="white", state="normal")}}
      }
  }
                             
  frame1.but <- tkbutton(frame1,  textvariable =varbut, fg="red",
                         padx = 10, command = turn.on.off )                              
                           

  if(return.string == F)
    {
      defvar[trim.blanks(defvar) == ""] <- NA
      defvar <- as.numeric(defvar)
    }
  
  tkgrid(frame1.but)
  tkpack(frame0)
  tkpack(frame1)
 lst <- list(frame=base, mat = defvar, where=ptr)
 
  return(lst)
}

##
## DESCRIPTION:  Creates the GUI with two entry textboxes and two buttons
##               Given a number of rows and columns for a matrix and
##               its elements in defvar, you may choose a range of cols
##               to display by choosing two number in the entry boxes.
##               It then calls matrix matrix.display.GUI with ncols=col1:col2
##               which are the choices of cols from the entry boxes.
##      
##
## INPUT: columns and rows and their names, matrix defvar to display and modify
##      
##
##
## VALUE:  returns tkframe, and matrix after calling matrix.display.GUI
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 05/23/2005
## 
## 
## ************************************************************************
## ************************************************************************

modaldiag <- function(ncols, nrows, colnames, rownames,  
                      defvar, title="Counterfactuals")
{
 
  base   <- tktoplevel()
  tkgrab.set(base)
  tkfocus(base) 
  tkwm.title(base,"Choose variables")
  ev <- environment()
 
  
  frame0 <-  tkframe(base, relief = "groove", borderwidth = 0)
  frame1 <- tkframe(base, relief = "groove", borderwidth = 0)
  frame2 <-  tkframe(base, relief = "groove", borderwidth = 0)
  separator <- tklabel(frame1, textvariable="     ");
  var1 <- tclVar(" ")
  var2 <- tclVar(" ")
  lbl  <- tklabel(frame0, text="Enter range of variables indices");
  frm1.lbl1 <- tklabel(frame1, text="Lower");
  frm1.lbl2 <- tklabel(frame1, text="Upper");
  frm1.entry1 <- tkentry(frame1, textvariable = var1,
                         width = 10, bg="white")
  frm1.entry2 <- tkentry(frame1, textvariable = var2,
                         width = 10, bg="white")
  tkgrid(lbl, sticky="w")
  tkgrid(frm1.lbl1, frm1.entry1, sticky="w")
  tkgrid(frm1.lbl2, frm1.entry2, sticky="w")


  ON.OK <- function(){
    col1 <- trim.blanks(tclvalue(var1))
    col2 <- trim.blanks(tclvalue(var2))
    col1 <- ifelse(length(col1) <= 0, 1, as.numeric(col1))
    col2 <- ifelse(length(col2) <= 0, 12, as.numeric(col2))
    ncol <- col1:col2
    if(length(colnames) > 0)
      colname = colnames[ncol]
    else
      colname= NULL
    ncols <- get("ncols", env=ev)
    base <- tkframe
    lst <- matrix.display.GUI(base=tktoplevel(),nrows, ncols=ncol, colnames=colname,
                        defvar =defvar,  begin.col = col1, tcols=ncols,
                        trows=nrows,  
                        tolnames=colnames, title = title);
    defvar <- lst$mat
    assign("lst", lst, env=ev)
    assign("defvar", defvar, env=ev)
    tkdestroy(base)
    
    
  }
  frame2.but1 <- tkbutton(framze2,  textvariable =tclVar("OK"), fg="blue",
                          padx = 10, command = ON.OK)
  frame2.but2 <- tkbutton(frame2,  textvariable =tclVar("Cancel"), fg="red",
                          padx = 10, command = function() tkdestroy(base))
  tkgrid(frame2.but1, frame2.but2)
  tkpack(frame0)
  tkpack(frame1)
  tkpack(frame2)
  tkwait.window(base)
  return(lst); 
}
expand.char <- function(vector)
      {
        len   <- sapply(vector, nchar)
        lmax  <- max(unlist(len))
        vector <- sapply(vector, function(str){
          nch <- nchar(str)
          pad <- lmax - nch
          if(pad > 0){
            pads <- str
            for(n in 1:pad)
              pads <- paste(" ", pads, sep="")
            }  
          return(str)
        })
        vector <- unlist(vector)
        return(vector)
      }


 convert.data.frame <- function(bayes.mat, row.nm)
       {
       
         if(class(bayes.mat) != "try-error"){
           bayes.mat[trim.blanks(bayes.mat) == ""] <- NA
     
           bayes.mat <- t(bayes.mat)
           print(dim(bayes.mat)); print(bayes.mat)
     ##      print(row.nm)
      ##  colnames(bayes.mat) <- row.nm
     
  ##         print(mat)
           bayes.dat <- data.frame(bayes.mat)
           names(bayes.dat) <- row.nm
         
           print(bayes.dat)
           return(bayes.dat)
         }
       }

 build.display <- function(H.sigma="", H.deriv1="", H.deriv2="",
                           H.age.weight="",H.time.weight="",
                           H.sigma.sd = "", width=5){

      H.lst <- list()
      len <- length(H.sigma)
      blank <- rep(" ", width - len)
      
##      cat("H.sigma   ", all(trim.blanks(na.omit(H.sigma))), "\n")
      if(!all(trim.blanks(na.omit(H.sigma))=="") ){
      ##  print(H.sigma)
        H.sigma.vec <- c(H.sigma, blank)
        H.lst <- c(H.lst, H.sigma = list(H.sigma.vec))}
     
      len <- length(H.deriv1)
      blank <- rep(" ", width - len)
##     cat("H.deriv1   ", all(trim.blanks(na.omit(H.deriv1))), "\n")
      if(!all(trim.blanks(na.omit(H.deriv1))=="")){
       ##   print(H.deriv1)
          H.deriv1.vec <- c(H.deriv1, blank)
          H.lst <- c(H.lst, H.deriv1 = list(H.deriv1.vec))}
      
      len <- length(H.deriv2)
      blank <- rep(" ", width - len)
##     cat("H.deriv2   ", all(trim.blanks(na.omit(H.deriv2))), "\n")
      if(!all(trim.blanks(na.omit(H.deriv2))=="")){
       ##   print(H.deriv2)
          H.deriv2.vec <- c(H.deriv2, blank)
          H.lst <- c(H.lst, H.deriv2 = list(H.deriv2.vec))}
      
      len <- length(H.age.weight)
      blank <- rep(" ", width - len)
      
##    cat("H.age.weight   ", all(trim.blanks(na.omit(H.age.weight))), "\n")
      if(!all(trim.blanks(na.omit(H.age.weight))=="")){
      ##  print(H.age.weight)
        H.age.weight.vec <- c(H.age.weight, blank)
        H.lst <- c(H.lst, H.age.weight = list(H.age.weight.vec))}
      
      len <- length(H.time.weight)
      blank <- rep(" ", width - len)
##   cat("H.time.weight   ",all(trim.blanks(na.omit(H.time.weight))), "\n")
       if(!all(trim.blanks(na.omit(H.time.weight))=="")){
       ##   print(H.time.weight)
          H.time.weight.vec <- c(H.time.weight, blank)
          H.lst <- c(H.lst, H.time.weight = list(H.time.weight.vec))}
      
      len <- length(H.sigma.sd)
      blank <- rep(" ", width - len)
##    cat("H.sigma.sd   ", all(trim.blanks(na.omit(H.sigma.sd))), "\n")
       if(!all(trim.blanks(na.omit(H.sigma.sd))=="")){
        ## print(H.sigma.sd)
         H.sigma.sd.vec <-c(H.sigma.sd, blank)
         H.lst <- c(H.lst, H.sigma.sd = list(H.sigma.sd.vec))}
 ##     print(H.sigma.vec);   print(H.deriv1.vec);   print(H.deriv2.vec)
 ##     print(H.age.weight.vec); print(H.time.weight.vec);
 ##     print(H.sigma.sd.vec)
     
      H.mat <- NULL
      for(el in   H.lst)  {
        
        H.mat <- rbind(H.mat, el)
      }
  ##    print(H.mat);

      rownames(H.mat) <- NULL
      return(H.mat)
    }
