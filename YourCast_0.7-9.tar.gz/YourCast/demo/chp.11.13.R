

chapter11.13 <- function()
{

  message("Example 11.13 Argentina transportation accidents...")
  
  verb <- T
  verb <-   user.prompt(1)
  if(exists("dataobj", inherits=TRUE))
    try(rm(dataobj, inherits=T), silent=T)
  
  trns <- eval(as.symbol(data(trns)))
  gdp <- eval(as.symbol(data(gdp)))
  tobacco <- eval(as.symbol(data(tobacco)))  
  population <- eval(as.symbol(data(population)))
  adjacency <- eval(as.symbol(data(adjacency)))
  cntrycode <- eval(as.symbol(data(cntry.codes)))
  cvec <- c(Argentina=2020, Chile=2120, Canada=2090, Colombia=2130,
            CostaRica=2140, Cuba=2150,USA=2450)
  trns[trns[,"trns"] <= 0.5 & !is.na(trns[,"trns"]),"trns"] <- 0.5
  
  dataobj <<- dataobjWHO(disease=trns, pop=population, cov.REDUCE=gdp, 
                       cov.FULL=NULL,lagyears = 30,  
                       cntry.vec =cvec,nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                       icode="ggggaatttt",proxfile=adjacency,
                       Gnames=cntrycode, selectages=seq(from=15, to=80, by=5), verbose=verb)
     
 
  message("Formula for male transportation accidents and gdp...")
  ff <- log(trns2/popu2) ~ log(gdp) + (time-1900)^2  + time
  print(ff)
  
  message("Running BAYES model...")

  zmean <- c(-8.334608,-7.848482,-7.940896,-8.022037,-8.062267,-8.077525,-8.041380,-8.028983,
             -7.990504, -7.919344, -7.874932, -7.708156, -7.557175, -7.330945)
  names(zmean) <- 3:16*5

  ybayes <- yourcast(formula=ff, dataobj=dataobj, model="bayes",
                     elim.collinear=T,zero.mean=zmean, low.pow=F, nsample=500,
                     Ha.sigma=0.3,Ha.sigma.sd=0, Ht.sigma=1, Ht.sigma.sd=0,Hat.sigma=0.01,
                     Hat.sigma.sd=0,Hct.sigma=0.01,Hct.sigma.sd=0,Hct.t.deriv=c(0,0,1),
                     Ha.deriv=c(0,1),Hat.a.deriv=c(0,1),Ht.deriv=c(0,0,1),
                     Hat.t.deriv=c(0,0,1), verbose=verb)
  message("Generating the graphics for BAYES...")

  yourgraph(ybayes)
  
  }

chapter11.13()
