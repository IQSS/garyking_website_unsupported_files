

chapter11.8 <- function()
{
    message("Dataobj for example 11.8 in the book...")
    message("Disease lung cancer, countries Trinidad and Tobago, Ukraine...")
    user.prompt()
    
    datobj <<- dataobjWHO(disease= c("lung"),
                          cov.FULL= NULL, timeseries=T, lagyears=30,
                          cntry.vec= c(Trinidad.and.Tobago=2440, Ukraine=4303))

   
    message("Formula for male population and lung disease...")
    ff <- log((lung2+0.5)/popu2) ~ time + log(time -1876)
    print(ff)
    message("Running yourcast with model MAP...")
    user.prompt()
    ymap <- yourcast(formula=ff, dataobj=datobj, model="map",
                     Ha.sigma=1.5, Ht.sigma=0.94, Hat.sigma=0.34)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap)
   

  }

chapter11.8()
