

chapter11.3 <- function()
{
    message("Dataobj for examples 11.3 in the book...")
    message("Disease respiratory infections, country Bulgaria, 30 years forecast...")
    user.prompt()
    
    datobj <<- dataobjWHO(disease= c("rspi"),
                          cov.FULL= NULL, timeseries=T, lagyears=30,
                          cntry.vec= c(Bulgaria=4030))

   
    message("Formula for male population and respiratory infections...")
    ff <- log((rspi2 + 0.5)/popu2) ~ time 
    print(ff)
      
    message("Running yourcast with MAP model...")
    user.prompt()
    zmean <- c(-7.474950, -10.391050, -10.745170, -10.511022, -10.450573, -10.321841, -10.066730, 
               -9.721626,  -9.362865,  -8.995520,  -8.607914,  -8.233437,  -7.752187,  -7.240793, 
                -6.626354,  -6.019082,  -4.938154)
    names(zmean) <- 0:16*5
    ymap <- yourcast(model="map", Ha.sigma=0.2, Ht.sigma=NA,Hat.sigma=0.05, zero.mean=zmean)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap)

  }

chapter11.3()
