

chapter11.5 <- function()
{
    message("Dataobj for example 11.5 in the book...")
    message("Disease lung cancer, countries Trinidad and Tobago, Ukraine...")
    user.prompt()
    
    datobj <<- dataobjWHO(disease= c("lung"),
                          cov.FULL= NULL, timeseries=T, lagyears=30,
                          cntry.vec= c(Trinidad.and.Tobago=2440, Ukraine=4303))

   
    message("Formula for male population and lung disease...")
    ff <- log((lung2+0.5)/popu2) ~ time + log(time -1876)
    print(ff)
    message("Running yourcast with model OLS...")
    user.prompt()
    yols <- yourcast(formula=ff, dataobj=datobj)
    
    message("Generating the graphics for OLS...")
    user.prompt()
    yourgraph(yols)
   

  }

chapter11.5()
