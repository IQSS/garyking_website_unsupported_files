

chapter11.7 <- function()
{
    message("Dataobj for example 11.7 in the book...")
    message("Disease lung cancer, countries Mauritius, Peru...")
    user.prompt()
    
    datobj <<- dataobjWHO(disease= c("lung"),
                          cov.FULL= NULL, timeseries=T, lagyears=30,
                          cntry.vec= c(Mauritius=1300, Peru=2370))

    message("Formula for male population and lung disease...")
    ff <- log((lung2 + 0.5 )/popu2 ) ~ time + log(time -1876)
    print(ff)
    message("Running yourcast with model MAP...")
    user.prompt()
    ymap <- yourcast(formula=ff, dataobj=datobj, model="map", Ha.sigma=1.5, Ht.sigma=0.94, Hat.sigma=0.34)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap)
   
    
  }

chapter11.7()
