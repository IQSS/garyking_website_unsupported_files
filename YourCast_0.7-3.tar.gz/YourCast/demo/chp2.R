

chapter2 <- function()
  {
    message("Examples 2.6-2.7 in the book...")

    message("Dataobj for male all causes, and countries New Zeland and Hungary")
    user.prompt()
    datobj <<- dataobjWHO(disease= "allc", cov.FULL= NULL,
                              timeseries=T, lagyears=60,
                              cntry.vec= c(NewZeland=5150, Hungary=4150))

    message("formula...")
    fallc <- log(allc2/popu2 + 5.e-5) ~ time
    print(fallc)
    
    message("Running yourcast with model LC...")
    user.prompt()
    yallc <- yourcast(formula=fallc, dataobj=datobj, model="LC")
    message("Running yourgraph..") 
    user.prompt()
    yourgraph(yallc)
   
    message("Dataobj for male suicide, and USA ...")
    user.prompt()
    datobj <<- dataobjWHO(disease= "suic", cov.FULL= NULL,
                          timeseries=T, lagyears=60,
                          cntry.vec= c(USA=2450))

    message("formula...")
    fsuic <- log(suic2/popu2 + 5.e-5) ~ time
    print(fsuic)
    message("Running yourcast with model LC...")
    user.prompt()
    ysuic <- yourcast(formula=fsuic, dataobj=datobj, model="LC")
    message("Running yourgraph..") 
    user.prompt()
   
    yourgraph(ysuic)
    
    message("Dataobj for female digestive disease, and Hungary...\n")
    user.prompt()
    datobj  <<- dataobjWHO(disease= "dgst", cov.FULL= NULL,
                           timeseries=T, lagyears=60,
                           cntry.vec= c(Hungary=4150))
    message("formula...")
    fdgst <- log(dgst3/popu3 + 5.e-5) ~ time
    print(fdgst)
    
    message("Running yourcast with model LC...\n")
    user.prompt()
    ydgst <- yourcast(formula=fdgst, dataobj=datobj, model="LC")
    message("Running yourgraph..") 
    user.prompt()
    yourgraph(ydgst)
    
    message("Dataobj for female cervix cancer, and United Kingdom...")
    user.prompt()
    datobj <<- dataobjWHO(disease= "cerv", cov.FULL= NULL,
                          timeseries=T, lagyears=60,
                          cntry.vec= c(UnitedKingdom=4308))
    message("formula...")
    fcerv <- log(cerv3/popu3 + 5.e-5) ~ time
    print(fcerv)
   
    message("Running yourcast with model LC...")
    user.prompt()
    ycerv <- yourcast(formula=fcerv, dataobj=datobj, model="LC")
    message("Running yourgraph..") 
    user.prompt()
    yourgraph(ycerv)
    
    message("Dataobj for male transportation accidents, and Portugal...\n")
    user.prompt()
    datobj <<- dataobjWHO(disease= "trns", cov.FULL= NULL, timeseries=T, lagyears=60, cntry.vec= c(Portugal=4240))
    message("formula...")
    ftrns <- log(trns2/popu2 + 5.e-5) ~ time
    print(ftrns)
   
    message("Running yourcast with model LC...")
    user.prompt()
    ytrns <- yourcast(formula=ftrns, dataobj=datobj, model="LC")
    message("Running yourgraph..") 
    user.prompt()
   
    yourgraph(ytrns)

  }


chapter2()
