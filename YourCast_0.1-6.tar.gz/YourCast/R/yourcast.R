##
## DESCRIPTION:  The driver for the simulation, which the user calls with his choice
##               of parameters or globals that initializes the simulation, and the
##               model for the predictions. We save two nevironmnets, the
##               env.base created inside mortality.driver, and env.who created by
##               the initialization file WHO(). The globals or static variables
##               are shared by all the functions. 
##               It reads system file and function WHO() with input globals.
##               Check for the arguments of mortality.driver, to see if the users 
##               has input a file (userfile) with his choices of parameters or globals.
##               It also checks if any of globals has been changed with the args of mortality.driver
##               Updates env.who with the input globals, if any and then runs the simulatio.
##               If the same data or globals is stored in a system file with who.reuse.data=T
##               uploads those results, without preprocessing any data. Otherwise calls
##               make.mortality.data().
##               It chooses the model to forecast with whomodel from env.who
##               Produces the forecast output and plots it with plot.forecast.
##               Output forecast object is saved into a file with who.save.output=T
##               
##                 
## FORMAT: yourcast(userfile="myfile.R",whogender=3, whousercntrylist=... ) 
##
## VALUE:  The forecast object and the graphics
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 11/12/2003
## 
## 
## ************************************************************************
## ************************************************************************

yourcast <- function(userfile=NULL, debug = F, env.who = NULL,
                     depvar=NULL, allcauses = NULL,population=NULL, codes.names= NULL, 
                     strata=NULL,cov=NULL,cov.type=NULL,fore=NULL,yrest=NULL,
                     lag=NULL,usercntrylist=NULL,cov.select=NULL,cntry.digits=NULL, 
                     year.digits=NULL,digit.first=NULL,age.digits=NULL,age.select=NULL, 
                     lag.cutoff=NULL,skip=NULL, userages=NULL, reuse.data=NULL, 
                     save.output=NULL,save.FULL = NULL,reuse.path=NULL,
                     model=NULL, standardize=NULL,elim.collinear=NULL,transform=NULL,
                     data.path=NULL, cov.path=NULL,prior.path= NULL,out.path = NULL,  
                     tol=NULL, delta.tol =NULL, solve.tol = NULL, svdtol=NULL, zero.mean=NULL, 
                     Ha.deriv=NULL, Ha.age.weight=NULL, Ha.time.weight=NULL,
                     Ha.sigma=NULL, Ha.sigma.sd= NULL, Hat.a.deriv=NULL,
                     Hat.t.deriv=NULL, Hat.age.weight=NULL,
                     Hat.time.weight=NULL, Hat.sigma=NULL, Hat.sigma.sd=NULL,
                     Ht.deriv=NULL, Ht.age.weight=NULL,
                     Ht.time.weight=NULL,Ht.sigma=NULL, Ht.sigma.sd=NULL,
                     Hct.t.deriv=NULL , Hct.time.weight = NULL, Hct.c.deriv =NULL,
                     Hct.sigma=NULL, Hct.sigma.sd = NULL, LI.sigma.mean=NULL,
                     LI.sigma.sd = NULL, nsample= NULL)
{
    ### some tidy up and initialization 
try(rm(env.base, env.who, inherits=T), silent=T);
results.path <- paste(getwd(), "/OUTPUT", sep="" )
input.path <- paste(getwd(), "/INPUT", sep="" )

if (!file.exists(results.path)){
  print("Creating directory  OUTPUT/ in your working directory"); 
  dir.create(path=results.path); }

if (!file.exists(input.path)){
  print("Creating directory  INPUT/ in your working directory"); 
  dir.create(path=input.path); }

##signaling if yourcast.GUI is driving the simulation
guirun <- T
### I'm defining base environment
env.base <- environment();
### for debug = T then make it availabel as global
 if(debug){
   print("Setting to mode debugging with the global env.base")
  env.base <<- env.base}

##****************
### check if the user has provided for any input with reflection
### give the name of the driver and call for the simulation
driver <- match.call()
driver <- as.character(driver)
### name of the calling function 
mortality.driver <- driver[1]
### give me its arguments
args  <- names((formals(mortality.driver)));
### for library only
### System file with default input parameters or globals:
if(identical(.GlobalEnv, parent.frame()) || length(env.who) <= 0)
  {
    guirun <- F ## this is not a GUI call
    env.who <- namelists();
  }
 
assign("env.who", env.who, env=env.base)   
whoind <- 1
whoind <- grep("userfile", args)
###***************
### First, we check if the user has provided for an input file
### either in the user working space or any directory
args1 <-  try(eval(as.symbol(args[whoind])), silent=T)
if (class(args1) != "try-error" && !is.null(args1)){
    cat("Updating global with the user file parameters\n")
    update.WHO(args);}

###***************
### Second, check for the rest of the input args of mortality.driver:
f.vec <- 1:length(args)
dind <- 2
gind <- 3
if(length(debug) > 0)
  dind <- grep("debug", args)
if(length(env.who) > 0)
  gind <- grep("env.who", args)

totindx <- c(whoind, dind, gind)

if(length(totindx) > 0)
  f.vec <- f.vec[-totindx]

## calling from yourcast with args (not a GUI call)
if (!guirun){
for(i in f.vec ){
  val <- try(eval(as.symbol(args[i])), silent=T)
  
  val <- unlist(val, recursive=T)
  if( class(val) != "try-error" && !is.null(val) ){
    cat("Updating globals with args of yourcast\n")
    args.mortality.driver(args);
   
    break; }
}
}
 
##******************
##

env.who <- WHO(env.base)
setWHO(env.who);

who.reuse.data <- get("who.reuse.data", env = get("env.who", env = env.base));
whomodel <- get("whomodel", env = get("env.who", env = env.base));
who.save.output <- get("who.save.output", env= get("env.who", env = env.base));

if (who.reuse.data == TRUE)
  who.reuse.data <- reuse.data2();
if(who.reuse.data == FALSE)
  make.mortality.data();


### if whomodel is NA (no choice), the program will only output
### the preprocessing results of make.mortality.data
  
  if (!is.character(whomodel) || trim.blanks(whomodel) == "") {
    print("Created data, no forecast produced");
    lst.output <- mortality.data();
    lst.output <- conversion.cntry.mat(obj=lst.output)
### we are not saving the preprocessing output since
### it has already being saved with make.mortality.data
    return(invisible(lst.output));}
 
  m <- switch(whomodel, OLS=ols(env.base),LC=lc(),POISSON=glm.poisson(),MAP=cxc(),
              BAYES=gibbs.sampler(), whomodel="", NULL);
  if (is.null(m))
    stop(paste("Model ",whomodel," is not available"));
### m contains obj= yhatin, yhatout, insampy, outsampy but listed with csid
### conversion.cntry.mat uses list.by.cntry to convert into country list matrices
### so it is a more useful format for the graphics output.  
    m <- conversion.cntry.mat(m); 
  if(who.save.output == T && !is.na(whomodel)){
    print("Saving the forecasting object into a file")
    build.file.output();}

  return(invisible(m));

}

