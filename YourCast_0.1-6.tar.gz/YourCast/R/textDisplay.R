## to run showCovs
textDisplay <- function(dataframe, flag=F){
  base <- tktoplevel()
  frame1 <- tkframe(base, relief = "groove", borderwidth = 2)
  frame1 <- showCovs(dataframe, base=frame1)
  tkpack(frame1)
  if(flag){
  dataframe <- as.data.frame(matrix(1:200, nrow=20))
  tkdestroy(frame1)
  frame1 <- tkframe(base, relief = "groove", borderwidth = 2)
  frame1 <- showCovs(dataframe, base=frame1)
  tkpack(frame1)}
  return(environment())}
##
## DESCRIPTION:  Creates the GUI with textbox area to display the data of the dataframe
##               Adapted from the limp package on R web public packages.  
##               It has a header (hdr) and a footer Ftr) and two more text areas to display
##               data and row names for dataframe.  Scrolls are also availabel for large data set.
##                 
## FORMAT: showCovs(dataframe, base, textvalues).  Here dataframe is data to display and
##           base is the tktoplevel container or a tkframe to build the GUI
##           and textvalues are character strings with the texts for each of the five entry boxes.
##
## VALUE:  a tkframe which needs to be included within a major (tktoplevel)
##         container if it is a frame,i.e. base, or possibly the toplevel container.
##
## WRITTEN BY: Elena Villalon after the R code on the web 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************


showCovs <- function (dataframe, base=tktoplevel(),
                      colname.bgcolor = "royalblue",
                      rowname.bgcolor = "grey90", body.bgcolor = "white",
                      colname.textcolor = "white",
                      rowname.textcolor = "darkred", 
                      body.textcolor = "black", font = "Courier 12",
                      maxheight = 10, maxwidth = 80,
                      title = NULL, rowname.bar = "left",
                      colname.bar = "top", titletext= "", 
                      titlename.bgcolor = "green", pos.text = "insert", 
                      titlename.textcolor ="darkred", 
                      rownumbers = FALSE, placement = "-20-40",
                      vechar = NULL, footer = F,
                      footerentry="", footertext="")
{
    
    object.name <- deparse(substitute(dataframe))
    if (!is.data.frame(dataframe)) 
        stop(paste(object.name, "is not a data frame"))
    if (is.numeric(rownumbers) && length(rownumbers) != nrow(dataframe)) 
        stop("Error:textdisplay")
    
    require(tcltk) || stop("Tcl/Tk support is absent")
    oldwidth <- options()$width
    options(width = 10000)
    conn <- textConnection("zz", "w")
    sink(conn)
    print(dataframe)
    sink()
    close(conn)
    options(width = oldwidth)
    
    nrows <- length(zz) - 1
    if (is.numeric(rownumbers)) 
        rowname.text <- paste(rownumbers, row.names(dataframe))
    else if (rownumbers) 
        rowname.text <- paste(1:nrows, row.names(dataframe))
    else
      rowname.text <- row.names(dataframe)
    namewidth <- max(nchar(rowname.text))
    widthtitle <- max(nchar(titletext))
    if(footer){
      widthtitle <- max(c(nchar(footerentry), widthtitle))
      titletext <- c(titletext, footerentry)
    }
    if (length(vechar) <= 0)
      namewidth <- max(namewidth,widthtitle)
    else{
      namewidth <- max(namewidth, vechar)
      namewidth <- max(namewidth,widthtitle)
    }
    
    yy <- substring(zz, 2 + max(nchar(row.names(dataframe))))
    rm(zz, envir = .GlobalEnv)
    datawidth <- max(nchar(yy))
    if(footer)
      datawidth <- max(datawidth, nchar(footertext))
    
    winwidth <- min(1 + datawidth, maxwidth)
    hdr <- tktext(base, bg = colname.bgcolor, fg = colname.textcolor, 
        font = font, height = 1, width = winwidth)
    if(footer){
      colname.bgcolor <- body.bgcolor
      colname.textcolor <- "black"}
    ftr <- tktext(base, bg = colname.bgcolor, fg = colname.textcolor, 
        font = font, height=1, width = winwidth)
    
    textheight <- min(maxheight, nrows)
    txt <- tktext(base, bg = body.bgcolor, fg = body.textcolor, 
        font = font, height = textheight, width = winwidth, setgrid = 1)
    lnames <- tktext(base, bg = rowname.bgcolor, fg = rowname.textcolor, 
        font = font, height = textheight, width = namewidth)
    rnames <- tktext(base, bg = rowname.bgcolor, fg = rowname.textcolor, 
        font = font, height = textheight, width = namewidth)
    tnames <- tktext(base, bg = titlename.bgcolor,
                     fg = titlename.textcolor, 
                font = font, height = 1, width = namewidth)
    footernames <- tktext(base, bg = rowname.bgcolor, fg = rowname.textcolor, 
        font = font, height = 1, width = namewidth)
    
    xscroll <- tkscrollbar(base, orient = "horizontal", repeatinterval = 1, 
        command = function(...) {
            tkxview(txt, ...)
            tkxview(hdr, ...)
            tkxview(ftr, ...)
        
        })
    string.to.vector <- function(string.of.indices) {
        string.of.indices <- tclvalue(string.of.indices)
        as.numeric(strsplit(string.of.indices, split = " ")[[1]])
    }
    tkconfigure(txt, xscrollcommand = function(...) {
        tkset(xscroll, ...)
        xy <- string.to.vector(tkget(xscroll))
        tkxview.moveto(hdr, xy[1])
        tkxview.moveto(ftr, xy[1])
       
    })
    tkconfigure(hdr, xscrollcommand = function(...) {
        tkset(xscroll, ...)
        xy <- string.to.vector(tkget(xscroll))
        tkxview.moveto(txt, xy[1])
        tkxview.moveto(ftr, xy[1])
       
    })
    tkconfigure(ftr, xscrollcommand = function(...) {
        tkset(xscroll, ...)
        xy <- string.to.vector(tkget(xscroll))
        tkxview.moveto(hdr, xy[1])
        tkxview.moveto(txt, xy[1])
       
    })
    yscroll <- tkscrollbar(base, orient = "vertical", repeatinterval = 1, 
        command = function(...) {
          tkyview(txt, ...)
          tkyview(lnames, ...)
          tkyview(rnames, ...)
       
        })
    tkconfigure(txt, yscrollcommand = function(...) {
        tkset(yscroll, ...)
        xy <- string.to.vector(tkget(yscroll))
        tkyview.moveto(lnames, xy[1])
        tkyview.moveto(rnames, xy[1])       
    })
   tkconfigure(lnames, yscrollcommand = function(...) {
        tkset(yscroll, ...)
        xy <- string.to.vector(tkget(yscroll))
        tkyview.moveto(txt, xy[1])
        tkyview.moveto(rnames, xy[1])
       
    })
    tkconfigure(rnames, yscrollcommand = function(...) {
        tkset(yscroll, ...)
        xy <- string.to.vector(tkget(yscroll))
        tkyview.moveto(txt, xy[1])
        tkyview.moveto(lnames, xy[1])
   })
    tkbind(txt, "<B2-Motion>", function(x, y) {
        tkscan.dragto(txt, x, y)
    })
    tktag.configure(hdr, "notwrapped", wrap = "none")
    tktag.configure(ftr, "notwrapped", wrap = "none")
    tktag.configure(txt, "notwrapped", wrap = "none")
    tktag.configure(lnames,"notwrapped", wrap = "none")
    tktag.configure(rnames, "notwrapped", wrap = "none")
    tkinsert(txt, "end", paste(paste(yy[-1], collapse = "\n"), 
        sep = ""), "notwrapped")

    tkgrid(txt, row = 1, column = 1,  sticky = "nsew")
    if ("top" %in% colname.bar) {
        tkinsert(hdr, pos.text, paste(yy[1], sep = ""), "notwrapped")
        tkgrid(hdr, row = 0, column = 1, sticky = "ew")
    }
    if ("bottom" %in% colname.bar) {        
        tkinsert(ftr, "end", footertext,"notwrapped")
        tkgrid(ftr, row = 2, column = 1, sticky = "ew")
    
      }
    if ("left" %in% rowname.bar) {
        tkinsert(lnames, "end", paste(rowname.text, collapse = "\n"), 
            "notwrapped")
       
        tkinsert(tnames, "end", paste(titletext, collapse = "\n"), 
            "notwrapped")
       
        tkgrid(tnames,row=0,column=0,sticky="ns")
        tkgrid(lnames, row = 1, column = 0, sticky = "ns")
        if(footer){
          tkinsert(footernames,"end", footerentry, collapse="\n", "notwrapped")
          tkgrid(footernames, row=2, column=0, sticky="ns")}
    }
    if ("right" %in% rowname.bar) {
        tkinsert(rnames, "end", paste(rowname.text, collapse = "\n"), 
            "notwrapped")
        tkgrid(rnames, row = 1, column = 2, sticky = "ns")
    }
    tkconfigure(hdr, state = "disabled")
    tkconfigure(ftr, state = "disabled")
    tkconfigure(txt, state = "disabled")
    tkconfigure(lnames, state = "disabled")
    tkconfigure(rnames, state = "disabled")
    tkconfigure(footernames, state = "disabled")
    
    if (maxheight < nrows) {
        tkgrid(yscroll, row = 1, column = 3, sticky = "ns")
    }
    if (maxwidth < datawidth) {
        tkgrid(xscroll, row = 3, column = 1, sticky = "ew")
    }
    tkgrid.rowconfigure(base, 1, weight = 1)
    tkgrid.columnconfigure(base, 1, weight = 1)

    return(base)
}

