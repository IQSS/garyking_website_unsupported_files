


chapter11.13 <- function()
{

  message("Example 11.13 Argentina...")
 
  message("Formula for male population...")
  ff <- log((trns2+ 0.5)/popu2) ~ log(gdp) + time^2
  print(ff)
  
  message("Dataobj for transportation accidents...")
  user.prompt()
  cvec <- c(Argentina=2020, Chile=2120, Canada=2090, Colombia=2130,
            CostaRica=2140, Cuba=2150,USA=2450) 
  datobj <- dataobjWHO(disease="trns", cov.FULL= c("FULL.gdp"), 
                            timeseries=T, lagyears=30,
                            cntry.vec=cvec, 
                            selectages=seq(from=15, to=80, by=5))
   
  datrns <<- datobj

  message("Running BAYES model...")
  user.prompt()
  zmean <- c(-8.334608,-7.848482,-7.940896,-8.022037,-8.062267,-8.077525,-8.041380,-8.028983,
             -7.990504, -7.919344, -7.874932, -7.708156, -7.557175, -7.330945)
 names(zmean) <- 3:16*5
             
  ymap <- yourcast(formula=ff, dataobj=datrns, model="bayes",
                   elim.collinear=FALSE,zero.mean=zmean,  
                   Ha.sigma=1.5, Ht.sigma=0.94, Hat.sigma=0.34,
                   Ha.deriv=c(0,1,0),Hat.a.deriv=c(1,0))
  message("Generating the graphics for BAYES...")
  user.prompt()
  yourgraph(ymap)

  }

chapter11.13()
