


chapter11.11 <- function()
{

  message("Examples 11.11 Chile, Angertina...")
 
 
  message("Formula for male population...")
  ff <- log((trns2+ 0.5)/popu2) ~ log(gdp) + time^2
  print(ff)
  
  message("Dataobj for transportation accidents...")
  user.prompt()
  
  datobj <- dataobjWHO(disease="trns", cov.FULL= c("FULL.gdp"), 
                            timeseries=T, lagyears=30,
                            cntry.vec=c(Chile=2120, Argentina=2020),
                            selectages=seq(from=15, to=80, by=5))
   
  datrns <<- datobj

  message("Running yourcast with OLS model...")
  user.prompt()
  yols <- yourcast(formula=ff, dataobj=datrns, model="OLS",elim.collinear=FALSE)
  message("Generating the graphics for OLS...")
  yourgraph(yols)

  }

chapter11.11()
