


chapter11.10 <- function()
{
 
  message("Examples 11.10 Chile, Cuba, Belgium, Netherlands...")
 
 
  message("Formula for female population...")
  ff <- log((brst3 + 0.5)/popu3) ~ log(hc) + log(gdp) + log(tobacco3) + log(fat) + time
  print(ff)
  
  message("Dataobj for breast cancer...")
  user.prompt()
  
  dat <- dataobjWHO(disease="brst", cov.FULL= c("FULL.hc","FULL.gdp", "tobacco", "FULL.fat"), 
                            timeseries=T, lagyears=30,
                            cntry.vec=c(Chile=2120, Cuba=2150, Belgium=4020,Netherlands=4210),
                            selectages=seq(from=25, to=80, by=5))
   
  datbrst <<- dat
  z.mean <- c(-11.391495,-10.147588, -9.305023, -8.692574, -8.232481, -7.953798, -7.798399,
              -7.678475, -7.577912, -7.433581,-7.293615, -6.926301)
  names(z.mean) <- 5:16*5
  message("Running yourcast with MAP model...")
  user.prompt()
  ymap <- yourcast(formula=ff, dataobj=datbrst, model="map",elim.collinear=FALSE,
                   Ha.sigma=1.5, Ht.sigma=0.94, Hat.sigma=0.34, zero.mean=z.mean)
  message("Generating the graphics for MAP...")
  yourgraph(ymap)

  }

chapter11.10()
