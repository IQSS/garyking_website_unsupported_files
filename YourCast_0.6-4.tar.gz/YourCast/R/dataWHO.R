### DESCRIPTION :
###               Takes the files WHO and builds element data of list dataoj, i.e. dataobj$data.
###               The object output (i.e. dataobj$data) is also a list whose elements are
###               csid (cross-sectional-time-series). The list elements of the ouput object
###               are named after the csid (or country+age combination), say "245045", 
###               for country US ("2450") and age group 45.  Every element is a matrix
###               which columns are either diseases, populations, or covariates.
###               The columns names are the covariates' names,
###               diseases names and "popu" for population.
###               Gender is appended to the name of the disease for each column in the matrix
###               such as "allc2", "allc3" for males and females,
###               and "popu2", "popu3" and "tobacco2", "tobacco3";
###               gender independent covariates are represented as it "gdp"; 
###               The total number of list elements
###               is the number of cross sectional time series units; i. e.,
###               191 x 17 = 3247 for 191 countries and 17 age groups.
###               Optionally if cntry.vec is not null then instead of returning a list
###               with all countries, only the countries in cntry.vec will be in the return object.
###               Similarly, if nobvs is non-null then a subset of countries will be included
###               in the return data object.  Those countries that has number of disease or death
###               observations and population observations greater than or equal to nobvs.
###
### INPUT:
###       datapath, the name of the directory with the files or links to the WHO files; 
###       disease, a vector with all the death causes from WHO files; 
###       pop, a string with population which values are given for all csid and two genders
###       cov.FULL, vector including covariates tobacco, and others gender, age independent covariates; 
###                 gender,age independent covs are in the FULL.cov version; 
###       lagyears, an optional parameter to advance covariates number of years.
###       timeseries, logical to append the observation years  to the data on covariates and disease.
###       cntry.vec, vector to select specific countries frm the dataset
###       nobvs,number of observations to select countries that have number of death observations >= nobvs 
###       covs.single, vector with names of covariates to exclude when counting observations
###       selectages a numeric vector, with ages groups selected or NULL (default) for all ages
###       Default values for the arguments are all the WHO files in datapath.
###
### CALL
###     datawho()
###     datawho(disease=c("allc", "cerv", "cvds"), lagyears=30)
###     datawho(disease=c("allc", "cerv", "cvds"), pop=NULL, cov.FULL=c("FULL.gdp", "tobacco"), timeseries=T)
###     datawho(disease=NULL, cov.FULL=c("FULL.gdp", "tobacco"))
###     datawho(disease=NULL, pop=NULL, cov.FULL=c("FULL.gdp", "tobacco"))
###     datawho(disease=c("livc", "malr"), cov.FULL=NULL)
###     datawho(disease="lung2", lagyears=30, timeseries=T, selectages=seq(from=30, to=80, by=5))
###     When one of the argumnets, disease, pop, cov.FULL are set to NULL, none
###     of the corresponding files will be included in the output object
###
### OUTPUT a list with as many elements as csid units
###        (i.e., 3247 list elements or a subset of them if either cntry.vec or nobvs are non-null)
###        Names of list elements are csid identifiers
###        Elements are matrices with two columns for each disease, population
###       for genders 2 and 3.  Two columns for tobacco, and one column for each of
###       the covariates that are not gender dependent.
###
### USES: disease.WHO, buildcovs.WHO, checkerrors.WHO, joindthcov.WHO, lagcovariates.WHO,
###       selectcntry.WHO, countobvs.WHO, processnolag.WHO
###
### AUTHOR: Elena Villalon
###         IQSS, Harvard University
###         evillalon@iq.harvard.edu
###         March 20th, 2006
###
#########################################################################################################


datawho <- function(datapath="~/INPUT/", disease = c("aids","allc", "allo", "brst", "cerv",
                                           "cvds", "dgst", "homi", "livc", "lung", "malr",
                                           "matc", "molp", "omal", "otin", "pern", "rspc",
                                           "rspi", "stom", "suic", "trns", "tubr","unin","ward"),
                    pop= "population",
                    cov.FULL= c("FULL.fat", "FULL.gdp", "FULL.hc", "FULL.tfr", "tobacco"),
                    lagyears = 0, timeseries=FALSE,
                    cntry.vec = NULL, nobvs=NULL, covselect.WHO=seq(0,10, 5), selectages=NULL)
  {
    
    if(length(disease) <= 0 && length(pop) <= 0 && length(cov.FULL) <= 0)
      stop("No data available")
### the number of digits for country, age and years    
    cdigits <- 4
    adigits <- 2
    ydigits <- 4
    covs.single <- cov.FULL
    ix <- grep("FULL", cov.FULL)
    if(length(ix) > 0){
      covs.s <- sapply(cov.FULL[ix], substring, 6)
      covs.single[ix] <- covs.s
    }
   
    covs.single <- unlist(covs.single)
    
### list of disease and population for csid and two genders     
    alldths <- disease.WHO(datapath, disease, pop)
### list of covariates for each csid and all cov.FULL and  two genders  
    allcovs <- buildcovs.WHO(datapath, cov.FULL)
    
    if(length(allcovs) >0 && length(alldths)<= 0){
      cstid <- allcovs[[1]][,1]
      dd <- cdigits + adigits + 1
      years <- as.numeric(substring(cstid, dd))
    }
    if(length(allcovs) <= 0 && length(alldths) > 0){
       cstid <- alldths[[1]][,1]
       dd <- cdigits + adigits + 1
       years <- as.numeric(substring(cstid, dd))
     }
    
### checking for errors: cross sectional time series must be identical
    ind <- NULL
    if(length(alldths) >0 )
      ind <- 1:length(alldths)
 
    if(length(ind) > 0 && length(cov.FULL) > 0)
        ix <- lapply(ind, FUN="checkerrors.WHO", alldths, allcovs)
  
    if(lagyears <0){
      cat("Setting lagyears = 0", "\n")
      lagyears <- 0
    }
    
 ### no lag of covariates
    
    if(lagyears <= 0){
      
      datalst <- processnolag.WHO(alldths, allcovs, timeseries,lagyears, years,
                                  cntry.vec, nobvs, covs.single, cov.FULL,
                                  covselect.WHO)
    if(length(selectages) <= 0)
      return(datalst)
    else
      return(datalst <- selectagesWHO(datalst, age.vec=selectages))
    }
  
    
  
### lagyears > 0, lag the covariates    
### add NA's for each element of list for alldths
### according to lagyears to match the lag of covariates
    if(length(pop) > 0)
      nc <- 2 * length(disease) + 2
    else
       nc <- 2 * length(disease)
 
    ln <- nc * lagyears
    lagdeath <- rep(NA, ln)
    
    if(length(alldths) > 0){
 
      lagdeath <- matrix(lagdeath, ncol=nc)
      onedth <- alldths[[1]]
      lastyear <- as.numeric(rownames(onedth)[nrow(onedth)])
      vyears <- (lastyear+1):(lastyear+lagyears)
      rownames(lagdeath) <- vyears
      alldths <- lapply(alldths, function(mat){
            ###          print(ncol(mat[,-1]))
            ###          print(ncol(lagdeath))
        rbind(as.matrix(mat[,-1]), lagdeath)})
      
    } ###if(length(alldths) > 0)
    
 ### lag each element list for all covs
    if(length(allcovs) <=0)
      {
        datalst <- joindthcov.WHO(alldths, allcovs, timeseries, lagyears, years)
        if(length(cntry.vec) > 0)
          datalst <- selectcntry.WHO(cntry.vec, datalst)

        if(length(nobvs) > 0)
          datalst <- countobvs.WHO(nobvs, datalst, covs.single)
        
        indcov <- 1:length(datalst)
        names(indcov) <- names(datalst)
        csidwho <- names(datalst)
       
        datalst <- lapply(indcov, FUN="agesexclude.WHO", datalst, csidwho, covselect.WHO)
        if(length(selectages) <= 0)
          return(datalst)
        else
          return(datalst <- selectagesWHO(datalst, age.vec=selectages))
      
     }
      
    
    nc <- ncol(allcovs[[1]]) -1
  
    ln <- nc * lagyears
    lagcovs <- rep(NA, ln)
    lagcovs <- matrix(lagcovs, ncol=nc)
    ind <- 1:length(allcovs)
    names(ind) <- names(allcovs)
    allcovs <- lapply(ind, FUN="lagcovariates.WHO", allcovs, lagcovs)
       
 ### join diseases and cov.FULL
    datalst <- joindthcov.WHO(alldths, allcovs, timeseries, lagyears, years)
    if(length(cntry.vec) > 0)
      datalst <- selectcntry.WHO(cntry.vec, datalst)

    if(length(nobvs) > 0)
      datalst <- countobvs.WHO(nobvs, datalst, covs.single)
    
    indcov <- 1:length(datalst)
    names(indcov) <- names(datalst)
    csidwho <- names(datalst)
    datalst <- lapply(indcov, FUN="agesexclude.WHO", datalst, csidwho, covselect.WHO)
    if(length(selectages) <= 0)
      return(datalst)
    else
      return(datalst <- selectagesWHO(datalst, age.vec=selectages))  
    
  
  }

### Error checking for datawho.  The cross sectional time series must be identical for
### covariates and deaths otherwise stop the program
### INPUT: index entry n, and the lists of covaraites and diseases


 checkerrors.WHO <- function(n, alldths, allcovs)
{
  mad <- alldths[[n]]
  rownames(mad) <- NULL
  mac <- allcovs[[n]]
  rownames(mac) <- NULL
  if(!identical(mad[,1], mac[, 1]))
    stop("matrices of covariates and diseases differents csid")
  
  return(n)
}
### Helper function to datawho. It lags the covariates by appending
### the matrix lagcovs whose entries are  NA's to the elemenst of allcovs
### INPUT: the index number m, list of covariates and lagcovs a matrix. 

lagcovariates.WHO <- function(m, allcovs, lagcovs)
  {
    mat <- allcovs[[m]]
    nm <- colnames(mat)
    nm <- as.vector(nm[-1])
      
    if(ncol(mat) > 2){
      mat <- as.matrix(rbind(lagcovs, mat[,-1]))
    }else{
      vec <- mat[,-1]
      mat <- matrix(vec, ncol=1)
      mat <- matrix(rbind(lagcovs, mat))
      colnames(mat) <- nm
    }
    return(mat)
  }

### DESCRIPTION takes list alldths, allcovs and bind them together for each csid; 
###             rownames for each matrix element is the time series years
###
### INPUT the lists of diseases, alldths,  for every csid
###       the list of covariates, allcovs, for every csid
###       times a logical to include time series years as one of the columns
###       ly number of years to lag covariates; years the observation time series for files WHO
###
### OUTPUT a list of elements csid combining all covariates and diseases from alldths, allcovs
###        and appending time series if times = T
###
### USES: shapelst.WHO, elimallna.cols 
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
#####################################################################################

joindthcov.WHO <- function(alldths, allcovs, times=T, ly, years)
  {
    ind <- NULL
    datalst <- allcovs
    
    if(length(alldths) > 0)
      {
        ind <- 1:length(alldths)
        names(ind) <- names(alldths)
    
        datalst <- lapply(ind, function(n){
          if(length(alldths) >0)
            mat.dth <- alldths[[n]]
          else
            mat.dth <- NULL
          if(length(allcovs) >0)
            mat.cov <- allcovs[[n]]
          else
            mat.cov <- NULL
          
          mat <- cbind(mat.dth, mat.cov)})
      }
  
     if(length(alldths) <= 0)
       {
         datalst <- lapply(datalst, function(mat) {
           lay <- years[length(years)]
           mat <- as.matrix(mat)
          
           if(ly > 0) 
             rownames(mat) <- years[1]:(lay+ly)
           else
             rownames(mat) <- years
           return(mat)
         })
       }
### remove all NA's for columns years < 1950
    
    datalst <- lapply(datalst, FUN="shapelst.WHO", times, ly)
    
### eliminate any column of datalst matrices elements that are all na's      
    datalst <- lapply(datalst, FUN="elimallna.cols")
                     
    return(datalst)
  }
### HELPER function to joindthcov.WHO;
###
### USES removeNA.WHO
###
### INPUT: mat, a matrix; times a logical; ly number of years to lag
###
### OUTPUT modify matrix mat
###
### AUTHOR Elena Villalon
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
##################################################################################

shapelst.WHO <- function(mat,times,ly)
{
  nm <- colnames(mat)
  
  ind <- 1:nrow(mat)         
  ind.toremove <- sapply(ind,FUN= "removeNA.WHO",mat)
         
  ind.toremove <- unlist(ind.toremove)
  sx <- 1:length(ind.toremove)
  sx <- sx + ind.toremove[[1]] -1
  fix <- (sx == ind.toremove )
  ind.toremove <- ind.toremove[fix]
      
  if(length(ind.toremove) > 0)
    mat <- as.matrix(mat[-ind.toremove, ])
  colnames(mat) <- nm
      
  if(times){
    nm <- colnames(mat)
    tm <- as.numeric(rownames(mat)) - ly
    mat <- cbind(as.matrix(mat), tm)
    colnames(mat) <- c(nm, "time") 
  }
  return(mat)
}
### DESCRIPTION given a matrix mat and index row n
###             finds if all elements in the row are NA and return NULL
###             otherwise if not all elements in the row are NA, return the row index
###
### AUTHOR Elena Villalon
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
##################################################################################
removeNA.WHO <- function(n, mat){
  rr <- mat[n, ]
  if(all(is.na(rr)))
    return(n)
  else
    return(NULL)
}
### DESCRIPTION builds the list with cross-sectional identifiers for all 
###             files in datapath whose names are in vector disease and population
###
### INPUT datapath, a character string with a directory name; 
###       disease, a vector with names of death causes of diseases; 
###       pop, a string with the name of the file for population
###
### OUTPUT: the list of csid elements one for each country and age group
###         Every element of the list is a matrix with two columns for
###         each disease and for population according to gender,
###         such as allc2, allc3, popu2, popu3 for male and female
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###
########################################################################
disease.WHO <- function(datapath, disease, pop)
  {
    
### all deaths included in disease and population for both genders
### the number of digits for country, age and years
    cdigits <- 4
    adigits <- 2
    ydigits <- 4
   
       alldths <- buildths.WHO(datapath,disease, pop)
       if(length(alldths) <= 0)
         return(list())       
### split according to gender
       
       nc <- ncol(alldths)
       alldths <- split.data.frame(alldths, alldths[,nc])
       alldths.male <- alldths[[1]]
       alldths.female <- alldths[[2]]
       
### split according to csid (or cntry+age identifiers)
       males.csid <- split.data.frame(alldths.male, floor(alldths.male[,1]/10^ydigits))
       females.csid <- split.data.frame(alldths.female, floor(alldths.female[,1]/10^ydigits))
### change columns names from allc to allc2 or allc3 depending on male or females
       males.csid <- lapply(males.csid, FUN="appendstrata.WHO")
       females.csid <- lapply(females.csid, FUN="appendstrata.WHO")
       ind <- 1:length(males.csid)
       names(ind) <- names(males.csid)
### error checking
       if(abs(length(males.csid) - length(females.csid)) > 0 ||
          !identical(names(males.csid), names(females.csid)))
         stop("error building csid males and females")
    
### construct list of matrices for each csid with males and females
### diseases (e.g, allc2 and allc3, cerv2, cerv3)
### and population (e.g, popu2, popu3)
       alldths <- lapply(ind, function(n){
                         nm2 <- colnames(males.csid[[n]])
                         nm3 <- colnames(females.csid[[n]])
                         nm3 <- nm3[-1]
                         mat <- cbind(as.matrix(males.csid[[n]]),
                                      as.matrix(females.csid[[n]][,-1]))
                         colnames(mat) <- c(nm2, nm3)
                         return(mat)})
       
       return(alldths)
     }

### DESCRIPTION helper function to disease.WHO
###             reads the files in datapath whose names are in the vectors disease, pop
###             Binds them in columns for every files
###
### INPUT datapath with directory name; 
###       disease vector of death causes and pop string with file population
###
### OUTPUT A matrix with as many columns as files in disease and pop plus
###        two additional columns to identify the gender and the cstid or cross sectional year
###        such as "4080351999", for cntry "4080", age "35" and year "1999"
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
#########################################################################
buildths.WHO <- function(datapath, disease, pop, alldths=NULL)
  {
    if(length(disease) <= 0 && length(pop) <= 0)
      return(list())
    
    if(length(disease) > 0){
      for(n in 1:length(disease))
        {
          dthstring  <- paste(datapath,disease[n],".txt",sep="")
          cat(paste("Reading file ", dthstring, sep=""), "\n")
          dth0 <- scan(file=dthstring,
                       na.strings=c("-999.0000", "-999", "NA"),
                       multi.line=T,quiet=T)
          dth0 <- matrix(dth0,ncol=3,byrow=T)
          csid <- dth0[,2]
          strata <- dth0[, 3]
          alldths <- cbind(alldths, nm=as.matrix(dth0[,1]))
            
        }
     
    colnames(alldths) <- disease
    }else
    alldths <- NULL
    
    if (length(pop) <= 0){
      alldths <- cbind(csid=csid, alldths, strata=strata)
  
      return(alldths)
    }
    popstring <- paste(datapath,pop,".txt",sep="")
    cat(paste("Reading file ", popstring, sep=""), "\n")
    pop0 <- scan(file=popstring,
                 na.strings=c("-999.0000", "-999", "NA"),multi.line=T,quiet=T)
    pop0 <- matrix(pop0, ncol=3, byrow=T)
    csid <- pop0[,2]
    pop0 <- pop0[,-2]
    colnames(pop0) <- c("popu", "strata")
    if(length(alldths) >0)
      alldths <- cbind(csid,as.matrix(alldths), popu =as.matrix(pop0))
    else
       alldths <- cbind(csid,popu =as.matrix(pop0))
      
    return(alldths)
  }
### given a matrix with a death or covariate column a gender column
### it appends the number 2 or 3 to the column name identifying the
### disease or covariate and delete the gender (strata) column
### returns the modified matrix 
appendstrata.WHO <- function(mat)
{
### the number of digits for country, age and years
  cdigits <- 4
  adigits <- 2
  ydigits <- 4
  
  cnm <- colnames(mat)
  no  <- mat[1,"strata"]
  ind <- grep("strata", cnm)
  
  mat <- mat[,-ind]
  cnm <- cnm[-ind]
  ind <- grep("csid", cnm)
  rcnm <- cnm[-ind]
  rcnm <- paste(rcnm,no, sep="")
  cnm <- c("csid", rcnm) 
  colnames(mat) <- cnm
  csid <- mat[,"csid"]
  dd   <- cdigits + adigits + 1
  rnm  <- substring(csid, dd)
  rownames(mat) <- rnm
  return(mat)
}
### DESCRIPTION builds the list with cross-sectional identifiers for all 
###             files in datapath whose names are in vector cov.FULL of covariates
###
### INPUT datapath, a character string with a directory name; 
###       cov.FULL, a vector with names of covariates
###
### OUTPUT: the list of csid elements one for each country and age group
###         Every element of the list is a matrix with two columns for
###         each covariate according to gender if tobacco, 
###         such as tobacco2, tobacco3,for male and female
###         Otherwise the name of the covariate if strata independent, "gdp"
###
### USES covexceptob.WHO; appendtobgender.WHO
###
### AUTHOR Elena Villalon
###        IQSS, Harvard University
###        evillalon@iq.harvard.edu
###
########################################################################
buildcovs.WHO <- function(datapath, cov.FULL)
  {
### the number of digits for country, age and years
    cdigits <- 4
    adigits <- 2
    ydigits <- 4
    
    ind <- grep("tobacco", cov.FULL)
    covF <- cov.FULL
    if(length(ind) > 0)
      covF <- cov.FULL[-ind]
    if (length(covF) > 0)
      allcovs.csid <- covexceptob.WHO(datapath, covF)
    else
      allcovs.csid <- list()
   
    if (length(ind) <= 0){
    
      return(allcovs.csid)
    }
    tobstring <- paste(datapath,cov.FULL[ind],".txt",sep="")
    cat(paste("Reading file ", tobstring, sep=""), "\n")
    tob0 <- scan(file=tobstring,na.strings=c("NA","-999", "-999.0000"),
                 multi.line=T,quiet=T)
    tob0 <- matrix(tob0, ncol=3, byrow=T)
    
    tobg <- split.data.frame(tob0, tob0[,3])
    tobm <- appendtobgender.WHO(tobg[[1]])
    tobf <- appendtobgender.WHO(tobg[[2]])
    
    tobm.csid <- split.data.frame(tobm, floor(tobm[,2]/10^ydigits))
    tobf.csid <- split.data.frame(tobf, floor(tobf[,2]/10^ydigits))    
    ind <- 1:length(tobm.csid)
    names(ind) <- names(tobm.csid)
    if(abs(length(allcovs.csid) - length(ind)) >0 && length(allcovs.csid) > 0 )
      stop("Provide for the FULL version of covariates")
   
    join.gender <- lapply(ind, function(n){
      if(length(allcovs.csid) <= 0)
        acv <- NULL
      else
        acv <- allcovs.csid[[n]]
      tm <- tobm.csid[[n]]
      tf <- tobf.csid[[n]]
      if(length(acv) > 0)
        matbacco <- cbind(as.matrix(tm[, 2]), as.matrix(tm[,-2]),
                          as.matrix(tf[,-2]), as.matrix(acv[, -1]))
      else
        matbacco <- cbind(as.matrix(tm[, 2]), as.matrix(tm[,-2]),
                          as.matrix(tf[,-2]))
      colnames(matbacco) <- c("csid", "tobacco2", "tobacco3",colnames(acv)[-1]) 
      return(matbacco)})
   
   
    return(join.gender)
  }
### HELPER function to build.covs;
### INPUT a matrix and returns modify matrix
### Appends the gender number 2 or 3 to colname tobacco
###
appendtobgender.WHO <- function(mat)
  { 
    no <- unique.default(mat[,3])
    mat <- mat[,-3]
    tob <- paste("tobacco", no, sep="")
    colnames(mat) <- c(tob, "csid")
    return(mat)
  }
### HELPER function to build.covs;
### DESCRIPTION:scan the covariates files and build three column matrices; 
###             bind all covariates matrices along columns to make a large matrix
###             The matrix has one column to identify the csid, and as many more
###             columns as ovariates are included in covF.
###             Split the large matrix will all covaraites values and csid
###             according to the country code + age group and returns the resulting list
###
### INPUT: datapath, a directotry path;
###        covF, a vector with name of covariates
###
### OUTPUT: a list whose elements are csid units (such as "245045")
###         every matrix in the list has as many columns as covaraites
###         in the vector covF, plus the csid time series identifier
### 
###
 covexceptob.WHO <- function(datapath, covF)
    {
      ### the number of digits for country, age and years
      cdigits <- 4
      adigits <- 2
      ydigits <- 4
      allcovs <- NULL
    for(n in 1:length(covF))
      {
        covstring  <- paste(datapath,covF[n],".txt",sep="")
        cat(paste("Reading file ", covstring, sep=""), "\n")
        cov0 <- scan(file=covstring,multi.line=T,na.strings=c("NA", "-999", "-999.0000"),quiet=T)
        cov0 <- matrix(cov0,ncol=3,byrow=T)
       if(n <= 1)
         allcovs <- cbind(allcovs, cov0[, 2], cov0[,1])
        else              
          allcovs <- cbind(allcovs, nm=cov0[,1])
            
      }
    rnm <- substring(covF, 6) ###from FULL.gdp to gdp
   
    colnames(allcovs) <- c("csid", rnm)
    allcovs.csid <- split.data.frame(allcovs, floor(allcovs[,1]/10^ydigits))
    return(allcovs.csid)
  }
### DESCRIPTION: Select a country set of datalst accoring to vector cntry.vec
###
### INPUT: datalst, a list of elements csid units for counties and age groups
###        cntry.vec, a vector with country codes
###
### OUTPUT: a subset of the list datalst with only the countries included in cntry.vec
###
### AUTHOR: Elena Villalon
###         IQSS, Harvard University
###         evillalon@iq.haravrd.edu
###         March 22, 2006
#################################################################################

selectcntry.WHO <- function(cntry.vec, datalst)
  {
### the number of digits for country, age and years
    cdigits <- 4
    adigits <- 2
    ydigits <- 4
    
    csid <- names(datalst)
    ind <- 1:length(datalst)
    names(ind) <- csid
    cntry.vec <- as.character(cntry.vec)
    ind <- sapply(ind, function(n, csid, cntry.vec)
                  {
                    chix <- csid[n]
                    ix <- NULL
                    ix <- if(is.element(substring(chix, 1, cdigits), cntry.vec))
                      ix <- n
                    return(ix)
                  }, csid,cntry.vec)
    ind <- unlist(ind)
    if(length(ind) > 0)
    datalst <- datalst[ind]
    else
      stop("No countries in dataset")
  }
### DESCRIPTION it select a particular subset of countries from datalst
###             if number of observations, for any death
###             or disease and population, is  no observations >= nobsv
###
### INPUT: nobsv, number of observations;
###        datalst, list of csid units for each cntry and age group
###        covs.nm, vector of covariates names to exclude from the counting
###
### OUPUT: datalst with countries satisfying criteria of no observations > nobsv
###
### AUTHOR: Elena Villalon
###         IQSS, Harvard University
###         evillalon@iq.haravrd.edu
###         March 22, 2006
#################################################################################
 

countobvs.WHO <- function(nobvs, datalst,
                          covs.nm =c("fat", "gdp", "hc", "tfr", "tobacco2", "tobacco3")) 
  {
### the number of digits for country, age and years
    cdigits <- 4
    adigits <- 2
    ydigits <- 4
    
    ind <- 1:length(datalst)
    names(ind) <- names(datalst)
    ind <- sapply(ind, function(n)
                    {                      
                      mat <- datalst[[n]]
                      cnm <- colnames(mat)
                      ix <- unlist(sapply(covs.nm, grep,cnm))
                     
                      if (length(ix) > 0)
                        mat <- mat[, -ix]
                      if(length(ix) == length(cnm))
                        return(n)
                      mat[!is.na(mat)] <- 1
                      mat[is.na(mat)] <- 0
                      vec.sum <- apply(as.matrix(mat), 2, sum)
                      xi <- NULL
                      if(all(vec.sum >= nobvs))
                        xi <- n
                        
                      return(xi)
                      })
    ind <- unlist(ind)
    datalst <- datalst[ind]
    nm <- names(datalst)
    nm <- sapply(nm, substring, 1, cdigits)
    nm <- unique.default(nm)
    cat("Number of countries with unless ", nobvs, " observations is ", length(nm), "\n")
    cat("Subset of country codes \n")
    cat(nm)
    cat("\n")
    return(datalst)        
  }

### DESCRIPTION: helper function to datawho(), when lagyears = 0
###              joins deaths and covariates into a single data list according to csid
###              select countriesa if cntry.vec is non null or number observations (nobvs)
###              is positive.  Exclude age groups <= 15 from the tobacco covariate
###
### INPUT: alldths, list of diseases by csid
###        allcovs, list of covaraites by csid
###        timeseries,true or false to inclues the time as covaraite
###        lagyers, integer to lag covariates = 0
###        years, times sereis in data sset
###        cntry.vec, vector of country codes
###        nobvs, number of deaths observations
###        covs.single, vector of covariates names (without the FULL, e.g, fat, gdp)
###        cov.FULL, vector of covarites names , FULL.gdp, FULL.fat
###        covselect.WHO, ages to exclude from tobacco
###
### USES: joindthcov.WHO,selectcntry.WHO, countobvs.WHO, agesexclude.WHO
###
### OUPUT the transform datalst, a list by csid (cntry+age) of data
###       for diseases and covariates
###
### AUTHOR: Elena Villalon
###         IQS, Harvard University
###         evillalon@iq.harvard.edu
###         March 27th, 2006
################################################################################
        
  processnolag.WHO <- function(alldths, allcovs, timeseries,lagyears, years,
                               cntry.vec, nobvs, covs.single, cov.FULL, covselect.WHO)
  {
      if(length(alldths) > 0)
        alldths <- lapply(alldths, function(mat) {
          nm <- colnames(mat)[-1]
          mat <- as.matrix(mat[,-1])
          colnames(mat) <- nm
          return(mat)})
      
      if(length(allcovs) > 0)
        allcovs <- lapply(allcovs, function(mat) {
          nm <- colnames(mat)[-1]
          mat <- as.matrix(mat[, -1])
          colnames(mat) <- nm
          return(mat)})
   
      datalst <- joindthcov.WHO(alldths, allcovs, timeseries, lagyears, years)
      if(length(cntry.vec) > 0)
        datalst <- selectcntry.WHO(cntry.vec, datalst)

      if(length(nobvs) > 0)
        datalst <- countobvs.WHO(nobvs, datalst, covs.single)
      
     if(length(grep("tobacco",cov.FULL)) > 0 )
       {
         incov <- 1:length(datalst)
         names(incov) <- names(datalst)
         csidwho <- names(datalst)
         datalst <- lapply(incov, FUN="agesexclude.WHO", datalst,csidwho, covselect.WHO)        
        
       }
    return(datalst)
    }
    
agesexclude.WHO <- function(n, datalst, csidwho, covselect.WHO)
{
### the number of digits for country, age and years
  cdigits <- 4
  adigits <- 2
  ydigits <- 4
  mat <- datalst[[n]]
  csid <- csidwho[n]
  nm <- colnames(mat)
  dd <- cdigits+1
  age <- as.numeric(substring(csid, dd))
  ix <- grep("tobacco", nm)
  if(is.element(age, covselect.WHO) && length(ix) > 0)
    mat <- mat[,-ix]
  return(mat)
}
                 
### Not in use for the program; to reduce the number of rows for elemenst
### matrices of datalst.  If any death or disease timeseries has no observations
### for all rows of mat, eliminates the rows before the first observation of death

datana.WHO <- function(datalst, covs.single)
{
  lapply(datalst, function(mat){
    cnm <- colnames(mat)
    ix <- unlist(sapply(covs.single, grep, cnm))
    dth <- mat[,-ix]
    dth[!is.na(dth)] <- 1
    dth[is.na(dth)] <- 0
    ix <- match(1, dth[,1])
    return(mat[ix:nrow(mat), ])})
}
### DESCRIPTION 
###        It checks if any of the columns of mat contains only na's
###        If it is the case then removes the column
###
### INPUT: mat, a matrix; 
###
### OUTPUT modify matrix mat with only columns that have unless one observation
###
### AUTHOR Elena Villalon
###        evillalon@iq.harvard.edu
###        March 20th, 2006
###
##################################################################################

elimallna.cols <- function(mat)
  {
    ix <- as.list(1:ncol(mat))
    names(ix) <- colnames(mat)
    ix <- sapply(ix, function(n){
      cc <- na.omit(mat[,n])
      
      if(length(cc) >0)
        return(n)
      else
        return(NULL)
      
    })
    ix <- unlist(ix)
    return(mat[, ix])
  }

### DESCRIPTION:construct the list dataobj argument of yourcast, 
###             which has four elements, data, index.code,
###             proximity, and G.names.
### INPUT: dataw the list with csd units for dataobj$data; 
###        if dataw=null then it calls datawho() with its defaults
###        arguments to build the list dataw; 
###        icode or index.code, a string; 
###        proxfile, the name of the proximity (or adjacency file); 
###        Gnames, the file for G.names;
###        dpath, the directory name where the files are
###
### OUTPUT: dataobj one of the arguments of yourcast
###
### AUTHOR: Elena Villalon
###         IQS, Harvard University
###         evillalon@iq.harvard.edu
###         March 2006
#################################################################

dataobjWHO <- function(datapath= "/nfs/where/export/data/death/WHOdata/Jun2002_data/", 
                       disease = c("aids","allc", "allo", "brst", "cerv",
                         "cvds", "dgst", "homi", "livc", "lung", "malr",
                         "matc", "molp", "omal", "otin", "pern", "rspc",
                         "rspi", "stom", "suic", "trns", "tubr","unin","ward"),
                       pop= "population",
                       cov.FULL= c("FULL.fat", "FULL.gdp", "FULL.hc", "FULL.tfr", "tobacco"),
                       lagyears = 0, timeseries=FALSE,
                       cntry.vec = NULL, nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                       dataw=NULL, icode="ggggaatttt",proxfile="adjacency.txt",
                       Gnames="cntry.codes.txt", selectages=NULL)
{

  dataobj <- list()
  
  if(length(dataw) <= 0){
    if(length(disease) <= 0 && length(pop) <= 0 && length(cov.FULL)<= 0)
      dataw <- datawho()
    else
      dataw <- datawho(datapath, disease, pop,cov.FULL,lagyears, timeseries,
                       cntry.vec, nobvs, covselect.WHO,selectages)
  }
    
    
  dpath <- datapath 
  dataobj <- c(dataobj, data=list(dataw), index.code=icode)
  Gnames <- paste(dpath,"/", Gnames, sep="") 
  gnames <- build.Gnames(pfile=Gnames)
  dataobj <- c(dataobj, G.names=list(gnames))
  proxobj <- proximity.file(datapath=dpath, filenm = proxfile,
                           filename = proxfile, dir="./tmp", savemat=F)
  dataobj <- c(dataobj, proximity=list(proxobj))
  return(dataobj)
}
### DESCRIPTION given a list whose elemnts have csid matrices
###             Names of elements ar cntry+age, say "245045"
###             Select those ages groups in all countries that
###             are in vector age.vec

selectagesWHO <- function(datlst, age.vec)
  {
    cdigits <- 4
    age.vec <- as.numeric(age.vec)
    nmlst <- names(datlst)
    ind <- as.list(1:length(nmlst))
    names(ind) <- nmlst
    ind <- sapply(ind, function(n) {
      csid <- nmlst[n]
      age <- as.numeric(substring(csid, cdigits + 1))
      toret <- NULL
      if(is.element(age, age.vec))
        toret <- n
      return(toret)
    })

    ind <- unlist(ind)
    if (length(ind) > 0)
      return(datlst[ind])
    else
      return(datlst)
  }
user.prompt <- function (){
 
silent <- readline("\nPress <return> to continue or Ctrl-c Ctrl-c to quit: ")



}

selectyearWHO <- function(datlst, year.vec=2000)
  {
    cdigits <- 4
    adigits <- 2
    ydigits <- 4
    
    year.vec <- as.character(year.vec)
    datlst <- lapply(datlst, function(mat) {
      rw <- rownames(mat)
      cl <- colnames(mat)
      ln <- 1:length(cl)
      ixr <- unlist(sapply(year.vec, grep, rw))
      if(length(ixr) > 0 ){
        mat <- matrix( mat[ixr, ], nrow=length(ixr))
       rownames(mat) <- year.vec
       colnames(mat) <- cl
      }else
        mat <- NULL
     return(mat)
    })
    ind <- sapply(datlst, function(mat){
                  bool <- T
                  if(length(mat) <= 0)
                    bool <- F
                  return(bool)
                })
    
    ind <- unlist(ind)

                    
    datlst <- datlst[ind]
    return(datlst)
  }

  
