### INPUT: dpath or directory path to look for files, if none it will take current directory
###        dataobj an optional list with data.frames; it may be set to null
###        icode, the index coding with default of 4 digits for cntry, 2 for age and 4 years
###        str the names of the list elements for dataobj, no set in simulation but hard-wire
###
### OUTPUT: It returns the dataobj input for yourcast, with elements in str
###         optional elements are A.names, G.names, T.names, proximity (depending on forecasting model)
###
### DESCRIPTION: The dataobj is a list whose elements' names are in str; see yourprep arguments
###              names(dataobj) = c("index.code","A.names","G.names","T.names","proximity","data"). 
###              The dataobj elements are:  index.code a string of characters; 
###              A.names T.names and G.names dataframes of two columns, possibly stored in files; 
###              proximity also a dataframe of three columns, may be stored in file; 
###              data is a list of many elements with the cross-sectinal identifiers  
###              covariance matrices or explanatory variables for yourcast; 
###              data/ is also  the name of the directory containing the files for csid
###              The directory is in path, dpath, or in current working directory
###              data/ contains the files, whose names are numeric strings that correspond 
###              to the cross-sectional identifiers of element dataobj$data.
###              After checking all inputs for either directories and files, if they
###              are valid names and if they exist, then builds the different elements of
###              dataobj if the element is not introduced as argument of yourprep.
###              Any list element argument of yourprep in dataobj takes priority and overrules
###              all existent files that may contain the values for that list elemnt.
###              It calls following functions to build the dataobj list elements
###
### FUNCTIONS:  GAT.names and build.Gnames, for A.names, T.names, G.names, index.code
###             build.data for files in data direcory and element dataobj$data
### 
###
### AUTHOR: Elena Villalon
###         evillalon@iq.harvard.edu
###         IQSS, Harvard University
###         Cambridge, MA
### Date 01/31/2006


yourprep <- function(dpath= NULL, dataobj=NULL, icode = "GGGGAATTTT",
                        str= c(index.code ="index.code",A.names="A.names",G.names="G.names",
                          T.names="T.names",proximity="proximity",data="data"), 
                       verb=T )
  {
    
### dataobj should be a list of elements whose names must be in the str vector     
   
    nmdobj <- NULL
    verbose <- verb 
    if(length(dpath) > 0 &&  length(grep("/$",dpath) ) <= 0)
      dpath <- paste(dpath,"/", sep="")
    
    if (length(dpath) <= 0)
      {
###set current directory as default
        dpath <- getwd()
        if(length(grep("/$",dpath) ) <= 0)
          dpath <- paste(dpath, "/", sep="")
      }
### if some elements are provided as inputs, make sure are the correct names
### they also take preference over any other files in the dpath or datadir 
    if(length(dataobj) > 0)
      {
        if(!is.list(dataobj))
          stop("Bad input: dataobj is either null or a list")
        
        nmdobj <- names(dataobj)
        bool <- sapply(nmdobj, is.element, str)
        if(any(bool==F))
          stop("Bad input: names of list dataobj are not correct")        
        allnames <- sapply(str,is.element, nmdobj)
      }
    
    mod <- FALSE
    mod <- GAT.names(dpath, str["G.names"],nmdobj, verbose)
    if(mod){
      Gfile <- paste(dpath, str["G.names"], sep="")
       
      dataobj$G.names <- build.Gnames(Gfile,verb=verbose)
  
    }

    mod <- FALSE
    mod <- GAT.names(dpath, str["A.names"],nmdobj,verbose)
    if(mod){
      Afile <- paste(dpath, str["A.names"], sep="")
      dataobj$A.names <- build.Gnames(Afile,verb=verbose)
     }
    
    mod <- FALSE
    mod <- GAT.names(dpath, str["T.names"],nmdobj,verbose)      
    if(mod){
      Tfile <- paste(dpath, str["T.names"], sep="")
      dataobj$T.names <- build.Gnames(Tfile,verb=verbose)
    }
    
    mod <- FALSE
    mod <- GAT.names(dpath, str["proximity"],nmdobj,verbose)      
    if(mod){
      proxfile <- paste(dpath, str["proximity"], sep="")
###      print(proxfile)
      dataobj$proximity <- build.Gnames(proxfile, nocol=3,verb=verbose)
    }
    
    mod <- FALSE
    mod <- GAT.names(dpath, str["index.code"],nmdobj,verbose)      
    if(mod){
   
      icodefile <- paste(dpath, str["index.code"], sep="")
      dataobj$index.code <- build.Gnames(icodefile, nocol=1,verb=verbose)
    }else
      if(!is.element(str["index.code"], nmdobj))
        dataobj$index.code <- icode
    
    datadir   <-  paste(dpath,str["data"], sep="")
    datafiles <- NULL
    if(file.exists(datadir))
      datafiles <- list.files(path=datadir, full.names=TRUE, recursive=TRUE)
    else{
      messout("Directory data not provided...", verbose)
      messout(paste("Reading dataobj$data files from ", dpath, sep=""),verbose)
    }

    if(length(datafiles) <= 0){
      datadir <- dpath
      datafiles <- list.files(path=datadir, full.names=TRUE, recursive=TRUE)
      ix <- grep(str["data"], str)
      if(length(ix) > 0)
        strdir <- str[-ix]
      else
        strdir <- str
      
      if(length(grep("/$",datadir)) <= 0)
        strdir <- sapply(str,function(nm) paste("/", nm,sep=""))
       
      files.to.exclude <- sapply(strdir,function(nm) paste(datadir,nm,sep=""))
      datafiles <- setdiff(datafiles, files.to.exclude)

    }
   ix <- grep(str["data"], str)
   str0 <- str
   if(length(ix) > 0)
     str0 <- str[-ix]
    
   if(length(datafiles) > 0 && !is.element(str["data"], nmdobj))
      dataobj$data <- build.data(datafiles, icode=dataobj$index.code,goodfiles=str0,verb=verbose)
   else if(!is.element(str["data"], nmdobj))
     messout("No data files provided for the simulation...", verbose)
     

   return(dataobj)
      
  }

### function:GAT.names(dirpath, filename,nmdataobj)
###
### INPUT: dirpath= a directory path; filename=the name of a file in the dirpath
###        dataobj a list of inputs to yourcast
###
### DESCRIPTION: finds whether filename is in the dirpath;
###              if it is in dirpath and is not mpart of nmdataobj
###              changes the flag modify to true.
###
### OUTPUT: return a boolean
###
### AUTHOR: Elena Villalon
###         email:evillalon@iq.harvard.edu
###         Institute for Quantitative Social Science
###         Harvard University
###         01/30/2006

 GAT.names <- function(dirpath, filename,nmdataobj,verbose)
  {
    modify <- FALSE
    file <- list.files(path=dirpath, pattern=filename, full.name=TRUE)
### if there is more than one file with G.names
###    print(file.exists(paste(dirpath,filename, sep="")))
    if(length(file) > 1 && file.exists(paste(dirpath,filename, sep="")))
      file <- paste(dirpath,filename, sep="")
###    print(file)
### if no input in dataobj for G.names call build.Gnames    
    if(length(file) > 0 && !is.element(filename, nmdataobj))
       modify <- TRUE
    else
      if(!is.element(filename, nmdataobj))
        messout(paste("File ", filename," is not provided...", sep=""),verbose) ###optional file
    return(modify)
   }

### function: build.data(filas=NULL, folder=NULL, icode="GGGGAATTTT", goodfiles=NULL)
###
### INPUT: filas names for files with their directory path;
###        folder the name of the directory where the files may reside
###        icode=the coding string for filenames
###        goodfiles are files that should not produced warnings messages
###
### DESCRIPTION: finds whether filas is a vector with filenames or
###              if the files are in directory folder;              
###              finds if filenames are valid names or follow
###              the icode structure for filenames
###              For example, a valid name is 245045
###              where 2450 is country code (GGGG) and 45 is age (AA)
###              Load all files locally and creates datalst, which is a list
###              of data.frames for every file in filas.
###
### OUTPUT returns a list with data.frames contain in valid filas.
###
### AUTHOR: Elena Villalon
###         email:evillalon@iq.harvard.edu
###         Institute for Quantitative Social Science
###         Harvard University
###         01/30/2006


build.data <- function(filas=NULL, folder=NULL, icode="GGGGAATTTT", goodfiles=NULL, chkcode=T,verb=T)
  {
    datalst <- list()
    lstnm   <- NULL
    torm    <- NULL
   
    ev <- environment()
    if(length(filas) <= 0 && length(folder) <= 0)
      stop("Provide the list of files or directory they reside")
    
    if(length(filas) <= 0){
       filas <- list.files(path=folder, full.names=TRUE, recursive=TRUE)
       if(length(filas) <= 0)
         stop("Directory empty")
     }
  ###  print(icode)
    if(length(icode) <= 0)
      icode <- "GGGGAATTTT"
    
    nogs   <- length(strsplit(icode, "[Gg]")[[1]]) - 1
    noas   <- length(strsplit(icode, "[Aa]")[[1]]) - 1
    nocsid <- nogs + noas
    
    messout("Reading the data files for dataobj...",verbose)    
    for(fille in filas){
      messout(paste(fille,"...",sep=""),verbose)
      spfille <- strsplit(fille, "/")[[1]]
      ln <- length(spfille)
      fno <- spfille[ln]
      zz <- nchar(fno) - nocsid
      fnosp <- strsplit(fno, NULL)[[1]] ### individual characters
      ind <- grep("[^0-9]", fnosp) ###exclude numbers
      lni <- length(ind)
      
   ### to make sure I have the correct file name
      mess <- "Not a valid filename"
      if(length(ind) > 0 && !is.element(1, ind)){
        messout(mess,verbose)
        next
      }
      if(length(ind) > 0 && !is.element(lni, ind)){
        messout(mess, verbose)
        next
      }
      if(length(ind) > 0 && length(ind) == nchar(fno)){
        messout(mess, verbose)
        next
      }
      fnochk <- fno
      if(length(ind) >0)
        {
          fnosp <- fnosp[-ind]
          fnochk <- paste(fnosp, collapse="")
        }
      if(chkcode)
        bb <- is.na(as.numeric(fnochk)) || abs(zz)
      else
        bb <- is.na(as.numeric(fnochk))
      
      if(bb )
        {
          if(length(goodfiles) > 1 && !is.element(fno, goodfiles))
            messout(mess, verbose)
          next
        }              
     
      fille0 <- try(load(fille, envir=ev), silent=T)
      
      if(class(fille0) != "try-error")
        fille <- try(eval(as.symbol(fille0)), silent=T)
      else {
        fille1 <- try(read.table(fille, header=T, row.names="time"), silent=T)
        if(class(fille1) =="try-error")
          fille <- try(read.table(fille, header=T), silent=T)
        else
          fille <- fille1
      }
      if(length(fille) > 0 && class(fille) != "try-error"){
        datalst <- c(datalst, list(fille))
        lstnm   <- c(lstnm, fno)
###      print(length(datalst))
###      print(length(lstnm))
        names(datalst) <- lstnm
      }else
      messout(paste("Warning: no input is available in: load(",fno,", envir = ev)", sep=""),verbose) 
    }
    return(datalst)
  }


### function:build.Gnames(pfile,nocol=2)
###
### INPUT: pfile the name of a file with directory path
###        nocol number of columns for output matrix or data.frame
###
### DESCRIPTION: load pfile in the local environment; 
###              the result of load command should be either a matrix or data.frame
###
### OUTPUT:      if ncol=1, returns a vector else returns matrix
###
### AUTHOR: Elena Villalon
###         email:evillalon@iq.harvard.edu
###         Institute for Quantitative Social Science
###         Harvard University
###         01/30/2006


build.Gnames <- function(pfile, nocol=2,verb=T)
  {
    ev <- environment()
    verbose <- verb
    messout(paste("Reading the data files for dataobj...", pfile, sep=""),verbose)
    dirfile  <- pfile
    spfille  <- strsplit(pfile, "/")[[1]]
    ln <- length(spfille)
###    print(spfille)
###    print(ln)
    if(ln > 0){
      
      filename <- spfille[ln]
      dpath <- paste(spfille[-ln], collapse="/")
    }else{
      
      filename <- pfile
      dpath <- getwd()

    }
    
  ##  pfile <- try(load(pfile, envir=ev), silent=T)
  ##  if(class(pfile) != "try-error"){
      
  ##    pfile <- try(eval(as.symbol(pfile)), silent=T)
  ##  }
  
 ###   bb <- !is.matrix(pfile) && !is.data.frame(pfile) && !is.vector(pfile)
    bb <- is.character(pfile)
    if( bb || class(pfile)=="try-error")
      {
       
        messout(paste("Scanning file...",filename,sep=""),verbose)
        if(nocol <= 1){ ### icode="ggggaatttt"
         
          pfile <- icode(datapath=dpath, fname=filename, icodes=filename, dir=dpath)
         
        }else if(nocol <= 2){ ### cntry.codes
      
          pfile <- Gnames.file(datapath=dpath, fname= filename,codes.names=filename,
                               dir=dpath,verb=verbose) 
  
        }else if(nocol <= 3){ #### adjacency or proximity matrix
         
          pfile <- proximity.file(datapath=dpath, filenm=filename, filename=filename, dir=dpath)    
        }else
        return(list())
        
        if(length(pfile) < 0)
          return(list())
    
      }
    pfile <- build.Gnames.obj(pfile,nocol,verb=verbose)
         
    return(pfile)
    
  }

build.Gnames.obj <- function(pfile, nocol=2,verb=T)
  {
    ev <- environment()
   
    verbose <- verb
    bb <- !is.matrix(pfile) && !is.data.frame(pfile) && !is.vector(pfile)
    if( bb || class(pfile)=="try-error")
      {
        return(list()) 
      }
    
    if(nocol > 1 )
      pfile <- as.matrix(pfile)
    else 
      pfile <- as.vector(pfile)
   
    
   if(is.matrix(pfile) || is.data.frame(pfile)){ 
     sz <- dim(pfile)
     nr <- sz[1]
     nc <- sz[2]
     ln <- nr * nc
   }else{
    ln <- length(pfile)
    nc <- ln
  }
   
    if(is.na(ln) || length(ln) < 1 || nocol != nc){
      messout("Matrix has incorrect data...", verbose)
      return(list())
    }
   
    return(pfile)
    
  }
####  I have my list datamat with matrices for each csid
###   Created files with the csid identifiers for each matrix as filenames
###   in the directory specified in dir, and save them 
###   Elena Villalon

makedir.ascii <- function(datamat, dir=".")
  {
    ln <- length(datamat)
    lstnm <- names(datamat)
    for (n in 1:ln){
      mat <- datamat[[n]]
      fno <- lstnm[n]
###testing do not put time as a column
   
      it <- grep("time", colnames(mat))
       if(length(it) >0 ){
         mat <- as.matrix(mat[,-it])
         mat <- cbind(rownames(mat), mat)
       }
      
  
###end of testing
     
      fno <- paste(dir,"/", fno, sep="")
      write.table(mat, file=fno,quote=F, sep="\t",eol="\n",row.names=F, col.names=T, na="NA")
       print(paste("The size of ",fno, " file is = ",
                  file.info(fno)$size)) 
 
    }
  ###   l4 <- read.table("./data/502010", header=T, row.names="time")
  }
makedir.dataframes <- function(datamat, dir=".")
  {
    ln <- length(datamat)
    lstnm <- names(datamat)
    for (n in 1:ln){
      mat <- datamat[[n]]
      fno <- lstnm[n]
      
      fno <- paste(dir,"/", fno, sep="")
      save(mat, file=fno, compress=TRUE)
    }
  }
### INPUT: two directories, datapath and dir, for inpput and output
###        two filenames, filenm and filename for input and output
###        savemat boolean to save the preprocess filename
###
### OUTPUT the name of the file, filename, where the proximity matrix
###        is stored
###
### DESCRIPTION reads the data in filenm of directory datapath
###             construct a matrix of three columns; two with cntry codes
###             and the third with the score for their correlation
###             Saves the matrix under the name filename in directory dir
###
### AUTHOR: Elena Villalon
###         evillalon@iq.harvard.edu
###         IQSS, Harvard University
### 

proximity.file <- function(datapath="~/data", filenm = "proximity",
                           filename = "proximity", dir="./tmp", savemat=F)
  {
  
  if(is.character(filenm))
    {
      weightstring <- paste(datapath,"/",filenm, sep="")
      cntry.weight <- scan(file=weightstring,
###what=c(integer(0),integer(0),numeric(0)), 
                           na.strings="-999.0000",multi.line=T)
### cntry.weight has three columns and rows = 191 x 191
### 1st and 2nd columns = cntry codes; 3rd correlation = 1, 2 or -999
      cntry.weight  <- matrix(cntry.weight, ncol=3, byrow=T)
    }else
      cntry.weight <- as.matrix(filenm)
  
  cntry.cor <- cntry.weight
### cntry's no correlated 3rd column= -999
### set = 0 (or NA's), 3rd column for no correlated cntry's 
  cntry.weight[cntry.weight== -999.0000] <- 0
  cntry.cor[cntry.cor== -999.0000] <- NA
### naming the rows with cntry codes
  vec.digits <- nchar(cntry.weight[,1])
  who.cntry.digits <- max(vec.digits)
  rownames(cntry.weight) <- cntry.weight[,1] * 10^who.cntry.digits +
                          cntry.weight[,2]
  rownames(cntry.cor) <- cntry.cor[,1] * 10^who.cntry.digits + cntry.cor[,2]
### eliminates cntry's which are not correlated
  cntry.cor <- na.exclude(cntry.cor)
### done building data records
  fname <- paste(dir, "/", filename, sep="")
  if(savemat)
    save(cntry.cor, file=fname, compress=TRUE)
### use  eval(as.symbol( ff <- load("./tmp/proximity")))    
return(cntry.cor)
}

### INPUT: two directories, datapath and dir, for inpput and output
###        two filenames, fname and codes.names for output and input
###        savemat a boolean to save preprcess fname 
###
### OUTPUT the name of the file, fname, where the G.names, A.names, T.names,  
###        matrix is stored
###
### DESCRIPTION reads the data in codes.names of directory datapath
###             construct a matrix of two columns; one with numeric code
###             (numeric code can be for cntry G, age A, time T), 
###             and the second with the corresponding given name 
###             If savemat=T then saves the matrix under
###             the name fname in directory dir
###
### AUTHOR: Elena Villalon
###         evillalon@iq.harvard.edu
###         IQSS, Harvard University
### Date 01/31/2006
Gnames.file <- function(datapath="~/data", fname= "G.names",
                        codes.names = "cntry.codes.txt", dir="./tmp",
                        savemat=F, cols =c("code", "name"),verb=T)
  {
    verbose <- verb
    filename <-  paste(datapath,"/",codes.names,sep="")
### It uses the NEW file from the data directory!!!
### (Which is separated with one tabulator character)

### quote is neccessary because of Cote d'Ivoire for ex.
    messout(paste("Scanning file...", filename,sep=""),verbose)
    tmp <- try(scan(file=filename,quiet=T,multi.line=T,
                 what=c(integer(0),character(0)), 
                    sep="\t",quote="\""), silent=T)
 
    if(class(tmp)=="try-error")
       tmp <- try(scan(file=filename,what=c(integer(0),character(0)),quiet=T,multi.line=T,
                sep="\t",quote="\"", skip=1), silent=T)
  
 
    tmp <- matrix(tmp,ncol=2,byrow=T)
    tmp <- na.omit(tmp)
    
    cod <- as.integer(tmp[,1])
    tmp[,1] <- cod
    colnames(tmp) <- cols
    fname <- paste(dir, "/", fname, sep="")
    if(savemat)
      save(tmp, file=fname, version=1, compress=TRUE)
### to upload: gg <- load(file="./tmp/G.names")
### eval(as.symbol(gg))
    
    return(tmp)
  }
###
### INPUT: two directories, datapath and dir, for inpput and output
###        two filenames, fname and icodes for output and input
###        savemat boolean to save the preprocess fname
###
### OUTPUT the name of the file, filename, where the index code  scaler 
###        is stored
###
### DESCRIPTION reads the data in fname of directory datapath
###             gets the scalar and saves it 
###             under the name fname in directory dir
###
### AUTHOR: Elena Villalon
###         evillalon@iq.harvard.edu
###         IQSS, Harvard University
### Date 01/31/2006

icode <- function(datapath="~/data", fname= "index.code",
                        icodes = "indexcode.txt", dir="./tmp", savemat =F)
  {
    
    filename <-  paste(datapath,"/",icodes,sep="")
### It uses the NEW file from the data directory!!!
### (Which is separated with one tabulator character)

### quote is neccessary because of Cote d'Ivoire for ex.
  tmp <- scan(file=filename,what=list(" "),quiet=T,nmax=1, multi.line=T)
        
  tmp <- tmp[[1]]
  fname <- paste(dir, "/", fname, sep="")
  if(savemat)
    save(tmp, file=fname, compress=TRUE)
    return(tmp)
  }
