##
## DESCRIPTION:  The driver function, which the user calls with his choice
##               of parameters or globals that initializes the simulation, and the
##               model for the predictions. We save two environmnets, the
##               env.base created inside mortality.driver, and env.who created by
##               the initialization file WHO(). The globals or static variables
##               are shared by all the functions. 
##               It reads arguments of yourcast and pass them to WHO() so that the names
##               are changed internally. It checks dataobj, which is a list   
##               of three elements; the data list whose elements are identified by csid
##               or cntry+code combination and each element is a matrix of rows corresponding
##               to the year series and columns the covariates or dependemnt variable data. 
##               The index.code that explicity indicates the digits for cntry, age and year
##               say ggggaatttt has 4 digits for cntry, two for age and 4 for year.
##               Optionally a matrix with the code-cntry correspondance one for every cntry.
##               For our programs we use dataobj$G.names = geo.names(), defined in build.from.formula. 
##               Parameter sample.frame is a 4 element vector that contains the years of data
##               and prediction, with second elemnt being the yrest dividing the periods 
##               for insample (depvar data use to forecast) and outsample (forecastin years). 
##               Updates env.who with the input globals, if any and then runs the simulation.
##               The formula to apply to the covaraites and dependent variable.
##               Optionally, you may just give a number for sample.frame indicating the
##               yrest dividing insample and outsample since the time series is part of
##               the list element data of dataobj.
##               The userfile where the user may stored the parameters instead of explicitly
##               changing them in the function call.
##               The order of preference is first the arguments stored in userfile and if no
##               file is specified then the arguments of yourcast.  If both dataobj and formula
##               are missing then we will check if the file yourcast.savetmp exists in the current
##               working directory and upload it with the resulst of previous simulation. Those
##               results are preprocessing lists with the depvar insample and outsample and the
##               covariates.  The user may want to use previous results with different models or
##               different parameters related to models only.
##               In addition, dataobj may refer to a file and the data, index.code and, optionally,
##               G.names will be uploaded from the file. Also, the file dataobj may contain just
##               the preprocessing of any previous simulation and then,
##               yourcast will just run the model part. 
##               It chooses the model to forecast with model from either argument of yourcast
##               or the userfile. 
##               Produces the forecast output and plots it with plot.forecast.
##              
##                 
## FORMAT: yourcast(userfile="myfile.R",formula=ff, dataobj=myoject,model="poisson",.... ) 
##
## VALUE:  The forecast object and the graphics
##
## WRITTEN BY: Elena Villalon 
##             evillalon@iqs.harvard.edu
##             IQSS, Harvard University
##
## LAST MODIFIED: 10/14/2005
## 
## 
## ************************************************************************
## ************************************************************************
### loading the libraries first

yourcast <- function(formula=NULL, dataobj=NULL,
                     sample.frame=c(time=1950, 2000, 2001, 2020), 
                     standardize=TRUE, elim.collinear=TRUE,
                     tol=0.9999, solve.tol = 1.e-10,svdtol=10^(-10),
### specific to models
                     model="OLS",
                     ols.sigma.param=list(sigma.bar=1,use.deaths=FALSE,average=TRUE,model.based=FALSE), 
                     zero.mean=FALSE,Ha.sigma=0.3, Ha.sigma.sd= 0.1,
                     Ha.deriv=c(0,0,1),Ha.age.weight=0, Ha.time.weight=0,
                     Ht.sigma=0.3, Ht.sigma.sd=0.1,  Ht.deriv=c(0,0,1),
                     Ht.age.weight=0, Ht.time.weight=0,
                     Hat.sigma=0.2, Hat.sigma.sd=0.1,
                     Hat.a.deriv=c(0,0,1),Hat.t.deriv=c(0,1),
                     Hat.age.weight=0,Hat.time.weight=0, 
                     Hct.sigma=0.3, Hct.sigma.sd =0.1,
                     Hct.t.deriv=1, Hct.time.weight = 0,
                     LI.sigma.mean=0.2,LI.sigma.sd = 0.1, nsample= 500,
                     userfile=NULL, savetmp = T, model.frame=F,
                     debug = F,guirun=NULL)
{
  #USER INPUT ERROR CHECKING
	#Load lpSolve package and print error if it is not available
	if (!require(sma, quietly = TRUE))  {
		stop("The sma package is required.\nInstall it from CRAN.")
	}
     if(length(userfile) > 0)
         cat("Inputs in userfile ", userfile, "takes priority", "\n")
       
          
### previous run of yourcast may be stored in file
  rerun <- "yourcast.savetmp"

###  print(formals(yourcast)$Ha.sigma)
###  print(match.call(yourcast))
###  print(str(match.call(yourcast)))
  
  if(length(dataobj$data) <= 0 && length(formula) <= 0 && 
     !file.exists(rerun) && length(userfile) <= 0)
    stop("Insufficient data")

  if(length(userfile) > 0)
    cat(paste("Parameters in ", userfile,
                " overwrite yourcast arguments.", "\n")) 
    
### some initialization and clean up
  try(rm(env.base, env.who, inherits=T), silent=T);
  
### I'm defining base environment
  env.base <- environment();
  
### for debug = T then make it available as global
  if(debug){
    cat("Setting to mode debugging with the global env.base", "\n")
    env.base <<- env.base
  }
  
##parsing for insample and outsample periods year
  if(length(sample.frame) > 0)
    yrest <- find.yrest(sample.frame)
  else
    yrest <- NULL
  
  year.digits <- nchar(yrest)
  
### get the number of digist for each of cntry, ages and years
### from the time cross sectional identifiers are stored in
### dataobj$index.code, parse it and assign them to env.base
  
  if(length(dataobj$index.code) > 0){
   ix.code <- parse.index.code(icode=dataobj$index.code, yrest)
    assign.number.digits(ix.code, env.base)
  
 }
  
  Hct.c.deriv <-  NULL
  if(length(dataobj$proximity) >0)
    Hct.c.deriv <- dataobj$proximity
   
### check if the user has provided other inputs with reflection
### give the name of the driver and call for the simulation
  
  driver <- match.call()
        
###        print(driver)
  driver <- as.character(driver)
### name of the calling function 
  mortality.driver <- driver[1]
### print(mortality.driver)
### give me its arguments
  
  args  <- names((formals(mortality.driver)))
###        print(args)
  names(args) <- args
### print(args)
###
### is the call coming from the global environment or from a GUI
### if from command line; creates env.who and stored all input data there
  
  if(identical(.GlobalEnv, parent.frame()) && !is.environment(guirun)){
    env.who <- WHO.yourcast(args, env.base)
  }else 
  env.who <- guirun
  
### find out the arguments of yourcast to be added to output 
  callst <- call.yourcast(formlst=formals(mortality.driver),
                          callmatch= match.call())
  
### exclude dataobj (way too big)  
  if(!model.frame){
    ix <- grep("dataobj", names(callst))
    if(length(ix) > 0)
      callst[[ix]] <- "Set model.frame=TRUE to include dataobj"
  }
### tobe added to output
  userfilelst <- NA
  if(length(userfile) > 0)
    userfilelst <- args.userfile(userfile)
###  print(callst)
### finds out the inputs for dataobj, if any.  Process them
### It migth be either a file or an object in memory; assign to env.base
  dataobj <- parse.dataobj(dataobj,env.base)
  
###last check the userfile and if it is not null, then its inputs
### parameters will overwrite the arguments of yourcast
  args1 <- try(get("userfile", env.who), silent=T)

### update args with the user supplied file, if any
  if (class(args1) != "try-error" && !is.null(args1)){
    cat("Updating global with the user file parameters\n")
    update.args(args, userfile, env.base);
    env.who <- WHO.yourcast(args, env.base, env.who)
  }
  
### rownames instead of tagging with years change to
### time cross-sectional id's for consistency with old code
 if(length(dataobj$data) > 0)
   {
     data <- conversion.rownames(dataobj$data, year.digits)
     dataobj$data <- data
    
   }
###sanity checks  
  if(length(unlist(dataobj)) <= 0 && length(formula) <=0 && !file.exists(rerun))
    stop("Insufficient data")
  
### if no dataobject and formula use previous run
### which might be stored in the file yourcast.savetmp
  
  if(length(unlist(dataobj)) <= 0 && length(formula) <=0 )
     dataobj <- parse.dataobj(rerun,env.base)
    
### done with data input check model  
  if(is.character(model))
    model <- trim.blanks(toupper(model))
  
  if(length(formula) > 0)
    {
      log.poiss <- check.depvar(formula)
      assign("log.poiss", log.poiss, env=env.who)
    }
  
### parameters args are stored correctly in env.who;
### bring them locally for easy of computation.
### This will only run if we have dataobj$data and formula
  
  if(length(dataobj) > 0 && !is.character(dataobj))
    {
      
      ind <- grep("lag", formula)
      if(length(ind) > 0){
        lst <-  lagdataobj(formula, dataobj)
        datamat <- lst$datamat
        formula <- lst$ff
        dataobj$data <- datamat
 ###       print(formula)
      
      }
      
      prepross <- input.to.model(datamat=dataobj$data,ff=formula,
                                 all.pow=T, sample.frame,
                                 index.code=dataobj$index.code,
                                 Gnames= dataobj$G.names,  
                                 standard=standardize, elim.collinear,
                                 tol=tol, solve.tol=solve.tol,
                                 log.poiss=log.poiss)
   
      if(class(Hct.c.deriv)!= "try-error" && length(Hct.c.deriv) > 0)
        hc <- Hct.c.deriv
      else 
        hc <- dataobj$proximity
      
      assign.to.env(prepross, model, prox = hc, ewho=env.who);
### if savetmp =T then saves the prepross list return by input.to.model
### into a file in the working directory whose name is given by parameter rerun
      
      if(savetmp)
        save.yourcast.file(rerun, env.base)
    }
  else
    prepross <- NULL
    
 
### runs the model regression analysis 
 
  model <- trim.blanks(toupper(model))
     
### sanity checks 
  if(model=="LS") model <- "OLS"; 
  
  if(model=="BAYES" || model=="MAP")
    {
     
      who.Hct.c.deriv <- get("who.Hct.c.deriv", env=env.who)
      
   
      if(length(who.Hct.c.deriv) <= 0){
        who.Hct.c.deriv <- dataobj$proximity
       
        assign("who.Hct.c.deriv", who.Hct.c.deriv, env=env.who)
      }
    
      if(length(get("who.Hct.c.deriv", env=env.who)) <= 0 ){
      
        stop("You need to provide for proximity matrix")}
    }
   
  m <- switch(model, OLS=ols(env.base),LC=lc(env.base),POISSON=glm.poisson(env.base),
              MAP=cxc(ebase=env.base),
              BAYES=gibbs.sampler(), model="", NULL);
  if (is.null(m))
    stop(paste("Model ",model," is not available"));
  
  
### m contains obj= yhatin, yhatout, insampy, outsampy but listed with csid
### conversion.cntry.mat uses list.by.cntry to convert into country list matrices
### so it is a more useful format for the graphics output.
  
###  m <- conversion.cntry.mat(m);
  model <- model.string()
  
  outy <- yhat.mat(ebase=env.base)
  coeff <- m$coeff
  std <- m$std
  outputlist <- list(yhat=outy,call=callst,userfile=userfilelst,
                     coeff=coeff, sigma=std)
  
  if(get("save.output", env=env.who)  && !is.na(model)){
    cat("Saving output file (option save.output = TRUE", "\n")
    depvar <- leftside.formula(ebase=env.base)
    build.file.output(outputlist,model, depvar);
  }
     
### some formatting for yhat
   
outy <- format.yhat(outy,year.digits)
outputlist$yhat  <- outy


     
return(invisible(outputlist)) 
}

### DESCRIPTION: Takes the list data and ydigits a number
###              The elements of the list data are identified with csid
###              or cross country and age group combo,i.e. 245045 for USA
###              2450 and age = 45. The elements are matrices  
###              of numbers, whose rows names are the years of sample.frame
###              or observation years, i. e. 1985. It combined the the csid
###              tags with the year numbers, i.e. 2450451985, and tags rownames
###              of elements o data with the cross time sectinal idetifiers
###
### AUTHOR Elena villalon
###        IQSS Harvard Univ
###        evillalon@iq.harvard.edu
##########################################################

conversion.rownames <- function(data, ydigits){
  ind <- 1:length(data)
  names(ind) <- names(data)
  data <- lapply(ind, function(n)
                 {
                   mat <- as.matrix(data[[n]])
                   rname <- rownames(mat)
                   csid <- names(ind)[n]
                   nc <- unique.default(nchar(rname))
                   if(length(nc) > 1)
                     stop("Rows of data need to be named consistently")
                   
                   if (nc <= ydigits){
                     rname <- paste(csid, rname, sep="")
                     rownames(mat) <- rname
                   }
                   return(mat)})
}
                     
### DESCRIPTION It takes the inputs of arguments of yourcast and a finds
###             the contents, assigning them to the environmnet that
###             yourcast is using to store the globals.
###
### AUTHOR Elena Villalon
###        IQSS Harvard Univ
###        evillalon@iq.harvard.edu
###################################################

update.args <- function(input.lst,userfile= NULL, ebase=NULL){

  ewho <- get("env.who", env=ebase);
  if(length(userfile) <= 0)
    {
      userfile <- get("userfile", env=ewho)
      filename <- userfile
    }else 
    filename <- read.file.input(userfile, ebase);
  
###  print(filename) 
  if(length(filename) <= 0)
    return(list())

  
  source(file=filename, local=T)
     
  n.input <-  length(input.lst)
  for(i in 1:n.input )
    {
      val <- try(eval(as.symbol(input.lst[i])), silent=T)
      inlsti <- trim.blanks(input.lst[i])
 ###     print(inlsti)
      if(class(val) != "try-error" && inlsti=="sample.frame")
        {
          
          yrest <- find.yrest(sample.frame)
          year.digits <- as.character(nchar(yrest))
       
          assign("yrest", as.numeric(yrest), env=ebase)
          assign("whoyrest", as.numeric(whoyrest), env=ewho)
          assign("year.digits", as.numeric(year.digits), env=ebase)
          assign("who.year.digits", as.numeric(year.digits), env=ewho)
          next; 
        }
      if(class(val) != "try-error" && inlsti =="dataobj")
        {
 ###         print(dataobj)
          dataobj <- parse.dataobj(val, ebase)
          assign("dataobj", dataobj, env=ebase)
         
          if(length(dataobj$index.code) > 0 )
            {
              ix.code <- parse.index.code(icode=dataobj$index.code)
             
                assign.number.digits(ix.code, env.base)
  
            }
          next;
        }
      
      if (class(val)!=  "try-error" && inlsti=="model")
        {
          assign(inlsti, val, env=ebase)
          assign(inlsti, val, env=ewho)
          next; 
        }
      if(class(val) != "try-error" && inlsti=="formula"){
      
        next;
      }
      if(class(val) != "try-error" && inlsti=="savetmp"){
          assign(inlsti, val, env=ebase)
       
          next; 
        }
      if (class(val)!=  "try-error" && !is.null(val))
        {
          ind <- grep(inlsti, ls(env=ewho))
          ch <- ls(env=ewho)[ind]
          assign(inlsti, val, env=ebase)
        }
    }
}
 args.userfile <- function(userfile){  
  
   userfile <- read.file.input(userfile, ebase);
  
###  print(filename) 
  if(length(userfile) <= 0)
    return(list())

  ev <- environment()
   
  source(file=userfile, local=T)
  param <- ls(env=ev)
  lst <- lapply(param, function(ch, ev) {
    val <- try(get(ch, env=ev), silent=T)
    if(class(val)!= "try-error")
      return(val)
    else
      return(NULL)}, ev)
   names(lst) <- param
   ixenv <- grep("ev",names(lst))
   ixuser <- grep("userfile",names(lst))
   ix <- c(ixenv, ixuser)
   lst <- lst[-ix]
   return(lst)}
    
## DESCRIPTION A vector ix.code with 4 elements that are named with the
##             digits parameters names.  Using those names we
##             extract their values and assign them to the environmnets
##             It works in conjuction with parse.index.code
##
## AUTHOR: Elena Villalon
##         IQSS, Harvard Univ
##         evillalon@iq.harvard.edu
##############################################
   assign.number.digits <- function(ix.code, ebase)
    {

    
    

      ewho <- try(get("env.who", env=ebase), silent=T)
      cdigits <- ix.code["cntry.digits"]
      try(assign("cntry.digits", cdigits, env=ebase), silent=T)
      adigits <- ix.code["age.digits"]
      try(assign("age.digits", adigits, env=ebase), silent=T)
      ydigits <- ix.code["year.digits"]
      try(assign("year.digits", ydigits, env=ebase), silent=T)
      dfirst <- ix.code["digit.first"]
      try(assign("digit.first", dfirst, env=ebase), silent=T)
      
      if(class(ewho) != "try-error"){
        assign("who.cntry.digits", as.numeric(cdigits), env=ewho)
        assign("who.age.digits", as.numeric(adigits), env=ewho)
        assign("who.year.digits",as.numeric(ydigits), env=ewho)
        assign("who.digit.first", as.numeric(dfirst), env=ewho)
      }
        
        
      return(list())
    }
### DESCRIPTION if dataobj is either an object or a character string
###             it calls two different functions
###
### AUTHOR Elena Villalon
###        IQSS Harvard Univ
###        evillalon@iq.harvard.edu
###
################################################################

parse.dataobj <- function(dataobj,ebase)
  {
    if(!is.character(dataobj)){
     
      dataobj <- assign.dataobj(dataobj, ebase)
     }         
    if(is.character(dataobj)){
     
      dataobj <- check.for.files(dataobj, ebase)
    }          
    return(dataobj)
  }
### DESCRIPTION It takes different elements of dataobj and defined them
##              or set them to null if they are not defind. Note that
##              both data and index.code need to have some values
## AUTHOR Elena Villalon
##        evillalon@iq.harvard.edu
##
#####################################################################
assign.dataobj <- function(dataobj, ebase)
  {
    
    ewho <- try(get("env.who", env=ebase), silent=T)
    data <- try(dataobj$data, silent=T)
    index.code <- try(dataobj$index.code, silent=T)
    G.names <- try(dataobj$G.names, silent=T)
    A.names <-  try(dataobj$A.names, silent=T)
    T.names <- try(dataobj$T.names, silent=T)
    Hct.c.deriv <- try(dataobj$proximity, silent=T)
    
    if(class(data)=="try-error")
      data <- NULL
    if(class(index.code)=="try-error")
      index.code <- NULL
    if(class(G.names)=="try-error")
      G.names <- NULL
    if(class(A.names)=="try-error")
      A.names <- NULL
    if(class(T.names)=="try-error")
      T.names <- NULL
    if(class(Hct.c.deriv)=="try-error")
      Hct.c.deriv <- NULL
###    print(dim(Hct.c.deriv))
    dataobj$data <- data
    dataobj$index.code <- index.code
    dataobj$G.names <- G.names
    dataobj$T.names <- T.names
    dataobj$A.names <- A.names
    dataobj$proximity <- Hct.c.deriv
    
    return(dataobj)
} 
            
### DESCRIPTION: It finds if userfile is in the working directory
###              or somewhere else
### AUTHOR Elena Villalon
################################################

read.file.input <- function(userfile=NULL, ebase=NULL,
                            datapath=getwd()){
  
  if(length(userfile) <= 0)
    userfile <- get("userfile", env=ebase)
  
  chu0 <- grep("/", userfile) ### for unix

  chw <- NULL
  if(length(grep(":",userfile)) > 0)
    
  chw <- grep("([\\]+)", userfile) ### for windows
  chu <- c(chu0, chw)
  
  look <- (length(chu) <= 0 )
  if(length(userfile) > 0 && look && length(chu0) > 0){
    dir <- datapath
    filename <- paste(dir,"/",userfile, sep="");
    
  }else if(length(userfile) > 0 && look && length(chw) > 0){
    dir <- datapath
    filename <- paste(dir,":\\",userfile, sep="");
 }else if(length(userfile) > 0) 
      filename <- userfile 
  else
    filename <- NULL
  return(filename) 
}

### DESCRIPTION Helper function to yourcast that is used after
###             the preprocessing part of yourcast, input.to.model
###             to put in the environmnets the list elements return
###             with input.to.model and assign to the argument lst.
###             mod stands for model string, and ewho is the environmnet.
### OUTPUT a bunch of assigmnets of variables and parameters needed to
###        run the different regression models.
###
### AUTHOR Elena Villalon
###        IQSS, Harvard Univ
###        evillalon@iq.harvard.edu
#########################################################
assign.to.env <- function(lst, mod, prox, ewho){
 
  whocov <- lst$whocov
  assign("whocov", whocov, env=ewho)
  
  whoinsampx <- lst$whoinsampx
  assign("whoinsampx", whoinsampx, env=ewho)
                
  whoutsampx <- lst$whoutsampx
  assign("whoutsampx", whoutsampx, env=ewho)
  
  whoinsampy <- lst$whoinsampy                 
  whoutsampy <- lst$whoutsampy
  
  assign("whoinsampy", whoinsampy, env=ewho)
  assign("whoutsampy", whoutsampy, env=ewho)
  whopopul <- lst$whopopul
  assign("whopopul", whopopul, env=ewho)
                
  whopopulos <- lst$whopopulos
  assign("whopopulos", whopopulos, env=ewho)
                
  cov.lst <- lst$cov.lst
  assign("cov.lst", cov.lst, env=ewho)
                
  age.vec <- lst$age.vec
  assign("age.vec", age.vec, env=ewho)
                
  cntry.vec <- lst$cntry.vec
  assign("cntry.vec", cntry.vec, env=ewho)
  
  geo.index <- lst$geo.index
  assign("geo.index", geo.index, env=ewho)

  c.vec <- as.character(cntry.vec)
  cntry.names.lst <- sapply(c.vec, function(ch,geo.index) {geo.index[ch]}, geo.index)
  names(cntry.names.lst) <- c.vec
  assign("cntry.names.lst", cntry.names.lst, env=ewho)
  
  log.poiss <- lst$log.poiss
  
  assign("log.poiss", log.poiss, env=ewho)
  
  formula <- lst$formula
  assign("formula", formula, env=ewho)
 
  assign("who.Hct.c.deriv", prox, env=ewho)
  who.Hct.c.deriv <- get("who.Hct.c.deriv", env=ewho)

  
   
}
### DESCRIPTION Given a formula for the simulation such as
###             log(depvar) ~ tobacco.txt + time + gdp.txt^3 or
###             depvar ~ tobacco.txt + time + gdp.txt^3 or
###             It splits it into the r-h-s and l-h-s
###             Finds out if the left-hand-side is the log of depvar
###             and assign values T or F to log.poiss accordingly
###
### AUTHOR Elena Villalon
###        IQSS Harvard Univ
###        evillalon@iq.harvard.edu
##################################################################
check.depvar <- function(formula)
  {
    fc  <- as.character(formula)
    ls  <- fc[2]
  
         ch <- sub("log\\(([a-z A-Z / \\. *]+)+\\)","\\1", ls) ### from "log(gdp)" to "gdp"
 ###   ch <-  sub("([a-z A-Z \\.]+)\\(([a-z A-Z / * \\+ \\. 0-9]+)+\\)","\\2",ls)
 
    log.poiss <- ifelse(nchar(ls) > nchar(ch), T, F)
  
    return(log.poiss)
  }
    
### DESCRIPTION It takes a filename and an environment
###             and load the filename locally. It checks what is
###             in the file.  The vector input.lst contains the lists
###             of the preprocessing part of yourcast.  If the information is in
###             obj or, unless, enough information for the basic lists needed
###             by the programs we just pass that to the environments
###             and return obj (the input).  If we do not have all information but we
###             provide for whoinsampy, whoutsampy, whoinsampx, whoutsampx
###             whopopul, whopopulos, then we reconstruct with them the rest
###             of thew lists needed by yourcast.
###             If none of those lists are provided we do some error checking
###             to make sure that dataobj is in the file and that the names of
###             the list elements correspond to "data" and "index.code" as a minimum.
###             After  all error checking is completed then we assign dataobj
###             and index.code to the environments and returns the object dataobj.
###
### INPUT       the obj which is a filename with inputs list and the environmnet
###
### OUTPUT      If obj file contains some of the preprocessing stuff that
###             yourcast needs, returns the file name itself obj after assigning
###             all lists in obj to the environments.
###             If obj contains the dataobj list input argument of yourcast, then\
###             it parses it and assign "data", and "index.code" to environments,
###             and return the object list dataobj.
###
### AUTHOR      Elena Villalon
###             IQSS, Harvard Univ
###             evillalon@iq.harvard.edu
##############################################################################


check.for.files <- function(obj, ebase)
  {
    ewho <- get("env.who", env=ebase)
    ev <- environment()
    load(obj, env=ev)
###    print(ls(env=ev))
   
    input.lst <- c("whoinsampx", "whoutsampx", "whoinsampy",
                   "whoutsampy", "whopopul", "whopopulos","whocov",
                   "cov.lst","age.vec", "cntry.vec", "geo.index",
                   "log.poiss", "formula", "who.Hct.c.deriv")
 
   
    ln <- length(input.lst)
    for(n in 1:ln)
      {     
        ch <- input.lst[n]
        val <- try(eval(as.symbol(ch)), silent=T)
        
        if(class(val)!="try-error"  && n <=6 )
          assign(ch, val, env=ewho)
        else if (n <= 6)
          break;
        
        if(class(val)=="try-error"  && n ==7){
          whocov <- build.whocov(ewho)
          assign("whocov", whocov, env=ewho)
         
          next;
        }else if (n==7){
          assign(ch, val, env=ewho)
          next;
       }
        
        if (class(val)=="try-error"  && n ==8){
          whoinsampx <- get("whoinsampx", env=ewho)
          cov.lst <- list.covariates(whoinsampx)
          assign("cov.lst", cov.lst, env=ewho)
          next;
        }else if(n==8){
          assign(ch, val, env=ewho)
          next;
        }
        
        if(class(val)=="try-error" && n == 9){
          age.vec <- build.age.cntry.vec(ebase)$age.vec
          assign("age.vec", age.vec, env=ewho)
          next;
        }else if(n==9){
          assign(ch, val, env=ewho)
          next; 
        }
        
        if (class(val)=="try-error" && n == 10){
          cntry.vec <- build.age.cntry.vec(ebase)$cntry.vec
          assign("cntry.vec", cntry.vec, env=ewho)
          next;
        }else if(n==10){
          assign(ch, val, env=ewho)
          cntry.vec <- val
          next;
       }
     
        if (class(val)=="try-error" && n == 11){
     
          val <- NULL
          assign(ch, val, env=ewho)
          next;
       }else if(n==11 ){
     
          c.vec <- as.character(cntry.vec)
          
          assign(ch, val, env=ewho)
          geo.index <- val
          if(length(geo.index) > 0){
            cntry.names.lst <- sapply(c.vec,
                                      function(ch,geo.index) {geo.index[ch]}, geo.index)
          
          }else
            cntry.names.lst <- rep(" ", length(c.vec))
          
          names(cntry.names.lst) <- NULL
          names(cntry.names.lst) <- as.character(c.vec)
          assign("cntry.names.lst", cntry.names.lst, env=ewho)
          next; 
        }
        if(class(val) != "try-error")       
          assign(ch, val, env=ewho)
        else
          assign(ch, NULL, env=ewho)
       
      }
   
    if(n >= ln){
      cat("Reading parameters from file... ", obj,"\n")
###                "\nIgnoring yourcast arguments that are not model specific and ", 
###                "are not in the userfile", "\n"))
###      print(ls(env=ev))
###      print(dim(who.Hct.c.deriv))
     
      digits <- age.cntry.digits(age.vec, cntry.vec, ebase)
      assign("age.digits", as.numeric(digits$age.digits), env=ebase)
      assign("cntry.digits", as.numeric(digits$cntry.digits), env=ebase)
      assign("digit.first", as.numeric(digits$digit.first), env=ebase)
      assign("who.age.digits", as.numeric(digits$age.digits), env=ewho)
      assign("who.cntry.digits", as.numeric(digits$cntry.digits), env=ewho)
      assign("who.digit.first", as.numeric(digits$digit.first), env=ewho)
      assign("who.Hct.c.deriv", who.Hct.c.deriv, env=ewho)
      assign("Hct.c.deriv", who.Hct.c.deriv, env=ebase)
      return(obj)
    }
    
    if(class(try(dataobj$proximity, silent=T))!= "try-error"){
        assign("who.Hct.c.deriv", dataobj$proximity, env=ewho)
        assign("who.Hct.c.deriv", dataobj$proximity, env=ebase)
      }
       
    
    dataobj <- try(eval(as.symbol("dataobj")), silent=T)
    
    if(class(dataobj) == "try-error")
      stop("Insufficient data")
### checks if data and index.code are in dataobj list         
    nmobj <- names(dataobj)
    if(length(nmobj) < 2)
      stop("Insufficient data")
    
    vec <- c("data", "index.code")
    logic <- all(is.element(vec, nmobj))
    if(!logic)
       stop("Insufficient data")
   
    dataobj <- assign.dataobj(dataobj, ebase)
    index.code <- dataobj$index.code
###parsing the index.code for the relevant digits
    ix.code <- parse.index.code(icode=dataobj$index.code, yrest=NULL)
    assign.number.digits(ix.code, ebase)    
            
    return(dataobj)     
  }

### DESCRIPTION finds the number of digist for age, country and years
###             using vectors age.vec and age.vec, and assign them to environmnets
###             It also creates a list with them to return with function call
### Author Elena Villalon
###        IQSS, Harvard Univ
###        evillalon@iq.havard.edu
##################################################################
age.cntry.digits <- function(age.vec, cntry.vec, ebase)
  {
    ewho <- get("env.who", env=ebase)
    age.digits <- max(as.numeric(unlist(sapply(as.character(age.vec), nchar))))
    age.digits <- as.numeric(age.digits)
    assign("who.age.digits", as.numeric(age.digits), env=ewho)
    cntry.digits <- max(as.numeric(unlist(sapply(as.character(cntry.vec), nchar))))
    cntry.digits <- as.numeric(cntry.digits)
    assign("who.cntry.digits", as.numeric(cntry.digits), env=ewho)
    nm <- names(get("whoinsampx", env=ewho))[1]
   
    digit.first <- nchar(nm) - age.digits - cntry.digits
    assign("who.digit.first", digit.first, env=ewho)
    if( digit.first < 0)
      digit.first <- 0
    assign("who.age.digits", age.digits, env=ewho)
    lst <- list(age.digits=age.digits, cntry.digits=cntry.digits, digit.first=digit.first)
    return(lst)
  }
### DESCRIPTION from sample.frame takes the year that divides
###             the insample and outsample perios called yrest and return it
### AUTHOR Elena Villalon
###        IQSS, Harvard Univ
###        evillalon@iq.harvard.edu
##########################################################

 find.yrest <- function(sample.frame)
    {
      if(length(sample.frame) == 1)
        yrest <- sample.frame
      else if(length(sample.frame)==4)
        yrest <- ifelse(try(sample.frame[2], silent=T) != "try-error", sample.frame[2], NULL)
      else
        stop("Wrong input data for sample.frame")
      return(yrest)
    }

### DESCRIPTION takes as argument the name rerun of the temp file to save
###             preprocessing lists and parameters of yourcast in the file rerun
###             Elements toi be saved are the insample and outsample periods
###             for dependent variable and covariates
###
### AUTHOR Elena Villalon
###        IQSS, Harvard Univ
###        evillalon@iq.harvard.edu
##################################################################
save.yourcast.file <- function(rerun, ebase = env.base){
  ebase <- get("env.base", env=parent.frame());
  env.base <- ebase
 
### get the environment where data is located
  ewho <- get("env.who", env=ebase)
 
### create the blank file to store data for directory: whooutpath
  filename  <-  rerun;
  filename  <- paste(getwd(),"/", filename,sep="")
  
  if (file.exists(filename)){
    file.remove(filename)}
  file.create(filename)
### name for present enviroment:
  esave <- environment()
    
### what to store in filename:   
    what <- c("whocov","whoinsampx", "whoutsampx", "whoinsampy","whoutsampy", 
              "whopopul","whopopulos", "cov.lst", "age.vec", "cntry.vec","geo.index", 
              "cntry.names.lst", "log.poiss", "formula", "who.Hct.c.deriv") 

   
### write those values in present environment esave

    for (i in 1:length(what)){
      wi <- try(get(what[i], env=ewho, inherits=T), silent=T)
     
      assign(what[i],wi, env=esave)
    }
  
   
 
### better to find what to exclude
### name of environments that start with "e":    
    ind.ex <- match(ls(env=esave,patt="^e"), ls(env=esave))
    ind.ex <- c(ind.ex,  match("filename", ls(env=esave)))
    ind.ex <- c(ind.ex, match("what", ls(env=esave)))
    ind.ex <- c(ind.ex, match("ch", ls(env=esave)))
    ind.ex <- c(ind.ex, match("^esave$", ls(env=esave)))
    ind.ex <- c(ind.ex, match("^ebase", ls(env=esave)))
    ind.ex <- c(ind.ex, match("^ev", ls(env=esave)))
    ind.ex <- c(ind.ex, match("^ewho", ls(env=esave)))
  
### indeces that start with "ind":
    ind.ex <- c(ind.ex, match(ls(env=esave, patt="^ind"), ls(env=esave)))
    ind.ex <- na.omit(ind.ex)
### now save everything in env= esave but variables in [indx.ex]:
###   save(list=ls(env=esave)[-ind.ex], file=filename,compress=T)
### Safer to save what you need
      
     save("whocov","whoinsampx", "whoutsampx", "whoinsampy","whoutsampy", 
          "whopopul","whopopulos", "cov.lst", "age.vec", "who.Hct.c.deriv", 
          "cntry.vec","geo.index", "cntry.names.lst", "log.poiss","formula",   
          file=filename,compress=T)

  cat(paste("The size of ", filename, " is = ", file.info(filename)$size, "\n"))
}

#### DESCRIPTION Takes whoinsampx and whoutsampx and joins
###              them together to form whocov that contains
###              the insample and outsample periods for the covariates
###
### AUTHOR Elena Villalon
###        IQSS Harvard Univ
###        evillalon@iq.harvard.edu
###################################################################
build.whocov <- function(ewho=NULL, whoinsampx=NULL, whoutsampx=NULL){
  if(length(ewho)>0){ 
    whoinsampx <- get("whoinsampx", env=ewho)
    whoutsampx <- get("whoutsampx", env=ewho)
  }
  ind <- 1:length(whoinsampx)
  names(ind) <- names(whoinsampx)
  whocov <- lapply(ind, function(n){
    inmat <- whoinsampx[[n]]
    outmat <- whoutsampx[[n]]
    mat <- rbind(inmat, outmat)
    return(mat)})
  return(whocov)
}

#### DESCRIPTION Takes number of digits for cntry, age, and the insampy list
###              and reconstruct the vectors of age and cntry for sample data 
###
### AUTHOR Elena Villalon
###        IQSS Harvard Univ
###        evillalon@iq.harvard.edu
###################################################################
build.age.cntry.vec <- function(ebase){
  cdigits <- get("cntry.digits", env=ebase)
  adigits <- get("age.digits", env=ebase)
  fdigit <- get("digit.first", env=ebase)
  st <- cdigits + 1 + adigits
  whoinsampx <- get("whoinsampx", env=get("ewho", env=ebase))
  tag <- names(whoinsampx)
  age.vec  <- unique.default(unlist(sapply(tag, substring, fdigit + cdigits+1, st)))
  cntry.vec <- unique.default(unlist(sapply(tag,substring, fdigit + 1,cdigits)))
  lst <- list(age.vec = age.vec, cntry.vec = cntry.vec)
  return(lst)
}

### DESCRIPTION Takes two arguments from a fuction call, such as
### yourcast(par1=1, par2=2,...,parn=n). The first argument formlst
### are the formals of the function call: formals(yourcast); and
### the second argument callmath is = match.call(yourcast).
### The formals arguments gives a list of the defaults parameters
### of the function call.  The match.call returns, in language, the
### actual function call for the run with the new values, if any,
### assign t the parameters of the function, yourcast(model="ols").
### We find the new values assign to the arguments of the function call
### and substitute the new values in the formals list.  Those that are
### redefined remains with their defaults values. Return the modified
### formals list with new arguments for those parameters included in
### the function call for the run.
###
### AUTHOR Elena Villalon
###        IQSS, Harvard Univ
###        evillalon@iq.harvard.edu
####################################################################


 call.yourcast <- function(formlst, callmatch)
    {
      cm  <- as.character(callmatch)
      nmf <- names(formlst)
      nmc <- names(callmatch)
      ind <- 1:length(formlst)
      names(ind) <- names(formlst)
      
      modform <- lapply(ind, function(n){
        val <- formlst[[n]]
        nm  <- nmf[n]
        ix  <- grep(nm, nmc)
        if(length(ix) > 0)
          return(as.character(callmatch[ix]))
        else
          return(val)})
      
      modform <- lapply(modform,function(ch){
        if(!is.character(ch))
          return(ch);
        
        ix <- grep("[0-9]+", ch)
        ix1 <- grep("[\\( , a-z A-Z \)]+", ch)
        if(length(ix) > 0 && length(ix1) <=0)
           return(as.numeric(ch))
        
### converting the string "c(1, 2, 3)" to regular vector
        if(length(ix)){
          ##getting rid of c and parenthesis
          noandcom <- gsub("[c \\(  \\)]+", "", ch)
          chno <- strsplit(noandcom,",")[[1]]
          return(as.numeric(chno))
        }
        return(ch);
      } )
    }
               
dataobj.load <- function(env = NULL){
  ev <- env
  if(length(env) <= 0)
    ev <- parent.frame()
  
   load(url("http://gking.harvard.edu/yourcast/dataobj.dat"), env=ev)
}

dataobj <- function(){
  load(url("http://gking.harvard.edu/yourcast/dataobj.dat"), env=environment())
return(invisible(dataobj))
}
### DESCRIPTION it takes the list yhat and rename the rownames with the
### year digits ony, say we have "--2450451989" then convert it to "1989"
### INPUT: list yhat with elements csid and ecah is a matrix of two columns
###        whose names are the csid cross time series identifiers
###        Convert it to time series, y substracting the cross-sectional id
### OUTPUT: the same list with the new rownames that only have years
### Elena Villalon
### evillalon@iq.harvard.edu    

    format.yhat <- function(y, ydg)
  {
    
    y <- lapply(y, function(mat, ydg) {
      vec <- rownames(mat)
      
   ##take away leading and trailing "-"   
      vec <- sapply(vec, function(mm) {
        mm <- sub("(^[-]*)", "", mm)
        mm <- sub("([-]*$)", "", mm)
        return(mm)})
   ##obtain the years digits   
      vec <- sapply(vec, function(x){
        nc <- nchar(x)
        ly <- nc - ydg + 1
        sb <- x 
        if( ly > 0)
          sb <- substring(x, ly)
        return(sb)})
   ##rename the rownames   
      vec <- unlist(vec)
      rownames(mat) <- vec
      return(mat)}, ydg)
     return(y)
  }
