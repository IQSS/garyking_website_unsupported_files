

##
## USED GLOBALS: env=env.base, our base environment,is now the environment for yourcast()
##               that wraps up all programs and functions, and also drives the simulation.
##               Also, env=env.who (an environment), which we create to store all
##               static variables to be shared by functions and programs.  
##               We assign env.who to the env.base, assign("env.who", env=env.base)
##               if you want to see what is in env.who:  >  ls(env=get("env.who", env=env.base));
##
## USED: make.output.filename()
##
## DESCRIPTION:  The output from different models, i.e. "LC", "OLS", "POISSON", and "CXC"
##               is stored in the list "lst.output", which is also in envr= env.who  
##               The length of the list and elements depend on the model used for the predictions.
##               We retreive with get the lst.output and put it in the environment inside
##               esave of build.file.output; and after that save lst.output in the filename. 
##
## FORMAT: build.file.output(ebase=env.base);   build.file.output()  
##
## VALUE:  store in filename the outputs from different models, i.e. yhatin, yhatout
##         for the predicted values of mortality in the insample and outsample periods
##         Also, insampy and outsampy for the actual data in the insample and outsample.
##         Other paramters which are modeled specific 
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu,
##             CBRSS, Harvard University
##
## LAST MODIFIED: 11/12/2003
## 
## 
## ************************************************************************
## ************************************************************************
build.file.output <- function(lst= NULL, ebase=env.base){
  ebase <- get("env.base", env=parent.frame());
  ewho <- get("env.who", env=ebase);
  env.base <- ebase
  whooutpath <- get("whooutpath", env= ewho)
  if(length(lst) <= 0)
    lst <- get("lst.output", env=ewho, inherits=T)
  whomodel <- get("whomodel", env=ewho)
  whodisease <- get("whodisease", env=ewho)
  whogender <- get("whogender", env=ewho)
  cntry.vec <- get("cntry.vec", env=ewho)
  
  if(! is.na(whomodel) &&
     ( whomodel == "LC" || whomodel=="OLS" || whomodel== "POISSON" || whomodel =="MAP"|| whomodel=="BAYES" ) ){
    coeff <- lst$coeff
    yhatin <- lst$yhatin
    yhatout <- lst$yhatout
    std <- lst$std }
    
### create the blank file to store data for directory: whooutpath

  filename  <-  make.output.filename(whomodel, whodisease,whogender);
  filename  <- paste(whooutpath,filename,sep="")
  if (file.exists(filename)){
    file.remove(filename)}
    file.create(filename)
### name for present enviroment:
    esave <- environment()
### 
### what to store in filename:
###
   n.lst <- length(names(lst))
   for(i in 1:n.lst)
     assign(names(lst)[i], lst[[i]],env=esave)
### save globals as well
### what to store in filename:
 
    what <- c("whodisease","whogender","whoyrest","age.vec","whomodel", 
              "cntry.vec","cntry.names.lst")

### get values of elements of what from env= ewho
### write those values in present environment esave

    for (i in 1:length(what))
      assign(what[i],get(what[i], env=ewho, inherits=T), env=esave)
    
### what we do not want in the output file
  ind.ex <- match(ls(env=esave, patt="^e"), ls(env=esave))
  ind.ex <- c(ind.ex, match("whooutputpath", ls(env=esave)))
  ind.ex <- c(ind.ex,  match("filename", ls(env=esave)))
  ind.ex <- c(ind.ex, match("$lst", ls(env=esave)))
  indx.ex <- c(ind.ex, match("$what", ls(env=esave)))
  indx.ex <- c(indx.ex,match("^esave$", ls(env=esave)))
  indx.ex <- c(indx.ex, match("^i$", ls(env=esave)))
  indx.ex <- c(indx.ex, match("^ind", ls(env=esave)))
  indx.ex <- c(indx.ex, match("lst$", ls(env=esave)))
###  save into file the model output
###  save(list=ls(env=esave)[-ind.ex], file=filename, compress=T );
### It looks safer to save what you need only since no mistake
   depvar <- whodisease
   strata <- ifelse(whogender==2,"m", "f")
   yrest <- whoyrest
   model <- model.string(); 
   cntry.lst <- cntry.names.lst
   save("depvar","strata","yrest","model", "age.vec", 
        "cntry.lst","coeff", "yhatin", "yhatout",
        "std", "insampy","outsampy",
        file=filename, compress=T);
  
### this also save the environmnet esave with all in it 
###  save(esave,file=paste(whooutpath,"evenv",sep=""), compress=T, env=esave); 
}


 make.output.filename <- function(whomodel,whodisease,whogender){
  gender <- ifelse(whogender==2,"male","female")
  return(paste(whodisease,"_",whogender,"_", whomodel,".dat",sep=""));
}


##
## USED GLOBALS: env=env.base, our base environment,is now the environment
##               for mortality.driver(), which wraps up all programs and
##               functions and drives the simulation. 
##               Also, env=env.who (an environment), which stores all static or global.  
##               
## USED:
##
## DESCRIPTION:  We search for userfile in the arguments of mortality.driver()
##               If the length(userfile) > 0 (not null), then find out where
##               the file is located (directory or user working space)
##                 
## FORMAT: build.file.input(ebase=env.base) 
##
## VALUE:  store in filename from user input parameters to mortality.driver
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu,
##             CBRSS, Harvard University
##
## LAST MODIFIED: 11/12/2003
## 
## 
## ************************************************************************
## ************************************************************************
##
build.file.input <- function(ebase=env.base){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase
  userfile <- get("userfile", env=ebase)
  chu <- grep("/", userfile)
  look <- (length(chu) <= 0 )
  if(length(userfile) > 0 && look){
      dir <- getwd()
      filename <- paste(dir,"/",userfile, sep="");
 }else if(length(userfile) > 0) 
      filename <- userfile 
  else
    filename <- NULL
  return(filename)
}
##
## USED GLOBALS: env=env.base, our base environment,is now the environment
##               for mortality.driver(), which wraps up all programs and
##               functions and drives the simulation. 
##               Also, env=env.who (an environment), which stores all static and global.
##               The filename, which should be a script in the R language. 
##               
## USED:   update.WHO(input.lst)
##
## DESCRIPTION: overwrite the static variables in env.who with the user choices
##              of new variables in the userfile of the args(=input.lst)
##              of yourcast (the driver)
##
## FORMAT: update.WHO(input.lst, ebase=env.base) 
##
## VALUE:  updates the system parameters provided with  namelists(),with the users values 
##         and stores them in the static envir=env.who
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu,
##             CBRSS, Harvard University
##
## LAST MODIFIED: 11/12/2003
## 
## 
## ************************************************************************
## ************************************************************************
        
update.WHO <- function(input.lst,ebase=env.base){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase
  ewho <- get("env.who", env=ebase);
  userfile <- get("userfile", env=ebase)
  if( length(userfile) > 0 ){
   filename <- build.file.input(env.base);
  }else{
    filename = NULL;}
  
  if(length(filename) > 0){
     source(filename, local=T)

  n.input <-  length(input.lst)
  for(i in 1:n.input ){
     val <- try(eval(as.symbol(input.lst[i])), silent=T)
      if (class(val)!= "try-error" && !is.null(val))
        assign(input.lst[i], val, env=ewho)}
 
   }
}

### Same as update.WHO but takes arguments of mortality.driver and updates
### the global parameters if their entry in non null.

args.mortality.driver <- function(input.lst, ind=2,ebase=env.base)
  {
   ebase <- get("env.base", env=parent.frame())
   env.base <- ebase
   ewho <- get("env.who", env=ebase)
   n.input <-  length(input.lst)
   vec <- ind:n.input
    for(i in vec){
      val <- get(input.lst[i], env=env.base,inherits=T)
    
      
      if(length(val) > 0)
      assign(input.lst[i], get(input.lst[i], env=env.base, inherits=T), env=ewho)}
     
 
  }


## USED GLOBALS: env=env.base, our base environment,is now the environment
##               for mortality.driver(), which wraps up all programs and
##               functions and drives the simulation. 
##               Also, env=env.who (an environment), which stores all static or global.  
##               
## USED:         mortality.driver
##
## DESCRIPTION:  The static variables outproducts of make.mortality.data are 
##               stored in env.who.  They described the data sets for particular
##               choices of counties and ages.  The paratmeters are retreived
##               from en.who and put into a list.
##                 
## FORMAT: mortality.data(ebase=env.base); mortality.data() 
##
## VALUE:  object store in a list; mortality.driver choice of preprocessin results
##         with no forecasts will output the object
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu,
##             CBRSS, Harvard University
##
## LAST MODIFIED: 11/18/2003
## 
## 
## ************************************************************************
## ************************************************************************
##
mortality.data <- function(ebase=env.base){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase
  ewho <- get("env.who", env=ebase);
  cntry.names.lst <- get("cntry.names.lst", ewho);
  age.vec <- get("age.vec", env=ewho);
  whocov <- get("whocov", env=ewho);
  whoinsampy <- get("whoinsampy", env=ewho);
  whopopul <- get("whopopul", env=ewho);
  whoutsampy  <- get("whoutsampy",env=ewho);
  whopopulos  <- get("whopopulos",env=ewho);
  whodisease <- get("whodisease", env=ewho)
  whogender <- get("whogender", env=ewho)
  whoyrest <- get("whoyrest", env=ewho)
  gender.str <- ifelse(whogender==2, "m", "f")
  lst <- list(disease=whodisease,gender=gender.str,yrest=whoyrest,
              age.vec=age.vec,cntry.names=cntry.names.lst,
              insampy=whoinsampy,insampopul=whopopul,
              outsampy = whoutsampy, outsampopul= whopopulos);
  return(lst)}

  
## ************************************************************************
## ************************************************************************
##
##
## IMPORTED:        global outputs from make.mortality.data &
##                  some input parameters from WHO.R
##
## DESCRIPTION:     creates file whoutpath to store globals and parameters
##
##
## INPUT:           globals & parameters
##
## OUTPUT:          file whoutpath with values 
##
## WRITTEN BY: Elena Villalon & Federico Girosi 
##             evillalon@latte.harvard.edu; fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 04/24/2003
## 
## ************************************************************************
## ************************************************************************

### SAVE.DATA.FILES

save.data.files <- function(ebase = env.base){
 ebase <- get("env.base", env=parent.frame());
 env.base <- ebase
### get the environment where data is located
    ewho <- get("env.who", env=ebase)
    whooutpath <- get("whooutpath", env= ewho)
### create the blank file to store data for directory: whooutpath
  filename  <-  make.data.filename(ebase);
  filename  <- paste(whooutpath,filename,sep="")
  if (file.exists(filename)){
    file.remove(filename)}
  file.create(filename)
### name for present enviroment:
    esave <- environment()
 
### what to store in filename:   
    what <- c("whodisease","whogender","whocovariates",
              "cov","whofore","whoyrest",
              "wholag","population","whousercntrylist",
              "whouserages","whoskip","whostandardize","whotransform",   
              "whodatapath","whooutpath","whocovpath","whopriorpath","whocov","whocovid","whoinsampy",
              "whoinsampid","whopopul","whoinsampx","whoutsampy",
              "whoutsampid","whopopulos","whoutsampx","cntry.vec","age.vec",
              "digit.cntry.begin","digit.cntry.end","digit.age.begin","digit.age.end",
              "digit.year.begin","digit.year.end", "n.cntry","n.age",
              "list.covariates", "cntry.names.lst")

### get values of elements of what from env= ewho
### write those values in present environment esave

    for (i in 1:length(what))
      assign(what[i],get(what[i], env=ewho, inherits=T), env=esave)
    
### better to find what to exclude
### name of environments that start with "e":    
    ind.ex <- match(ls(env=esave,patt="^e"), ls(env=esave))
    ind.ex <- c(ind.ex, match("whooutputpath", ls(env=esave)))
    ind.ex <- c(ind.ex,  match("filename", ls(env=esave)))
    ind.ex <- c(ind.ex, match("what", ls(env=esave)))
    ind.ex <- c(ind.ex, match("ch", ls(env=esave)))
    ind.ex <- c(ind.ex, match("^esave$", ls(env=esave)))
### indeces that start with "ind":
    ind.ex <- c(ind.ex, match(ls(env=esave, patt="^ind"), ls(env=esave)))
### now save everything in env= esave but variables in [indx.ex]:
###  save(list=ls(env=esave)[-ind.ex], file=filename,compress=T)
### Safer to save what you need
      
     save("whodisease","whogender","whocovariates",
          "cov","whofore","whoyrest",
          "wholag","population", "whousercntrylist",
          "whouserages","whoskip","whostandardize","whotransform",   
          "whodatapath","whooutpath","whocovpath","whopriorpath",
          "whocov","whocovid","whoinsampy",
          "whoinsampid","whopopul","whoinsampx","whoutsampy",
          "list.covariates", "cntry.names.lst", 
          "whoutsampid","whopopulos","whoutsampx","cntry.vec","age.vec",
          "digit.cntry.begin","digit.cntry.end","digit.age.begin","digit.age.end",
          "digit.year.begin","digit.year.end", "n.cntry","n.age",file=filename,compress=T)

#  print(paste("The size of ", filename, " is = ", file.info(filename)$size))
}


#####################################################################################


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      make.data.filename
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: whogender,whodisease
##
## DESCRIPTION: It returns the file name where data are stored
##
## FORMAT:  filename  <- make.data.filename()
##
## VALUE: the filename contains both the cause of death and the gender
##        example: data_allc_3.dat
##
## WRITTEN BY: Federico Girosi 
##             fgirosi@latte.harvard.edu, anitag@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

make.data.filename <- function(ebase=env.base){
 ebase <- get("env.base", env=parent.frame());
 env.base <- ebase
  ewho <- get("env.who", env=ebase)
  whodisease <- get("whodisease", env=ewho)
  whogender <- get("whogender", env=ewho)
  gender <- ifelse(whogender==2,"male","female")
  return(paste("data_",whodisease,"_",whogender,".dat",sep=""));
}

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      conversion.cntry.mat
##
## 
## IMPORTED functions: list.by.cntry
##
## USED GLOBALS: environments (env.base, env.who or aliases ebase, ewho)
##               the object outputs from models (LC, OLS, POISSON, CXC)
##
## DESCRIPTION: The object outputs contain yhatin, yhatout,insampy,outsampy
##              They are listed by csid or cntry+age combinations,
##              so that they are 1 col matrices with rows=no of years.  
##              We use list.by.cntry to obtain the listing for every
##              country, which are TxA matrices with rows = no of years, and
##              cols= age groups.  This is the output which is needed
##              for the graphics.  
##
## FORMAT:  filename  <- conversion.cntry.mat(obj=lst.output)
##
## VALUE: the object output with yhatin, yhatout, insampy, outsampy
##        listed by cntry, i.e. list elements are TxA matrices for evry cntry
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu, 
##             CBRSS, Harvard University
##
## Date: 12/09/2003
## 
## ************************************************************************
## ************************************************************************

conversion.cntry.mat <- function(obj=NULL, ebase=env.base){
### I do not think that we need to check for obj and environmnets
### since obj will be passed when we call the function, but
    ebase <- get("env.base", env=parent.frame())
    env.base <- ebase
    ewho <- get("env.who", env=ebase)
    whomodel <- get("whomodel", env=ewho)
    if(length(obj) <= 0)
      obj <- get("lst.output", env=ewho)
### obj should come when the function is called.
  insampy  <- obj$insampy
  outsampy <- obj$outsampy
  obj$insampy  <- list.by.cntry(insampy)
  obj$outsampy <- list.by.cntry(outsampy) 
if(!is.na(whomodel)){
    yhatin   <- obj$yhatin
    yhatout  <- obj$yhatout
### list.by.cntry needs the env.who
    obj$yhatin   <- list.by.cntry(yhatin)
    obj$yhatout  <-  list.by.cntry(yhatout)
  }else{
    obj$whopopul <- list.by.cntry(whopopul)
    obj$whopopulos <- list.by.cntry(whopopulos)}
  assign("lst.output",obj,env=ewho)
  return(obj)}


append.file.extension <- function(comp, datapath=data.path)
  {
    indtxt <- grep("\\.txt", comp)
    indcsv <- grep("\\.csv", comp)
   
    if(length(indtxt) > 0 || length(indcsv) > 0)
      return(comp)
    
    ix <- grep("\\(", comp)
    if(length(ix) <= 0)
      {
        comptxt <- paste(comp,".txt", sep="")
        compcsv <- paste(comp,".csv", sep="")
        filetxt <- paste(getwd(), "/", datapath, comptxt,sep="")
        filecsv <- paste(getwd(), "/", datapath, compcsv,sep="")
      }else{
        comptxt <- paste(strsplit(comp, "\\)")[[1]][1],".txt", ")",
                         na.omit(strsplit(comp, "\\)")[[1]][2]), sep="")
        compcsv <- paste(strsplit(comp, "\\)")[[1]][1],".csv", ")",
                         na.omit(strsplit(comp, "\\)")[[1]][2]), sep="")
        crtxt <- strsplit(strsplit(comptxt,"\\(")[[1]][2],"\\)")[[1]][1]
        crcsv <-  strsplit(strsplit(compcsv,"\\(")[[1]][2],"\\)")[[1]][1]
        filetxt <- paste(getwd(), "/", datapath, crtxt,sep="")
        filecsv <- paste(getwd(), "/", datapath, crcsv,sep="")
      }
        
       if(file.exists(filetxt))
      return(comptxt)
   
    if(file.exists(filecsv))
      return(compcsv)
   
    stop(message=paste("File ",comp, " does not exist in the data directory"))
  }

find.extensions <- function(vec, dpath = data.path)
  {

      if(length(vec) <= 0){
        vec <- NA
        return(vec)}
      
      boolcnst <- F
      ind <- grep("cnst", vec)
      if(length(ind) > 0){
        vec <- vec[-ind]
        boolcnst <- T
      }
      
      booltime <- F
      ind <- grep("time", vec)
      if(length(ind) > 0){
        vec <- vec[-ind]
        booltime <- T
      }
      
      nm <-  names(vec)
      if(length(nm) <= 0 ){
        vec 
        vec <- sapply(vec, FUN=append.file.extension, dpath)
        vec <- unlist(vec)
        names(vec) <- NULL
        if(boolcnst)
          vec <- c(vec, "cnst")
        if(booltime)
          vec <- c(vec, "time")
        
        return(vec)
      }
      nm.extends <-  sapply(nm, FUN= append.file.extension, dpath)
      nm.extends <- unlist(nm.extends)
      names(vec) <- nm.extends
      return(vec)
    
    
  }
##     input.lst <- c("whodisease", "whogender","whocovariates","whofore","whoyrest",   
##                    "wholag", "wholagdth","whogdp2","whousercntrylist",
##                    "who.cov.select","forecast", "who.cntry.digits", 
##                    "who.year.digits","who.digit.first","who.age.digits","who.age.select", 
##                    "who.lag.cutoff","whousersubreg","whoskip", "whouserages", "who.reusedata", 
##                    "who.reuse.path","who.save.output","whomodel", "whostandardize", "whoelim.collinear",
##                    "whotransform", "datapath", "whodatapath", "whocovpath","whooutpath",
##                    "whographdir", "tol", "svdtol", "who.prior.path", "who.zero.mean", 
##                    "who.ols.sigma.param", "who.Ha.deriv", "who.Ha.age.weight", 
##                    "who.Ha.time.weight", "who.Ha.sigma", "who.Hat.a.deriv","who.Hat.t.deriv",
##                    "who.Hat.age.weight", "who.Hat.time.weight", "who.Hat.sigma", "who.Ht.deriv", 
##                    "who.Ht.age.weight", "who.Ht.time.weight", "who.Ht.sigma")
