data.creator <- function(){
allc <- read.depvarAndcov(skp=1)
allc <<- allc
suic <- read.depvarAndcov(file="suic",skp=1)
suic <<- suic
dgst <- read.depvarAndcov(file="dgst",skp=1)
dgst <<- dgst
cerv <- read.depvarAndcov(file="cerv",skp=1)
cerv <<- cerv 
trns <- read.depvarAndcov(file="trns",skp=1)
trns <<- trns 
rspi <- read.depvarAndcov(file="rspi",skp=1)
rspi <<- rspi 
lung <- read.depvarAndcov(file="lung",skp=1)
lung <<- lung 
brst <- read.depvarAndcov(file="brst",skp=1)
brst <<- brst
tobacco <- read.depvarAndcov(file="tobacco",skp=1)
tobacco <<- tobacco
gdp <- read.depvarAndcov(file="gdp", nc=2,skp=1)
gdp <<- gdp 
hc <- read.depvarAndcov(file="hc", nc=2,skp=1)
hc <<- hc 
fat <- read.depvarAndcov(file="fat", nc=2,skp=1)
fat <<- fat
population <- read.depvarAndcov(file="population",skp=1)
population <<- population
adjacency <- read.depvarAndcov(file="adjacency",skp=0)
adjacency <<- adjacency 
cntrycode <- read.depvarAndcov(file="cntry.codes",nc=2, codes=T,skp=0)
cntrycode <<- cntrycode
}
