

chapter11.1 <- function()
{
    message("Dataobj for examples 11.1...")
    message("Disease respiratory infections, country Belize, 30 years forecast...")
    user.prompt()
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    rspi <- eval(as.symbol(data(rspi)))
    population <- eval(as.symbol(data(population)))
    cntrycode  <- eval(as.symbol(data(cntry.codes)))
    rspi[rspi[,"rspi"] <= 0.5 & !is.na(rspi[,"rspi"]),"rspi"] <- 0.5
    
    dataobj <<- dataobjWHO(disease=rspi,pop=population,cov.REDUCE=NULL,
                         cov.FULL=NULL, cntry.vec=c(Belize=2045), lagyears=30, 
                         nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                         icode="ggggaatttt",proxfile=NULL,
                         Gnames=cntrycode, selectages=NULL)
   
    message("Formula for male population and respiratory infections...")
    ff <- log(rspi2/popu2) ~ time 
    print(ff)
    message("Running yourcast with model LC...")
    user.prompt()
    ylc <- yourcast(formula=ff, dataobj=dataobj, model="LC")
    
    message("Generating the graphics for LC...")
    user.prompt()
    yourgraph(ylc, pred.insample=F)
   
    message("Running yourcast with MAP model...")
    user.prompt()
    zmean <- c(-7.474950, -10.391050, -10.745170, -10.511022, -10.450573, -10.321841, -10.066730, 
               -9.721626,  -9.362865,  -8.995520,  -8.607914,  -8.233437,  -7.752187,  -7.240793, 
               -6.626354,  -6.019082,  -4.938154)
    names(zmean) <- 0:16*5
    ymap <- yourcast(model="map", Ha.sigma=0.2, Ht.sigma=NA,Hat.sigma=NA, zero.mean=zmean)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap, pred.insample=F)
    

  }

chapter11.1()
