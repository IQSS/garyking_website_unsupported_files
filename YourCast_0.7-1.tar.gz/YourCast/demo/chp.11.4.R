

chapter11.4 <- function()
{
    message("Dataobj for example 11.4...")
    message("Disease lung cancer, countries Mauritius, Peru...")
    user.prompt()
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    lung <- eval(as.symbol(data(lung)))
    population <- eval(as.symbol(data(population)))
    cntrycode <- eval(as.symbol(data(cntry.codes)))
    lung[lung[,"lung"] <= 0.5 & !is.na(lung[,"lung"]),"lung"] <- 0.5
    
    dataobj <<- dataobjWHO(disease = lung, pop= population, cov.REDUCE= NULL, 
                          cov.FULL= NULL,lagyears = 30,  
                          cntry.vec =c(Mauritius=1300, Peru=2370),
                          nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                          icode="ggggaatttt",proxfile=NULL,
                          Gnames=cntrycode, selectages=seq(from=30,to=80,by=5))
   
    message("Formula for male lung disease...")
    ff <- log(lung2/popu2 ) ~ time + log(time -1876)
    print(ff)
    message("Running yourcast with model OLS...")
    user.prompt()
    yols <- yourcast(formula=ff, dataobj=dataobj)
    
    message("Generating the graphics for OLS...")
    user.prompt()
    yourgraph(yols, pred.insample=F)
   
  }

chapter11.4()
