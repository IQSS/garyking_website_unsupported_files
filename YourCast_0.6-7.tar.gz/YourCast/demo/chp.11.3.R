

chapter11.3 <- function()
{
    message("Dataobj for examples 11.3...")
    message("Disease respiratory infections; country Bulgaria and 30 years forecast...")
    user.prompt()
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    rspi <- eval(as.symbol(data(rspi)))
    population <- eval(as.symbol(data(population)))
    adjacency <- eval(as.symbol(data(adjacency)))
    cntrycode <- eval(as.symbol(data(cntry.codes)))
    
    dataobj <<- dataobjWHO(disease = rspi, pop= population, cov.REDUCE= NULL, 
                          cov.FULL= NULL,lagyears = 30, timeseries=TRUE, 
                          cntry.vec = c(Bulgaria=4030), nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                          icode="ggggaatttt", proxfile=adjacency,
                          Gnames=cntrycode, selectages=NULL)
    
###    dataobj <<- dataobjWHO(disease= c("rspi"),
###                          cov.FULL= NULL, timeseries=T, lagyears=30,
###                          cntry.vec= c(Bulgaria=4030))

   
    message("Formula for male respiratory infections...")
    ff <- log((rspi2 + 0.5)/popu2) ~ time 
    print(ff)
      
    message("Running yourcast with MAP model...")
    user.prompt()
    zmean <- c(-7.474950, -10.391050, -10.745170, -10.511022, -10.450573, -10.321841, -10.066730, 
               -9.721626,  -9.362865,  -8.995520,  -8.607914,  -8.233437,  -7.752187,  -7.240793, 
               -6.626354,  -6.019082,  -4.938154)
    names(zmean) <- 0:16*5
    ymap <- yourcast(formula=ff, dataobj=dataobj, model="map", Ha.sigma=0.2, Ht.sigma=NA,Hat.sigma=0.05,
                     Hat.a.deriv=c(0,1), Hat.t.deriv=c(0,1), zero.mean=zmean)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap, pred.insample=F)


  }

chapter11.3()
