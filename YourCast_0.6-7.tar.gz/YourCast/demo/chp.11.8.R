

chapter11.8 <- function()
{
  
    message("Dataobj for example 11.8...")
  
    
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    lung <- eval(as.symbol(data(lung)))
    population <- eval(as.symbol(data(population)))
    gdp  <- eval(as.symbol(data(gdp)))
    fat  <- eval(as.symbol(data(fat)))
    hc   <-  eval(as.symbol(data(hc)))
    tobacco <- eval(as.symbol(data(tobacco)))
    adjacency <- eval(as.symbol(data(adjacency)))
    cntrycode <- eval(as.symbol(data(cntry.codes)))
  
    message("Formula for male lung disease...")
    ff <- log((lung2 + 0.5)/popu2) ~ time + log(hc) + log(fat) + log(gdp) + log(tobacco2)
    print(ff)

    message("The summary measures for lung cancer as calculated in 11.7 are...")
    SD <- c(SD=0.29891746)
    d1.a <- c(d1.a=0.50122654)
    d1.t <- c(d1.t=0.03371817)
    dtda <- c(dtda=0.00664950)
    cat("SD= ", SD, "  d1.a= ", d1.a, "  d1.t= ", d1.t, "  dtda= ", dtda, "\n")
   
   
    message("dataobj for disease lung cance and Ukraine ...")
    user.prompt()
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
###TrinidadAndTobago=2440
    
   dataobj <<- dataobjWHO(disease=lung, pop=population,
                          cov.REDUCE=c(list(hc), list(fat), list(gdp)),  
                          cov.FULL=tobacco,
                          lagyears = 30, timeseries=TRUE, 
                          cntry.vec =c(Ukraine=4303), 
                          nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                          icode="ggggaatttt",proxfile=adjacency,
                          Gnames=cntrycode, selectages=seq(from=30, to=80, by=5))
    
    message("Running yourcast with model MAP...")
    user.prompt()
    zmean <- c(-11.123375, -10.188764,  -9.239278,  -8.419195,  -7.699627,
               -7.141269,  -6.702073,-6.400106,  -6.223774,  -6.153787,  -6.231790)
    names(zmean) <- 6:16*5

    sims <- c(sims=50)
   
    ymap <- yourcast(formula=ff, dataobj=dataobj,
                     model="map",elim.collinear=FALSE, 
                     Ha.sigma=c(0.1,1.5,5,d1.a, SD),
                     Ht.sigma=c(0.1,1.5,5,d1.t, sims),
                     Hat.sigma=c(0.05,1.5,5,dtda),
                     zero.mean=zmean,
                     Ha.deriv=c(0,0,1),
                     Hat.a.deriv=c(0,1), Hat.t.deriv=c(0,0,1),
                     Ht.deriv=c(0,0,1))
  
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap)
    message("dataobj for lung cancer and Trinidad and Tobago ...")
    
    
   if(exists("dataobj", inherits=TRUE))
     try(rm(dataobj, inherits=T), silent=T)
    
##
    
   dataobj <<- dataobjWHO(disease=lung, pop=population,
                          cov.REDUCE=c(list(hc), list(fat), list(gdp)),  
                          cov.FULL=tobacco,
                          lagyears = 30, timeseries=TRUE, 
                          cntry.vec =c(TrinidadAndTobago=2440), 
                          nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                          icode="ggggaatttt",proxfile=adjacency,
                          Gnames=cntrycode, selectages=seq(from=30, to=80, by=5))
    
    message("Running yourcast with model MAP...")
    user.prompt()
    
   
    ymap <- yourcast(formula=ff, dataobj=dataobj,
                     model="map",elim.collinear=FALSE, 
                     Ha.sigma=c(0.1,1.5,5,d1.a, SD),
                     Ht.sigma=c(0.1,1.5,5,d1.t, sims),
                     Hat.sigma=c(0.05,1.5,5,dtda),
                     zero.mean=zmean,
                     Ha.deriv=c(0,0,1),
                     Hat.a.deriv=c(0,1), Hat.t.deriv=c(0,0,1),
                     Ht.deriv=c(0,0,1))
  
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap)

  }

chapter11.8()
