

chapter11.8 <- function()
{
    message("Dataobj for example 11.8 in the book...")
    message("Disease lung cancer, countries Trinidad and Tobago, Ukraine...")
    user.prompt()
    
    datobj <<- dataobjWHO(disease= c("lung"),
                          cov.FULL= NULL, timeseries=T, lagyears=30,
                          cntry.vec= c(Trinidad.and.Tobago=2440, Ukraine=4303),
                          selectages=seq(from=30, to=80, by=5))
   
    message("Formula for male population and lung disease...")
    ff <- log((lung2+0.5)/popu2) ~ time + log(time -1876)
    print(ff)
    message("Running yourcast with model MAP...")
    user.prompt()
    zmean <- c(-11.123375, -10.188764,  -9.239278,  -8.419195,  -7.699627,
               -7.141269,  -6.702073,-6.400106,  -6.223774,  -6.153787,  -6.231790)
    names(zmean) <- 6:16*5
    ymap <- yourcast(formula=ff, dataobj=datobj, model="map",
                     Ha.sigma=0.2, Ht.sigma=0.9, Hat.sigma=1.0, zero.mean=zmean)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap)
   

  }

chapter11.8()
