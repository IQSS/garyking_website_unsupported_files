### Reads file from the directory datapath, which
### is one of the WHO files for either death or cov.  
### Selects from the file the countries specified
### in the vector of country codes, cntry.vec, and
### from the parameter nobvs or number of observations.
### It may select the strata or gender 2 for male,
### and 3 for female or NA for both. The file may be
### one of the death causes, tobacco or other covariates
### Death causes and tobacco have a complete dataset 
### for every country, age group and year.  The covariate
### files (i.e. fat, gdp, hc, tfr)  need to be read with
### the parameter cov=TRUE and have for every country,
### only one age group and all years.
### The parameter wrt=T means that the subset files
### are written as a txt file into the directory ~/INPUT/tmp.

file.selection <- function(datapath="~/INPUT/", dir = "~/INPUT/WHOCov/", file ="allc", cov=F,  
                           cntry.vec=NULL, nobvs=0, Gnames="cntry.codes.txt",strata=NA, wrt=FALSE){
  
  cdigits <- 4 ### 4 digits for cntry: 2450
  adigits <- 2 ### 2 digits for age :00, 05, 10, 15,..80
  ydigits <- 4 ### 4 digits for years:1988, 2000
  age.g <- ifelse(!cov, 17, 1) ### age groups from 0 to 80 groups of 5
  ### not needed but for information:
  ### series of 81 years from 1920 to 2000; two genders
  no.years   <- 81
  no.genders <- 2
  
  mm  <- NULL
  if(length(dir) <= 0)
    dir <- paste(datapath,"tmp/", sep="") 
  filename  <- paste(datapath,file,".txt",sep="")
  cat("Reading file ", filename, "\n")
  dth <- scan(file=filename,
              na.strings=c("-999.0000", "-999", "NA"),
              multi.line=T,quiet=T)
  if(!cov)
    dth <- matrix(dth,ncol=3,byrow=T)
  else
    dth <- matrix(dth,ncol=2,byrow=T)
  
 ### choosing only one gender
  twogender <- T
  if(!is.na(strata) && dim(dth)[[2]] >= 3 &&
     any(dth[,3]==as.numeric(strata)))
    {
      ind <- dth[,3] == as.numeric(strata)
      dth <- dth[ind, ]
      twogender <- F
    }
      
  dth <- split.data.frame(dth, floor(dth[,2]/10^(adigits+ydigits)))
###  dthtopass <<- dth 
###  dth.omit <- lapply(dth, na.omit)
###  cnt.obvs <- lapply(dth.omit, nrow)
  dth1 <- NULL
  dth2 <- NULL
  cntry.byobvs <- NULL
  if(nobvs > 0){
    dth1 <- extract.cntry.nobvs(dth, nobvs, age.g, twogender)
    cntry.byobvs <- as.numeric(names(dth1))
    Gnames <- paste(datapath,Gnames, sep="")
    cat("Scanning file ", Gnames, "\n")
    tmp <- scan(file=Gnames,what=c(integer(0),character(0)),quiet=T,multi.line=T,
                sep="\t",quote="\"", skip=1)
 
    tmp <- matrix(tmp,ncol=2,byrow=T)
    tmp <- na.omit(tmp)
    
    cod <- as.integer(tmp[,1])
    ind <- match(cntry.byobvs, cod)
    cmat <- tmp[ind,]
    cnames <- cmat[,2]
    names(cntry.byobvs) <- cnames
    cat("Cntry by obvs: ")    
    cntry.byobvs <<- cntry.byobvs
    print(cntry.byobvs)  
    }
  if(length(cntry.vec) > 0){
    cntry.vec <- as.character(cntry.vec)
    cvec <- as.character(names(dth))
    
    ind <- sapply(cntry.vec,grep,cvec)
    ind <- unlist(ind)
    if(length(ind) > 0)
      dth2 <- dth[ind]
  }
   
    if(length(dth2) >0 && length(dth1) > 0)
      dth <- c(dth1, dth2)
    else if(length(dth1) > 0)
      dth <- dth1
    else if (length(dth2) > 0)
      dth <- dth2

    nmd  <- names(dth)
    nmdu <- unique.default(nmd)
    ind  <- match(nmdu, nmd)
    dth  <- dth[ind]
    all.cntry <- as.numeric(names(dth))
    join.cntry <- as.numeric(c(cntry.vec, cntry.byobvs))
    if(length(join.cntry) > 0)
      print(setdiff(join.cntry,all.cntry))
      
    nr.lst <- lapply(dth,nrow)
    nr.lst <- unlist(nr.lst)
    nrtotal <- sum(nr.lst)

    for(n in 1:length(dth)){
      mat <- dth[[n]]
      if(n <= 1)
        mm <- mat
      else
        mm <- rbind(mm, mat)
    }
  if(!cov){
    if(identical(file,"population"))
        colnames(mm) <- c("popu", "csid", "strata")
    else 
    colnames(mm) <- c(file, "csid", "strata")
  }else
    colnames(mm) <- c(file, "csid")
  
  if(length(mm) > 0 && wrt){
      fileout <- paste(dir,file,".txt", sep="")
      write.table(mm, file=fileout,quote=F, sep="\t",eol="\n",row.names=F, col.names=T, na="NA")
         message("The size of ",fileout, " file is = ",file.info(fileout)$size) 
    }
  return(invisible(mm))
  
}

Gnames.file <- function(datapath="~/INPUT/", Gnames="cntry.codes.txt",wrt=T, dir="."){
   Gnames0 <- Gnames
   Gnames <- paste(datapath,Gnames, sep="")
   cat("Scanning file ", Gnames, "\n")
   tmp <- scan(file=Gnames,what=c(integer(0),character(0)),quiet=T,multi.line=T,
               sep="\t",quote="\"", skip=1)
 
   tmp <- matrix(tmp,ncol=2,byrow=T)
 
   vecntry <- sapply(tmp[,2], function(mat){
     paste("\"",as.character(mat), "\"", sep="")})
   
  
   mm <- tmp
 
   mm[,2] <- unlist(vecntry)
  if(length(mm) > 0 && wrt){
      fileout <- paste(dir,"/",Gnames0, sep="")
      write.table(mm, file=fileout,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")
         message("The size of ",fileout, " file is = ",file.info(fileout)$size) 
    }
}
extract.cntry.nobvs <- function(dth, nobvs, age.g, twog)
  {
    dth <- lapply(dth, function(mat, nobvs){
      mat0 <- mat
      mat <- na.omit(mat)
      ret <- NULL
      w <- ifelse(twog,2, 1)
      if (nrow(mat) >= w* age.g *nobvs)
        ret <- mat0
      
      return(ret)
    }, nobvs)
    
    ind <- sapply(as.list(1:length(dth)),
                  function(n, dth){
                    mat <- dth[[n]]
                    ret <- NULL
                    if(length(mat) > 0)
                      ret <- n
                    return(ret)
                  }, dth)
    ind <- unlist(ind)
    dth <- dth[ind]
    return(dth)
  }
