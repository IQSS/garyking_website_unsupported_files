chapter2.6 <- function()
{
    message("Dataobj for examples 2.6 and all causes...")
    message("Countries New Zeland, Hungary; 60 years forecast...")
    user.prompt()
    
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    allc <- eval(as.symbol(data(allc)))
    population <- eval(as.symbol(data(population)))
    adjacency <- eval(as.symbol(data(adjacency)))
    cntrycode <- eval(as.symbol(data(cntry.codes)))
    
    allc[allc[,"allc"] <= 0.5 & !is.na(allc[,"allc"]),"allc"] <- 0.5                       

    cvec <- c(NewZeland=5150, Hungary=4150)
 
    dataobj <<- dataobjWHO(disease=allc,pop=population, cov.FULL=NULL,timeseries=T,
                           cntry.vec=cvec,lagyears=60, 
                           nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                           icode="ggggaatttt",proxfile=adjacency,
                           Gnames=cntrycode, selectages=NULL)

    message("Formula for male population and all causes...")
    ff <- log(allc2/popu2) ~  time
    print(ff)
    message("Running yourcast with model LC...")
    user.prompt()
    ybayes <- yourcast(formula=ff, dataobj=dataobj, model="LC",
                       elim.collinear=FALSE)

    message("Generating the graphics for LC...")
    user.prompt()
    yourgraph(ybayes,row.num=1,col.num=2,pred.insample = F)
####new plot
    message("Dataobj for male transportation accidents, and Portugal...\n")
    user.prompt()
    trns <- eval(as.symbol(data(trns)))
    trns[trns[,"trns"] <= 0.5 & !is.na(trns[,"trns"]),"trns"] <- 0.5
    
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    dataobj <<- dataobjWHO(disease=trns,pop=population, cov.FULL=NULL,timeseries=T,
                         cntry.vec= c(Portugal=4240), lagyears=60, 
                         nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                         icode="ggggaatttt",proxfile=adjacency,
                         Gnames=cntrycode, selectages=NULL)
    
  
    message("formula...")
    ftrns <- log(trns2/popu2) ~ time
    print(ftrns)
   
    message("Running yourcast with model LC...")
    user.prompt()
    ytrns <- yourcast(formula=ftrns, dataobj=dataobj, model="LC")
    message("Running yourgraph..") 
    user.prompt()
   
    yourgraph(ytrns)
 
  }

chapter2.6()
