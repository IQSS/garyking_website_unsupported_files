
chapter11.10 <- function()
{
 
  message("Examples 11.10 Chile, Cuba, Belgium, Netherlands...")
  user.prompt()
  if(exists("dataobj", inherits=TRUE))
    try(rm(dataobj, inherits=T), silent=T)

  
  brst <- eval(as.symbol(data(brst)))
  gdp <- eval(as.symbol(data(gdp)))
  fat <- eval(as.symbol(data(fat)))
  hc <-  eval(as.symbol(data(hc)))
  tobacco <- eval(as.symbol(data(tobacco)))
  population <- eval(as.symbol(data(population)))
  adjacency <- eval(as.symbol(data(adjacency)))
  cntrycode <- eval(as.symbol(data(cntry.codes)))

  brst[brst[,"brst"] <= 0.5 & !is.na(brst[,"brst"]),"brst"] <- 0.5
  
  dataobj <<- dataobjWHO(disease=brst, pop=population, cov.REDUCE=c(list(gdp),list(fat), list(hc)), 
                    cov.FULL=tobacco,lagyears = 30, timeseries=TRUE, 
                    cntry.vec=c(Chile=2120, Cuba=2150, Belgium=4020,Netherlands=4210), 
                    nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                    icode="ggggaatttt",proxfile=adjacency,
                    Gnames=cntrycode, selectages=seq(from=25, to=80, by=5))
     
  message("Formula for female breast cancer and covariates hc, gdp, fat, tobacco...")
  ff <- log(brst3/popu3) ~ log(hc) + log(gdp) + log(tobacco3) + log(fat) + time
  print(ff)
   
   
  z.mean <- c(-11.391495,-10.147588, -9.305023, -8.692574, -8.232481, -7.953798, -7.798399,
              -7.678475, -7.577912, -7.433581,-7.293615, -6.926301)
  names(z.mean) <- 5:16*5
  message("Running yourcast with MAP model...")
  user.prompt()
  ymap <- yourcast(formula=ff, dataobj=dataobj, model="MAP",elim.collinear=FALSE,
                   Ha.sigma=1.22,Ht.sigma=0.94,Hat.sigma=0.38,
                   zero.mean=z.mean,  Ha.deriv=c(0,0,1),
                    Hat.a.deriv=c(0,1), Hat.t.deriv=c(0,0,1),
                    Ht.deriv=c(0,0,1))
                   
  message("Generating the graphics for MAP...")
  yourgraph(ymap)
 
  }

chapter11.10()
