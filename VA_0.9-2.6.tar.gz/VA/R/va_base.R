require(Design, quietly=TRUE)
require(quadprog, quietly=TRUE) 


## just an interface to cod.est.base to simplify user inputs
##add a new  option to clean data
## by column there are should be some variability, if all responses=1
##or 0,then delete


va<-function(formula, data=list(hospital=NA, community=NA),nsymp=16,
             n.subset=300, method="quadOpt", fix=NA, bound=NA, 
             prob.wt=1,  boot.se=FALSE,
             nboot=300, printit=TRUE,
             print.reg.size=TRUE, checkrow.names=FALSE,
             predict.S=FALSE){
    if (nboot==1) boot.se<-FALSE
  if (method=="quadOpt") {
    tt<-require("quadprog")
    if (!tt)
      stop("\n Require Quadractic Programming package 'quadprog'\n",
           call.=FALSE)
  }

  prior <- list()

  if (!is.na(fix)) {
    prior$fix <- fFix(fix)
  }
  if (!is.na(bound)) {

    prior$bdd <- fBdd(bound)
  }
  print(prior)
  
  rhsVars<-all.vars(formula[[3]])
  lhsVars<-all.vars(formula[[2]])
  lhsVars<-dot(lhsVars,data[[1]])

        
  if(length(rhsVars)==2){
    hospVars<-c(rhsVars[[1]],lhsVars)
    commVars<-c(rhsVars[[2]],lhsVars)
  }
  else
    hospVars<-commVars<-c(rhsVars,lhsVars)

  ## first column cause of death
  ## second to last symptoms

  hospD <- data[[1]][,hospVars]

  ## Sometimes cause of death variable (rhs[[1]]) is not present
  ## in the community dataset. In this case, add one variable with
  ## the same name and arbitrary numeric values (read documentation)


  comm.cod <- TRUE
  commD <- data[[2]][,commVars]
  if ((rhsVars[[1]] %in% colnames(commD))==FALSE){
    warning("cause of deach not in population sample")
    comm.cod <- FALSE
    tmp <- rep(1,nrow(commD))
    commD<-cbind(tmp,commD)
    colnames(commD)[[1]]<-rhsVars[[1]]
  }

  q<-ncol(hospD)
  p<-nrow(hospD)
  
        
  ##check data: exit if
  ## any missing in causes of death (column 1)
  ## or, any missing in symptoms (column 2:q)
  ## or, no variation in certain symptoms (column 2:q)
  ## or, any values not equal to 0 or 1 (column 2:q)

  if (any(is.na(hospD[,1])))
    stop("\n Missing values found in the cause of death column\n",
         call.=FALSE)
        
  if (any(is.na(hospD[,2:q])) || any(is.na(commD[,2:q])))
    stop("\n Missing valus found in symptom profiles\n", call.=FALSE)

  colsums<-colSums(hospD[,2:q], na.rm=TRUE)

  if (any(colsums==0 | colsums ==p))
    stop("\nSome symptoms have no variation!!\n",call.=FALSE)

  if ((!all(as.matrix(hospD[,2:q]) %in% c(0,1))) ||
      (!all(as.matrix(commD[,2:q]) %in% c(0,1))))
    stop("\n All te symptoms should be coded 0,1 \n",call.=FALSE)

 
  ##if user decides to supply prob.wt, it must be the same length as
  ##symptoms
        
  if (length(prob.wt)>1)
    if (length(prob.wt)!=dim(hospD)[2]-1)
      stop("probability weights
  length must equal to number of symptoms in hosptial/community
          data\n")
  
        
  cod.names<-union(names(table(hospD[,1])), names(table(commD[,1])))
        
  index.all<-cod.names
  index.all<- index.all[order(as.numeric(index.all))]
  nd <- length(index.all)
  ns <- ncol(hospD)-1

  if (length(prob.wt)==1) {
    if (prob.wt==1) {
      temp<-rbind(hospD, commD)
      end<-dim(temp)[2]
      sta<-2
      prob.wt<-rep(0, (end-sta+1))
      for ( i in sta:end){
        tt<-table(temp[,i])
        n<-sum(tt)
        prob.wt[i-sta+1]<-tt[1]*tt[2]/n^2
      } 
      prob.wt<-prob.wt/sum(prob.wt)
    } else {
      if (prob.wt==0) prob.wt<-NULL
    }
  }
  
  if (!boot.se) nboot<-1
  comp<-array(0, dim=c(nboot, nd,2),
              dimnames=list(1:nboot, index.all, c("true", "emp")))
  s.fit <- matrix(0, nboot, ncol(hospD)-1)        

  if (nboot==1) boot.se<-FALSE
    for (t in 1:nboot){
      p1<-dim(commD)[1]
      p2<-dim(hospD)[1]

      boot.good<-FALSE
      while (!boot.good) {
        index.boot1<-sample(1:p1, p1, replace=TRUE)
        index.boot2<-sample(1:p2, p2, replace=TRUE)
    
        commD0<-commD[index.boot1,]
        hospD0<-hospD[index.boot2,]

        boot.good<-!(any(colMeans(commD0[,-1])==1) ||
                     any(colMeans(commD0[,-1])==0) || 
                     any(colMeans(hospD0[,-1])==1) ||
                     any(colMeans(hospD0[,-1])==0) )
      }

      res<- cod.est.base(hospital=hospD0,community=commD0,
                         n.subset=n.subset, nsymp=nsymp,
                         method=method,prior=prior,
                         prob.wt=prob.wt,printit=printit,
                         print.reg.size=print.reg.size,
                         checkrow.names=checkrow.names)
                
      cod.emp<-res$est.CSMF
      cod.true<-res$true.CSMF
      print(cod.true)
      print(cod.emp)

      comp[t,index.all %in% row.names(cod.true), 1]<-cod.true
      comp[t,index.all %in% names(cod.emp), 2]<-cod.emp

      if (predict.S==TRUE) {
        nd <- length(index.all)
        ns <- ncol(hosp)-1
        sd.mat<-matrix(0,ns,nd)
        for (k in 1:nd)
          {
            sd.mat[,k] <- colMeans(hospD0[hospD0[,1]==k,2:(ns+1)])
          }
        sd.mat[is.na(sd.mat)]<-0
        s.fit[t,]<-sd.mat%*%res$est.CSMF
        
      }

    
    if (boot.se)
      cat(paste(t, "th bootstrap sampling done.\n\n"))
    }
  

  if (!boot.se) {
    
    out<-list()
    out$est.CSMF<-rep(0,nd)
    out$true.CSMF<-rep(0,nd)
    out$est.CSMF[index.all %in% names(cod.emp)]<-cod.emp
    out$true.CSMF[index.all %in% names(cod.true)]<-cod.true
    names(out$est.CSMF)<-index.all
    names(out$true.CSMF)<-index.all
    out$subsets.est<-res$est.res
    out$index.match<-res$index.match

  }
  else {
    res0<-cod.est.base(hospital=hospD,community=commD,
                       n.subset=1,
                       nsymp=nsymp, prob.wt=prob.wt,printit=FALSE)
    out<-list()
    out$est.CSMF<-res0$est.CSMF
    out$CSMF.se<-apply(comp[,,2], 2, var)^0.5
    out$true.CSMF<-rep(0, length(out$est.CSMF))
    out$true.CSMF[index.all %in% names(res0$true.CSMF)]<- res0$true.CSMF
    names(out$true.CSMF)<-index.all
    out$true.CSMF.bootmean<-colMeans(comp[,,1])
    out$true.bootse<-apply(comp[,,1], 2, var)^0.5
    out$res.boot<-comp
    out$index.match<-res0$index.match
  }
  if (predict.S==TRUE) {
    out$s.fit<-s.fit
    }
  if (!comm.cod)
    out$true.CSMF<-NA
  class(out)<-"VA"
  return(out)
}

##subsampling.estimates
##hospital is the community based data
##community is the hospital based data
##format--MRcause, Symptom1,2,...

cod.est.base<-function(hospital,community, n.subset=300, nsymp=16,
                       prior=list(), prob.wt=NULL, printit=TRUE,
                       print.reg.size=TRUE, method=NULL,
                       checkrow.names=FALSE, h.cod=NULL){

        if (is.null(method)) method<-"quadOpt"
        
        q<-dim(community)[2]
        
        if (nsymp > (q-1))
          stop("nsymp is bigger than actual no. of symptoms")
        if (n.subset>choose((q-1), nsymp))
          warning("n.subset is bigger than choose(q, nsymp)")    
        nd<-length(table(hospital[,1]))
        # remove d.res this eventually 
        d.res<-matrix(NA, n.subset, nd)
        colnames(d.res)<-names(table(hospital[,1]))

        for (subset in 1:n.subset){
                sample.ok<-FALSE
                counter<-1
                while (!sample.ok) {
                        sample.ok<-TRUE
                        index<-sample(2:q, nsymp, replace=FALSE, prob=prob.wt)
                        # remove missing here, only affecting selected symptoms
                     #  hospital0<-na.omit(hospital[, c(1,index)])
                      #  community0<-na.omit(community[,c(1,index)])


                          h.probs<-DISTgen(hospital[,c(1,index)], whichdata="hospital")
                          c.probs<-DISTgen(community[, c(1,index)],whichdata="community")
                                
                          y<-c.probs$tsp
                          x<-h.probs$sd.mat
                                
                          index.match<-intersect(row.names(y), row.names(x))

                         # y.use<-rep(0,length(row.names(x)))
                          #y.use[row.names(x)%in% row.names(y)]<-y
                         y.use<-y[row.names(y) %in% index.match]
                          x.ind<-row.names(x) %in% index.match
                                
                          x.use<-NULL
                          if (!is.null(x.ind)) 
                           x.use<-x[x.ind,]
                          #           x.use<-x
                                     
                          ratio.y<-length(y.use)/length(y)
                          ratio.x<-nrow(x)/nrow(x.use)
                                
                          if (is.null(y.use) || is.null(x.use)
                              || is.null(dim(x.use))
                              || (!is.null(dim(x.use)) &&
                                  (dim(x.use)[1]<dim(x.use)[2]))
                              ) {
                            
                            sample.ok<-FALSE
                            counter<-counter+1
                            if (counter==2)
                              warning("sample could be too low
                                  for nsym\n")
                                  else
                                    if (counter==10)
                                      stop("please use a smaller nsymp\n", call.=FALSE)
                            
                          }
                        if (method=="quadOpt") {
                          coef<-try(quad.constrain(y.use, x.use, prior=prior), TRUE)
                          #coef<-quad.constrain(y.use, x.use, prior=prior)
                          if (length(coef)==1)
                            sample.ok<-FALSE
                        }
                        
                      }
                if (print.reg.size) {
                  cat("the dimension of X matrix in constraint
                optimization step\n")
                  print(dim(x.use))
                }

                if (method=="constrainLS")
                  coef<-ls.constrain(y.use, x.use, sum1=TRUE, prior=prior)

                
                d.res[subset, 1:nd]<-coef
                if ((printit) & (subset==round(subset/n.subset,digits=1)*n.subset))
                  cat(paste(round(subset/n.subset, digits=1)*100, "percent done. \n"))
          
              }      
        
        cod<-table(community[,1])
        cod<-cod/sum(cod)
        c.probs$cod<-cod
        if (!checkrow.names) index.match<-NULL
#    print("ok\n")
 #       print(dim(d.res))

        if (n.subset>1){
          good<-rowSums(d.res[,1:nd])==1
          est<-colMeans(as.matrix(d.res[good,1:nd]), na.rm=TRUE)
        }
        else if (n.subset==1)
          est<-coef
        res<-list(est.CSMF=est, true.CSMF=c.probs$cod,
                  est.res=d.res, index.match=index.match)
        
        return(res)
        
      }



dot<-function(lhsVars,data){
        dotpos<-match("...",lhsVars)
        if(is.na(dotpos))
          return(lhsVars)
        tmp<-colnames(data)
        if(dotpos==1){
                if(length(lhsVars)==1)
                  return(tmp)
                out<-tmp[1:which(tmp==lhsVars[[dotpos+1]])-1]
                lhsVars<-lhsVars[-(1:dotpos)]
                dotpos<-match("...",lhsVars)
        }else
        out<-c()
        while (!is.na(dotpos)){
                bef.miss.index<-which(tmp==lhsVars[[dotpos-1]])
                if(dotpos==length(lhsVars))
                  after.miss.index<-length(tmp)+1
                else
                  after.miss.index<-which(tmp==lhsVars[[dotpos+1]])
                out<-c(out,lhsVars[1:(dotpos-1)],tmp[(bef.miss.index+1):(after.miss.index-1)])
                lhsVars<-lhsVars[-(1:dotpos)]
                dotpos<-match("...",lhsVars)
        }
        out<-c(out,lhsVars)
        return(out)
      }




##pack fix and bound input into list like prior

fFix <- function(fix) {

     getNamesF<-function(x)
          x[[1]]
     getValuesF <- function(x)
          x[[2]]

    parseF <- function(x)
          sapply(x, strsplit,split="=")

        pfixed <- sapply(fix,parseF)
        fix <- matrix(as.numeric(sapply(pfixed,getValuesF)),
                        dimnames=list(sapply(pfixed,getNamesF),"value"))
     fix
   }

fBdd <- function(bound) {
  
        getNamesB <- function(x)
          x[[2]]
        getValuesB <- function(x)
          c(x[[1]],x[[3]])
 
        parseB <- function(x)
          sapply(x,strsplit,split ="<")
      
        pbound <- sapply(bound, parseB)
        bdd <- matrix(as.numeric(unlist(sapply(pbound, getValuesB,
simplify=FALSE))),
                      nrow=length(pbound), dimnames=list(sapply(pbound,
getNamesB),c("lbd","ubd")))
      
        bdd
}

