## make p(S), P(D) and p(S|D) from the hospital data
## with option of boostraping symptoms
## Data takes the format
## column 1: causes of disease
## column 2--q: symptoms


DISTgen<-function(wmat, whichdata) {
        p<-dim(wmat)[1]
        q<-dim(wmat)[2]

        tsp<-sd.mat<-NULL
        
       if (q<43) {
          sp <- apply(wmat[,2:q],1,bintodec)
        }else{
          sp <- apply(wmat[,2:q],1,paste,sep="",collapse="")
        }
        if (whichdata=="community") {
           tsp <- table(sp)
           tsp<-tsp/sum(tsp)
         }

        if (whichdata=="hospital") {
          sd.mat <- table(sp, by=wmat[,1])
          for (j in 1:ncol(sd.mat))
            sd.mat[,j]<-sd.mat[,j]/sum(sd.mat[,j])
        }
        
        cod <- table(wmat[,1])        

        cod<-cod/sum(cod)
 
        return(prob.dist=list(tsp=tsp, sd.mat=sd.mat, cod=cod))
}

 bintodec<-function(x){
 sum(x * 2^ ((length(x)-1):0))
 }
