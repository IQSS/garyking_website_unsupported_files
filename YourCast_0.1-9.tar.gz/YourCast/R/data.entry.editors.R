##
## FUNCTION NAME:    model.dialog()
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
##
## DESCRIPTION: It constructs a bunch of text boxes to enter data.
##              Each text box is a tkentry() widget. The number of them is
##              specified by the length of variable questions,
##              and their widths by entrywidth.
##              Entry boxes are all displayed in a single columns and multiple
##              rows that equal length(questions). Some defaults text values are
##              assigned to all tkentry text boxes with textDef,
##              but the user may change them. The two buttoms
##              OK and Cancel  will either change the default values of the entry boxes
##              or simply cancel the new entry values and restored the default values
##              of variable textDef. 
##
## FORMAT:  res <- modal.dialog(title, entrywidth, questions, textDef)
##         
## INPUT:  title for the widget, width of tex entry boxes, questions a vector
##         with as many elements as entry boxes or tkentry widgets on the GUI and
##         Each element of vector questions is the label to the tkentry box.
##         textDef is the text to display for each entry box widget, the length 
##         of textDef is the same length of questions, since each entry box needs
##         to display some text, which the user may choose to change.
## 
## OUTPUT: Upon pressing OK the texts appearing in entry boxes are assigned to the
##         vector retVal, which is also the variable that gui function model.dialog
##         returns as its value. Upon pressing Cancel the return value is the default
##         value assigned to the variable retVal 
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@iq.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 15/05/2005
## 
## ************************************************************************
## ************************************************************************



model.dialog <- function(title="Select Directories Path",entrywidth= 30,
                         questions=c("Data","Covariate", "Prior ", "OUTPUT", "Peprocess"),
                         textDef =c(data.path= "INPUT/",cov.path= "INPUT/",
                           prior.path="INPUT/",out.path="OUPUT/", reuse.path ="OUTPUT/"),
                         names.to.ret =c("data.path", "cov.path", "prior.path",
                                         "out.path", "reuse.path"))
  {
    dlg <- tktoplevel()
    spacer <- "     "
    tkwm.deiconify(dlg)
    tkgrab.set(dlg)
    tkfocus(dlg)
    tkwm.title(dlg, title)
    textDef0 <- formals(model.dialog)$texDef
               
    frame1  <- tkframe(dlg, relief = "groove", borderwidth = 0)
    frame2 <- tkframe(dlg, relief = "groove", borderwidth = 0)
    var <- as.list(1:length(questions))
    for ( x in var )
        var[[x]] <- tclVar(textDef[x])
    
    entrywidget <- as.list(1:length(questions))
    for(x in entrywidget)
        entrywidget[[x]] <- tkentry(frame1, width=entrywidth,
                                    textvariable=var[[x]], bg="white")

    tklabel <- as.list(1:length(questions))
    for(x in tklabel)
        tklabel[[x]] <- tklabel(frame1, text=questions[x])
    
    tkgrid(tklabel(frame1, text=spacer))

    for(i in (1:length(questions)))                   
      tkgrid(tklabel[[i]], entrywidget[[i]])
    
    tkgrid(tklabel(frame1, text=spacer))
    tkpack(frame1)
    
    retVal <- textDef
    if(length(names.to.ret) == length(questions))
      names(retVal) <- names.to.ret
    
    envdlg <- environment()
    
    onOK <- function(){
    
      for(i in (1:length(questions)))
        retVal[i] <- tclvalue(var[[i]])
      assign("retVal", as.list(retVal), env=envdlg)
      tkgrab.release(dlg)
      tkdestroy(dlg)
    }
    onCancel <- function(){
        retVal <- textDef
        tkgrab.release(dlg)
        tkdestroy(dlg)
    }
    OK.but      <- tkbutton(frame2, text ="   OK   ", command=onOK, fg="blue")
    Cancel.but  <- tkbutton(frame2, text =" Cancel ", command=onCancel, fg="red")
    tkgrid(OK.but, Cancel.but,sticky="we")
###    tkgrid(tklabel(frame2, text=spacer))
    tkpack(frame2)
   
    tkfocus(dlg)
    tkbind(dlg, "<Destroy>", function() tkgrab.release(dlg))
    for(n in (1:length(questions)))
          tkbind(entrywidget[[n]], "<Return>", onOK)
        
    tkwait.window(dlg)
    return(retVal)
  }
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:    modaldiag2 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## INPUT: two strings to display in the entry boxes and a title
##
## DESCRIPTION: It construct two entry boxes to enter strings,
##              which in this case are two directory names.
##              It is a modal dialog that blocks any actions
##              until the GUI is dismissed. Upon OK it returns
##              the strings contain in the entry boxes
##              and dismiss the dialog giving control to the caller. 
##
## FORMAT:  modaldiag2(string, string, string); modaldiag2()
##         
## OUTPUT: The tw strings in the entry boxes.
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 30/03/2005
## 
## ************************************************************************
## ************************************************************************

modaldiag2 <- function(harvardpath=" ", destpath=" ", title="Link files")
{
 
  base   <- tktoplevel()
  tkwm.title(base,"Choose Directories")  
  frame0 <-  tkframe(base, relief = "groove", borderwidth = 0)
  frame1 <- tkframe(base, relief = "groove", borderwidth = 0)
  frame2 <-  tkframe(base, relief = "groove", borderwidth = 0)
  separator <- tklabel(frame1, textvariable="     ");
  lenh <- nchar(harvardpath)
  lenp <- nchar(destpath)
  len <- ifelse(lenh > lenp, lenh, lenp)
  maxwidth <- ifelse(len > 10, len, 10)
  var1 <- tclVar(harvardpath)
  var2 <- tclVar(destpath)
  lbl  <- tklabel(frame0, text=title);
  frm1.lbl1 <- tklabel(frame1, text="Copy from  ");
  frm1.lbl2 <- tklabel(frame1, text="Destination");
  frm1.entry1 <- tkentry(frame1, textvariable = var1,
                         width = maxwidth, bg="white")
  frm1.entry2 <- tkentry(frame1, textvariable = var2,
                         width = 10, bg="white")
  tkgrid(lbl, sticky="w")
  tkgrid(frm1.lbl1, frm1.entry1, sticky="w")
  tkgrid(frm1.lbl2, frm1.entry2, sticky="w")
  ev <- environment()
  
  ON.OK <- function(){
    col1 <- trim.blanks(tclvalue(var1))
    col2 <- trim.blanks(tclvalue(var2))
    tkdestroy(base)
    
}
  frame2.but1 <- tkbutton(frame2,  textvariable =tclVar("OK"), fg="blue",
                          padx = 10, command = ON.OK)
  frame2.but2 <- tkbutton(frame2,  textvariable =tclVar("Cancel"), fg="red",
                          padx = 10, command = function() tkdestroy(base))
  tkgrid(frame2.but1, frame2.but2)
  tkpack(frame0)
  tkpack(frame1)
  tkpack(frame2)
  lst <- c(harvard = list(tclvalue(var1)), input =  list(tclvalue(var2)))
  tkwait.window(base)
  return(lst)
}

## ************************************************************************
##
## FUNCTION NAME:    model.buttons 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## INPUT: four strings to display in the entry boxes:textDef
##        additional inputs are titles nad labels to the entry boxes
##        The default values display in the boxes are textDef.
##        questions are the label of the entry boxes; title is the title of the widget
##        names.to.ret are the names for the return vector retVal
##        It is only applicable to 4 entry boxes or less
##
## DESCRIPTION: It construct 4 entry boxes to enter strings,
##              which in this case are 4 file names with full paths.
##              It is a modal dialog that blocks any actions
##              until the GUI is dismissed. Upon OK it returns
##              the strings contain in the entry boxes
##              and dismiss the dialog giving control to the caller.
##              In addition, next to each entry box we have a button to load files
##              It can easily be extended to more than 4 entry boxes
##              but you need to write for each additional
##              button the bring.file# with # hard-coded
##              in the parameters of the function. 
##
## FORMAT:  model.buttons(title string, integer width, labels string,
##          textDef= input filenames,string names to vector output)
##         
## OUTPUT: The 4 strings in the entry boxes, with names corresponding to the
##         global variables they represent
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 16/05/2005
## 
## ************************************************************************
## ************************************************************************

model.buttons <- function(title="Parameters Files",entrywidth= 30,
                          questions=c("User Input ","Countrty Codes",
                            "Adjacency Matrix ", "Ages specification"),
                          textDef =c(user.file= "",codes.names= "cntry.codes.txt",
                            Hct.c.deriv="adjacency.txt", age.file="allc.txt"),
                          names.to.ret =c("user.file", "codes.names",
                                          "Hct.c.deriv", "age.file"))
  {
    dlg <- tktoplevel()
    spacer <- "     "
    tkwm.deiconify(dlg)
    tkgrab.set(dlg)
    tkfocus(dlg)
    tkwm.title(dlg, title)
    envdlg <- environment()
    ewho <- get("ewho", env=parent.frame())
    data.path <- get("data.path", env=ewho)
    prior.path <- get("prior.path", env=ewho)
   ## current <- paste(getwd(),"/",sep="")
   ## for(ch in names(textPath)){
   ##   if(length(trim.blanks(textPath[ch])) > 0)
   ##     textDef[ch] <- paste(current,textPath[ch], sep="")
   ## }
    retVal <- textDef
###    cat("retVal ....") ; print(retVal)
    filenames <- formals(model.dialog)$textDef
    filenames <- c(data.path, data.path,prior.path,prior.path,data.path)
    names(filenames) <- names.to.ret
    
#### cat("filenames..."); print(filenames)
#### building the gui:two frames            
    frame1  <- tkframe(dlg, relief = "groove", borderwidth = 0)
    frame2 <- tkframe(dlg, relief = "groove", borderwidth = 0)
 
#### building the variables or text to display in the entry boxes,
#### which the user may change either writing on the text entries
#### or loading them with the buttons
    ind.lst <- (1:length(questions))
    
  ##  print(ind.lst) ; print(textDef)
    var <- list()
    for ( x in ind.lst ){
###      print(x)
###        print(textDef[x])
        var[[x]] <- tclVar(textDef[x])
 ##       print(tclvalue(var[[x]]))
      }
   ## building the entry widgets with text variables as above
    entrywidget <- list()
    for(x in ind.lst)
        entrywidget[[x]] <- tkentry(frame1, width=entrywidth,
                                    textvariable=var[[x]], bg="white")
   ## building the labels to entry boxes
    tklabel <- list()
    for(x in ind.lst)
        tklabel[[x]] <- tklabel(frame1, text=questions[x])
    
    generic.butt <- tkbutton(frame1, text ="Load", fg="purple",
                             bg="gray", padx=2, borderwidth=2,command=function(){})
    ## helper function to the command functions for the buttons            
    load.file <- function(ind, retVal)
      {      
        filepath <- tclvalue(tkgetOpenFile())
        if (!nchar(filepath)){
          tkmessageBox(message="No file selected from previous GUI's")
          return(list());
        }
      
        tkmessageBox(message=paste("File selected is\n",filepath ))
            
        retVal[ind] <- filepath
        lst <- strsplit(filepath,"/")[[1]]
        inx <- length(lst)
        userfile <- lst[inx]
        var[[ind]] <- tclVar(userfile)
###     cat("retVal is ....");  print(retVal)
        lst <- list(retVal=retVal, var = var)
        return(lst)
        }## return the entire directory path with name of file
         ##i.e., "/nfs/where/home/evillalo/YourCast/index"
    varbut <- var
       
    butt <- list() 
    for(ix in ind.lst) ### building 4 buttons next to entry boxes; skip zero mean
      {
        generic.butt <- tkbutton(frame1, textvariable =tclVar("Load"), fg="purple",
                             bg="gray", padx=2, borderwidth=2,command=function(){})
        butt[[ix]] <- generic.butt
        ind <- ix
       
      if(ix == 1){ ## command for button1
           bring.file1 <- function(...) {
             lst <- load.file(1, retVal)
          
             if(length(lst) <= 0)
               return(lst()); 
             retVal[1] <- (lst$retVal)[1]
###          print(retVal[1])
             var <- lst$var
             assign("retVal", retVal, env=envdlg)
             assign("var", var, env=envdlg)
           
             tkconfigure(entrywidget[[1]], textvariable = var[[1]])
             }           
          
           tkconfigure(butt[[1]], command=bring.file1)
           }
           if(ix == 2){ ##command for button2
             bring.file2 <- function(...) {
               lst <- load.file(2, retVal)
               if(length(lst) <= 0)
                 return(lst()); 
            
               retVal[2] <- (lst$retVal)[2]
               var <- lst$var
               assign("retVal", retVal, env=envdlg)
               assign("var", var, env=envdlg)
           
               tkconfigure(entrywidget[[2]], textvariable = var[[2]])
               }           
           
             tkconfigure(butt[[2]], command=bring.file2)
             }
        if(ix == 3){##command for button3
          bring.file3 <- function(...) {
            lst <- load.file(3, retVal)
            if(length(lst) <= 0)
              return(lst()); 
        
            retVal[3] <- (lst$retVal)[3]
            var <- lst$var
 ###           print(retVal)
            assign("retVal", retVal, env=envdlg)
            assign("var", var, env=envdlg)
          
            tkconfigure(entrywidget[[3]], textvariable = var[[3]])
          }
         
          tkconfigure(butt[[3]], command=bring.file3)
          }
          if(ix == 4){##command for button4
            bring.file4 <- function(...) {
              lst <- load.file(4, retVal)
              if(length(lst) <= 0)
                return(0);
              retVal[4] <- (lst$retVal)[4]
              var <- lst$var
              assign("retVal", retVal, env=envdlg)
              assign("var", var, env=envdlg)
         
              tkconfigure(entrywidget[[4]], textvariable = var[[4]])
             }          
         
            tkconfigure(butt[[4]], command=bring.file4)
          }
         ###Additional entries and buttons need their own command function
         ### with the buttons numbers hardcoded .
       }

    tkgrid(tklabel(frame1, text=spacer))

    for(i in (1:length(questions)))  ## pack labels next to the boxes and buttons     
      tkgrid(tklabel[[i]], entrywidget[[i]], butt[[i]])
    
    tkgrid(tklabel(frame1, text=spacer))
    tkpack(frame1)
    
  
    if(length(names.to.ret) == length(questions))
      names(retVal) <- names.to.ret ## return vector with names of global it represents
    
    
    onOK <- function(){
    
      for(i in (1:length(questions)))
        filenames[i] <- tclvalue(var[[i]])
###      cat("onOK.....") ; print(filenames)
      if(length(filenames) <= 0)
        filenames <- textDef 
      assign("retVal", as.list(retVal), env=envdlg)
      assign("filenames", filenames, env=envdlg)
      tkgrab.release(dlg)
      tkdestroy(dlg)
    }
    onCancel <- function(){
      retVal <- textDef
      ##     cat("onCancel ");  print(retVal)
      tkgrab.release(dlg)
      tkdestroy(dlg)
    
    }
    ## two more buttons for OK and cancel to manage the GUI
    OK.but      <- tkbutton(frame2, text ="   OK   ", command=onOK, fg="blue")
    Cancel.but  <- tkbutton(frame2, text =" Cancel ", command=onCancel, fg="red")
    tkgrid(OK.but, Cancel.but,sticky="we")
###    tkgrid(tklabel(frame2, text=spacer))
    tkpack(frame2)
   
    tkfocus(dlg)
    tkbind(dlg, "<Destroy>", function() tkgrab.release(dlg))
    for(n in (1:length(questions)))
      tkbind(entrywidget[[n]], "<Return>", onOK)
    
    tkwait.window(dlg)
    lst <- list(filepath = retVal, filenames = filenames)
    return(lst)
  }
## ************************************************************************
##
## FUNCTION NAME:    model.buttons 
##
## PLACE:    GUI for yourcast
## 
## IMPORTED functions: none
##
## INPUT: four strings to display in the entry boxes:textDef
##        additional inputs are titles nad labels to the entry boxes
##        The default values display in the boxes are textDef.
##        questions are the label of the entry boxes; title is the title of the widget
##        names.to.ret are the names for the return vector retVal
##        It is only applicable to 4 entry boxes or less
##
## DESCRIPTION: It construct 4 entry boxes to enter strings,
##              which in this case are 4 file names with full paths.
##              It is a modal dialog that blocks any actions
##              until the GUI is dismissed. Upon OK it returns
##              the strings contain in the entry boxes
##              and dismiss the dialog giving control to the caller.
##              In addition, next to each entry box we have a button to load files
##              It can easily be extended to more than 4 entry boxes
##              but you need to write for each additional
##              button the bring.file# with # hard-coded
##              in the parameters of the function. 
##
## FORMAT:  model.buttons(title string, integer width, labels string,
##          textDef= input filenames,string names to vector output)
##         
## OUTPUT: The 4 strings in the entry boxes, with names corresponding to the
##         global variables they represent
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 16/05/2005
## 
## ************************************************************************
## ************************************************************************

model.buttons.save <- function(title="Parameters Files",entrywidth= 30,
                               questions=c("User Input ","Countrty Codes",
                                 "Adjacency Matrix ", "Ages Specification" ),
                               textDef =c(user.file= "",codes.names= "cntry.codes.txt",
                                 Hct.c.deriv="adjacency.txt"),
                               names.to.ret =c("user.file", "codes.names","Hct.c.deriv"),
                              textSave ="Save GUI Selections"
                               
                               )
  {
    dlg <- tktoplevel()
    spacer <- "     "
    tkwm.deiconify(dlg)
    tkgrab.set(dlg)
    tkfocus(dlg)
    tkwm.title(dlg, title)
    envdlg <- environment()
    cat("Inside model.buttons.save..,.")
    print(questions)
    ewho <- get("ewho", env=parent.frame())
    data.path <- get("data.path", env=ewho)
    prior.path <- get("prior.path", env=ewho)
   ## current <- paste(getwd(),"/",sep="")
   ## for(ch in names(textPath)){
   ##   if(length(trim.blanks(textPath[ch])) > 0)
   ##     textDef[ch] <- paste(current,textPath[ch], sep="")
   ## }
    retVal <- textDef
###    cat("retVal ....") ; print(retVal)
    filenames <- formals(model.dialog)$textDef
    filenames <- c(data.path, data.path,prior.path,prior.path)
    names(filenames) <- names.to.ret
    
#### cat("filenames..."); print(filenames)
#### building the gui:two frames            
    frame1  <- tkframe(dlg, relief = "groove", borderwidth = 0)
    frame2 <- tkframe(dlg, relief = "groove", borderwidth = 0)
 
#### building the variables or text to display in the entry boxes,
#### which the user may change either writing on the text entries
#### or loading them with the buttons
    ind.lst <- (1:length(questions))
    
  ##  print(ind.lst) ; print(textDef)
    var <- list()
    for ( x in ind.lst ){
  ##      print(x)
  ##      print(textDef[x])
        var[[x]] <- tclVar(textDef[x])
  ##      print(tclvalue(var[[x]]))
      }
   ## building the entry widgets with text variables as above
    entrywidget <- list()
    for(x in ind.lst)
        entrywidget[[x]] <- tkentry(frame1, width=entrywidth,
                                    textvariable=var[[x]], bg="white")
   ## building the labels to entry boxes
    tklabel <- list()
    for(x in ind.lst)
        tklabel[[x]] <- tklabel(frame1, text=questions[x])
    
    generic.butt <- tkbutton(frame1, text ="Load", fg="purple",
                             bg="gray", padx=2, borderwidth=2,command=function(){})
    ## helper function to the command functions for the buttons            
    load.file <- function(ind, retVal)
      {      
        filepath <- tclvalue(tkgetOpenFile())
        if (!nchar(filepath)){
          tkmessageBox(message="No file selected from previous GUI's")
          return(list());
        }
      
        tkmessageBox(message=paste("File selected is\n",filepath ))
            
        retVal[ind] <- filepath
        lst <- strsplit(filepath,"/")[[1]]
        inx <- length(lst)
        userfile <- lst[inx]
        var[[ind]] <- tclVar(userfile)
###     cat("retVal is ....");  print(retVal)
        lst <- list(retVal=retVal, var = var)
        return(lst)
        }## return the entire directory path with name of file
         ##i.e., "/nfs/where/home/evillalo/YourCast/index"
    varbut <- var
       
    butt <- list() 
    for(ix in ind.lst) ### building 4 buttons next to entry boxes; skip zero mean
      {
        generic.butt <- tkbutton(frame1, textvariable =tclVar("Load"), fg="purple",
                             bg="gray", padx=2, borderwidth=2,command=function(){})
        butt[[ix]] <- generic.butt
        ind <- ix
       
      if(ix == 1){ ## command for button1
           bring.file1 <- function(...) {
             lst <- load.file(1, retVal)
          
             if(length(lst) <= 0)
               return(lst()); 
             retVal[1] <- (lst$retVal)[1]
###          print(retVal[1])
             var <- lst$var
             assign("retVal", retVal, env=envdlg)
             assign("var", var, env=envdlg)
           
             tkconfigure(entrywidget[[1]], textvariable = var[[1]])
             }           
          
           tkconfigure(butt[[1]], command=bring.file1)
           }
           if(ix == 2){ ##command for button2
             bring.file2 <- function(...) {
               lst <- load.file(2, retVal)
               if(length(lst) <= 0)
                 return(lst()); 
            
               retVal[2] <- (lst$retVal)[2]
               var <- lst$var
               assign("retVal", retVal, env=envdlg)
               assign("var", var, env=envdlg)
           
               tkconfigure(entrywidget[[2]], textvariable = var[[2]])
               }           
           
             tkconfigure(butt[[2]], command=bring.file2)
             }
        if(ix == 3){##command for button3
          bring.file3 <- function(...) {
            lst <- load.file(3, retVal)
            if(length(lst) <= 0)
              return(lst()); 
        
            retVal[3] <- (lst$retVal)[3]
            var <- lst$var
 ###           print(retVal)
            assign("retVal", retVal, env=envdlg)
            assign("var", var, env=envdlg)
          
            tkconfigure(entrywidget[[3]], textvariable = var[[3]])
          }
         
          tkconfigure(butt[[3]], command=bring.file3)
          }
          if(ix == 4){##command for button4
            bring.file4 <- function(...) {
              lst <- load.file(4, retVal)
              if(lst == 0)
                return(0);
              retVal[4] <- (lst$retVal)[4]
              var <- lst$var
              assign("retVal", retVal, env=envdlg)
              assign("var", var, env=envdlg)
         
              tkconfigure(entrywidget[[4]], textvariable = var[[4]])
             }          
         
            tkconfigure(butt[[4]], command=bring.file4)
          }
         ###Additional entries and buttons need their own command function
         ### with the buttons numbers hardcoded .
       }

    tkgrid(tklabel(frame1, text=spacer))

    for(i in (1:length(questions)))  ## pack labels next to the boxes and buttons     
      tkgrid(tklabel[[i]], entrywidget[[i]], butt[[i]])
    
    cbVal <- tclVar("0")  
    frame1.lbl.save <- tklabel(frame1, text= textSave, bg = "blue")
    frame1.chk <- tkcheckbutton(frame1, variable=cbVal)
     
    out.GUIfile <- function(){
      depvar <- get("depvar", env=ewho)
      strata <- get("strata", env=ewho)
      model  <- get("model", env=ewho)
      results.path <- paste(getwd(), "/INPUT/", sep="" )
      save.GUI <- paste(depvar,".",strata,".",
                        tolower(as.character(model)),"_GUI.dat",sep="")
      save.GUI <- paste(results.path,save.GUI, sep="")
      mess <- paste("Your GUI selections are saved in the file, \n",save.GUI, sep="")
      ##            depvar,".",strata,".",tolower(model),"_GUI.dat",sep="") 
      retVal <- tkmessageBox(message=mess, icon="info")
      if(tolower(as.character((tclvalue(retVal)))) =="ok"){
        
        assign("save.GUI",save.GUI, env=eGUI)
        assign("save.GUI", save.GUI,env=ewho)
      }
      
    }
    tkbind(frame1.chk, "<Button-1>", function(...){
###   print(as.character(tclvalue(cbVal)))
      on.off <- as.character(tclvalue(cbVal))
      if(on.off == "0"){
        cbVal <- tclVar("0")
        save.GUI <- F
        
      }else
      out.GUIfile()
    })
      
    tkgrid(tklabel(frame1, text=spacer))
    tkpack(frame1)
    
  
    if(length(names.to.ret) == length(questions))
      names(retVal) <- names.to.ret ## return vector with names of global it represents
    
    
    onOK <- function(){
    
      for(i in (1:length(questions)))
        filenames[i] <- tclvalue(var[[i]])
 ##     cat("onOK.....") ; print(filenames)
      if(length(filenames) <= 0)
        filenames <- textDef 
      assign("retVal", as.list(retVal), env=envdlg)
      assign("filenames", filenames, env=envdlg)
      tkgrab.release(dlg)
      tkdestroy(dlg)
    }
    onCancel <- function(){
      retVal <- textDef
      ##     cat("onCancel ");  print(retVal)
      tkgrab.release(dlg)
      tkdestroy(dlg)
    
    }
    ## two more buttons for OK and cancel to manage the GUI
    OK.but      <- tkbutton(frame2, text ="   OK   ", command=onOK, fg="blue")
    Cancel.but  <- tkbutton(frame2, text =" Cancel ", command=onCancel, fg="red")
    tkgrid(OK.but, Cancel.but,sticky="we")
###    tkgrid(tklabel(frame2, text=spacer))
    tkpack(frame2)
   
    tkfocus(dlg)
    tkbind(dlg, "<Destroy>", function() tkgrab.release(dlg))
    for(n in (1:length(questions)))
      tkbind(entrywidget[[n]], "<Return>", onOK)
    
    tkwait.window(dlg)
    lst <- list(filepath = retVal, filenames = filenames)
    return(lst)
  }


## IMPORTED functions: none
##
## INPUT: filepath = the name of the file and the directory path 
##        default directory directory.def = data.path for the file,
##        type of file, identify with its extension typedef= "txt"
##
## DESCRIPTION: It checks if the directory path for the file is the
##              same as the default irectory.  If that is the case
##              returns the name of the file stripped from directory path,
##              otherwise copies the file to the default directory
##              and returns also the name of the file.  Helper function
##              to master.GUI() and menu function open.files().
##
## FORMAT:  parse.files(filepath,directory.def, type.def) 
##         
## OUTPUT: The name of the file strpped from directory path
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@iq.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 20/05/2005
## 
## ************************************************************************
## ************************************************************************


parse.files <- function(filepath = NULL, 
                        directory.def = data.path, typedef= "txt", dir = data.path)
  {
    
   vec.def <- c("user.file", "codes.names",
                "Hct.c.deriv","zero.mean")
###   print(filepath)
   cn <- nchar(filepath)
   filepath <- trim.blanks(filepath)
   
   if(filepath == "")
     return(list());
   
    lst <- strsplit(filepath,"/")[[1]]
    ix <- length(lst)
###    print(lst)
    directory <- directory.def 
     
    filename <- lst[[ix]]
   
   if(ix > 1 ){
     directory <- lst[[(ix - 1)]]
     directory <- paste(directory, "/", sep="")
   }
###  cat("in parse dir and file ", "\n")
###     print(directory)
###     print(filename)
     
### handle when file is the cntry.codes.txt, adjacency.txt, zero.mean.txt 
   if(identical(trim.blanks(directory), directory.def))
     { ## in the correct directory
         
       return(filename)
          
     } ## in another directory, so move it
   else 
     {
       if (!file.exists(directory.def))
         {
           mess <- paste("Directory ", directory.def, " does not exist.")
           tkmessageBox(message=mess)
           directory.def <- dir
         }
         
       destfile <- paste(directory.def,filename, sep="")
       res <- readLines(pipe(paste("cp", filepath, destfile)))
       lst <- strsplit(destfile,"/")[[1]]
       ix <- length(lst)
        filename <- lst[ix]
     
       return(filename)
         
     }
    
 }

## IMPORTED functions: none
##
## INPUT: datap = the name and path of the directory to search for files  
##        with extension txt, csv and xls, such as data.txt, data.xls, data.csv
##        
##
## DESCRIPTION: It checks if directory for files ending with txt, csv and xls. 
##              First it looks for files xtarting with FULL and excludes them
##              Then find indces for txt, csv and xls extensions, extract 
##              the files names, and return them. 
##              
##
## FORMAT:  read.dir(datap=name of the directory to search for files) 
##         
## OUTPUT: Return file names with extensions xls, txt, csv 
##
##
## WRITTEN BY: Elena Villalon 
##             evillalon@iq.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 06/27/2005
## 
## ************************************************************************
## ************************************************************************


read.dir <- function(datap=NULL){
  if(is.null(datap))
    datap <- get("data.path",env=parent.frame())
  
### get rid of text files starting with FULL_
  if(length(grep("/$", datap)) <= 0)
    datap <- paste("./",datap,sep="")
  
  if(!file.exists(datap)){
    tkmessageBox(message=paste("Directory ", datap," does not exist.", sep=""))
    contents <- NULL
  }else
  contents <- dir(datap)
  
  
  disc <- sapply(contents, function(ch) {
    res <- grep("^FULL", ch)
   
  })
  
  if(length(unlist(disc)) > 0){
    ind <- sapply(names(unlist(disc)), grep, contents)
    
    contents <- contents[-unlist(ind)]
  }
###  print(contents)
  
  end.txt <- sapply(contents, function(ch) {
    res <- grep("txt$", ch)
   
    return(res)
  })

  end.txt <- unlist(end.txt)
  end.txt <- names(end.txt)
###  print(end.txt)

  
  end.xls <-  sapply(contents, function(ch) {
    res <- grep("xls$", ch)
   
    return(res)
  })
  end.xls <- unlist(end.xls)
  end.xls <- names(end.xls)
###  print(end.xls)

  end.csv <-  sapply(contents, function(ch) {
    res <- grep("csv$", ch)
   
    return(res)
  })
  end.csv <- unlist(end.csv)
  end.csv <- names(end.csv)
###    print(end.csv)
  
  contents <- c(end.csv, end.xls, end.txt)
 
  return(contents)
  
}

find.ages <- function(datap=NULL, file="allc.txt",
                      aged = age.digits, yeard = year.digits)
  {
    if(length(datap) > 0)
      dthstring  <- paste(datap,file,sep="")
    else
      dthstring <- file
    
###    print(paste("Reading file ", dthstring, sep=""))
    dth0 <- scan(file=dthstring,
                 na.strings="-999.0000",multi.line=T,quiet=T)
    dth0 <- matrix(dth0,ncol=3,byrow=T)
    csid <- dth0[,2]
    dat <- unique.default(csid%%10^(aged+ yeard))
    datage <- unique.default(dat%/%10^yeard)
    return(datage)
  }
