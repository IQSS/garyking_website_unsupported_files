## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      make.mortality.data
##
## PLACE:     Preprocessing module, the old Gauss make_mortality_data2.g
##            function rewritten in R
##
## IMPORTED functions:
##                      data.funcs.R
##                      make.dth.R
##                      make.covariates.R
##                      setWHO.R
##
## DESCRIPTION: This is the main program for all preprocessing staff
##
## FORMAT:
##
## INPUT:  the base environment env.base, which contains env.who with
##         all satatic (global) variables needed to build the data set.
##
## OUTPUT:
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 04/09/2003
## 
## ************************************************************************
## ************************************************************************

make.mortality.data <- function(ebase= env.base){
  ebase <- get("env.base", env=parent.frame());
  env.base <- ebase; 
  ewho <- get("env.who", env=ebase)
  env.who <- ewho 
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho)
  popu <- get("population", env=ewho)
  cov.type  <- get("cov.type", env=ewho)
  datapath <- get("datapath", env=ewho)
  whocovpath <- get("whocovpath", env=ewho)
  whotransform <- get("whotransform", env=ewho)
### In terms of the global, the structure of dataset cstsid: 
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits 
  assign("digit.cntry.begin",  digit.cntry.begin, env=ewho)
  assign("digit.cntry.end",  digit.cntry.end, env=ewho)
  assign("digit.age.begin",  digit.age.begin, env=ewho)
  assign("digit.age.end",  digit.age.end, env=ewho)
  assign("digit.year.begin",  digit.year.begin, env=ewho)
  assign("digit.year.end",  digit.year.end, env=ewho)
  
  
  
### READ DTH AND OTHER BASIC VARIABLES
  whodisease <- get("whodisease", env=ewho)
  whogender <- get("whogender", env=ewho)
 
  death  <- make.dth.WHO(whodisease,whogender,popu, datapath)
  dth    <- death$dth
  cstsid <- death$cstsid
  popu <- death$popu
  popu[popu <= 0] <- NA
  
### Fixing zeros
 print("Setting 0.5 to any dth below 0.5 to avoid possible zeros:")
  dth[dth <= 0.5]  <- 0.5
### zeros fixedd
  
   
  remove(death)
  
### inherits=T will also put them all the way up to the 
### .GlobalEnv, but we do not want them in user's env
##  assign("dth", dth, env=ewho, inherits=T)
##  assign("cstsid", cstsid, env=ewho, inherits=T)
##  assign("popu", popu, env=ewho, inherits=T)
  
  assign("dth", dth, env=ewho)
  assign("cstsid", cstsid, env=ewho)
  assign("popu", popu, env=ewho)

  cntry <- digitpull(cstsid, digit.cntry.begin, digit.cntry.end)
  cntrylist <- unique.default(cntry);
  t <- digitpull(cstsid,digit.year.begin,digit.year.end)
  
### MAKE COVARIATES 

### extended REGEXP: to match "ln" at the beginning of word only use"^ln"
### to anchor "ln" at the end of word use "ln$";
### anywhere between letters in middle of word: ".ln"
### whocovariates is a combination of lncov and cov (some logarithmic and others no)
  
  whotime <- FALSE;
  whocnst <- FALSE;
  whologtime <- FALSE; 
  whocovariates <- get("whocovariates", env=ewho)
  cov.remainder <- as.vector(whocovariates)
  
  ## dealing with time and its powers, i.e. time, (time)3
 if(is.null(cov.remainder))
   stop("Error: You need unless cnst & time in covaraites")
  
     indt <- grep("^time", as.vector(cov.remainder))
     indt <- c(indt, grep("^\\(time", as.vector(cov.remainder))) 
     logtime <- grep("ln\\(time", as.vector(cov.remainder))
    ## no include ln(time)
     if(length(indt) > 0 && length(logtime) > 0)
    {
        whotime <-  T
        powtime <- setdiff(indt, logtime) ##only power time but not its log
        cov.remainder <- cov.remainder[-powtime]
    }else if(length(indt) > 0 ){
        whotime <- T
        powtime <- indt
        cov.remainder <- cov.remainder[-powtime]
    }
    
  ## dealing with log(time) and its powers, i.e. time, (time)3
 if(is.null(cov.remainder))
   stop("Error: You need unless cnst & time in covariates")
  ## now you should only get powers of log(time) if any
  lnind <- grep("ln\\(time", as.vector(cov.remainder))
  if(length(lnind) >= 1 ){
      cov.remainder <- cov.remainder[-lnind]
      whologtime <- TRUE
      }  
 ## dealing with time and its powers, i.e. time, (time)3
 if(is.null(cov.remainder))
   stop("Error: You need cnst & time in covaraites")
        
  if (!is.null(cov.remainder)){
    covsplit <- split(cov.remainder,cov.remainder == "cnst");
  if (!is.null(covsplit$"TRUE")) whocnst <- TRUE
    cov.remainder <- covsplit$"FALSE";
  }
 

  if (!is.null(cov.remainder)) {
    lst <- build.covariates(cov.remainder,cov.type)
    covtmp <- cov.remainder
    print(cov.remainder)
    
    if(length(lst) > 0){
      covtmp   <- lst$covtmp
      cov.type <- lst$cov.type
      covnude <- lst$covnude
      logpowcol <- lst$logpowcol
      powcol <- lst$powcol
      logcol <- lst$logcol
   }else
    covtmp <- cov.remainder
      
    makecov <- make.covariates.WHO(covlist=covtmp, cntrylist=cntrylist,
                                   type=cov.type,datapath=whocovpath,
                       who.year.digits,who.cntry.digits, who.age.digits)
    makecov <- makecov
   
    covariates <- makecov$covariates
    WHOcovid <- makecov$covid
    remove(makecov)
    
### take power or log of nude covariates,
### if they are specified in user inputs

   covar <- covariates.mat(lst,covariates)
     
 #@#  if (length(covar) > 0)
    covariates <- covar

   covtmp <- cov.remainder
### just to make sure we identify some cov as "(gdp)" or "gdp"
   cov.remainder <- sapply(cov.remainder, function(x) {
                          ln <- grep("^ln", x)
                          if(length(ln) > 0 )
                            return(x)
                          st <- grep("\\(", x)
                          en <- grep(")$", x)
                          if(length(st) > 0 && length(en) > 0){
                            x <- gsub("\\(","",x )
                            x <- gsub(")$","", x) }
                          return(x) })
   
    indWHO <- setdiff(WHOcovid, cstsid)
    indcst <- setdiff(cstsid, WHOcovid)
      
    if (!identical(WHOcovid, cstsid)) stop("Error in covariates id")
      rownames(covariates) <- as.character(WHOcovid);
    if (!identical(as.vector(cov.remainder),colnames(covariates)[1:length(cov.remainder)])){
      stop("Error in covariates names")
      print(as.vector(cov.remainder))
      print(colnames(covariates) )}
    
  } else
  covariates <- NULL
   
  
  if (whotime == TRUE) {
    print("Adding time as covariate")
    ixpow <- find.powers.time(powtime,
                              as.vector(whocovariates))
    ixnm <- as.numeric(names(ixpow))
    wname <- paste("(time)", ixpow, sep="")
    ind1 <- grep("\\(time\\)1", wname)
    if(length(ind1) > 0)
        wname[ind1] <- "time"
   
    for(n in (1:length(ixpow))){
        p <- ixpow[n]
        fun <- t
        fun <- fun^p
       colnames( fun) <- wname[n]
       covariates <- cbind(covariates,fun)
    }
        
}
 

   if (whologtime == TRUE)
   {
    print("Adding log(time) as covariate")
    indpower <- find.powers.logtime(ind=logtime,
                                    covs=as.vector(whocovariates));
    ind <- as.numeric(names(indpower))
    
    vname <- paste("ln(time)", indpower, sep="")
    ind1 <- grep("ln\\(time\\)1", vname)
    if(length(ind1) > 0)
        vname[ind1] <- "ln(time)"
    for(n in (1:length(indpower))){
        p <- indpower[n]
        fun <- log(t)
        fun <- fun^p
       colnames( fun) <- vname[n]
       covariates <- cbind(covariates,fun)
    }
        
}
   
  

  
### adding constant if requested
    
  if (whocnst == TRUE) {
    print("Adding constant as covariate");
    cnst <- matrix(1,c(nrow(t),1));
    colnames(cnst) <- "cnst";
    covariates    <- cbind(covariates, cnst);
  }
 
  whocovariates <- as.vector(colnames(covariates));
  assign("whocovariates", whocovariates, env=ewho)
  
  print("The covariates are: ");
  print(colnames(covariates))

  
### ASSEMBLE DATAMAT AND GIVE NAMES TO VARIABLES 

  flag   <- matrix(0, nrow=nrow(dth))
  cntry  <- matrix(cntry)
   t      <- matrix(t)

  if ( length(cntry) != nrow(dth) || length(t) != nrow(dth))
    stop(message="wrong building datamat: all cols must have lengths =nrow(dth)")

### all datamat's columns are filled with data from files, but for
### columns flag =0 and cnst =1

  datamat  <- cbind(dth,cstsid,popu,flag,cntry,t,covariates)
  namecol  <- c("dth","id","popu","flag","cntry","t")
  covindx  <- length(namecol)
  namecol <- c(namecol,whocovariates);

  colnames(datamat) <- namecol;
  
### all the covariates for the local run (not a global as whocovariates)
  whocovlist <- matrix(namecol[-(1:covindx)]) 
  
### make -999 missing
  datamat[datamat == -999] <- NA

### SELECT COUNTRY LIST: WHOUSERCNTRYLIST 
### cntrylist is a selection of countries from the program make.dth
### user makes own selection of cntry's or subregs  
### if no user choice,then count observations and select with whoskip


### whousercntrylist and whousersubreglist are obtained from user input
### if both are empty, then select countries with observ >= whoskip
  whousercntrylist <- get("whousercntrylist", env=ewho)
  cntrylist <- whousercntrylist;
 
  whoskip <- get("whoskip", env=ewho)
 
  if (any(is.na(cntrylist))) { ## if1 whousercntrylist 
 ### select based on minimum observations, whoskip
      aux <- count.observations(datamat[,"dth"],  datamat[,"id"])
     
      cntrylist <- (split.data.frame(aux, aux[ , 2] >= whoskip))$T[ ,1]
      print(paste("There are",length(cntrylist),"countries with more than",
                  whoskip, "observations"))
### whousercntrylist= countries with >=  whoskip observations 
      cntrylist <- matrix(sort(cntrylist))
      rm(aux)
    } ## end if1 any(is.na(whousercntrylist))

### cntrylist may still be empty; then  
### take everything from cntrylist in the file make.dth

### SUBSET OF COUNTRIES OR REGIONS ********/
### further pojection from cntrylist based on user choices or whoskip

  if (!any(is.na(cntrylist))){      
    print("Selecting countries")
    tmpindx <- is.element(datamat[ ,"cntry"],cntrylist)
    datamat <- datamat[tmpindx, ]
    rm(tmpindx) }
  
### creates a new variable with the chosen countries for this run

  whocntrylist <- unique.default(datamat[, "cntry"])
  
### SELECT USER DEFINED AGE GROUPS 
  whouserages <- get("whouserages", env=ewho)
  
  if (any(is.na(whouserages)))  whouserages <- drop.ages(whodisease);
  
  whouserages <- sort(whouserages)
  agelist     <- digitpull(datamat[ ,"id"],digit.age.begin,digit.age.end )
  age.v   <- unique.default(agelist)
  
  if (length(whouserages) < length(age.v) ) {
    cat("Selecting age groups: ", whouserages, "\n")
    tmpindx <- is.element(agelist, whouserages)
    datamat <- datamat[tmpindx, ]
    whoagelist <- unique.default(digitpull(datamat[ ,"id"],digit.age.begin,digit.age.end))
    rm(tmpindx)
  }   else   {
    whoagelist <-   age.v;
  }
  
### whoagelist is not global variable  but I define it locally:
  
### MAKE SPACE FOR OUT OF SAMPLE 

### idcol <- col(datamat)[1, colnames(datamat) == "id"]  ### the col number
  whofore <- get("whofore", env=ewho)
  tmax    <- max(datamat[,"t"])
  timevec <- c(tmax, whofore)

  if (ncol(datamat) != length(namecol))   ## recall namecol = colnames(datamat)
    stop(message="all columns of datamat must have a name")
  print("Making space for out of sample")

  rownames(datamat) <- datamat[,"id"]
  aux <- datamat[ ,"id"]
### we may not need to pass aux after testing
  xtdatamat <- extend.datamat(whocntrylist,whoagelist,timevec,colnames(datamat),aux)
### before extending datamat count rows
  nrdata   <- nrow(datamat)
  nrxtdata <- nrdata
  if (length(xtdatamat) > 0){
  datamat  <- rbind(datamat, xtdatamat)
  nrxtdata <- nrow(datamat)}
  rm(timevec); rm(aux)
  
### REORGANIZED DATAMAT: sorting along the column "id" = cstsid 
  
  ord <- order(datamat[,"id"])
  datamat <- datamat[ord, ]
  rm(ord)

### CONVERTING DTH TO  MORTALITY 
 
  print("Converting dth column to mortality")
  
  if (any(datamat[,"popu"] == 0, na.rm= T)){
    print("Found some population = 0, and change to NA")
    datamat[, "popu"] <- NA }
  
  datamat[,"dth"] <- datamat[,"dth"]/datamat[,"popu"]
  
### TRANSFORM DTH AND ALLC 

  print("Transforming death")

  datamat[, "dth"] <- trans(datamat[,"dth"], whotransform)

### RECODE MISSING INSAMPLE DTH TO -111 
  whoyrest <- get("whoyrest", env=ewho)
     
  datamat[,"flag"] <- ifelse (is.na(datamat[ ,"dth"]) & datamat[,"t"] <= whoyrest, -111,
                              datamat[ ,"flag"])
  
### RECODE MISSING OUTSAMPLE DTH TO -222 

  datamat[,"flag"] <- ifelse (is.na(datamat[ ,"dth"]) & datamat[,"t"] > whoyrest, -222,
                              datamat[ ,"flag"])

### SPLIT DATAMAT WITH csid (cross sectional identifiers) 
  
  datasubmat <- split.data.frame(datamat, datamat[ ,"id"]%/%10^(who.year.digits))
  
  stopifnot (length(datasubmat) ==( length(whoagelist) * length(whocntrylist)))
  print(paste("Number of csid's in datamat = ",length(datasubmat)))
  
### elements of list datasubmat must have a range in time:  
  timerng <- range(datamat[,"t"])
  
### thus, the number of rows of any list element is:
  nrsubmat <- abs(timerng[2]-timerng[1])+ 1         

### RECODE FLAG for NA's in rows <= whoyrest & DEP VAR BEFORE FIRST OBV TO -333  
  
### assume elements datasubmat have same time range/or equal no.rows:
  indxyrest <- seq(along= datasubmat[[1]][ ,"t"])[ datasubmat[[1]][ ,"t"] == whoyrest]
  nyrest <- 1:indxyrest

### creating global variables for output of chkrest,
### and to delete some csid that are flagged with -999

### making some globals for persistence through function calls
  assign("etrial",new.env(TRUE, NULL), env=ebase)
  assign("vecount", vector(, length=0) , env=get("etrial", env=ebase))
  assign("count", 0, env=get("etrial", env=ebase))

### renaming datasubmat after eliminating countries; call it newsubmat      
  newsubmat <- lapply(datasubmat, FUN="chkrest",timerng,nyrest, whoskip,ebase)
  vecount <- get("vecount", env=get("etrial", env=ebase))
  count <- get("count", env=get("etrial", env=ebase))
  delcntry <- length(vecount)/length(whoagelist)

### eliminate all empty arrays from newsubmat
  if (length(vecount) > 0) {
    newsubmat <- newsubmat[-vecount]
    cntid <- sapply(newsubmat, function(x) unique.default(x[,"cntry"]), simplify=T)
    whocntrylist <- unique.default(cntid)
    if (length(whocntrylist) == 0) stop("No countries left in data base, probably whoskip too high");
    print("Remaining Countries after deletion: ")
  }else
    print("The countries in the current data are:");
    print(whocntrylist)
### remove locally
  rm(count, vecount)
  
### NAMING THE ELEMENTS OF LIST WITH CSID's
### cross sectional id's (countrycode + agegroup) after deletion of flag -999:
  fd <- floor(log10(max(whoagelist))) + 1
  csid <- sort(kronecker(whocntrylist * 10^fd, whoagelist, FUN = "+"))
  names(newsubmat) <- csid
  
### The list list.covariates has, for each cross-section, the set of covariates
### for that cross-section. The covariates are still the same for all csid 
 list.covariates <- lapply(newsubmat, function(x){whocovlist <- colnames(x)[-(1:covindx)]})
 names(list.covariates) <- csid
### Actually, the covaraites since they are still same are obtained:  
### whocovlist <- unique.default(unlist(list.covariates))
  
 ind <- as.list(1:length(newsubmat));
 names(ind) <- csid;
  
### MISSING COVARIATES
  
### Now we eliminate the covariates which are missing in entire data time series.
### We consider missing covariates (such as tobacco) for t <= tmax, and for each csid 
### we use elim.all.na to make a new list of covariates, specific to
### each cross-section, and then lapply del.cov to make the change in newsubmat
### (elim.all.na and del.cov are in data.funcs.R and are documented)
  
  print(paste("Deleting missing covariates in entire time series, tmax= ", tmax)) 
  list.covariates <- lapply(ind,FUN="elim.all.na",newsubmat,list.covariates,tmax, ebase, ewho)
  
  newsubmat <- lapply(ind,FUN="del.cov",newsubmat,whocovlist,list.covariates)
  
### FIND wholag.max
### I am using together with lagcov, which finds for each csid the max to lag 
### It groups countries according on how much data for dth and covariates is available
  
  wholag.max.lst <- lapply(ind, FUN="wholagMax",newsubmat,list.covariates, tmax, ebase);
   print("done with whoLagMax")
   wholag.max.lst <- wholag.max.lst 
### to include depvar (i.e. dth/
### LAG COVARIATES
  wholag <- get("wholag", env=ewho)
  print("Lagging covariates")
  newsubmat <- lapply(ind, FUN="lagcov",newsubmat,list.covariates,wholag.max.lst, 
                      timerng,wholag,tmax,covindx, ebase)
  
### consistency checks in case that lagcov created empty matrices,
### such as when including dth as covariate  
 ind.to.keep <- sapply(newsubmat, function(x){
   to.keep <- ifelse(length(x) > 0,T,F) })
  
 if(any(ind.to.keep==F)){
  newsubmat <- newsubmat[ind.to.keep]
  if(length(newsubmat) <= 0)
    stop("No countries left in data set...Review your depvar and covarites data")
  csid <- csid[ind.to.keep]
  ind <- as.list(1:length(newsubmat));
  names(ind) <- csid;}
  
### FUN= "lagcov", lags the covariates depending on the relative values
### of wholag and foy - fy; foy=(first year dth observ) and fy=timerng[1].
### After applying "lagcov" the list of covariates migth have changed,
### For any csid, if wholag <  foy - fy; e.g.,wholag <= 30,
### the list.covariates still remain the same after lagging,( but for those 
### that were completed missed, and which we eliminated with elim.all.na.)
  
  list.covariates <- lapply(newsubmat, function(x){whocovlist <- colnames(x)[-(1:covindx)]})
  names( list.covariates) <- csid
  
### But if wholag >  foy - fy, the covariates might depend on csid, even
### if wholag is the same, because the data is missing for years:  
### fy > year >= (foy - wholag). Function "lagcov" set all   
### covariates ready for deletion by marking them with NA's 
### in the entire time series (see data.funcs.R), with the  
### exception of "cnst" and "time", which takes its actual values. 
### If "cnst" and "time" were not in the list of covariates
### FUN= "lagcov" has the necessary code to include them.  
### FUN="elim.all.na" eliminates the covariates with NA's.   
  

### DECIDE ABOUT TOBACCO, FAT, ALLC, & WHOLAGDTH################

### Now we will modify list.covariates further according to some criteria.
### Everytime we redefine list.covariates we delete covariates in newsubmat
### in order to match the structure of list.covariates. This operation is
### performed by lapplying the function del.cov to newsubmat
### Note that "elim.all.na" was used previously for t <= tmax (or entire time data series).
### We use it next to eliminate those covariates that are missing in
### the insample period for t <= whoyrest. The operation with "del.cov"
### also eliminates those that were marked with NA's with FUN="lagcov".
 
  print(paste("Deleting missing covariates for the insample period, whoyrest= ", whoyrest)) 
  list.covariates <- lapply(ind, FUN="elim.all.na",newsubmat,list.covariates,whoyrest,ebase,ewho)
  newsubmat <- lapply(ind, FUN="del.cov",newsubmat,whocovlist,list.covariates)
  
### some consistency checks for empty matrices after the deletions
   ind.to.keep <- sapply(newsubmat, function(x){
   to.keep <- ifelse(length(x) > 0,T,F) })
   
  if(any(ind.to.keep==F)){
    newsubmat <- newsubmat[ind.to.keep]
     if(length(newsubmat) <= 0)
       stop("No countries left in data set...Review your depvar and covarites data")
    csid <- csid[ind.to.keep]
    ind <- as.list(1:length(newsubmat));
    names(ind) <- csid;}
  
    list.covariates <- lapply(ind, FUN="elim.all.na",newsubmat,list.covariates,whoyrest,ebase,ewho)
    
### Now we deal with covariates which have some missing values.
### The algorithm find the covariates which have missing values
### and which have not. Then it looks at the set of covariates with missing values:
### it counts the percentage of insample observations that have to be thrown away using 
### these covariates. If this percentage exceeds who.lag.cutoff then we delete
### those covariates from the list of desired covariates, and store the desired
### covariates in list.covariates. Then we lapply del.cov to modify newsubmat
### accordingly
  who.lag.cutoff <- get("who.lag.cutoff",env=ewho) 
  print("Checking for covariates with some sparse missing values:") 
  list.covariates <- lapply(ind, FUN="elim.cov",newsubmat,list.covariates,whoyrest,who.lag.cutoff,ebase)
  
  newsubmat <- lapply(ind, FUN="del.cov",newsubmat,whocovlist,list.covariates)

### Now we remove some user specified covariates from some user specified age groups
### the function age.remove is in data.funcs and it is documented
  who.cov.select <- get("who.cov.select", env=ewho)
  who.age.select <- get("who.age.select", env=ewho)
  
  print("Removing some user specified covariates from specified age groups:") 
  if (!is.na(who.cov.select) && !is.na(who.age.select)) {
    list.covariates <- lapply(ind,FUN="age.remove",list.covariates,who.cov.select,who.age.select, ebase)
    newsubmat <- lapply(ind,FUN="del.cov",newsubmat,whocovlist,list.covariates)
  }
  names(newsubmat) <- csid;
  
### consistency checks, no dth data as depvar or only one dth  
### delete csid's with only one dth observation for insample period or empty matrices
  ind.to.keep <- sapply(1:length(newsubmat), function(n,newsubmat){
    x <- newsubmat[[n]]
    nm <- names(newsubmat)[n]
    to.keep <- ifelse(length(x) > 0,T,F)
    if(to.keep == T && length(na.omit(x[,"dth"])) <= 1 ) 
       to.keep <- F
###    if(length(na.omit(x[,"dth"])) <= 2)
###      cat("names nm = ", nm, "nos. of dth", length(na.omit(x[,"dth"])), "\n")
    return(to.keep)},newsubmat)

 
  newsubmat <- newsubmat[ind.to.keep]
  if(length(newsubmat) <= 0)
    stop("No countries left in data set...Review your depvar and covarites data")
  cntid <- sapply(newsubmat, function(x) unique.default(x[,"cntry"]), simplify=T)
     whocntrylist <- unique.default(cntid)
     if (length(whocntrylist) == 0) stop("No countries left in data base, probably whoskip too high");
  
  if(any(ind.to.keep==F)){
  print("Remaining Countries after deletion because no insample deaths <= 1: ")
     print(whocntrylist)}

### for convenience convert elements of newsubmat into data frame and
### name all rows of each list element with the "id" unique identifier
### newsubmat   <- lapply(newsubmat, function(x){ dimnames(x)[[1]] <- x[,"id"]; return(x)})
  
### xsclSTANDARDIZE WHOCOVARIATES & MAKE DATA.FRAMES 
  whostandardize <- get("whostandardize", env=ewho)
  if (whostandardize == TRUE){
    print("standardizing whocovariates")
    framesubmat <- lapply(newsubmat, FUN="standard",covindx)
  }else{
    framesubmat <- lapply(newsubmat, function(x){ x <- data.frame(x, row.names=x[,"id"])})}
  
  
  if(length(framesubmat) != length(newsubmat))
    stop(message="Dataframe and mat have different lengths; something is wrong")
 
                       
### MAKE WHOCOV 
  print("Making whocov")
  
  whocovid <- lapply( framesubmat,
                     function(x) {## subset.data.frame(x, select= id)
### same as selecting with columns
                       x["id"]
                     } )
  
### whocovlist = whocovariates but not global, matrices of 1 col
  whocov   <- lapply(framesubmat,
                     function(x){## subset.data.frame(x, select=whocovlist)
                       x[-(1:covindx)]})

### find the index row corresponding to a cstsid, for example
### (I do not need this but just write it for future development): 

### indcsid <- seq(along=names(whocov))[names(whocov)== "101045" ]
### indcstsid <- grep("1980$", row.names(whocov[[indcsid]]))
### indcstsid <- seq(along=whocov[[indcsid]])[row.names(whocov[[indcsid]]) == "1010451980"]
  
### REMOVE ROWS WITH -333 FOR INSAMPLE & OUTSAMPLE DATA
  framesubmat <- lapply(framesubmat, function(x) subset.data.frame(x, na.omit(flag) != -333))

### INSAMPLE DATA 
 print("Creating insample")
  
  whoinsampy  <- lapply(framesubmat,
                      function(x){subset.data.frame(x, t <= whoyrest,select= dth)})
whoinsampid <- lapply(framesubmat,
                      function(x) subset.data.frame(x, x[,"t"] <= whoyrest, select= id))
whopopul    <- lapply(framesubmat,
                      function(x) subset.data.frame(x, t <= whoyrest, select= popu))
### already standardize:
  whoinsampx  <- lapply(framesubmat,
                        function(x){subset.data.frame(x, t <= whoyrest, select= -(1:covindx))})

     
###
### OUTSAMPLE DATA
     
print("Creating outsample")
  
whoutsampy  <- lapply(framesubmat,
                      function(x){subset.data.frame(x, t > whoyrest,select= dth)})
whoutsampid <- lapply(framesubmat,
                      function(x) subset.data.frame(x, x[,"t"] > whoyrest, select= id))
whopopulos   <- lapply(framesubmat,
                       function(x) subset.data.frame(x, t > whoyrest, popu))
### already standardize:
whoutsampx  <- lapply(framesubmat,
                      function(x){subset.data.frame(x, t > whoyrest, select= -(1:covindx))})
       
### OUTPUT
  cntry.vec <- whocntrylist
  assign("cntry.vec", cntry.vec, env=ewho)
  age.vec   <- whoagelist
  assign("age.vec", age.vec, env=ewho)
  n.cntry   <- length(cntry.vec)
  assign("n.cntry", n.cntry, env=ewho)
  n.age     <- length(age.vec)
  assign("n.age", n.age, env=ewho)
 assign("list.covariates", list.covariates, env=ewho) 
### It turns out that if we keep the elements of variables such as insampx or insampy as data frames
### we cannot perform standard matrix operations on them, as necessary in most algorithms.
### so they must be matrices. this problem does not show up in LC, but just by chance.

  whocov   <- lapply(whocov,as.matrix);
  assign("whocov", whocov, env=ewho)
  assign("whocovid", whocovid,env=ewho)
  assign("wholag.max.lst", wholag.max.lst, env=ewho)  
###in  
  whoinsampy  <- lapply(whoinsampy,as.matrix);
  assign("whoinsampy", whoinsampy, env=ewho)
  assign("whoinsampid", whoinsampid, env=ewho)
  whopopul    <- lapply(whopopul,as.matrix);
  assign("whopopul", whopopul, env=ewho)  
  whoinsampx  <- lapply(whoinsampx,as.matrix);
  assign("whoinsampx", whoinsampx, env=ewho)  
###out
  whoutsampy  <- lapply(whoutsampy,as.matrix);
  assign("whoutsampy", whoutsampy, env=ewho)
  assign("whoutsampid", whoutsampid, env=ewho)  
  whopopulos  <- lapply(whopopulos,as.matrix);
  assign("whopopulos", whopopulos, env=ewho)  
  whoutsampx  <- lapply(whoutsampx,as.matrix);
  assign("whoutsampx", whoutsampx, env=ewho)  

### ELIMINATE COLLINEARITIES
  whoelim.collinear <- get("whoelim.collinear", env=ewho)
  if (whoelim.collinear == TRUE) preproc.elim.collinear(ebase);

### this is to make it easier to establish equality between whocovariates and the covariates
### stored in a pre-existing data file
  
  whocovariates <- sort(whocovariates);
  assign("whocovariates", whocovariates, env=ewho)
  
  if (!any(is.na(whousercntrylist))) assign("whousercntrylist",sort(whousercntrylist), env=ewho);
  
### Find the names of countries that are included in cntry.vec or whocntrylist
### creates a list with the names of those countries and indeces with codes; 
### for example: cntry.names.lst["2450"] = USA;

    nmcd <- cntryid(whousercntry = cntry.vec)
    cntry.names.lst <- as.list(nmcd$name)
    names(cntry.names.lst) <- nmcd$code
    assign("cntry.names.lst", unlist(cntry.names.lst), env=ewho)

### CREATE OUTPUT FILE
  whooutpath <- get("whooutpath", env=ewho)
  if (!is.na(whooutpath)){
    print("Saving preprocessing data file");
   save.data.files();
  }
  }

 

### LIST OF MISSING CODES 

### 9999 = any variables missing in year 2000
### -333 = dep variable before first observation
### -111 = dep variable insample;
### -222 = dep variable missing out of sample 
### -999 = the whole insample cross-section is missing
### -444 = missing lag dth
### -555 = denotes any covariate labeled missing
### -666 = cov made missing by lagging: ready for deletion
### -777 = all the remaining missing values for both dep var and covariates

### *****************************************************************/    
