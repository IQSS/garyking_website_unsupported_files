
chapter11.9 <- function()
{
  fhisto <- function(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, ff){
    silent <- readline("\nEnter 1 to see the histograms else <return>...\n")
    
    if(silent==1){
      depvar <- leftside.formula(ff)$numerator
      histograph(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, depvar,
                 model="ebayes", graphics.file=NA)
    }
    else
      return(list())
  }
  message("Dataobj for examples 11.9 breast cancer...")
    message("Countries with 25 or more observations; disease breast cancer, lag 30 years...")
    user.prompt()
    datm <- dataobjWHO(disease="brst", cov.FULL= c("FULL.hc","FULL.gdp", "tobacco", "FULL.fat"), 
                   timeseries=T, lagyears=30, nobvs=25)
    datlst <- datm$data
    datlst <- selectagesWHO(datlst, age.vec=seq(from=25, to=80, by=5))
    datm$data <- datlst
    
    datbrst.ebayes <<- datm
    message("Formula for female population...")
    ff <- log((brst3 + 0.5)/popu3) ~ log(hc) + log(gdp) + log(tobacco3) + log(fat) + time
    print(ff)
    message("Running yourcast with model ebayes...")
    user.prompt()
    yebayes <- yourcast(formula=ff, dataobj=datbrst.ebayes, elim.collinear= FALSE, model="ebayes")
    auto <- yebayes$summary
    distvec   <- yebayes$summary.vec
    d1.a.vec <- distvec$d1.a
    d1.t.vec <- distvec$d1.t
    dtda.vec <- distvec$dtda
    SD.vec <- distvec$SD
    message("Summary measures are...")
    auto <- unlist(auto)
   
    fs <- fhisto(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, ff)
    
    message("Dataobj for breast cancer and Croatia...")
    user.prompt()
  
    dat.croatia <- dataobjWHO(disease="brst", cov.FULL= c("FULL.hc","FULL.gdp", "tobacco", "FULL.fat"), 
                   timeseries=T, lagyears=30, cntry.vec=c(Croatia=4038))
    datlst <- dat.croatia$data
    datlst <- selectagesWHO(datlst, age.vec=seq(from=25, to=80, by=5))
    dat.croatia$data <- datlst
    datbrst.croatia <<- dat.croatia
    message("Running yourcast with model OLS...")
    user.prompt()
    yols <- yourcast(formula=ff, dataobj=datbrst.croatia, model="OLS",elim.collinear=FALSE)
    message("Generating the graphics for OLS...")
    user.prompt()
    yourgraph(yols)
    message("Running yourcast with MAP model and...\n smoothing parameters obtained from summary measures")
    user.prompt()
    
    d1.a <- auto["d1.a"]
    d1.t <- auto["d1.t"]
    dtda <- auto["dtda"]
    SD   <- auto["SD"]
   
    z.mean <- c(-11.391, -10.148,  -9.305,  -8.693,
                -8.232,  -7.954,  -7.798,  -7.678,  -7.578,
                -7.434,   -7.294,  -6.926)
   names(z.mean) <- 5:16*5

    ymap <- yourcast(model="map", Ha.sigma=c(0.1,1.5,6,d1.a, SD),
                    Ht.sigma=c(0.1,1.5,6,d1.t, sims=20), Hat.sigma=c(0.1,1.5,6,dtda),
                     zero.mean=z.mean)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap)

  }

chapter11.9()
