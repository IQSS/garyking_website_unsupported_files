

chapter2.7 <- function()
  {
    message("Examples 2.7...")

    message("Dataobj for male suicide, and USA ...")
    verb <- T
    verb <- user.prompt(1)
   
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    suic <- eval(as.symbol(data(suic)))
    population <- eval(as.symbol(data(population)))
    cntrycode <- eval(as.symbol(data(cntry.codes)))
    
    suic[suic[,"suic"] <= 0.5 & !is.na(suic[,"suic"]),"suic"] <- 0.5
    
    cvec <- c(USA=2450)
    
    dataobj <<- dataobjWHO(disease=suic,pop=population, cov.FULL=NULL,
                           cntry.vec=cvec,lagyears=60, 
                           nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                           icode="ggggaatttt",proxfile=NULL,
                           Gnames=cntrycode, selectages=seq(from=15,to=80, by=5),
                           verbose=verb)

    message("Formula...")
    fsuic <- log(suic2/popu2) ~ time
    print(fsuic)
    message("Running yourcast with model LC...")
    user.prompt()
    ysuic <- yourcast(formula=fsuic, dataobj=dataobj, model="LC",
                      sample.frame=c(1950,2000, 2001, 2060), verbose=verb)
    message("Running yourgraph..") 
    user.prompt()
   
    yourgraph(ysuic)
      
    message("Dataobj for female digestive disease, and Hungary...\n")
    user.prompt()
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
    
    dgst <- eval(as.symbol(data(dgst)))
    dgst[dgst[,"dgst"] <= 0.5 & !is.na(dgst[,"dgst"]),"dgst"] <- 0.5
    
    dataobj <<- dataobjWHO(disease=dgst,pop=population, cov.FULL=NULL,
                          cntry.vec=c(Hungary=4150),
                          lagyears=60, nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                          icode="ggggaatttt",proxfile=NULL,
                          Gnames=cntrycode, selectages=NULL, verbose=verb)

    message("Formula...")
    fdgst <- log(dgst3/popu3) ~ time
    print(fdgst)
    
    message("Running yourcast with model LC...\n")
    user.prompt()
    ydgst <- yourcast(formula=fdgst, dataobj=dataobj, model="LC",
                      sample.frame=c(1950,2000, 2001, 2060), verbose=verb)
    message("Running yourgraph..") 
    user.prompt()
    yourgraph(ydgst)
    
    message("Dataobj for female cervix cancer, and United Kingdom...")
    user.prompt()
    if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)    
        
    cerv <- eval(as.symbol(data(cerv)))
    cerv[cerv[,"cerv"] <= 0.5 & !is.na(cerv[,"cerv"]),"cerv"] <- 0.5
    
    dataobj <<- dataobjWHO(disease=cerv,pop=population,cov.FULL=NULL,
                           cntry.vec=c(UnitedKingdom=4308),lagyears=60, 
                           nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                           icode="ggggaatttt",proxfile=NULL,
                           Gnames=cntrycode, selectages=seq(from=25, to=80, by=5),
                           verbose=verb)
         
    message("Formula...")
    fcerv <- log(cerv3/popu3) ~ time
    print(fcerv)
   
    message("Running yourcast with model LC...")
    user.prompt()
    ycerv <- yourcast(formula=fcerv, dataobj=dataobj, model="LC",
                      sample.frame=c(1950,2000, 2001, 2060), verbose=verb)
    message("Running yourgraph..") 
    user.prompt()
    yourgraph(ycerv)
       

  }


chapter2.7()
