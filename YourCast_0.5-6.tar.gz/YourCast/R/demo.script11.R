democast <- function(){
cat("Creating dataobj for examples 11.4-11.8 in the book...\n")

datobj <<- dataobjWHO(disease= c("lung"), cov.FULL= NULL, timeseries=T, lagyears=30,
                     cntry.vec= c(Mauritius=1300, Peru=2370, Thailand=3380, Lithuania=4188))

user.prompt()
cat("Formula for male population and lung disease...\n")
ff <- log(lung2/popu2 + 5.e-5) ~ time + log(time -1875)
print(ff)
user.prompt()
cat("Running yourcast with model OLS...\n")
yols <- yourcast(formula=ff, dataobj=datobj)
user.prompt()
cat("Generating the graphics for OLS...\n")
yourgraph(yols)
user.prompt()
cat("Running yourcast with MAP model...\n")
ymap <- yourcast(model="map", Ha.sigma=0.3, Ht.sigma=1.58, Hat.sigma=0.12)
user.prompt()
cat("Generating the graphics for MAP...\n")
yourgraph(ymap)

}
