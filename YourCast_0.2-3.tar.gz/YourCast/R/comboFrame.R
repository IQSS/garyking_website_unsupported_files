##
## DESCRIPTION:  Simulates a drop down combo box.
##               Creates the GUI with text entry and a button to display the data
##               of the vector fruits, with starting selection fruit.selection. 
##               After clicking the button a frame is created showing all values of fruits.
##               If you double click in onwe of the vector fruit entries then it displays in 
##               the entry box; in addition, if selecting one value and clicking the
##               button again the selection also displays in the entry box. 
##               The frame with the fruits is created and destroy so the total container will
##               expands and shrinks as the button is clicked or after a double click
##               on fruit selection. We have space for a text label next to the text entry
##               which needs to be adjusted for lining of the text antry and the drop
##               down frame. Needs more work for better GUI and the expansion problem.
##               The results of selecting any index of fruits and multiple selections
##               are stored in variable comboEntry and comboValue, respectively.  
##                 
## FORMAT: comboBox(base, fruits,fruit.selection, text,listwidth, env.towrite).
##          Here base is the toplevel container or a tkframe and fruits is the vector
##          of data to display and base is the tktoplevel container or a tkframe to build the GUI
##          text is the text, if any, to display with comboBox,
##          fruit.selection the starting index for selection of fruits and listwidth an adjustment
##          variable to line the frame containing fruits with the entry box. 
##
## VALUE:  a tkframe, base, which needs to be included within a major (tktoplevel) or the toplevel 
##         container. Results from multiple selections and latest selection of vector fruits
##         are written in to the env.towrite and may be retreived from another GUI or container. 
##
## WRITTEN BY: Elena Villalon  
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## LAST MODIFIED: 26/01/2005
## 
## 
## ************************************************************************
## ************************************************************************

comboBox <- function(base, 
                     fruits = c("Apple", "Orange", "Banana", "Strawberry",
                                "Kiwi","Sandia", "Melon", "Pinapple" ),
                     fruit.selection=1 , text= NULL, listwidth=-5,
                     textna ="<NA>", env.towrite= parent.frame())
{
     ## listwidth = 15 is good for a text of 10 chars, increase it by
     ## about a ratio of 1.5, so text contains 30 chars then
     ## listwidth = 30*1.5 = 45
  
     stage  <-  F
     eCombo <- environment()
   
     butext <- "Click"
     butvar <- tclVar(butext)
     if(fruit.selection > 0){
       comboValue <- fruits[fruit.selection]
       if(identical(trim.blanks(comboValue),"<NA>") ||
          identical(trim.blanks(comboValue),"N/A") ||
          identical(trim.blanks(comboValue),NA) ||
          identical(trim.blanks(comboValue), textna))
         comboValue <- NA
     }else 
       comboValue <-  NULL

     assign("comboValue", comboValue, env=env.towrite)
     
     comboEntry <- comboValue
     assign("comboEntry", comboEntry, env=env.towrite)
 
     if(fruit.selection > 0){
       comboValue <- fruits[fruit.selection]
       comboEntry <- fruits[fruit.selection]
       var <- tclVar(comboValue)
     }else
     var <- tclVar("N/A")
    
           
    forclose <- function(...) { 
      stage <- get("stage", env=eCombo)
   
      if(stage == F){
        frame1 <- tkframe(frameAll, relief = "flat", borderwidth = 2)
         scr <- tkscrollbar(frame1, repeatinterval=5,
                       command=function(...)tkyview(frame1.lstbox1, ...))
        frame1.lstbox1 <- tklistbox(frame1, height=3, ##length(fruits),
                                    selectmode="single",
                                    yscrollcommand=function(...)tkset(scr,...),
                                    background="white") 
        for (i in 1:length(fruits))
          tkinsert(frame1.lstbox1, "end", fruits[i])
        spacer <- ""
        if( length(text) >0){
          nch <- nchar(text)
          if(listwidth <= 0)
            listwidth <- nch *1.6
          for(n in (1:listwidth*nch))
            spacer <- paste(spacer, "")
          
          tkgrid(tklabel(frame1, text=spacer),
                 frame1.lstbox1, scr, sticky = "e")
          tkgrid.configure(scr, rowspan=4, sticky="nsw")
        }
        else
          {
            tkgrid(frame1.lstbox1, scr, sticky = "w")
            tkgrid.configure(scr, rowspan=4, sticky="nsw")
          }
            
 ### mouse motion on fruits selections
        
        tkbind(frame1.lstbox1, "<Double-Button-1>", function() {
          stage <- F
        if(length(as.numeric(tkcurselection(frame1.lstbox1))) >0){
          lstchoice <- fruits[as.numeric(tkcurselection(frame1.lstbox1))+1]
          comboValue <- lstchoice
          tclvalue(var) <- comboValue
          comboEntry <- c(comboValue, comboEntry)
          assign("comboEntry", comboEntry, env=eCombo)
          assign("comboEntry", comboEntry, env=env.towrite)
          assign("comboValue", comboValue, env=env.towrite)
          assign("comboValue", comboValue, env=eCombo)     
        }
          assign("stage",stage, env=eCombo)
          tkdestroy(frame1); 
        })
### end of mouse motion on fruit selections
        
        tkpack(frame1)
        stage <- T
        assign("stage",stage, env=eCombo) 
        assign("frame1", frame1, env=eCombo)
        assign("frame1.lstbox1", frame1.lstbox1, env=eCombo)
      
      }else{  ## if(stage == F)
       
        stage <- F
        if(length(as.numeric(tkcurselection(frame1.lstbox1))) >0){
          lstchoice <- fruits[as.numeric(tkcurselection(frame1.lstbox1))+1]
          comboValue <- lstchoice
          tclvalue(var) <- comboValue
          comboEntry <- c(comboValue, comboEntry)
          assign("comboEntry", comboEntry, env=eCombo)
          assign("comboEntry", comboEntry, env=env.towrite)
          assign("comboValue", comboValue, env=env.towrite)
          assign("comboValue", comboValue, env=eCombo)
        }
        assign("stage",stage, env=eCombo)
        tkdestroy(frame1);
              
      }  ## end if(stage == F)
      
    } ## end of forclose

    allength <- sapply(fruits, nchar)
    entryw <- max(unlist(allength))
     if(entryw <= 15)
       entryw <- 19
     
    frameAll <- tkframe(base, relief = "groove", borderwidth = 0)
    frame0 <- tkframe(frameAll, relief = "groove", borderwidth = 0)
    frame0.entry1 <- tkentry(frame0, textvariable = var, width = (entryw-4),
                             bg="white", state="disabled")
    frame0.but1 <- tkbutton(frame0,  textvariable =butvar,
                            fg="purple", bg="gray", 
                            padx = 2, borderwidth=1, command = forclose)
     if(length(text) > 0){
       frame0.label1 <- tklabel(frame0, textvariable=tclVar(text),fg="blue") 
       tkgrid(frame0.label1, frame0.entry1,frame0.but1)}
     else
       tkgrid(frame0.entry1,frame0.but1)
   
      tkpack(frame0) 
      
 ###    env.towrite <<- env.towrite 
     return(frameAll)
 ###     return(eCombo)  
  }


