
sample.data <- function(filename="data_allc.txt_2.dat")
  {
    ev <- environment()
    load(paste("./OUTPUT/", filename,sep=""), env=ev)
    print(ls(env=ev))
    ind <- 1:length(whoinsampy)
    names(ind) <- names(whoinsampy)
    
    dth <- lapply(ind, function(n){
      iny <- round(whoinsampy[[n]] * whopopul[[n]])
      outy <- round(whoutsampy[[n]] *whopopulos[[n]])
      mat <- rbind(iny, outy)
      colnames(mat) <- "allc.txt"
      return(mat)})
    
    whox <- lapply(ind, function(n){
      inx <- whoinsampx[[n]]
      ix <- grep("cnst", colnames(inx))
 
      if(length(ix) > 0)
        inx <- inx[,-ix]
      outx <- whoutsampx[[n]]
      ix <- grep("cnst", colnames(outx))
 
      if(length(ix) > 0)
        outx <- outx[,-ix]
      mat <- rbind(inx, outx)
      
      return(mat)})

    whop <- lapply(ind, function(n){
      inp <- whopopul[[n]]
      outp <- whopopulos[[n]]
      mat <- rbind(inp, outp)
      colnames(mat) <- "population.txt"
      return(mat)})
    
  datamat <- lapply(ind, function(n){
      p <- whop[[n]]
      x <- whox[[n]]
      d <- dth[[n]]
      mat <- cbind(x,d,p)
      return(mat)})

    datamat <- lapply(datamat, function(x){
      nm <- rownames(x)
      nm <- sapply(nm, substring, 7)
      rownames(x) <- nm
      return(x)
    })
    lst <- list(datamat=datamat, dth=dth, whoinsampy=whoinsampy, whoutsampy=whoutsampy,
                whopopul=whopopul, whopopulos=whopopulos,
                whoinsampx= whoinsampx, whoutsampx=whoutsampx, whocov=whocov)
      return(lst)
  }
