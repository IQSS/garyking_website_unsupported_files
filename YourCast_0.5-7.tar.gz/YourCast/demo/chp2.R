
message("Examples 2.6-2.7 in the book...")


message("Dataobj for male all causes, and countries New Zeland and Hungary")
datobj.allc <- dataobjWHO(disease= "allc", cov.FULL= NULL, timeseries=T, lagyears=60,
                     cntry.vec= c(NewZeland=5150, Hungary=4150))
user.prompt()
message("formula...")
fallc <- log(allc2/popu2 + 5.e-5) ~ time
user.prompt()
message("Running yourcast with model LC...")
yallc <- yourcast(formula=fallc, dataobj=datobj.allc, model="LC")
user.prompt()
yourgraph(yallc)
user.prompt()
message("Dataobj for male suicide, and country USA ...")
datobj.suic <- dataobjWHO(disease= "suic", cov.FULL= NULL, timeseries=T, lagyears=60,
                     cntry.vec= c(USA=2450))
user.prompt()
message("formula...")
fsuic <- log(suic2/popu2 + 5.e-5) ~ time
user.prompt()
message("Running yourcast with model LC...")
ysuic <- yourcast(formula=fsuic, dataobj=datobj.suic, model="LC")
user.prompt()
yourgraph(ysuic)
user.prompt()
message("Dataobj for female digestive disease, and country Hungary...\n")
datobj.dgst <- dataobjWHO(disease= "dgst", cov.FULL= NULL, timeseries=T, lagyears=60,
                          cntry.vec= c(Hungary=4150))
message("formula...")
fdgst <- log(dgst3/popu3 + 5.e-5) ~ time
user.prompt()
message("Running yourcast with model LC...\n")
ydgst <- yourcast(formula=fdgst, dataobj=datobj.dgst, model="LC")
yourgraph(ydgst)
user.prompt()
message("Dataobj and formula for female cervix cancer...")
datobj.cerv <- dataobjWHO(disease= "cerv", cov.FULL= NULL, timeseries=T, lagyears=60,
                     cntry.vec= c(UnitedKingdom=4308))
message("formula...")
fcerv <- log(cerv3/popu3 + 5.e-5) ~ time
user.prompt()
message("Running yourcast with model LC...")
ycerv <- yourcast(formula=fcerv, dataobj=datobj.cerv, model="LC")
yourgraph(ycerv)                      
message("Dataobj for male transportation accidents, and country Portugal...\n")
datobj.trns <- dataobjWHO(disease= "trns", cov.FULL= NULL, timeseries=T, lagyears=60,
                     cntry.vec= c(Portugal=4240))
message("formula...")
ftrns <- log(trns2/popu2 + 5.e-5) ~ time
user.prompt()
message("Running yourcast with model LC...")
ytrns <- yourcast(formula=ftrns, dataobj=datobj.trns, model="LC")
user.prompt()
yourgraph(ytrns)

user.prompt()


