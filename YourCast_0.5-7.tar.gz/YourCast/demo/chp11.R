
message("Creating dataobj for examples 11.4-11.8 in the book...")

datobj <- dataobjWHO(disease= c("lung"), cov.FULL= NULL, timeseries=T, lagyears=30,
                     cntry.vec= c(Mauritius=1300, Peru=2370, Thailand=3380, Lithuania=4188))

user.prompt()
message("Formula for male population and lung disease...")
ff <- log(lung2/popu2 + 5.e-5) ~ time + log(time -1875)

user.prompt()
message("Running yourcast with model OLS...")
yols <- yourcast(formula=ff, dataobj=datobj)
user.prompt()
message("Generating the graphics for OLS...")
yourgraph(yols)
user.prompt()
message("Running yourcast with MAP model...")
ymap <- yourcast(model="map", Ha.sigma=0.3, Ht.sigma=1.58, Hat.sigma=0.12)
user.prompt()
message("Generating the graphics for MAP...")
yourgraph(ymap)


