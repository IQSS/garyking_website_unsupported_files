

chapter11 <- function()
{
    message("Dataobj for examples 11.4-11.8 in the book...")
    message("Disease lung cancer, countries Mauritius, Peru, Thailand, Lithuania..")
    user.prompt()
    
    datobj <<- dataobjWHO(disease= c("lung"),
                          cov.FULL= NULL, timeseries=T, lagyears=30,
                          cntry.vec= c(Mauritius=1300, Peru=2370, Thailand=3380, Lithuania=4188))

   
    message("Formula for male population and lung disease...")
    ff <- log(lung2/popu2 + 5.e-5) ~ time + log(time -1875)
    print(ff)
    message("Running yourcast with model OLS...")
    user.prompt()
    yols <- yourcast(formula=ff, dataobj=datobj)
    
    message("Generating the graphics for OLS...")
    user.prompt()
    yourgraph(yols)
   
    message("Running yourcast with MAP model...")
    user.prompt()
    ymap <- yourcast(model="map", Ha.sigma=0.3, Ht.sigma=1.58, Hat.sigma=0.12)
    
    message("Generating the graphics for MAP...")
    user.prompt()
    yourgraph(ymap)

  }

chapter11()
