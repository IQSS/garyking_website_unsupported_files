### R code from vignette source 'yourcast.Rnw'

