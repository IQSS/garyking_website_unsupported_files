Study:  6311     Name:  Elections to the United States House of
                        Representatives, 1898-1992
    Dataset:    1  Name: 1898 Data
	LREC  DATA    25       357  da6311.yr898

	Also see the following paragraph(s) for study 6311 dataset 1:
	53

    Dataset:    2  Name: 1900 Data
	LREC  DATA    25       357  da6311.yr900

	Also see the following paragraph(s) for study 6311 dataset 2:
	53

    Dataset:    3  Name: 1902 Data
	LREC  DATA    25       395  da6311.yr902

	Also see the following paragraph(s) for study 6311 dataset 3:
	53

    Dataset:    4  Name: 1904 Data
	LREC  DATA    25       395  da6311.yr904

	Also see the following paragraph(s) for study 6311 dataset 4:
	53

    Dataset:    5  Name: 1906 Data
	LREC  DATA    25       395  da6311.yr906

	Also see the following paragraph(s) for study 6311 dataset 5:
	53

    Dataset:    6  Name: 1908 Data
	LREC  DATA    25       395  da6311.yr908

	Also see the following paragraph(s) for study 6311 dataset 6:
	53

    Dataset:    7  Name: 1910 Data
	LREC  DATA    25       395  da6311.yr910

	Also see the following paragraph(s) for study 6311 dataset 7:
	53

    Dataset:    8  Name: 1912 Data
	LREC  DATA    25       456  da6311.yr912

	Also see the following paragraph(s) for study 6311 dataset 8:
	53

    Dataset:    9  Name: 1914 Data
	LREC  DATA    25       456  da6311.yr914

	Also see the following paragraph(s) for study 6311 dataset 9:
	53

    Dataset:   10  Name: 1916 Data
	LREC  DATA    25       456  da6311.yr916

	Also see the following paragraph(s) for study 6311 dataset 10:
	53

    Dataset:   11  Name: 1918 Data
	LREC  DATA    25       456  da6311.yr918

	Also see the following paragraph(s) for study 6311 dataset 11:
	53

    Dataset:   12  Name: 1920 Data
	LREC  DATA    25       456  da6311.yr920

	Also see the following paragraph(s) for study 6311 dataset 12:
	53

    Dataset:   13  Name: 1922 Data
	LREC  DATA    25       435  da6311.yr922

	Also see the following paragraph(s) for study 6311 dataset 13:
	53

    Dataset:   14  Name: 1924 Data
	LREC  DATA    25       435  da6311.yr924

	Also see the following paragraph(s) for study 6311 dataset 14:
	53

    Dataset:   15  Name: 1926 Data
	LREC  DATA    25       435  da6311.yr926

	Also see the following paragraph(s) for study 6311 dataset 15:
	53

    Dataset:   16  Name: 1928 Data
	LREC  DATA    25       435  da6311.yr928

	Also see the following paragraph(s) for study 6311 dataset 16:
	53

    Dataset:   17  Name: 1930 Data
	LREC  DATA    25       435  da6311.yr930

	Also see the following paragraph(s) for study 6311 dataset 17:
	53

    Dataset:   18  Name: 1932 Data
	LREC  DATA    25       479  da6311.yr932

	Also see the following paragraph(s) for study 6311 dataset 18:
	53

    Dataset:   19  Name: 1934 Data
	LREC  DATA    25       479  da6311.yr934

	Also see the following paragraph(s) for study 6311 dataset 19:
	53

    Dataset:   20  Name: 1936 Data
	LREC  DATA    25       479  da6311.yr936

	Also see the following paragraph(s) for study 6311 dataset 20:
	53

    Dataset:   21  Name: 1938 Data
	LREC  DATA    25       479  da6311.yr938

	Also see the following paragraph(s) for study 6311 dataset 21:
	53

    Dataset:   22  Name: 1940 Data
	LREC  DATA    25       479  da6311.yr940

	Also see the following paragraph(s) for study 6311 dataset 22:
	53

    Dataset:   23  Name: 1942 Data
	LREC  DATA    25       442  da6311.yr942

	Also see the following paragraph(s) for study 6311 dataset 23:
	53

    Dataset:   24  Name: 1944 Data
	LREC  DATA    25       442  da6311.yr944

	Also see the following paragraph(s) for study 6311 dataset 24:
	53

    Dataset:   25  Name: 1946 Data
	LREC  DATA    25       442  da6311.yr946

	Also see the following paragraph(s) for study 6311 dataset 25:
	53

    Dataset:   26  Name: 1948 Data
	LREC  DATA    25       442  da6311.yr948

	Also see the following paragraph(s) for study 6311 dataset 26:
	53

    Dataset:   27  Name: 1950 Data
	LREC  DATA    25       442  da6311.yr950

	Also see the following paragraph(s) for study 6311 dataset 27:
	53

    Dataset:   28  Name: 1952 Data
	LREC  DATA    25       439  da6311.yr952

	Also see the following paragraph(s) for study 6311 dataset 28:
	53

    Dataset:   29  Name: 1954 Data
	LREC  DATA    25       439  da6311.yr954

	Also see the following paragraph(s) for study 6311 dataset 29:
	53

    Dataset:   30  Name: 1956 Data
	LREC  DATA    25       439  da6311.yr956

	Also see the following paragraph(s) for study 6311 dataset 30:
	53

    Dataset:   31  Name: 1958 Data
	LREC  DATA    25       439  da6311.yr958

	Also see the following paragraph(s) for study 6311 dataset 31:
	53

    Dataset:   32  Name: 1960 Data
	LREC  DATA    25       439  da6311.yr960

	Also see the following paragraph(s) for study 6311 dataset 32:
	53

    Dataset:   33  Name: 1962 Data
	LREC  DATA    25       444  da6311.yr962

	Also see the following paragraph(s) for study 6311 dataset 33:
	53

    Dataset:   34  Name: 1964 Data
	LREC  DATA    25       444  da6311.yr964

	Also see the following paragraph(s) for study 6311 dataset 34:
	53

    Dataset:   35  Name: 1966 Data
	LREC  DATA    25       444  da6311.yr966

	Also see the following paragraph(s) for study 6311 dataset 35:
	53

    Dataset:   36  Name: 1968 Data
	LREC  DATA    25       444  da6311.yr968

	Also see the following paragraph(s) for study 6311 dataset 36:
	53

    Dataset:   37  Name: 1970 Data
	LREC  DATA    25       444  da6311.yr970

	Also see the following paragraph(s) for study 6311 dataset 37:
	53

    Dataset:   38  Name: 1972 Data
	LREC  DATA    25       436  da6311.yr972

	Also see the following paragraph(s) for study 6311 dataset 38:
	53

    Dataset:   39  Name: 1974 Data
	LREC  DATA    25       436  da6311.yr974

	Also see the following paragraph(s) for study 6311 dataset 39:
	53

    Dataset:   40  Name: 1976 Data
	LREC  DATA    25       436  da6311.yr976

	Also see the following paragraph(s) for study 6311 dataset 40:
	53

    Dataset:   41  Name: 1978 Data
	LREC  DATA    25       436  da6311.yr978

	Also see the following paragraph(s) for study 6311 dataset 41:
	53

    Dataset:   42  Name: 1980 Data
	LREC  DATA    25       436  da6311.yr980

	Also see the following paragraph(s) for study 6311 dataset 42:
	53

    Dataset:   43  Name: 1982 Data
	LREC  DATA    25       435  da6311.yr982

	Also see the following paragraph(s) for study 6311 dataset 43:
	53

    Dataset:   44  Name: 1984 Data
	LREC  DATA    25       435  da6311.yr984

	Also see the following paragraph(s) for study 6311 dataset 44:
	53

    Dataset:   45  Name: 1986 Data
	LREC  DATA    25       435  da6311.yr986

	Also see the following paragraph(s) for study 6311 dataset 45:
	53

    Dataset:   46  Name: 1988 Data
	LREC  DATA    25       435  da6311.yr988

	Also see the following paragraph(s) for study 6311 dataset 46:
	53

    Dataset:   47  Name: 1990 Data
	LREC  DATA    25       435  da6311.yr990

	Also see the following paragraph(s) for study 6311 dataset 47:
	53

    Dataset:   48  Name: 1992 Data
	LREC  DATA    25       435  da6311.yr992

	Also see the following paragraph(s) for study 6311 dataset 48:
	53

    Dataset:   49  Name: Exceptions Data
	LREC  DATA    64       839  da6311.excep

	LREC  SJCC    77       101  sp6311.excep

	Also see the following paragraph(s) for study 6311 dataset 49:
	53

    Dataset:   50  Name: SPSS Data Definition Statements for All Years
                         Files (Parts 1-48)
	LREC  SJCC    55        85  sp6311.yrsall

	Also see the following paragraph(s) for study 6311 dataset 50:
	53

    Dataset:   51  Name: SAS Data Definition Statements for All Years Files
                         (Parts 1-48)
	LREC   SAS    41        85  sa6311.yrsall

	Also see the following paragraph(s) for study 6311 dataset 51:
	53

    Dataset:   52  Name: SAS Data Definition Statements for Exceptions File
                         (Part 49)
	LREC   SAS    71        88  sa6311.excep

	Also see the following paragraph(s) for study 6311 dataset 52:
	53

    Dataset:   53  Name: Codebook for All Parts
	LREC  CBLT    80       517  cb6311.all

	Also see the following paragraph(s) for study 6311 dataset 53:
	53




Dataset notes:

Paragraph #53:
Many of the machine-readable codebook files are supplied with carriage
control characters in column one of each record.  Users should check the
first few records in these files to determine whether the files they have
received contain these characters.  If the file does have carriage
control characters in column one (usually a 1, -, +, or blank and with
either a 1, -, or + appearing in the first column of the first record),
the file should be listed with a print program that can interpret these
characters.  As an alternative, the first column of each record can be
skipped and the remaining columns may be listed.  When carriage control
characters do not exist in a file, all columns in each record can be
routinely printed.  These listings document the appropriate data files.



