print.optim.autocast <- function(x,...){summary(x)}
