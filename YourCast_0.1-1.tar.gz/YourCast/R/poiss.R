### Module for Poisson regression model with glm: driver glm.poisson()
### Contains following functions
### glm.poisson() Poisson linear regression model build upon
### glm.colinear.poiss(xw, yw,yoff, nmx, delta.tol=0.005, tol=0.999), which
### checks for colinearities using covdel

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME: glm.poisson  
##
## INPUT:     whoinsampx, whoutsampx matrix of covariates for given csid 
##            whoinsampy, whoutsampy (1 col) matrices = ln(mortality) 
##            mortality = dth/population, and dth are observations
##            delta.tol decrement to supress colinearities among cols of whoinsampx;
##
## DESCRIPTION: same as ols but uses glm to obtain the estimates for dth's 
##
## IMPORTED functions:
##                      covdel
##                      glm.colinear.poiss
##
## OUTPUT:    list of matrix elements for each csid; yhat = ln(dth/popu) 
##            with predicted (log of mortalities) yhatin,for years of insample
##            and yhatout for years of outsample
##            The fitting coefficients coeff and standard deviation. 
##           
##
##  WRITTEN BY: Federico Girosi & Elena Villalon 
##              fgirosi@latte.harvard.edu
##              CBRSS, Harvard University
## 
## Last modified: 05/18/2003
## 
## ************************************************************************
## ************************************************************************

glm.poisson <- function(ebase=env.base){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase
  ewho <- get("env.who", env=ebase)
  print("Using Poisson with glm-modified")
  ttmp <- proc.time()
  whotransform <- get("whotransform", env=ewho)
  whoinsampy <- get("whoinsampy", env=ewho)
  whoutsampy <- get("whoutsampy", env=ewho)
  whopopul   <- get("whopopul", env=ewho)
  whopopulos <- get("whopopulos", env=ewho)
  whoinsampx <- get("whoinsampx", env=ewho)
  whoutsampx <- get("whoutsampx", env=ewho)
  whocov <- get("whocov", env=ewho)
  whodisease <- get("whodisease", env=ewho)
  whogender <- get("whogender", env=ewho)
  whoyrest <- get("whoyrest", env=ewho)
  age.vec <- get("age.vec", env=ewho)
  cntry.names.lst <- get("cntry.names.lst", env=ewho) 
  gender.str <- ifelse(whogender==2, "m", "f")      

  if(whotransform != 1)
    stop("Set whotransform = 1 to run the Poisson regression")
  
  ly <- length(whoinsampy)
  yhatin  <- whoinsampy;
  yhatout <- whoutsampy;
  coeff <- vector(mode="list",length= ly);
  std <- vector(mode="list",length=ly);  
  names(coeff) <- names(whoinsampy);
  names(std) <- names(whoinsampy);
### if you not wish to eliminate colinears set delta.tol <- 0
### experience shows that delta.tol =0.005 is a good choice to get rid
### of all NA's coefficients from glm
    delta.tol <- 0.005

### for values of dth that might be zero, dth <- zero.tol
  zero.tol <- 1.e-4 
  for (i in 1:length(whoinsampy)){
### assuming whotransform = 1 so whoinsampy = ln(mortality)
    y <- exp(whoinsampy[[i]]);  ### y is mortality= dths/popul
    ypop  <-  whopopul[[i]]  ### population insample
    yoss  <- whopopulos[[i]] ### population outsample
    y <- y * ypop - 0.5  ### deaths
### testing:
### y <- y * ypop 
    ylen <-  length(y)
    y[y <= zero.tol] <- 0
    yna <- na.omit(y)
    n.obs <- nrow(yna);
    yoff <- log(ypop)
### not to get many warnings from glm round to integers    
    ind <- na.omit(seq(along=y)[y > 0.5])
    y[ind] <- round(y[ind])
### check if too many 0 in data
    y0 <- yna[yna <= zero.tol]
    ly0 <- length(y0)
### obtain useful quantities for testing
    ymean <- mean(as.data.frame(ypop), na.rm=T)
    ypopbar <- rep(ymean, length(y))
### for testing
### yoff <- matrix(1, nrow=length(ypop))
    
    x <- whoinsampx[[i]];
    n.cov <- length(colnames(x))
    if(length(ypop) != nrow(x)) print("wrong ypop and x must be of same length")
### for testing
### yoff <- matrix(x[,"time"] * 10)
### yoff <- matrix(x[,"tfr"] *10)
    xout <- whoutsampx[[i]]
    yw <- y;
    xw <-  x;
    nmx <- names(whoinsampx[i])
    obj <- glm.colinear.poiss(xw, yw, yoff, nmx, delta.tol= 0, tol=0.999)       
### yx is only needed if working with glm.fit
### (note that glm calls glm.fit; so NA's are removed)
### yx  <- na.omit(cbind(y,x))
### yna <- yx[,1]
### xna <- yx[,-1]
### if using glm.fit with no colinear checking 
### obj <- glm.fit(xna,yna,family=poisson(), offset=yoff)
    ri <- obj$covind
    if (length(ri) > 0 ) {
        xout <- xout[,-ri]
        x <- x[,-ri]
        whocov[[i]] <- whocov[[i]][,-ri]
        
      }
        beta <- obj$coeff
### if too little data set beta = NA
### define degree of freedoms: dg.f
    
        dg.f <- n.obs - (n.cov + 1)
        if (( dg.f > 0 && (n.cov/dg.f > (1 - ly0/dg.f))) || dg.f <= 0){
        print(paste("Warning: for csid: ", names(whoinsampy[i]),"and disease ", whodisease))
        print(paste("n.dth zeros= ",ly0, "; n.obs= ", n.obs,"; n.cov= ", n.cov))
        beta <- matrix(,nrow=n.cov)
      }
    
    coeff[[i]] <- beta
    dthatin  <-  ypop * exp(x %*% beta) ### dth estimation for insamp
    dthatout <-  yoss * exp(xout %*% beta)  ### dth estimation for outsample
    yhatin[[i]]  <- x %*% beta   ### log(mortality) insample
    yhatout[[i]] <- xout %*% beta  ### log(mortality) outsample
    std[[i]] <- NA;
      
### take care of new globals after deleting colinears
    whoinsampx[[i]] <- x
    whoutsampx[[i]] <- xout
    }
###   print("Time spent with ols-glm: "); print(proc.time() - ttmp)
  rm(ttmp)
   assign("whocov", whocov, env= ewho)
   assign("whoinsampx", whoinsampx, env= ewho)
   assign("whoutsampx", whoutsampx, env=ewho)
   model <- model.string()  
   lst <- list(depvar=whodisease, strata=gender.str, yrest=whoyrest,
              model=model, age.vec=age.vec, cntry.lst=cntry.names.lst,
              coeff=coeff,yhatin=yhatin,yhatout=yhatout,std=std,
               insampy=whoinsampy,outsampy=whoutsampy)
   assign("lst.output", lst, env=ewho)
   return(lst)
        
}
    

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME: glm.colinear.poiss 
##
## INPUT:     whoinsampx matrix of covariates for given csid 
##            with rows = years of observations in the insample matrix
##            and no. of cols= the covariates;
##            whoinsampy matrix of dth's observations for each csid
##            delta.tol tolerance decrement and tol factor for linear dependencies.
##
## DESCRIPTION: glm finds coeff with NA's (because of linear dependencies);  
##              i)  set is.na(coeff) = 0 if delta.tol <= 0; or, alternatively,
##              ii) if delta.tol > 0, call covdel which eliminates colinearities
##                  with values of tol that are decreased by delta.tol,
##                  until colinears (or NA's coefficients) are removed
##
## OUTPUT:    matrix whoinsampx modified,if necessary, eliminating colinearities 
##            the coefficients obtained with glm; and 
##            tol after decreasing in steps delta.tol
##           
##
##  WRITTEN BY: Elena Villalon
##              evillalon@latte.harvard.edu
##              CBRSS, Harvard University
##
## Last modified: 05/18/2003
## 
## ************************************************************************
## ************************************************************************
 glm.colinear.poiss <- function(xw, yw,yoff, nmx, delta.tol=delta.tol, tol=0.999){
    n   <- floor( tol/delta.tol)
    ri  <- vector(,length=0)
    xw <- as.matrix(xw)
    x <- xw 
### options(show.error.messages=F)
    res <- glm(yw~x-1, family=poisson(), na.action=na.omit,offset=yoff)
    coeff <- res$coeff
    isna  <- seq(along= coeff)[is.na(coeff)]
    isnames <- names(coeff[isna])
      
  test <-  1
  if (length(isna) > 0 && delta.tol <= 0){  ### if1
    coeff[isna] <- 0
  }else  if (length(isna) > 0 && delta.tol >0){  ### if1
  print(paste("Eliminating colinearities for glm-gaussian and csid= ", nmx))
       while(n > 0){  ### while
           tol <- tol - delta.tol
           ret <- covdel(xw, tol)
           x   <- as.matrix(ret$covx)
           ri   <- ret$covind
           rn   <- ret$covnam
           rnx <- paste("x", rn, sep="")
           if (!any(is.element(rnx,names(coeff))))
              stop(paste("Wrong covariates deleted for csid= ", nmx))
           
           if((tol - delta.tol) > 0  &&  (length(rn) < length(isna))){  ### if2
                   n <- n - 1
### may eliminate more than (isna) with glm, if delta.tol is large
           }else if ((tol - delta.tol) > 0 && (length(rn) >= length(isna))) { ### if2
              res <- glm(yw~x-1, family=poisson(), na.action=na.omit,offset=yoff)
              coeff <- res$coeff
              n   <-  0
           }else {n <-  0
                  test <- F}  ### if2
               
            } ### while(n >0)
        } ### if1
        
      
    if (test==F)  
         print(paste("Correlation not eliminated for glm-gauss csid= ", nmx))
   
    nmc <- names(coeff)
### to remove x from glm on the names of covariates
    nmc <- substring(nmc, 2)
    coeff <- matrix(coeff)
    rownames(coeff) <- nmc 
    options(show.error.messages=T)
    return(list(covind= ri, coeff=coeff, tol= tol))}
      
 
   
  
    
