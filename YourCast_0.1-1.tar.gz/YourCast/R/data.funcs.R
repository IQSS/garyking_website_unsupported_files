## ************************************************************************
## ************************************************************************
##
## FILE NAME:         data.funcs
##
## PLACE:     Preprocessing module, funcs functions.
## index of functions:  disease.number,subregvec,
##                      drop.ages, count.observations,
##                      extend.datamat, cntryid, long.causes 
##
## ************************************************************************
## ************************************************************************

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      cntry.names
##
## PLACE:     Preprocessing module, the old Gauss cntry_names.g (and the used
##            token2.g) functions rewritten in R.
## 
## IMPORTED functions: none
##
## USED GLOBALS: whodatapath from env.who
##
## DESCRIPTION: It returns a vector with all the names of the 191
##              countries in the database, indexed by their
##              country codes.
##
## FORMAT:  c.names <- cntry.names()
##          c.names <- cntry.names(file)
##
## INPUT:   file: (optional) string, name of the file with path.
##                The named file is containing pairs of
##                country code and country name. Each line contains 
##                two entries, separated by at least one blank space: 
##                an integer number (the WHO code) and the name 
##                of the corresponding country. If filename is missing
##                then default <whodatapath>/cntry.odes.txt is used.
##                The environment ebase=env.base, which contains all progams and
##                the environmnet= env.who with all globals of the WHO code  
##
## OUTPUT: names = Kx1 string array. K is the maximum country code.
##                 names[j] contains the name of the country whose
##                 country code is j or "" otherwise.
##                 For ex. names[1025] = "Benin", names[1]=""
##
## WRITTEN BY: Federico Girosi & Anita Gulyasne Goldpergel & Elena Villalon 
##             fgirosi@latte.harvard.edu, anitag@latte.harvard.edu
##             evillalon@latte.harvard.edu 
##             CBRSS, Harvard University
## 
## Last modified: 12/12/2003
## 
## ************************************************************************
## ************************************************************************

cntry.names <- function(filename=NULL, flag= F, ebase=env.base) {
  if ((identical(.GlobalEnv,parent.frame()) && length(filename) <= 0 )|| flag ){
### if you are working in the library no need to source
    ewho <- namelists(); 
    whodatapath <- get("data.path", env=ewho);
    codes.names <- get("codes.names", env=ewho)
    filename <-  paste(whodatapath,codes.names,".txt",sep="")
  }else if(length(filename) <= 0 ){  
    ebase <- get("env.base", env = parent.frame())
    env.base <- ebase
    ewho <- get("env.who", env=ebase)
    whodatapath <- get("whodatapath", env=ewho)
    codes.names <- get("codes.names", env=ewho)
    filename <-  paste(whodatapath,codes.names,sep="")}
### It uses the NEW file from the data directory!!!
### (Which is separated with one tabulator character)

### quote is neccessary because of Cote d'Ivoire for ex.
  tmp <- scan(file=filename,what=c(integer(0),character(0)),quiet=T,multi.line=T,
              sep="\t",quote="\"")
  tmp <- matrix(tmp,ncol=2,byrow=T)
  codes <- as.integer(tmp[,1])
  maxcode <- max(codes)
  names <- array("",dim=maxcode)
  names[codes] <- tmp[,2]
  return(names)
  }
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      args.default
##
## PLACE:     To be used from the user environmnet so he/she
##            knows the default parameters of the simulation
##
## IMPORTED functions: namelists()
##
## DESCRIPTION: call function namelists() that returns an environment
##
## FORMAT:  env.who <- namelists()
##
## OUTPUT:  environmnet with all globals; say you want disease
##          disease <- get("whodisease", env=env.who)
##          
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu,
##             CBRSS, Harvard University
## 
## Last modified: 06/14/2004
## 
## ************************************************************************
## ************************************************************************
args.default <- function(){
  env.who <- namelists();
  args <- ls(env=env.who)
  ind <- match("env.who", args)
  if (!is.na(ind))
    args <- args[-ind]
  lst <- lapply(args, function(x) {
                      get(x, env=env.who)})
  names(lst) <- args
  return(lst)}

arguments <- function(driver="yourcast"){
  
  args <- names((formals(driver)))
              }
  
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      digitpull
##
## PLACE:     Preprocessing module, the old Gauss digitpull.g
##            function rewritten in R
##
## IMPORTED functions: none
##
## DESCRIPTION: digitpull() pulls connected digits from a numeric variable
##
## FORMAT:  x <- digitpull(v, start, stop)
##
## INPUT:   v           vector of numeric data, all of the same length,
##                      and with at least stop digits
##          
##          startdig    the first digit of v to return
##
##          stopdig     the last digit of v to return. 
##                      (stopdig must be >= startdig)
##
## OUTPUT:  x           startdig to stopdig digits of v
##
## REMARKS:    As currently written, digitpull() only works on the 
##             integer portion of v
##
## WRITTEN BY: Federico Girosi & Anita Gulyasne Goldpergel
##             fgirosi@latte.harvard.edu, anitag@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 11/14/2002
## 
## ************************************************************************
## ************************************************************************

digitpull <- function(v, startdig, stopdig) {
  v <- matrix(v, ncol = 1)
  v <- trunc(v)

### error checking
  if (stopdig < startdig) {
    stop(message="stopdig < startdig in proc preproc.digitpull")
  }

  if (min(abs(v)) < 10^(stopdig-1)) {
    stop(message="narrowest element in v not as wide as stopdig in proc digitpull()")
  }

  if (startdig < 1) {
    stop(message="startdig < 1 in proc digitpull()")
  }
  
  if (ncol(v) > 1) {
    stop(message="v not column vector in proc digitpull()")
  }
### end error checking  

  n <- trunc(log10(v[1]))+1
  a1 <- trunc(v/10^(n-stopdig))
  a2 <- trunc(v/10^(n-startdig+1))
  ret <- a1 - a2*10^(stopdig - startdig +1)
  return(matrix(ret))
}


## ************************************************************************
##
## FUNCTION NAME:      disease.number
##
## IMPORTED functions: none
##
## DESCRIPTION: It returns with the disease code for the given disease.
##
## FORMAT: dis_number <- disease.number(disease)
##
## INPUT: disease: String (4 character) of the disease name and environment
##                 ebase which contains all progrmas and env.who with the
##                 initialization and globals 
##
## OUTPUT: dis_number: code of disease from 1 to 24
##                     or 0, if there's no code for the string
##
## WRITTEN BY: Federico Girosi & Anita Gulyasne Goldpergel 
##             fgirosi@latte.harvard.edu, anitag@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 12/12/2003
## 
## ************************************************************************

disease.number <- function(whodisease=NULL, ebase=env.base) {
 
  arr <- c("allc", "malr", "aids", "tubr", "otin", "lung", "molp", "livc",
           "stom", "brst", "cerv", "omal", "rspi", "rspc", "cvds", "dgst",
           "matc", "pern", "allo", "trns", "unin", "suic", "homi", "ward")
  ebase <- try(get("env.base", env=parent.frame()), silent=T)
  if(class(ebase) != "try-error" && length(whodisease) <= 0 ){
     env.base <- ebase; 
     whodisease <- get("whodisease", env= get("env.who", env=ebase))}
  else if (length(whodisease) <= 0)
    stop("You need to provide a disease..please retry.")
  
  ret <- match(whodisease,arr,nomatch=0)
  if (ret == 0)
    stop(paste(whodisease,"is not a correct string code"))
  else
    print(ret)
  invisible(ret)
}


## ************************************************************************
##
## FUNCTION NAME:      subregvec
##
## IMPORTED functions: digitpull (from preproc.funcs)
##
## IMPORTED global:    whodatapath from envr= env.who created with
##                     WHO() & namelists() and containg all globla
##
## DESCRIPTION: finds the subregions of selected countries. 
##              Counterpart of cntrys.subreg, which finds
##              countries id's associated to subregions 
##
## FORMAT: subr <- subregvec(id,load=0)
##         subr <- subregvec(id, load=1, filename)
##         subr <- subregvec(id)
##
## INPUT: vector of arbitray length, id =cstsid; also, id may just contains cntry codes
##        and filename that contains country identifiers and their subregions
##
## OUTPUT: the list containing id= cstsid and the subregvec (same length as id),
##         which gives the subregions' for elements of id in the same order. 
##                     
##
## WRITTEN BY: Federico Girosi & Elena Villalon &  Anita Gulyasne Goldperge
##             fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 12/12/2003
## 
## ************************************************************************

subregvec <- function(id,load=1,filename = NULL, ebase=env.base) {
   ebase <-  try(get("env.base", env=parent.frame()), silent=T)
   if(class(ebase)=="try-error"){
     ewho <- namelists()
     who.digit.first <- get("digit.first", env=ewho)
     who.cntry.digits <- get("cntry.digits", env=ewho)
     whodatapath <- get("data.path", env=ewho)  
   }else{
     env.base <- ebase
     ewho <- get("env.who", env=ebase)
     who.digit.first <- get("who.digit.first", env=ewho)
     who.cntry.digits <- get("who.cntry.digits", env=ewho)
     whodatapath <- get("whodatapath", env=ewho)  }

  if (load == 0){
    print(paste("Not loading WHO_cntry_subreg.txt for load = ", load ))
    print("Want to change load = 0 or 1?")
    load <- scan(file="", quiet=T,what= integer(0), n=1)}
  
  if (load==1){
### It uses the NEW file from the data directory!!!
### (Which is separated with one tabulator character)
    if(length(filename) <= 0){
         filename <- paste(whodatapath,"WHO_cntry_subreg.txt",sep="")}
    
    if (filename == "") 
      print("Warning: the filename parameter is empty in subregvec.")
    else{
      print(filename)
      mat <- scan(file=filename,na.strings="-999.0000",quiet=T,multi.line=T)
      matsubreg <- matrix(mat,ncol=2,byrow=T)
      assign("matsubreg", matsubreg, env=ewho)
    }
  }
  mat <- matsubreg
  
  if (nchar(id[1])== who.cntry.digits){
    cntryvec <- id
  } else {
    cntryvec  <- digitpull(id, who.digit.first + 1, who.digit.first + who.cntry.digits)}
  
  cntrylist <- unique.default(cntryvec)

### select countries belonging to each of the 14-subregions:
### list of subreg's of length=14 
### subreg <- split.data.frame(mat, mat[ ,2])
  
  subregvec <- 0*cntryvec
  indx   <- match(cntryvec, mat[ ,1])
  
### indx points to rows of mat containing elements of cntryvec
### assume mat[,1] has not repeated values but cntryvec may have;
### length(indx)=length(cntryvec)  
### elements of cntryvec not among those of mat[ ,1], indx returns NA
  
  if (any(is.na(indx)))
    stop("Error in subregion: the input is incorrect")
  else    
    subregvec <- mat[indx, 2]
  
  return(list(cstsid = id, subregion = subregvec))
}


## ************************************************************************
##
## FUNCTION NAME:      drop.ages
##
## IMPORTED functions: none
##
## FORMAT:  z <- drop.ages(d)
##
## INPUT:    d =    string, disease and
##           envir= env.who, where global are stored
##
## OUTPUT:   relevant age groups for given disease
##
## WRITTEN BY: Federico Girosi & Anita Gulyasne Goldpergel
##             fgirosi@latte.harvard.edu, anitag@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 11/11/2003
## 
## ************************************************************************

drop.ages <- function(disease, age.groups=0:125, ebase=env.base) {
   ebase <- get("env.base", env=parent.frame());
   env.base <- ebase
   ewho <- get("env.who", env=ebase)
   

  if ((disease == "brst") || (disease == "cerv")) {
    ret <- seq(25,80,by=5)
  } else if (disease == "matc") {
    ret <- seq(10,45,by=5)
  } else if (disease == "suic") {
    ret <- seq(15,80,by=5)
  } else if (disease == "pern") {
    ret <- 0
  } else if (disease == "lung") {
    ret <- seq(30,60,by=5)
  } else {
    ret <- seq(0,80,by=5)
  }


 return(ret) }

## ************************************************************************
##
## FUNCTION NAME:      count.observations
##
## FORMAT:      z <- count.observations(dth,id)
## INPUT:       vectors dth and id containing number of deaths and 
##              the cstsid = country-age-years combination identifiers. 
##
## OUTPUT:      number of observations (=! NA) for each country 
##
## WRITTEN BY:  Federico Girosi & Elena Villalon
##              fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##              CBRSS, Harvard University
## 
## Last modified: 11/12/2003
## 
## ************************************************************************

count.observations <- function(dth,id, ebase = env.base) {
  ebase <- get("env.base", env=parent.frame());
  env.base <- ebase
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho)

### structure of cstsid:
  
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits
###
  mat   <- na.omit(cbind(dth, id))
  cid   <- unique.default(digitpull(mat[,2], digit.cntry.begin,digit.cntry.end))
  ageid <- unique.default(digitpull(mat[,2], digit.age.begin, digit.age.end))
  
  map  <- split.data.frame(mat, mat[ ,2]%/%10^(who.year.digits + who.age.digits))
  
### map is a list of elements with a unique country code,
### each element of map has complete age groups and time series
  
  if (length(map) > 191 || length(map) != length(cid))
    stop("You cannot have more than 191 countries or the input")
  
  nobv           <- matrix(0, nrow= length(map), ncol= 2)
  colnames(nobv) <- c("cntryid", "no.obv")
  nobv[,1] <- cid

  observation <- function(x){
### if age groups depend on cntry codes, then:  
### ageid <- digitpull(x[ ,2], digit.age.begin,digit.age.end);
### but age groups are only dependent on disease,and 
### assuming length(ageid) is same for all cntry age groups
    
    return(nrow(x)/length(ageid))
  }
  nobv[,2] <- sapply(map, FUN= "observation", simplify=T)
  
### if you have only one object to return not named it
  return(nobv) 
}
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      extend.datamat
##
## PLACE:     Preprocessing module.
## 
## IMPORTED functions: none
##
## USED GLOBALS: whofore
##
## DESCRIPTION: Builds the matrix with same no.columns of datamat,and
##              fills "id" (or cstsid column) with countries-ages-years combinations
##              also, fills columns "cntry", "t", "subreg" with values 
##              
## FORMAT:  
##
## INPUT:   matrices (Nx1): cntrylist (country's codes);
##                   (Mx1): agelist (age groups)
##          vector (2)  : timevec <- c(tmax, whofore)
##          vector(lcol): namecol with strings of the names of datamat cols
##          scalars: tmax (max time datamat); whofore (year to extend)
##                   lcol <- ncol(datamat)
##          vector:  aux for checking purposes that contains cstsid's
##
## OUTPUT: matrix xtdatamat, with dimensions are
##         no.rows=length(cntrylist) x length(agelist) x (whofore -tmax)
##         no.cols= ncol(datamat)=lcol
##         matrix is filled with NA's but for the cstsid column
##             
##
## WRITTEN BY: Federico Girosi & Elena Villalon
##             fgirosi@latte.harvard.edu, anitag@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 11/08/2003
## 
## ************************************************************************
## ************************************************************************

extend.datamat <- function(cntrylist,agelist,timevec,namecol, aux, ebase=env.base){
  ebase <- get("env.base", env=parent.frame());
  env.base <- ebase 
  ewho <- get("env.who", env=ebase)
  who.digit.first <- get("who.digit.first", env=ewho)
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits <- get("who.age.digits", env=ewho)
  who.year.digits <- get("who.year.digits", env=ewho)
### Structure of dataset cstsid: 
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits 
###  
  csid  <- t(outer(cntrylist * 10^(who.age.digits), agelist, FUN="+"))
  csid  <- sort(as.vector(csid))
### function kronecker is similar to outer but simpler:
### csid <- sort(kronecker(cntrylist * 100, agelist, FUN = "+"))
  
  ttmp <- proc.time()
  csid1 <- unique.default(digitpull(aux, digit.cntry.begin, digit.age.end))
  csid1 <- sort(csid1)

  if (identical(csid,csid1)==FALSE)
    stop(message="Something wrong with outer in extend.datamat")
  
  tmax    <- timevec[1]
  whofore <- timevec[2]
  whofore <- get("whofore", env=ewho)
  if ( tmax >= whofore ){
    print(paste("no need to extend datamat; whofore= ",whofore,"; and tmax= ", tmax ))
    xtdatamat <- array(,dim=0)
  } else
  {
### build xtdatamat with nrow equal filas, and
### ncol equal to ncol(datamat), and same colnames
    filas <- (whofore - tmax) * length(csid)
    lcol  <- length(namecol)
    xtdatamat <- matrix(NA, nrow= filas, lcol)
    colnames(xtdatamat) <- namecol
    timevec <- (tmax +1):whofore
    xtcstsid <-  t(outer(csid * 10^(who.year.digits),timevec,FUN="+"))
### with function kronecker:
### xtcstsid <- kronecker(csid * 10^4, timevec, FUN="+")
    
    if (length(xtcstsid) != ((whofore - tmax) * length(csid)))
      stop(message="you make a mistake extending datamat")
    else
      {
        xtdatamat[ ,"id"]    <- as.vector(xtcstsid)
        xtcntry  <- digitpull(xtcstsid,digit.cntry.begin,digit.cntry.end)
        xtdatamat[, "cntry"] <- xtcntry
        xtdatamat[, "t"]     <- digitpull(xtcstsid,digit.year.begin,digit.year.end)
        rownames(xtdatamat) <- xtdatamat[,"id"]
        return(xtdatamat)
      }
  }     
}

##*************************************************************************************
##*************************************************************

## FUNCTION NAME:      cntryid
##
## PLACE:     Preprocessing module, the old Gauss cntry_names.g (and the used
##            token2.g) functions rewritten in R.
## 
## IMPORTED functions: none
##
## USED GLOBALS: whodatapath from envr= en.who created with WHO(), namelists()
##
## DESCRIPTION: Returns name (names) of countries for given country codes
##              and countries code (codes) of character string input
##              Also, indices (indx) in a sorted array according to codes
##              
##
## FORMAT:  names   <- cntryid(whousercntry)$name
##          codes   <- cntryid(whousercntry)$code
##          subregs <- cntryid(whousercntry)$subreg
##          indx    <- cntryid(whousercntry)$entry ### I do not need the entry
##          whousercntry is a vector of either numeric codes
##                           or the strings with names of cntry's
##
## INPUT:   file: The named file is containing pairs of
##                country code and country name. Each line contains 
##                two entries, separated by at least one blank space: 
##                an integer number (the WHO code) and the name 
##                of the corresponding country;
##                file may be loaded with load =1 only.
##                whousercntry is vector can contain codes or names:
##                numeric for countries' codes or
##                characters if countries' names  
##
## OUTPUT: names and codes; say names( who= 1010) or codes( who= "USA")
##             
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 12/12/2003
## 
## ************************************************************************
## ************************************************************************

cntryid <- function(whousercntry = NULL, filename= NULL, load=1, ebase=env.base) {
  
    if (identical(.GlobalEnv,parent.frame()) &&
        (length(whousercntry) <= 0 || length(filename) <= 0)){
### if you are working in the library no need to source
    ewho <- namelists(); 
    if (length(whousercntry)<=0)
      whousercntry <- get("usercntrylist", env=ewho)
    whodatapath <- get("data.path", env=ewho)
    cntry.codes <- get("codes.names", env=ewho)
    if(length(filename) <= 0 && !is.na(cntry.codes))
      filename <- paste(whodatapath,cntry.codes,".txt",sep="");
    
    
  }else if(length(filename) <= 0 || length(whousercntry) <= 0){
  
    ebase <- get("env.base", env=parent.frame());
    env.base <- ebase
    ewho <- get("env.who", env=ebase)
    cntry.vec <- try(get("cntry.vec", env=ewho), silent=T)
    if(class(cntry.vec)=="try-error")
      cntry.vec <- NULL 
    whodatapath <- get("whodatapath", env=ewho)
    cntry.codes <- get("codes.names", env=ewho)
    if(length(filename) <= 0 && !is.na(cntry.codes))
      filename <- paste(whodatapath,cntry.codes,".txt",sep=""); 
    if(length(whousercntry) <= 0 && length(cntry.vec) > 0)
      whousercntry <- cntry.vec
    else if (length(whousercntry) <= 0)
      whousercntry <- get("whousercntrylist", env=ewho)}
   if (all(is.na(whousercntry)))
     stop("You need to provide for a country..please retry.")
    
   whousercntry <- na.omit(whousercntry)
### load the file only once for load =1
  if (load == 0 ){
    print(paste("Not loading file codes.names with load= ",load))
    print("Want to change value of load = 0 or 1?")
    load <- scan(file="", quiet=T,what= integer(0), n=1)}
  
  if(load == 1 && !is.na(cntry.codes)){  
### It uses the NEW file from the data directory!!!
### (Which is separated with one tabulator character)

    print(filename)
    cntry.c <- scan(file=filename,what=c(integer(0),character(0)),quiet=T,multi.line=T,
                     sep="\t",quote="\"")
    cntry.c <- matrix(cntry.c,ncol=2,byrow = T)
    codn <- as.numeric(cntry.c[ ,1])
    ord <-  order(codn)
    cntry.c <- cntry.c[ord, ]

  }
 
  if(!is.na(cntry.codes)){
    
  matnames <- cntry.c[, 2]
  matcodes <- as.integer(cntry.c[, 1])
  whousercntry <- matrix(whousercntry)
  
  if (is.numeric(whousercntry))
    {
      findnames <- function(cc){ matnames[seq(along = matcodes)[matcodes==cc ]]}
      names <- apply(whousercntry, FUN="findnames", 1)
      codes <- as.vector(whousercntry)
    }
  else
    {
      findcodes <- function(cc){ matcodes[seq(along = matnames)[matnames == cc]]}
      codes <- apply(whousercntry, FUN="findcodes", 1)
      names <- as.vector(whousercntry)
    }

  dx <- function(cd){tmpindx <- seq(along =matcodes)[matcodes == cd]}                    
  codes   <- matrix(codes)
  entry   <- apply(codes, FUN="dx", 1)
  codes   <- as.vector(codes)
}else{
  names <- as.vector(whousercntry)
  codes <- as.vector(whousercntry)}
    
   
    
  return(list(name= names, code= codes))
  
  }

##**************************************************************************
##**************************************************************************


long.causes <- function(x){

  disnam1 <- switch(paste(x),
                    allc =    "All",
                    malr =    "Malaria", 
                    aids =    "AIDS", 
                    tubr =    "Tuberculosis", 
                    otin =    "Other",
                    lung =    "Lung", 
                    molp =    "Cancer of",
                    livc =    "Liver", 
                    stom =    "Stomach",
                    brst =    "Breast",
                    cerv =    "Cervix",
                    omal =    "Other",
                    rspi =    "Respiratory",
                    rspc =    "Respiratory",
                    cvds =    "Cardiovascular",
                    dgst =    "Digestive",
                    matc =    "Maternal",
                    pern =    "Perinatal",
                    allo =    "All",
                    trns =    "Transportation",
                    unin =    "Other",
                    suic =    "Suicide", 
                    homi =    "Homicide",   
                    ward =    "War");

  disnam2 <- switch(paste(x),
                    allc =    "Causes", 
                    malr =    "", 
                    aids =    "", 
                    tubr =    "", 
                    otin =    "Infectious",
                    lung =    "Cancer", 
                    molp =    "Mouth and",
                    livc =    "Cancer", 
                    stom =    "Cancer", 
                    brst =    "Cancer", 
                    cerv =    "Cancer", 
                    omal =    "Malignant", 
                    rspi =    "Disease,", 
                    rspc =    "Disease,", 
                    cvds =    "Disease", 
                    dgst =    "Disease", 
                    matc =    "Conditions",
                    pern =    "Conditions", 
                    allo =    "Other", 
                    trns =    "Accidents", 
                    unin =    "Unintentional", 
                    suic =    "", 
                    homi =    "",   
                    ward =    "");

  disnam3 <- switch(paste(x),
                    allc =    "", 
                    malr =    "", 
                    aids =    "", 
                    tubr =    "", 
                    otin =    "Diseases", 
                    lung =    "", 
                    molp =    "Esophagus", 
                    livc =    "", 
                    stom =    "", 
                    brst =    "",
                    cerv =    "",
                    omal =    "Neoplasms", 
                    rspi =    "Infectious", 
                    rspc =    "Chronic", 
                    cvds =    "",
                    dgst =    "",
                    matc =    "",
                    pern =    "",
                    allo =    "Diseases", 
                    trns =    "",
                    unin =    "Injuries", 
                    suic =    "",
                    homi =    "",
                    ward =    "");
  name <- paste(disnam1,disnam2,disnam3);
  return(list(name,disnam1,disnam2,disnam3));
}

## ######################################################################################
##
## FUNCTION NAME:      bind.list
##
## IMPORTED functions: none
##
## DESCRIPTION: given two lists of equal length, whose elements are matrices,
##              it returns one list of same length, whose elements are the concatenation
##              of the corresponding elements in the two lists
##              
##
## FORMAT: lst <- bind.list(x,y,bycol=bycol,namex=namex)
##
## INPUT: x,y:  lists of length n. x[[i]] and y[[i]] must have either the same
##              number of rows or the same number of columns
##        bycol: logical. If TRUE concatenation is performed along columns
##               otherwise along rows
##        namex: logical. If TRUE the resulting list inherits the names of x
##               otherwise it inherits the names of y
##
## OUTPUT: lst: a list of length n. if bycol=FALSE then lst[[i]] = rbind(x[[i]],y[[i]]),
##              otherwise lst[[i]] = cbind(x[[i]],y[[i]]).
##              if namex=TRUE then names(lst) = names(x), otherwise names(lst)=names(y)
##
##  Federico Girosi
##  CBRSS
##  Harvard University
##  34 Kirkland St. 
##  Cambridge, MA 02143
##  fgirosi@latte.harvard.edu
##  (C) Copyright 2003   


bind.list <-  function(x,y,bycol=FALSE,namex=TRUE) {
  if (length(x) != length(y)) stop("x and y have different lengths");
  n <- length(x);
  z <- as.list(1:n);
  z <- lapply(z,FUN=function(n,x=x,y=y,bycol=bycol){
                             if (bycol==FALSE) {return(rbind(x[[n]],y[[n]]))}
                             else {return(cbind(x[[n]],y[[n]]))}},
              x,y,bycol);
  if (namex==TRUE) {names(z) <- names(x)}
  else {names(z) <- names(y)}
  return(z);
}



## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      preproc.elim.colinear
##
## 
## IMPORTED functions: eliminate.colinear (also in this module)
##
## USED GLOBALS: envr=env.who with globals from WHO() &namelists() and the
##               list with data processing from make.mortality.data()
##               We use whoinsampx, whoutsampx, and whocov, 
##
## DESCRIPTION: It eliminates some of the covariates for csid identifiers
##              of list elements whoinsampx,whoutsampx, whocov.
##              Criteria for colinearities with tolerance values, delta.tol & tol
##              as defined with eliminate.colinear.
##
## FORMAT:  filename  <- preproc.elim.colinear()
##
## VALUE:  Returns modified values of whoinsampx, whoinsampy,whocov and
##         write the new values into the envr=env.who
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu, 
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************


preproc.elim.collinear <- function(ebase= env.base){
   ebase <- get("env.base", env=parent.frame());
   env.base <- ebase; 
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho)
  whoinsampy <- get("whoinsampy", env= ewho)
  whoinsampx <- get("whoinsampx", env= ewho)
  whoutsampx <- get("whoutsampx", env= ewho)
  whocov <- get("whocov", env=ewho)
  whocovariates <- get("whocovariates", env=ewho)
  
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits
  ###
  delta.tol <- 0.005
  csid <- 0 *vector(, length=length(whoinsampy))
  indx <- 1:length(whoinsampy)
 
  
  for(i in indx){
    y <- whoinsampy[[i]];
    n.obs <- nrow(na.omit(y));
    x <- whoinsampx[[i]];
    csid[i] <- names(whoinsampy[i])
    nmx <-  csid[i]
    w <- as.numeric(is.na(y) == FALSE) ### 0 if NA, 1 otherwise ###
    xout <- whoutsampx[[i]];
    yw <- y;
    xw <-  x;
    yxw <- cbind(yw, xw)
    yxw <- na.omit(yxw)
    yw <- yxw[,1]
    xw <- yxw[,-1]
    colin  <- eliminate.colinear(xw,nmx, delta.tol=0.005, tol=0.9999)
    xw     <- colin$xw
    invxw  <- colin$invxw
    tol    <- colin$tol
    ri     <- colin$covind
 ### Just not to have a huge I/O we only print for one age group, since that
 ### except for tobacco they behave very similarly
    if (length(ri) >0  ) {
 ### printing for anormal conditions 
      if(substr(nmx, digit.age.begin,digit.age.end) == "45" )
      print(paste("Covariate(s)",whocovariates[ri],"eliminated from cs",
                  substr(nmx, digit.cntry.begin, digit.cntry.end)));
      xout <- xout[, -ri]
      x <- x[,-ri]
      whocov[[i]] <- whocov[[i]][,-ri]
      whoinsampx[[i]] <- x
      whoutsampx[[i]] <- xout
      
    }
  }
      assign("whocov", whocov, env=ewho)
      assign("whoinsampx", whoinsampx, env=ewho)
      assign("whoutsampx", whoutsampx, env=ewho)
}
##############################################################################

## ######################################################################################
##
## FUNCTION NAME:      trans
##
## IMPORTED functions: none
##
## DESCRIPTION:  trans is a helper function to obtain different representation of mortality 
##               depending on the global whotransform stored in envr=env.who
##              
##
## FORMAT:   mortality <- trans(dthvec, whotransform,ebase=env.base)
##
## INPUT: dthvec: vector with mortality data from make.mortality.data()
##        whotransform a global envr=env.who,defining the type transformation
##        ebase our base environmnet
##
## OUTPUT: vector same length as input dthvec but after applying transformation function:
##
##  Elena Villalon & Federico Girosi
##  CBRSS
##  Harvard University
##  34 Kirkland St. 
##  Cambridge, MA 02143
##  evillalon@latte.harvard.edu ;
###
  trans <- function(dthvec, whotransform=NULL, ebase=env.base) {
   ebase <- get("env.base", env=parent.frame());
     env.base <- ebase;
   
   if(is.na(whotransform)) whotransform <- 0
   
   if(length(whotransform) <= 0)
     whotransform <- get("whotransform", env=get("env.who", env=ebase))
   if(is.na(whotransform)) whotransform <- 0
   
    if (whotransform == 1)
      retp <- log(dthvec)
    else if (whotransform == 2)
      retp <- sqrt(dthvec)
    else if (whotransform == 3)
      retp <- log(dthvec + 1)
    else
      retp <- dthvec
    return(retp)}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      lagcov
##
## INPUT:   1) n index into list newsubmat so we may extract element x= newsubmat[[n]]
##          2) list newsubmat (make.mortality.data.R),elements identify with csid (cntry+age)
##          3) list.covariates the covariates list for each csid;
##             extract for each n the covariates list: whocovlist=list.covariates[[n]]
##          4) wholag.max.lst list with max number to lag without discarding any covariates; 
##             extract for each n wholag.max =wholag.max.lst[[n]]
##          5) timerng= vector of length 2; the start and end of time series
##          6) wholag the number of years to lag the covariates;
##          7) tmax the maximum year of actual data <= tmrng[2]
##          8) covindx the number of cols of x (element newsubmat), not covariates.   
##
## GLOBALS : as stored in env.who created inside ebase=env.base (our base envr)
##           which contains all parameters of WHO() & namelists()
##
## USED : wholagMax, to obtain max years to lag any csid without discarding covariates
##        firstobv, for first year of dth observation
##        fill.cnst.time(indx, whocovlist, csidx, tmpx, timerng) to add cnst & time 
##
## DESCRIPTION: It returns x (elemnt newsubmat) modified according number of years to lag= wholag
##              i)  For wholag <= foy (first year dth obsv), covariates are lag starting with  
##                  year= tmrng[1] + wholag; those years in range: timerng[1] < year < wholag,
##                  rows of matrix x are filled with NA's, and ready for deletion. 
##              ii) For wholag >  foy, only covariates "cnst" and "time" shall prevail 
##                  and rows of time series <= foy are deleted.  
##                  However, other covariates which are not cnst or time are set to NA
##                  for the entire series, and elim.all.na will also delete them.
##              Function lagcov will be applied to elements of newsubmat (with specific csid)  
##
## FORMAT:  x  <- lagcov( n,newsubmat,list.covariates,timerng,wholag,tmax,covindx)
##
## VALUE: Return element of newsubmat with some rows deleted depending on value wholag;
##        for wholag > (foy - timerng[1])(= first dth obv- beginning time series), 
##        covariate that are not cnst or time are filled with NA's for
##        the entire time series and marked for deletion.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu,
##             CBRSS, Harvard University
##
## Date modified: 11/12/2003
## 
## ************************************************************************
## ************************************************************************

  lagcov <- function(n,newsubmat,list.covariates, wholag.max.lst,
                     timerng,wholag,tmax,covindx, ebase ){
  env.base <- ebase; 
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho)
  wholag  <- get("wholag", env=ewho)
  whodisease <- get("whodisease", env=ewho)
  allc <- get("allc.str", env=ewho)

  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits 
### we need a fresh start with whocovlist each time it takes a new elemnt x
    csidx <- names(newsubmat[n]);
    x <- newsubmat[[n]]
    whocovlist <- list.covariates[[n]]
    tmpx <- x
    nrsubmat <- timerng[2] - timerng[1] + 1
    indx <- na.omit(match(c("cnst", "time"), whocovlist))
### indx counts all cols (not just the covariates) of newsubmat element 
    indx <- sort(indx) + covindx
### find out about depvar and allc as covariates
   depvar.as.cov <- grep(whodisease, whocovlist)
   allc.as.cov   <- grep(allc, whocovlist)
   depvar.as.cov <- c(depvar.as.cov, allc.as.cov)
   depvar.as.cov <- unique.default(depvar.as.cov)
   allc.as.cov <- NULL
   foy <- firstobv(tmpx)$foy
   wholag.extend <- wholag
  if(length(depvar.as.cov)> 0)
    wholag.extend <- foy + wholag - timerng[1]
  
### first year of dth observations (using helper function firstobv):
     if (length(tmpx) <= 0 || wholag <= 0 ) {
      print(paste("No lag is possible for csid: ", csidx))
      return(tmpx)}
### given time structure of covariates and dth, the max years to lag
### any covariates without loosing any mortality data is wholag.max; 
### wholag.max may depend on csid, if any dependency at all
    wholag.max <- wholag.max.lst[[n]]
    if(wholag.max <= 0){
       print(paste("No lag is possible for csid: ", csidx))
       return(tmpx)}
  
### Actual lag of covariates: 
### we need to solve two cases depending on the 
### relative values of wholag and wholag.max

    if(wholag <= wholag.max ){
      seqlag <- (wholag + 1):nrsubmat
### delete rows (1:wholag.extend) after lagging all covariates wholag years.
### Note that wholag.extend = wholag if not including dth or allc as covariates
      tmpx[1:wholag.extend, whocovlist] <- NA
### but if you include depvar or allc, you need to delete more than just wholag
### even when lagging of years is the same      
       
### whocovlist is specific for each csid 
### gauss recodes missing values to -666 for deletion;
### actually, not needed for R code:
      tmpx[1:wholag.extend, "flag"] <- -666
### if we include depvar as covaraite or allc, then we need to delete more rows
    
      tmpx[seqlag, whocovlist] <- x[1:(nrsubmat - wholag),whocovlist]
### delete rows with flag=-666, simply with:
### if no dth's in covariate list then we delete 1:wholag,
### otherwise we delete more because dth has lready
### foy-timerng[1] missing observations years, before first observed
      tmpx <- tmpx[-(1:wholag.extend),]
      foylag <- firstobv(tmpx)$foy
      tmrng <- range(tmpx[,"t"])
      
      if(is.na(foylag))
        tmpx <- NULL
      else if (foylag > tmrng[1]){
        to.delete <- foylag - tmrng[1]
        tmpx <- tmpx[-(1:to.delete), ]}
       
    } else { ##if1 (wholag > wholag.max)
### We may extend covariates data up to foy - wholag.max, without loosing dth data
### Because, for wholag > wholag.max, no covariates' data is availables for years in range 
### (foy - wholag)< year <= timerng[1], only the covariates "cnst" and "time" will prevail. 
### Thus, all other covariates are set to NA's for entire time series and ready for deletion. 
### Also, rows less than foy, for first dth obv, are omitted from time series
### Note that the deletion of covariates may depend on csid,
### but we shall only print name of the cntry once since I/O is unbearable.  
      if(substr(csidx, digit.age.begin, digit.age.end) == "45"){
                find.cntry.name <-  as.numeric(csidx)%/%10^who.age.digits
                print(paste("For wholag= ", wholag," and cs= ",find.cntry.name, 
                  ", we may only keep cnst & time as covariates (due to lack of data)"))}
### If user did not include any of cnst or time in whocovariates we need to do so
### with fill.cnst.time, this is just a security check      
       if(length(indx) < 2){
         res <- fill.cnst.time(indx, whocovlist, csidx, tmpx, timerng)
         tmpx <- res$tmpx
         whocovlist <- res$whocovlist}
### end of checking that cnst and time are in covariates list
      cov.n <-  (1:length(whocovlist))
      mat.n <- covindx + cov.n 
      if(length(indx) > 0){
        find.ind <- match(indx, mat.n)
        ind.rm <- mat.n[-find.ind]} 
      delt.year <- wholag - wholag.max
     
      fy  <- timerng[1]
      if (!is.na(foy)){ ##if2 (first year dth observation exists)
### set the lag for "time" since cnst=1
         xt <- foy - wholag 
         nt <- xt:tmax
         wholag0 <- foy - timerng[1] 
         seqlag0 <- (wholag0 + 1):nrsubmat  
         tmpx[1:wholag0, whocovlist] <- NA
### delete rows with -666; actually not needed since we delete rows
         tmpx[1:wholag0,"flag"] <- -666
         if(length(seqlag0)!= length(nt))
           print("Wrong extension in lagcov with wholag > wholag.max")
         tmpx[seqlag0,"time" ] <- nt
         tmpx[seqlag0,"cnst"]  <- 1
### delete rows before the first observation of dth 
         tmpx <- tmpx[-(1:wholag0), ]
### we could just remove the covariates
###      tmpx <- tmpx[, -ind.rm]
### instead we choose to make them NA's and
### remove covariates in make.mortality.data() with elim.all.na(); 
### thus, mark covariates any that cnst and time and ready for deletion
         tmpx[,ind.rm] <- NA
       }else{ ##if2 (first year dth observation missing in data)
         tmpx <- NULL}
      
    } ##if1 (wholag <= wholag.max)
    return(tmpx)}



### Function firstcov finds first row of observation for covariates, which is 
### any covariate that does not have NA's for first year in time series; 
### then calculates with first dth observation how many years 
### is plausible to lag for further predictions.
### It is not used directly in make.mortality.data() but as a helper of lagcov. 
### 
##  WRITTEN BY: Elena Villalon 
##              evillalon@latte.harvard.edu,
##              CBRSS, Harvard University
## 

firstcov <- function(x, whocovlist,tmax){
  styear <-  tmax
  fcov <- apply(x[,whocovlist],2, function(xcol){
                foindx <- seq(along= xcol)[!is.na(xcol)]
                fo     <- ifelse( length(foindx) > 0, min(foindx), NA)
                foy    <- ifelse( !is.na(fo), x[fo, "t"], NA)
                return(foy)})
  
  if (any(is.na(fcov)) || any(fcov >= tmax)){
    styear <- NA
  }else{
    styear <- max(fcov)}
 return(styear)}

### end of first observations for covariates
####
### helper function for lagcov: if either "cnst" and/or "time" no present,
### we need to include them for wholag > wholag.max
###
##  WRITTEN BY: Elena Villalon 
##              evillalon@latte.harvard.edu,
##              CBRSS, Harvard University
## 
fill.cnst.time <- function(indx, whocovlist, csidx, tmpx, timerng, ebase=env.base){
   ebase <- get("env.base", env=parent.frame());
     env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho)
  
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits
  
      if(length(indx) < 2){
         whocovtmp  <- c(whocovlist, "time", "cnst")
         whocovtmp  <- unique.default(whocovtmp)
      if(substr(csidx, digit.age.begin, digit.age.end) == "45"){       
         find.cntry.name <-  as.numeric(csidx)%/%10^who.age.digits;
         print(paste("Adding cnst & time as covariates for cntry= ", find.cntry.name))}
### indx may contain either of cnst or time but not both 
         if (length(indx) > 0) tmpx <- tmpx[, -indx]
         tmpx <- cbind(tmpx, "time"=(timerng[1]:timerng[2]), "cnst"=1)
         indx <- sort(match(c("cnst", "time"), names(tmpx)))
         whocovlist <- whocovtmp}
         return(list(whocovlist=whocovlist, tmpx = tmpx))}

### end fill.cnst.time
###
### standard covariates, each column of elements newsubmat corresponding to
### a covariate is standardize with scale (substracting mean and dividing by sdv)
### Global whostandardize should be always set to true to apply standard;
###

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      wholagMax
##
## INPUT:   1) n index into list newsubmat so we may extract element x= newsubmat[[n]]
##          2) list newsubmat (make.mortality.data.R),elements identify with csid (cntry+age)
##          3) list.covariates the covariates list for each csid;
##             extract whocovlist=list.covariates[[n]]
##          4) tmax the maximum year of actual data <= tmrng[2]
##
## USED : 
##        firstobv(x) (to obtain first year of dth observation, also in this file)
##        notna.year.cov <- firstcov(x, whocovlist, tmax) to obtain first year
##        of observation (not NA) for any given covariates in whocovlist.
##
## DESCRIPTION: It returns an integer, wholag.max, for each elemnt of newsubmat,
##              which represents the maximum numbers of years, the lag is allowed with
##              the covariates without loosing any dth data.  For lagging larger that
##              wholagMax only covariates "cnst" and "time" will be available.
##              The variable wholagMax, which depends on csid, may be useful
##              to group countries according to the available data.
##
## FORMAT:  wholag.max <- wholagMax( n,newsubmat,list.covariates,tmax)
##
## VALUE: Return one parameter, wholag.max, for each element of newsubmat or csid;
##        
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu,
##             CBRSS, Harvard University
##
## DATE: Sept. 29th, 2003
## 
## *********************************************************************
## *********************************************************************

wholagMax <- function(n,newsubmat,list.covariates,tmax, ebase, ewho){
 env.base <- ebase
 ewho <- get("env.who", env=ebase)
 whodisease <- get("whodisease", env=ewho)
 allc <- get("allc.str", env=ewho)
 wholag <- get("wholag", env=ewho)

  x <- newsubmat[[n]];
  cnm <- colnames(x)
  indth <- grep("dth",cnm) 
  csidx <- names(newsubmat[n]); 
  whocovlist <- list.covariates[[n]];
### if including depvar=whodisease or allc as covariates,
### we may have a lot of missing values before first observation,
### as well as missing after first observed.
### Then some of the death data must be discarded to include
### dth and allc in the covariates list
 depvar.as.cov <- grep(whodisease, whocovlist)
 allc.as.cov   <- grep(allc, whocovlist)
### make sure whodisease is not allc
 depvar.as.cov <- c(depvar.as.cov, allc.as.cov)
 depvar.as.cov <- unique.default(depvar.as.cov)
 allc.as.cov <- NULL
### first year dth observations; using helper firstobv
  foy <- firstobv(x, ebase)$foy

### first year of covariates actual observations (using helper function firstcov)
  notna.year.cov <- firstcov(x,whocovlist,tmax);

  if (is.na(foy))
    stop(paste("Cross-section csid = ", csidx, " has no death data; pls discard it."));
 if(is.na(notna.year.cov)){
   cat("No lag is possible for csid: ", csidx, " pls check your data.\n")
      return (0)}
 
 if(length(depvar.as.cov) <= 0 ){
  if(notna.year.cov >= foy) {
   cat("No lag is possible for csid: ", csidx, " pls check your data.\n")
      return (0)}
  else{
     wholag.max <- foy - notna.year.cov;
 
    return(wholag.max)}
}
 if(length(depvar.as.cov) > 0)
   whocov.reduce <- whocovlist[-depvar.as.cov]

  notna.year.cov.reduce <- firstcov(x,whocov.reduce,tmax);
  if(is.na(notna.year.cov.reduce) || notna.year.cov.reduce >= foy) {
   cat("No lag is possible for csid: ", csidx, " pls check your data.\n")
      return (0)
  }else{
     wholag.max <- foy - notna.year.cov.reduce;
     timerng <- range(x[,"t"])
### years you are going to miss of data after including depvar or allc
### lag years of death data will be missed, from foy up to foy + lag
### maximum number of years you can miss data is max.miss, when the lag is
### exactly the number of years of missing data for first death observed
### (assuming  covariates that are not death starts at year = timerng[1])
### Then, maximum number of deaths observations
### you are throwing away is max.miss= 2 (foy - timrng[1]) 
   
     max.miss <- foy - timerng[1] + wholag.max
      
                        
  return(wholag.max)
   }
}

### end wholagMAX
###
##  INPUT: matrix x from make mortality and covindx the index for non-covariates data.
##
##  DESCRIPTION: matrix x has as many cols as covarites and other cols of non-covariates data,
##               which are 1:covindx. standardize is applied only to the covarites columns
## 
##  OUTPUT:      It returns x with covariates cols change with scale or standardize
##
##  WRITTEN BY: Elena Villalon 
##              evillalon@latte.harvard.edu,
##              CBRSS, Harvard University
## 

  standard <- function(x,covindx) {
    x1  <- x[ ,1:covindx]
    x2  <- x[ ,-(1:covindx)]
### you may also x2 <- x[ ,as.vector(whocovlist)]
    x2 <- scale(x2,center=T, scale=T)
    x2[ is.nan(x2)] <- 1
    x  <- cbind(x1, x2)
    x  <- data.frame(x, row.names= x[,"id"])
    return(x)}


### Module for ols/gaussian linear models:
### ols: normal linear regression, driver ols()
### ols.functional: same as ols, but uses glm( and slower); driver ols.functional()
### Contains following functions:
### covdel(xmat, tol=tol) eliminates colinearities of xmat for tolerance=tol
### eliminate.colinear(xw,nmx, delta.tol, tol) call covdel recursively
### inverse.trans(yin,yout,y,whotransform) inverse to trans (make.mortality.data)
### ols() calls covdel,eliminate.colinear and inverse.trans
### ols.functional() calls covdel, glm.colinear and inverse.trans
### glm.colinear(xw, yw, nmx, delta.tol, tol) uses glm (built in function)
### and checks for colinearities with covdel 
###
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME: covdel
##
##
## INPUT:     elemnt of whoinsampx, matrix of covariates for given csid (cntry+age group)
##            rows = years of observations insample matrix and cols=covariates; 
##            tol, tolerance factor for linear dependencies among cols whoinsampx
## OUTPUT:    matrix whoinsampx modified after eliminating linear dependencies, 
##            or those cols of covariates which are correlated with tolerance >= tol; 
##            also the index of those cols eliminated by colinearity;
##            and the names of the eliminated cols 
##
##  WRITTEN BY: Elena Villalon
##              evillalon@latte.harvard.edu
##              CBRSS, Harvard University
##
## Last modified: 05/12/2003
## 
## ***********************************************************************
## ***********************************************************************

covdel <- function(xmat, tol=tol, ebase=env.base) {
  ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho)
if (dim(xmat)[2] <= 1)
  return(list(covx=xmat,covind=NULL,covnam = NULL))
  
x  <- data.frame( xmat)
vn <- colnames(x)
bf <- length(x)
### find cols with constant elements of sd =0
ind0 <- seq(along=x)[sd(x,na.rm=T)==0]
### index for cols other than "cnst" ( last?)
if(length(ind0) > 0){
cn <- grep("cnst", vn[ind0])
cn <- cn[length(cn)]
cti  <- ind0[-cn]
x    <- x[-ind0]}

mat <- cor(x, use="pairwise")
r <- row(mat)[row(mat) < col(mat) & abs(mat) >= tol]
r <- na.omit(r)
if(length(r) > 0)  {
  x <- x[-r]
  ri <- c(r, cti)
  rn <- vn[ri]
} else{
  ri <- cti 
  rn <- vn[cti]}

x  <- cbind(x, "cnst"=1)
af <-  length(x) 
csid <-  as.numeric(row.names(x)[1])%/%10^(who.year.digits)
### Because of the I/O we only print once the message below
if( abs(bf -af) >0 & csid %% 10^(who.age.digits) == 45) 
print(paste("Colinears, ncols deleted = ", bf - af, " for tol= ", tol,
            "; and cntry= ",csid%/%10^(who.age.digits)))
if (length(ri) > 0) xmat <- xmat[,-ri]
### returns covariate matrix with colinearities removed if appropiate
### index of columns being removed, and their names
return(list(covx=xmat,covind=ri,covnam = rn))
}  

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME: eliminate.colinear 
##
## INPUT:     element of whoinsampx or a matrix of covariates for given csid 
##            rows = years of observations insample matrix & cols= covariates; 
##            tol, tolerance for linear dependencies among cols of whoinsampx
##
## DESCRIPTION: if matrix t(xw) %*% xw (where xw= whoinsampx) cannot be inverted, 
##              it calls covdel to eliminate the linear dependencies with a value of
##              tol that is decreased from call to call by delta.tol
##              until built-in function solve() inverts t(xw) %*% xw   
##
## OUTPUT:    matrix element of whoinsampx modified after eliminating lineariarities 
##            the inverted matrix of (t(xw) %*% xw); and the tol that remains after 
##            eliminating correlations in decrement steps of delta.tol
##
##  WRITTEN BY: Elena Villalon
##              evillalon@latte.harvard.edu
##              CBRSS, Harvard University
##
## Last modified: 10/12/2003
## 
## ************************************************************************
## ************************************************************************
 eliminate.colinear <- function(xw,nmx, delta.tol, tol, ebase=env.base){
   ebase <- get("env.base", env=parent.frame())
   env.base <- ebase
   n <- floor( tol/delta.tol)
    ri <- vector(,length=0)
    xw <- as.matrix(xw)
    xww <- xw
    options(show.error.messages=F)    
### tol=1.e-10 may be changed as part of the options of solve
    invxw <- try(solve(t(xw) %*% x, tol=1.e-10))
    if( inherits(invxw, "try-error")){
        while(n >0){
           tol <- tol - delta.tol
           options(show.error.messages=T)               
           ret <- covdel(xw, tol, ebase)
           options(show.error.messages=F)               
           xww  <- as.matrix(ret$covx)
           ri   <- ret$covind
           invxw <- try(solve(t(xww) %*% xww))
       if(inherits(invxw, "try-error") && tol > delta.tol){
           n   <-  n - 1
        } else  {
          n <- 0
          xw <- xww}
      } }
    if(inherits(invxw, "try-error")) 
      print(paste("Collinearity not eliminated for csid= ", nmx))
    options(show.error.messages=T)        
  return(list(xw =xw, covind=ri,invxw=invxw, tol= tol))}



######################################################################
## ************************************************************************
##
## FUNCTION NAME:      firstobv
##
## INPUT:   1) element x of  newsubmat for each csid
##          2) whocol="dth" or covariate dth column of x
##
## USED : 
##        firstobv(x,whocol="dth") (to obtain first year of dth observation)
##
## DESCRIPTION: It returns a list of three elements: 
##              i)   foindx a vector with indeces rows of observed values of dth (!= NA)                 
##              ii)  sindx a vector of indeces for years of observed dth and <= whoyrest   
##              iii) foy first year of actual dth observed (not NA)
##
## FORMAT:  res  <- firstobv(x); foindx <- res$foindx, sindx <- res$sindx, foy <- res$foy
##
## VALUE: Return the list of three elemnts foindx, sindx (vectors) and foy variable
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu,
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

### FIND FIRST OBSERVATION OF DEATH, used as helper function throughout the code
### find first year of dth; x is an elemnet of datasubmat list

firstobv <- function(x,whocol="dth", ebase=env.base){
 ebase <- get("env.base", env=parent.frame())
  env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  whoyrest <- get("whoyrest", env=ewho)
  
  foindx <- seq(along= x[,"dth"])[!is.na(x[,"dth"])]
  fo     <- ifelse( length(foindx) > 0, min(foindx), NA)
  foy    <- ifelse( !is.na(fo), x[fo, "t"], NA)
  
  if(!is.na(foy) && foy <= whoyrest)
    sindx <- seq(along =x[, "t"])[x[, "t"]>= foy & x[, "t"] <= whoyrest & !is.na(x[, "dth"])]
  else
    sindx <- vector(,length=0)
  
  return(list(foindx = foindx, sindx = sindx, foy = foy)) }

######################################################################
### chkrest uses firstobv (or first dth observation) for given elemnt
### of newsubmat,x, and depending on the relative values with other variables
### along time series, it sets the column flag with different marking values.
### The column "flag" will be checked in the main program and some rows
### of the elemnt x of newsubmat will be deleted according to "flag"

chkrest <- function(x,timerng,nyrest,whoskip=NULL,ebase=env.base) {
  env.base <- ebase
  ewho <- get("env.who", env=ebase)
  if(length(whoskip) <= 0)
    whoskip <- get("whoskip", env=get("env.who", env=ebase))
  stopifnot(range(x[,"t"]) == timerng)
  fobv  <- firstobv(x, ebase)
  foy   <- fobv$foy
  sindx <- fobv$sindx
  count <- get("count", env=get("etrial", env=ebase))
  count <- count + 1
  assign("count", count,env=get("etrial", env=ebase))
  if(all(is.na(x[nyrest, "dth"]))) ## if1: same as if( is.na(foy) || foy > whoyrest)
    x[, "flag"] <- -999  ## ready to delete entire matrix
  else { ## if1
### if count of nonmissing < whoskip set flag=-999; ready to delete   
    if (length(sindx) < whoskip)  ## if2
      x[,"flag"] <- -999
    else   ## if2
      x[,"flag"] <- ifelse(x[,"t"] < foy, -333, x[,"flag"]) ## end of if2
    
  }## end of if1
### let's do some cleaning: 
  if(any(x[,"flag"] == -999)){
    vecount <- get("vecount",env= get("etrial", env=ebase))
    vecount <- c(vecount, count)
    assign("vecount", vecount, env=get("etrial", env=ebase))
    x <- array(,dim=0)}
  return(x) }


######################################################################
## DESCRIPTION: Data generated running make.mortality.data(), may be saved
##             for other computations. The function below uses check.parameters
##             to find out if the parameters or globals for this computation are same
##             as previously saved data and, if so,it loads the file with the output
##            of a previous computation
##
## IMPORTED:check.parameters also with this module 
##
## GLOBALS: whooutpath from envr= env.who
##
## WRITTEN BY: Elena Villalon & Federico Girosi 
##             fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
reuse.data <- function(ebase=env.base){
  ebase <- get("env.base", env=parent.frame());
    env.base <- ebase;
  whooutpath <- get("whooutpath", env=get("env.who", env=ebase))
  filename <- make.data.filename();
  filename  <- paste(whooutpath,filename,sep="")

  if (!file.exists(filename)) {
    print(paste("File",filename,"does not exist, it will be created"));
    return(FALSE);}
  if (check.parameters(filename) == FALSE) {
    print("WARNING: the user-set globals do not match pre-existing globals, new data will be created");
    return(FALSE);
  }
  print("I AM RE-USING AN EXISTING DATA FILE");
  ewho <- get("env.who", env=ebase)
  ereuse <- environment()
  l <- load(filename, env=ereuse);
   
  for (i in 1:length(l)){
  assign(l[i],eval(as.symbol(l[i])),env= ewho)}
 
  return(TRUE);
}


## ************************************************************************
##
## NAME:      check.parameters
##
## GLOBALS : WHO.R and whooutpath (output from make.mortality.data)
##           from envr=env.who 
##
## DESCRIPTION: It checks if parameters on files WHO.R and the output are same
##
## FORMAT: 
##
## INPUT: character vector what with names of parameters to be compared 
##
## OUTPUT: it prints which parameters are the same and which are different
##
## WRITTEN BY: Elena Villalon & Federico Girosi 
##             fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 04/24/2003
## 
## ************************************************************************
check.parameters <- function(filename, ebase=env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
what <- c("whodisease", "whogender","cov","whofore",
          "whoyrest","wholag", "population", 
          "whousercntrylist","whoskip","whouserages",
          "whostandardize","whotransform", "whodatapath")
whatlst <- c("depvar","strata","cov","fore","yrest", "lag",
             "population", "usercntrylist", "skip", "userages",
             "standardize", "transform","data.path")

ewho <- get("env.who",env=ebase); 
echeck <- environment(); 
n.what <- length(what)
### let get the values of what from env.who
### and place them in the present environment= echeck 
 for (i in 1:length(what))
    assign(what[i],get(what[i], env=ewho, inherits=T), env=echeck)

 whocovariates <- sort(cov)
 logcol <-  grep("^lngdp", whocovariates )
 lngdp <- ifelse(length(logcol) > 0, T, F)
 indx <- vector(, length=0)
 whocovtmp <- whocovariates

 whocovariates <- sort(whocovtmp);
    
whov <- as.list(1:n.what)
names(whov) <- what
whov <- lapply(whov, function(x) eval(as.symbol(what[x])))
load(file=filename);

whod <- vector(mode="list", length=n.what)
names(whod) <- what
whod[1:n.what] <- 1:n.what
whod <- lapply(whod, function(x) eval(as.symbol(what[x])))
what <- as.matrix(what)

check <- function(i,what,whatlst){
  nmwhat <- whatlst[i]
   i <- what[i]

   whovi <- whov[[i]]
   whodi <- whod[[i]]
isnawhov <- seq(along=whovi)[is.na(whovi)]
isnawhod <- seq(along=whodi)[is.na(whodi)]
whopara  <- na.omit(whovi)
whodata  <- na.omit(whodi)
### I am been very strict since I required same values and indx pos
  if(length(isnawhov) != length(isnawhod)){
        print(paste("Run make.mortality data: test FAIL for ", nmwhat))
        print(whopara);
        print(whodata);        
        return(FALSE);
   }else if(any(isnawhov != isnawhod)){
        print(paste("Run make.mortality data: test FAIL for ", nmwhat))
        print(whopara);
        print(whodata);        
        return(FALSE);        
  }else if (length(whopara) != length(whodata)){
        print(paste("Run make.mortality data: test FAIL for ", nmwhat))
        print(whopara);
        print(whodata);        
        return(FALSE);        
  }else if (identical(whopara,whodata) == FALSE){
        print(paste("Run make.mortality data: test FAIL for ", nmwhat))
        print(whopara);
        print(whodata);
        return(FALSE);        
  }else print(paste("OK for ",nmwhat));
        return(TRUE)}
count <- 0
test <- apply(matrix(1:length(what)), 1, FUN="check",what,whatlst)
return(!any(test == FALSE))
}

 
## ************************************************************************
## ************************************************************************
##

setWHO <- function(ebase=env.base){
  ebase <- get("env.base", env=parent.frame());
  env.base <- ebase; 
ewho <- get("env.who", env=ebase)
whogender <- get("whogender", env=ewho)
whomodel <- get("whomodel", env=ewho)
who.zero.mean <- get("who.zero.mean", env=ewho)
whotransform <- get("whotransform", env=ewho)
whousercntrylist <- get("whousercntrylist", env=ewho)
whocovariates <- get("whocovariates", env= ewho)
whoelim.collinear <- get("whoelim.collinear", env=ewho)
whofore <- get("whofore", env=ewho)
whoyrest <- get("whoyrest", env=ewho)
wholag <- get("wholag", env=ewho)

### SET SOME BASIC GLOBAL VARIABLES AND MAKE SOME SANITY CHECKS
### ON THE INPUT PARAMETERS
  if(whogender!=2 && whogender!=3)
    stop("You must select whogender= either 2 or 3 for male, or female, respectively.")

  if (whomodel == "CXC" && who.zero.mean == FALSE && whotransform != 1)
    stop("You cannot use a prior with non-zero mean if the dependent variable is not log-mortality");
  
  if (length(whousercntrylist) == 0) stop("Error: whousercntrylist not a valid choice");

### this is to make it easier to establish equality between whocovariates and the covariates
### stored in a pre-existing data file
 
  whocovariates <- sort(unlist(whocovariates));
  assign("whocovariates", whocovariates, env=ewho)
  if (!any(is.na(whousercntrylist))) {
    whousercntrylist <- sort(whousercntrylist);
    assign("whousercntrylist", whousercntrylist, env=ewho)}

  if (is.null(whocovariates) | any(is.na(whocovariates))) {
    stop("whocovariates cannot be empty and cannot contain missing values, aborting");
  }

  if (is.na(match("cnst",whocovariates)) && whoelim.collinear == TRUE) {
    stop("Cannot have whoelim.collinear = TRUE and no constant term")
  }
  
### array returning countries names for given codes; see also
### procedure cntryid in data.funcs.R
### the following call assigns function cntry.names(), which name
### is c.name to the envr=ewho = env.who
### if you want to store also in higher env use inherits =T

### whogdp2, user choice that may be changed but with constraint
  flag <-  F;
  if (is.null(whocovariates)) {
    flag <-  T;
  } else {
    if (length(grep("gdp$", whocovariates))== 0) flag <-  T;
  }
  

  if(whofore - whoyrest > wholag) {
    whofore <- whoyrest + wholag
    assign("whofore", whofore, env= ewho)
    print(paste("Change of whofore to ",whofore, "for consistency"))}  
### wholag may be >= (whofore - whoyrest) but if 
### (whofore - whoyrest)< wholag, either whofore or wholag need adjustmant

}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      make.average.age.profile
##
## 
## IMPORTED functions: list.by.cntry
##
## USED GLOBALS: none
##
## DESCRIPTION: given a cross-sectional time series in list format,
##              it returns the average  age profile (where the average
##              is taken over countries and years)
##
## FORMAT:  mean.age.profile <- make.average.age.profile(y)
##
## INPUT:   y: (list) a cross-sectional time series over C countries
##                      and A age groups, in list format
##
##
## OUTPUT: mean.age.profile: A x 1 vector. The average age profile, with elements named
##                           according to age groups
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

make.average.age.profile <- function(y,bycntry=FALSE, ebase=env.base){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase
  ewho <- get("env.who", env=ebase)
  insampy <- list.by.cntry(y);
  age.profile.list <- lapply(insampy,FUN=function(x){return(mean(as.data.frame(x),na.rm=TRUE))});
  result <- age.profile.list;
 
  if (!bycntry){
    mean.age.profile <- 0*age.profile.list[[1]];
    for (i in 1:length(age.profile.list)){
      print(i)
      mean.age.profile <- mean.age.profile + age.profile.list[[i]];
    }
    result <- mean.age.profile/length(age.profile.list);
  }
  return(result);
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      list.by.cntry
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: given a cross-sectional time series over C countries
## and A age groups, in list format, it returns a list of C matrices,
## one for each country. The matrices have dimension T x A, where T is
## the length of the time series and A is the number of age groups.
## Each column of a matrix is the time series for the corresponding age group
##
## FORMAT:  insampy <- list.by.cntry(whoinsampy)
##
## INPUT:   whoinsampy: (list) a cross-sectional time series over C countries
##                      and A age groups, in list format.
##
##
## OUTPUT: insampy: list of C matrices. The names of the elements of
##                  the list are the country codes. Each matrix is T x A. The names of
##                  the rows are the years of the time series, and the names of the
##                  columns are the names of the age groups.
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

list.by.cntry <- function(x, ebase=env.base){
    if (identical(.GlobalEnv, parent.frame())){
### if you are working in the library no need to source
### source("WHO.R", local=T)
      ewho <- namelists();
      who.digit.first  <- get("digit.first", env=ewho) 
      who.cntry.digits <- get("cntry.digits", env=ewho)
      who.age.digits   <- get("age.digits",env=ewho)
      who.year.digits  <- get("year.digits", env=ewho)
    }else{ 
      ebase <- get("env.base", env=parent.frame());
      env.base <- ebase;
      ewho <- get("env.who", env=ebase)
      cntry.vec <- get("cntry.vec", env=ewho)
      age.vec <- get("age.vec", env=ewho)
    
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho)}
### Structure of dataset cstsid:
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits
  
  cs.vec <- as.numeric(names(x));
  cs.cntry.vec <- digitpull(cs.vec,digit.cntry.begin,digit.cntry.end);  
  cntry.vec <- unique.default(cs.cntry.vec);
  age.vec <- unique.default(digitpull(cs.vec,digit.age.begin,digit.age.end));
  n.cntry <- length(cntry.vec);
  n.age <- length(age.vec);
  newlist <-  list();
  for (i in 1:n.cntry){
    cntry <- cntry.vec[i];
    ### get all the elements of the list x which correspond to country cntry 
    c.list <- x[cs.cntry.vec == cntry];
    colnam <- digitpull(as.numeric(names(c.list)),digit.age.begin,digit.age.end)
    rownam <- digitpull(as.numeric(rownames(c.list[[1]])),digit.year.begin, digit.year.end);
    c.mat <- as.matrix(as.data.frame(c.list));
    colnames(c.mat) <- colnam;
    rownames(c.mat) <- rownam;
    newlist <-  c(newlist, list(c.mat));
  }
  names(newlist) <- cntry.vec;
  return(newlist);
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      list.by.csid
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: it inverts the effect of list.by.cntry.
##
## FORMAT:  whoinsampy <- list.by.csid(insampy)
##
## INPUT:   insampy: (list) the output of list.by.cntry
##
##
## OUTPUT: whoinsampy: (list) ther cross-sectional time series which,
##                      when given as input to list.by.cntry, generates insampy
## 
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## ***********************************************************************
## ************************************************************************

list.by.csid <- function(insampy.c,col.name="dth", ebase=env.base){
    if (identical(.GlobalEnv, parent.frame())){
### if you are working in the library no need to source
      ewho <- namelists();
      who.age.digits   <- get("age.digits",env=ewho)
    }else{
      ebase <- get("env.base", env=parent.frame());
      env.base <- ebase;
      ewho <- get("env.who", env=ebase)
  ### Structure of dataset cstsid: 
  who.age.digits   <- get("who.age.digits",env=ewho)}
  
  cntry.vec <- as.numeric(names(insampy.c));
  age.vec <- as.numeric(colnames(insampy.c[[1]]));
  n.age <- length(age.vec); 
  csid.vec  <- sort(kronecker(cntry.vec *10^(who.age.digits), age.vec, FUN="+"))
  n.csid <- length(csid.vec)
  indx <- as.list(1:n.csid)
  names(indx) <- as.character(csid.vec)

  newlist <- function(x){
    resto <- x %% n.age
    indx <-  x %/% n.age
    if(resto > 0) indx <- indx + 1
    naming <- as.character(csid.vec[x])
    nm.vec <-  rownames(insampy.c[[indx]]);
    nm.vec <-  paste(naming, nm.vec, sep="") 
    if(resto == 0){
      x <- insampy.c[[indx]][,n.age]
      x <- as.matrix(x);
      rownames(x) <- nm.vec;
      colnames(x) <- col.name;
    } else {
      x <- insampy.c[[indx]][,resto];
      x <- as.matrix(x);
      rownames(x) <- nm.vec;
      colnames(x) <- col.name;
    }
    return(x)
  }
  
  whoinsampy <- lapply(indx,FUN="newlist")
  return(invisible(whoinsampy))
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      load.mean.age.profile
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: whodisease, whogender, who.prior.path
##
## DESCRIPTION: it returns the average age profile for the current cause of death and gender.
##              it assumes that age profiles are stored in the directory defined
##              by who.prior.path
##              
## FORMAT: x <- load.mean.age.profile()
##
## OUTPUT:  the mean age profile  for the current cause of death and gender.
##     
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

load.mean.age.profile <- function(prior.path=who.prior.path,disease=NULL,
                                  gender=NULL, ebase= env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
  if(length(gender) <= 0)
        gender <- get("whogender", env=get("env.who", env=ebase))
      if(length(disease) <= 0)
        whodisease <- get("whodisease", env=get("env.who", env=ebase)) 
      filename <- paste(prior.path,"prior_",disease,"g",gender,".dat",sep="");
      n <- load(filename);
      x <- eval(as.symbol(n));
      return(x)
}



## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      modify.mean.age.profile
##
## 
## IMPORTED functions: list.by.cntry, list.by.csid
##
## USED GLOBALS: none
## DESCRIPTION: given a cross-sectional time series in the usual list
##              format, it applies a given function to each age profile
##              and returns the modified cross-sectional time-series
##              
## FORMAT: new.y <- modify.mean.age.profile(y, func)
##
## INPUT: y: a cross-sectional time series in list format
##
##        func: a function of one argument, which takes an age profile and returns
##              a vector of the same length
##
## OUTPUT:  new.y: a cross-sectional time series obtained from y by replacing each age profile
##                 x by the vector func(x).
##     
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

 
 modify.age.profiles <- function(y,func,param){
   insampy <- list.by.cntry(y);
   insampy <-  lapply(insampy,FUN=function(x,func,param){t(apply(x,1,FUN=func,param))},func,param);
   new.whoinsampy <- list.by.csid(insampy);
   return(invisible(new.whoinsampy))
 }




## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      split.matrix
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: it splits a matrix in blocks along the rows.
##              
## FORMAT: Y <- split.matrix(X,blocks)
##
## INPUT: X: a matrix, vector, data frame or 2-dimensional array
##
##        blocks: a vector of integers, which sum up to the number of rows of X.
##                it specify the size of the blocks
##
## OUTPUT: Y a list of length equal to the length of blocks, with the blocks as elements
##         the blocks are stored as matrices.
##
## EXAMPLE: if X is a matrix with 10 rows and blocks = c(2,3,5) then Y has the 3 elements;
##           the first elements has the first 2 rows of X, the second has rows 3 to 5, and
##           the 3rd element has rows 6 to 10.
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************


split.matrix <- function(x,blocks){
  x <- as.data.frame(x);
  if (nrow(x) != sum(blocks)) stop("Block structure is wrong in partition.vector");
  f <- factor(rep(1:length(blocks),blocks));
  res <- split(x,f);
  res <- lapply(res,FUN=as.matrix);
  return(res);  
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  make.forecast
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: given a list of coefficients and covariates it returns
##              the corresponding list of predicted values 
##              
## FORMAT: yhat <- make.forecast(coeff,X)
##
## INPUT: coeff: list of regression coefficients, one element for each cross-section;
##
##            X: list  of covariate matrices, one element for each cross-section;
##
##
## OUTPUT: yhat: list of predicted values: yhat[[n]] =X[[n]] %*% coeff[[n]].
##               It inherits the names of X.
##
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

make.forecast <- function(coeff,X){
  indx <- seq(1,length(X));
  names(indx) <-  names(X);
  yhat <- lapply(indx,FUN=function(n,coeff){
    beta <- coeff[[n]];
    Z <- X[[n]];
    mult <- try(Z%*%beta, silent=T)
    if(class(mult)=="try-error"){
      print(names(X[n]))
      print(dim(beta))
      print(dim(Z))
      return(0)
    }else
      return(mult)}, coeff);  
##    return(Z%*%beta)},coeff);
  return(yhat);
}




## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  elim.all.na
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: it is used to find, for a given cross-section, which
##              covariates are entirely missing in the insample period
##              and/or for the entire time series depending on values of yrest
##              
## FORMAT:   new.cov.list <- elim.all.na(n,newsubmat,covlist,yrest)
##
## INPUT:        n: (integer) the index of an element of the list newsubmat
##
##       newsubmat: (list) an object of type "submat" as used in make.mortality.data
##
##         covlist: (vector) the names of all possible covariates appearing in newsubmat
##
##           yrest: (scalar) the last year of the insample period or tmax (data series)
##
##
## OUTPUT: new.cov.list: (vector) the vector of covariates which are not entirely missing in
##                        the n-th cross-section of newsubmat
##
##
## WRITTEN BY: Elena Villalon & Federico Girosi 
##             fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 11/6/2003
## 
## ************************************************************************
## ************************************************************************

  elim.all.na <- function(n,newsubmat,list.covariates,yrest,ebase, ewho){
  env.base <- ebase;
  env.who <- ewho
### ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho)
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho)  
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits
  whoyrest <- get("whoyrest", env = ewho)
###
    mm <- newsubmat[[n]];
    csidx <- names(newsubmat[n]);
    covlist <- list.covariates[[n]]
### relevant indices in yindx
    yindx <- seq(along=mm[,"t"])[mm[,"t"] <= yrest]
   
    if (length(yindx) == 0 && yrest== whoyrest) stop(paste("Error in cross-section",
                    names(newsubmat)[n],
                ": there is no insample (whoyrest too small)"))
### we make a new vector of covariates, which includes only those
### which are not entirely missing in the insample period
    new.covlist <-  NULL;
    for(i in 1:length(covlist)){
      cov <- covlist[i]
      if(!all(is.na(mm[yindx, cov]))) {
        new.covlist <-  c(new.covlist,cov);
### because I/O migth be very slow we only print for age group = 45
      } else if(yrest == whoyrest && 
                substr(csidx, digit.age.begin, digit.age.end) == "45"){
                find.cntry.name <-  as.numeric(csidx)%/%10^who.age.digits; 
                print(paste("Covariate= ", cov," in cs= ",find.cntry.name, 
                  ", missing for whoyrest= ", whoyrest))}
       else if (substr(csidx, digit.age.begin, digit.age.end) == "45"){
                find.cntry.name <-  as.numeric(csidx)%/%10^who.age.digits; 
                print(paste("Covariate= ", cov," in cs= ",find.cntry.name, 
                  ", missing for entire data time series")) }
    }
    return(new.covlist)
  }



## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  del.cov
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: It is used to delete certain covariates in a given cross-section.
##   
##              
## FORMAT:   newsubmat.element <-   del.cov(n,newsubmat,whocovlist,list.covariates)
##
## INPUT:        n: (integer) the index of an element of the list newsubmat
##
##       newsubmat: (list) an object of type "submat" as used in make.mortality.data
##
##      whocovlist: (vector) the names of all possible covariates appearing in newsubmat
##
##  list.covariates: (list) a list indexed by the cross-section (like newsubmat)
##                   an element of the list is the subset of the covariates whocovlist
##                   which we wish to retain for that particular cross-section
##
##
## OUTPUT: new.submat.element: (matrix) the n-th elemnt of newsubmat, from which
##                             we have deleted some covariates, according to list.covariates
##
##
## WRITTEN BY: Elena Villalon & Federico Girosi 
##             fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/6/2003
## 
## ************************************************************************
## ************************************************************************


del.cov <- function(n,newsubmat,whocovlist,list.covariates){
 
  mm <- newsubmat[[n]];
  new.covariates <- intersect(list.covariates[[n]],colnames(mm));
  old.covariates <- intersect(whocovlist,colnames(mm));
### out of whocovlist we only want to keep those which are in new.covariates
  if (length(new.covariates) < length(old.covariates)){
    ind1 <- match(old.covariates,colnames(mm));
    ind2 <- match(new.covariates,colnames(mm));
    to.delete <- setdiff(ind1,ind2);
    mm <- mm[,-to.delete];
  }
  return(mm);
}
  


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  elim.cov
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: It is used to decide whether the covariates which have missing
##              values should be kept or not. It returns an element of an
##              object of the type list.covariates
##              
## FORMAT:     new.cov.list <- elim.cov(n,newsubmat,list.covariates,whoyrest,who.lag.cutoff)
##
## INPUT:        n: (integer) the index of an element of the list newsubmat
##
##       newsubmat: (list) an object of type "submat" as used in make.mortality.data
##
##
##  list.covariates: (list) a list indexed by the cross-section (like newsubmat)
##                   an element of the list is the set of the covariates
##                   appearing in the corresponding element of newsubmat
##
##         whoyrest: (scalar) the last year of the insample period
##
##   who.lag.cutoff: (scalar) a percentage. If the number of observations that
##                   we have to throw away because we use covariates with missing values
##                   exceeds this value, then the covariates with missing values are flagged
##                   for elimination.
##
## OUTPUT: new.cov.list : (vector) the vector of covariates that we can use without
##                        losing an excessive number of data points
##
##
## WRITTEN BY: Elena Villalon & Federico Girosi 
##             fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/6/2003
## 
## ************************************************************************
## ************************************************************************

  elim.cov <- function(n,newsubmat,list.covariates,whoyrest=NULL,who.lag.cutoff=NULL, ebase=env.base) {
      env.base <- ebase;
    if(length(whoyrest) <= 0)
      whoyrest <- get("whoyrest", env=get("env.who", env=ebase))
    if(length(who.lag.cutoff) <= 0)
      who.lag.cutoff <- get("who.lag.cutoff", env=get("env.who", env=ebase))
    mm <- newsubmat[[n]];
    nc <- ncol(mm)
      cov.list <- list.covariates[[n]];
  
### here we only care about the insample observations which are not missing
    indx <- seq(along= mm[,"dth"])[!is.na(mm[,"dth"]) & mm[,"t"] <= whoyrest];
    if (length(indx) == 0) stop(paste("Error in cross-section",
                names(newsubmat)[n],
                ": insample dth is all missing"));         
   
   
###   cat("length = \t", length(cov.list), "\tn", n, " \tlength(mm)",dim(mm), "\tcsid ", names(newsubmat)[n])   
### Now I find the names of the covariates with  missing values and put it in cov.with.na.
### covmat is a matrix of 0s of the size of the matrix of covariates
### I put 1s in covmat where I find a missing value and sum over columns:
### only columns with all 0s will give me 0. I put the names of the columns
### which do not sum to 0 in cov.with.na
      if(!is.null(dim(mm))){    
         covmat <- 0*mm[,cov.list];
      }else if(length(mm)> 0)
          covmat <-  0*mm[cov.list];
           
      
    covmat[is.na(covmat)] <-  1;
    aux <- colSums(covmat); ### this is 0 if no missing found
    cov.with.na <- cov.list[aux != 0];
    if (length(cov.with.na)==0) return(cov.list);

### Now we can focus on the covariates with missing values and find
### the number of rows in which there is at least one missing value.
### sub.mm is a matrix of 0s od the size of the covariates cov.with.na
### I put 1s where there is a missing value, then I sum over columns:
### only the rows with no missing values will give me 0. Therefore
### aux has 0 where the rows is entirely not missing.
### Summing the number of elements of aux different from 0 I get the
### number of observation that I will have to throw away if I use these covariates.
    
    sub.mm <- 0*mm[,cov.with.na];
    sub.mm[is.na(sub.mm)] <-  1;
    aux <- rowSums(as.matrix(sub.mm));
    aux[aux > 0] <-  1;
    n.obs.throw.away <- sum(aux);
### if the percentage of lost data exceeds the threshold we
### eliminate the covariates cov.with.na, making sure
### there are covariates left (if not we crash).
### otherwise we keep all the covariates but print
### a measure of the loss of data due to cov.with.na
    if (n.obs.throw.away/nrow(mm) > who.lag.cutoff) {
      new.cov.list <- setdiff(cov.list,cov.with.na);
      print(paste("Eliminated covariates",
                  paste(cov.with.na,collapse=" "),
                  "in cross section",
                  names(newsubmat)[n]));
      if (length(new.cov.list)==0) stop(paste("Error in cross-section",
                                               names(newsubmat)[n],
                                               ": no covariates left"));                    
    } else {
      new.cov.list <- cov.list;
      print(paste("Losing",
                  round(100*n.obs.throw.away/nrow(mm)),
                  "percent of insample data due to covariates",
                  paste(cov.with.na,collapse=" "),
                  "in cs",
                  names(newsubmat)[n]));
    }
    return(new.cov.list)
  }




## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  age.remove
##
## 
## IMPORTED functions: 
##
## USED GLOBALS: none
##
## DESCRIPTION: It is used to decide whether certain ages group (who.age.select)
##              must be removed from certain covariates in who.cov.select
##   
##              
## FORMAT:     new.cov.list <-  age.remove(n,list.covariates,who.cov.select,who.age.select)
##
## INPUT:         n: (integer) the index of an element of the list newsubmat
##
##
##  list.covariates: (list) a list indexed by the cross-section (like newsubmat)
##                   an element of the list is the set of the covariates
##                   appearing in the corresponding element of newsubmat
##
##   who.cov.select: (character vector) the list of covariates that we want to
##                   exclude from the age groups specified by who.age.select
##
##   who.age.select: (numeric vector) the list of age groups from whichthe the covariates
##                   specified in who.cov.select should be deleted
##
## OUTPUT: new.cov.list : (vector) the vector of covariates after having eliminated
##                        the covariates specified by who.cov.select and who.age.select
##
##
## WRITTEN BY: Elena Villalon & Federico Girosi 
##             fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/6/2003
## 
## ************************************************************************
## ************************************************************************

     
   age.remove <- function(n,list.covariates,who.cov.select=NULL,who.age.select=NULL, ebase){
    env.base <- ebase; 
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho) 
### Structure of dataset cstsid: 
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits
  if(length(who.cov.select) <= 0)
    who.cov.select <- get("who.cov.select", env=ewho)
  if(length(who.age.select) <= 0)
    who.age.select <- get("who.age.select", env=ewho)

  who.age.select <- formatC(who.age.select,wid=who.age.digits,format="d", flag="0")
### cov.list is the vector of covariates in the n-th cross-section
     cov.list <-  list.covariates[[n]];
### rnm is the name of the n-th cross-section
     rnm    <- names(list.covariates)[n];
### subage is the age group of the n-th cross-section
     subage <- substr(rnm, digit.age.begin, digit.age.end)
### if a covariate is in who.cov.select and the age group
### is in who.age.select we remove it
     for(i in 1:length(who.cov.select)){
       indx   <- seq(along=cov.list)[cov.list==who.cov.select[i]]
       if (length(indx)> 0 && is.element(subage, who.age.select) == T ){
         cov.list <- cov.list[-indx]
         print(paste("Removing covariates: ", who.cov.select[i],
                     " from cs ", rnm))
       }
     }        
     return(cov.list)
   }


cs.mean <- function(x,extended=FALSE){
  func <- function(z,extended){
    m <-  mean(as.data.frame(z),na.rm=TRUE);
    if (extended == TRUE) {
      z[T,T] <- 0; ### this makes a matrix of 0s preserving the names of z
      m <- scale(z, center=-m,scale=rep(1,ncol(z)));
    }
      return(m);
  }
  y <- lapply(x,FUN="func",extended);
  return(invisible(y))
}




## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  death.from.logmortality
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: to compute the cross-sectioanl time series of deaths
##              given the cross-sectional time series of log mortality and population
##   
##              
## FORMAT:      d <- death.from.logmortality(logm,popu)
##
## INPUT:    logm: (list) log-mortality cross-sectional time series
##
##           popu: (list) population cross-sectional time series
##  
##
## OUTPUT:      d: (list) cross-sectional time series of deaths
##               
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/7/2003
## 
## ************************************************************************
## ************************************************************************


death.from.logmortality <- function(logm,popu){
  ind <- as.list(1:length(logm));
  names(ind) <-  names(logm);
  func <- function(n,logm,popu){
    x <- logm[[n]];
    y <- popu[[n]];
    dth <- y*exp(x)
    dth[dth <= 0.5] <- 0.5
    return(dth)
  }
  d <-  lapply(ind,FUN="func",logm,popu);
  return(invisible(d));
}



## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  model.string
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: whomodel, obtained from envr=env.who which is embedded in ebase=env.base
##
## DESCRIPTION: to compute the cross-sectioanl time series of deaths
##              given the cross-sectional time series of log mortality and population
##   
##              
## FORMAT:      s <- model.string()
##
## INPUT:    none
##
## OUTPUT:      s: (string) a string which uniquely identifies the model being used,
##                 consisting of whomodel and some other strings specifying parameters value.
##                 Right now is equal to whomodel, except when whomodel is "OLS".
##                 In this case, if we use an heteroskedastic OLS, with observations
##                 weighted by number of deaths (a la Wilmoth) the string is "OLSH"
##                
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/7/2003
## 
## ************************************************************************
## ************************************************************************


model.string <- function(ebase=env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  whomodel <- get("whomodel", env= ewho)
  who.ols.sigma.param <- get("who.ols.sigma.param", env=ewho)
  s <-  whomodel;
  if (whomodel == "OLS"){
    if (who.ols.sigma.param$use.deaths == TRUE && who.ols.sigma.param$average == FALSE){
      s <- "OLSH";
    }
  }
  return(s);
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  strpad
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: to convert a list of strings of different lenghts into
##              a list of strings of the same length, given by the maximum
##              string length in the list. This is achieved by padding the shorter
##              string with blanks, It is useful in printing statements.##   
##              
## FORMAT:      s <- strpad(x)
##
## INPUT:       x: (list) a list of strings
##
## OUTPUT:      s: (list) the same list as x, but with  right-padding with blanks, so
##                 that all the elements have the same length.
##                
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/7/2003
## 
## ************************************************************************
## ************************************************************************


strpad <- function(x){
  l <- max(nchar(x));
  z <-  lapply(x,FUN=function(x,l){a <- paste(x,paste(rep(" ",l-nchar(x)),sep="",collapse=""),sep="");return(a)},l)
}




## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  list.coeff.by.cntry 
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: 
##              
## FORMAT:   s <- list.coeff.by.cntry(coeff,cntry.vec,age.vec)
##
## INPUT:    coeff: (list) a cross-sectional list of regression coefficients,
##                  indexed by country and age.
##
##       cntry.vec: (vector) vector of country codes represented in the list coeff
##
##         age.vec: (vector) vector of age groups represented in the list coeff
##
##         if either of cntry.vec or age.vec are not defined, get them from the
##         ewho environmnet: ewho= get("env.who", env = env.base); ebase= env.base
##
## OUTPUT:       s: (list) a cross-sectional list indexed by countries.
##                  For each county the regression coefficients corresponding
##                  to different age groups are concatenated one after the
##                  the other, according to the order of the age groups in age.vec
##
##
##                
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/7/2003
## 
## ************************************************************************
## ************************************************************************


list.coeff.by.cntry <- function(coeff,cntry.vec=NULL,age.vec=NULL, ebase = env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  who.age.digits <- get("who.age.digits", env=ewho)
  if(length(cntry.vec) <= 0)
    cntry.vec <- get("cntry.vec", env=ewho)
  if(length(age.vec) <= 0)
    age.vec <- get("age.vec", env=ewho)
  
  age.char <- formatC(age.vec,wid= who.age.digits,format="d", flag="0")

### cov.list is the vector of covariates in the n-th cross-section;
  names(cntry.vec) <- cntry.vec;
  b <- lapply(cntry.vec,FUN=function(x,coeff,age.char){
    ind <- paste(x,age.char,sep="");
    return(unlist(coeff[ind]))},coeff,age.char);
  return(b);  
}




## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  impute.ts
##
## DESCRIPTION: it imputes missing values in a multivariate time series
##
## IMPORTED FUNCTIONS: 
##
## FORMAT: x.imp <- impute.ts(x)
##
## INPUT:        x:  (array) a multivariate time series with missing values 
##
## 
## OUTPUT:   x.imp: (array) <- the multivariate time series x with the
##                  missing values imputed by local linear interpolation.
##                  names of x are preserved.
##
##     
##
## WRITTEN BY: Federico Girosi 
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 08/14/2003
## 
## ************************************************************************
## ************************************************************************

impute.ts <- function(x){
  nr <- nrow(x);
  nc <- ncol(x);
  ind <- 1:nc;
  z <- apply(as.array(ind),MARGIN=1,FUN=function(n,x){s <- x[,n];
                                                      if (any(is.na(s))){
                                            s <- approx(1:length(s),s,xout=1:length(s),rule=2)$y;}
                                            return(s)},x)
  colnames(z) <-  colnames(x);
  rownames(z) <-  rownames(x);
  return(z);
}



## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  impute.csts
##
## DESCRIPTION: it imputes missing values in a cross-sectional multivariate time series
##
## IMPORTED FUNCTIONS: 
##
## FORMAT: x.imp <- impute.csts(x)
##
## INPUT:        x:  (list) a cross-sectional multivariate time series with missing values 
##
## 
## OUTPUT:   x.imp: (array) <- the cross-sectional multivariate time series x with the
##                  missing values imputed by local linear interpolation.
##                  names of x are preserved.
##
##     
##
## WRITTEN BY: Federico Girosi 
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 08/14/2003
## 
## ************************************************************************
## ************************************************************************

impute.csts <- function(y){
         s <- lapply(y,FUN=impute.ts);
return(invisible(s))
}

######################################################################


load.logmortality.data <- function(disease=NULL,gender=NULL,cntrylist=NULL,userages=NULL, ebase=env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
### In terms of the global, the structure of dataset cstsid:
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho) 
### Structure of dataset cstsid: 
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits

  whodisease <- get("whodisease", env=ewho)
  whogender <- get("whogender", env=ewho)
  whousercntrylist <- get("whousercntrylist", env=ewho)
  whouserages <- get("whouserages", env=ewho)
    
  if(length(disease) <= 0)
      disease <- whodisease
  if(length(gender) <= 0)
      gender <- whogender
  if(length(cntrylist) <= 0)
      cntrylist <- whousercntrylist
  if(length(userages) <= 0)
      userages <- whouserages

### READ DTH AND OTHER BASIC VARIABLES 

  death <- make.dth(disease,gender)
  dth <- death$dth
  cstsid <- death$cstsid
  popu <- death$popu
  remove(death)
  

  cntry <- digitpull(cstsid, digit.cntry.begin, digit.cntry.end)
  cntrylist <- unique.default(cntry);
  t <- digitpull(cstsid,digit.year.begin,digit.year.end)

  subreg <- subregvec(cntry, load=1)$subregion
  subreglist <- unique.default(subreg) 
  
  
### ASSEMBLE DATAMAT AND GIVE NAMES TO VARIABLES 

  flag   <- matrix(0, nrow=nrow(dth))
  cntry  <- matrix(cntry)
  subreg <- matrix(subreg)
  t      <- matrix(t)

  if ( length(cntry) != nrow(dth) || length(subreg) != nrow(dth) || length(t) != nrow(dth))
    stop(message="wrong building datamat: all cols must have lengths =nrow(dth)")

### all datamat's columns are filled with data from files, but for
### columns flag =0; gdp2 =1 /or lngdp2=1; and cnst =1

  datamat  <- cbind(dth,cstsid,popu,flag,subreg,cntry,t)
  namecol  <- c("dth","id","popu","flag","subreg","cntry","t")
  covindx  <- length(namecol)

  colnames(datamat) <- namecol;
  
### make -999 missing
  datamat[datamat == -999] <- NA

### SELECT COUNTRY LIST: WHOUSERCNTRYLIST 
### cntrylist is a selection of countries from the program make.dth
### user makes own selection of cntry's or subregs  
### if no user choice,then count observations and select with whoskip


### whousercntrylist and whousersubreglist are obtained from user input
### if both are empty, then select countries with observ >= whoskip
   whousersubreg <- get("whousersubreg", env=ewho)
   whoskip <- get("whoskip", env= ewho)
   if (any(is.na(cntrylist))) { ## if1 whousercntrylist 
    if (any(is.na(whousersubreg))) { ## if2  whousersubreg
### select based on minimum observations, whoskip
      aux <- count.observations(datamat[,"dth"],  datamat[,"id"])
      cntrylist <- (split.data.frame(aux, aux[ , 2] >= whoskip))$T[ ,1]
      print(paste("There are",length(cntrylist),"countries with more than",
                  whoskip, "observations"))
### whousercntrylist= countries with >=  whoskip observations 
      cntrylist <- matrix(sort(cntrylist))
      rm(aux)
    }

    else { ## if2 length(whousersubreg) > 0
### select countries belonging to user selected subregions
      tmpindx <- !is.na(match(datamat[ ,"subreg"], whousersubreg))
### tmpindx <- is.element(datamat[, subreg], whousersubreg)
      datamat <- datamat[tmpindx, ]
      rm(tmpindx)
    }
  } ## end if1 any(is.na(whousercntrylist))

### cntrylist may still be empty; then  
### take everything from cntrylist in the file make.dth

### SUBSET OF COUNTRIES OR REGIONS ********/
### further pojection from cntrylist based on user choices or whoskip

  if (!any(is.na(cntrylist))){      
    print("Selecting countries")
    tmpindx <- is.element(datamat[ ,"cntry"],cntrylist)
    datamat <- datamat[tmpindx, ]
    rm(tmpindx) }

  
### creates a new variable with the chosen countries for this run

  whocntrylist <- unique.default(datamat[, "cntry"])
  
### SELECT USER DEFINED AGE GROUPS 

  if (any(is.na(whouserages)))  whouserages <- drop.ages(disease);
  
  whouserages <- sort(whouserages)
  agelist     <- digitpull(datamat[ ,"id"],digit.age.begin,digit.age.end )
  age.v   <- unique.default(agelist)
  
  if (length(whouserages) < length(age.v) ) {
    print("Selecting age groups")
    tmpindx <- is.element(agelist, whouserages)
    datamat <- datamat[tmpindx, ]
    whoagelist <- unique.default(digitpull(datamat[ ,"id"],digit.age.begin,digit.age.end))
    rm(tmpindx)
  }   else   {
    whoagelist <-   age.v;
  }
  
### REORGANIZED DATAMAT: sorting along the column "id" = cstsid 
  
  ord <- order(datamat[,"id"])
  datamat <- datamat[ord, ]
  rm(ord)

  
### CONVERTING DTH TO  MORTALITY 

### Now fixing zeros
  print("Adding 0.5 to dth column to avoid possible zeros:")
  datamat[,"dth"] <- datamat[,"dth"] + 0.5
  print("Converting dth column to mortality")
  
  if (any(datamat[,"popu"] == 0, na.rm= T)){
    print("Found some population = 0, and change to NA")
    datamat[, "popu"] <- NA }
  
  datamat[,"dth"] <- datamat[,"dth"]/datamat[,"popu"]
  
### TRANSFORM DTH AND ALLC 

  print("Transforming death")
  whotransform <- get("whotransform", env=ewho)
  datamat[, "dth"] <- trans(datamat[,"dth"], whotransform)


### SPLIT DATAMAT WITH csid (cross sectional identifiers) 

  datasubmat <- split.data.frame(datamat, datamat[ ,"id"]%/%10^(who.year.digits))
  
  stopifnot (length(datasubmat) ==( length(whoagelist) * length(whocntrylist)))
  print(paste("Number of csid's in datamat = ",length(datasubmat)))
  
### elements of list datasubmat must have a range in time:  
  timerng <- range(datamat[,"t"])
  
### thus, the number of rows of any list element is:
  nrsubmat <- abs(timerng[2]-timerng[1])+ 1         

### RECODE FLAG for NA's in rows <= whoyrest & DEP VAR BEFORE FIRST OBV TO -333  
  
### assume elements datasubmat have same time range/or equal no.rows:
  whoyrest <- get("whoyrest", env=ewho)
  indxyrest <- seq(along= datasubmat[[1]][ ,"t"])[ datasubmat[[1]][ ,"t"] == whoyrest]
  nyrest <- 1:indxyrest

### creating global variables for output of chkrest,
### and to delete some csid that are flagged with -999

### making some globals for persistence through function calls
    etrial <- new.env(TRUE, NULL)
    assign("etrial", env=ebase)
    assign("vecount", vector(, length=0), env=etrial)
    assign("count",0, env=trial)
  
### renaming datasubmat after eliminating countries; call it newsubmat      
  newsubmat <- lapply(datasubmat, FUN="chkrest",timerng,nyrest,env.base)
  vecount <- get("vecount", env=etrial)
    count <- get("count", env=etrial)
  delcntry <- length(vecount)/length(whoagelist)
  
### eliminate all empty arrays from newsubmat
  if (length(vecount) > 0) {
    newsubmat <- newsubmat[-vecount]
    cntid <- sapply(newsubmat, function(x) unique.default(x[,"cntry"]), simplify=T)
    whocntrylist <- unique.default(cntid)
    if (length(whocntrylist) == 0) stop("No countries left in data base, probably whoskip too high");
    print("Remaining Countries after deletion: ")}
  else
    print("The countries in the current data are:");
    print(whocntrylist)
### remove globals
  rm(count, vecount)
  
### NAMING THE ELEMENTS OF LIST WITH CSID's
### cross sectional id's (countrycode + agegroup) after deletion of flag -999:
  
  csid <- sort(kronecker(whocntrylist * 100, whoagelist, FUN = "+"))
  names(newsubmat) <- csid
  
  

### for convenience convert elements of newsubmat into data frame and
### name all rows of each list element with the "id" unique identifier
### newsubmat   <- lapply(newsubmat, function(x){ dimnames(x)[[1]] <- x[,"id"]; return(x)})
  
  

  
### INSAMPLE DATA 
 print("Creating insample")
framesubmat <- lapply(newsubmat, function(x){ x <- data.frame(x, row.names=x[,"id"])})
 framesubmat <- lapply(framesubmat, function(x) subset.data.frame(x, na.omit(flag) != -333))
  

whoinsampy  <- lapply(framesubmat,
                      function(x){subset.data.frame(x, t <= whoyrest,select= dth)})

  
  whoinsampy  <- lapply(whoinsampy,as.matrix);
  return(invisible(whoinsampy))
}


######################################################################
######################################################################
######################################################################

list.by.cntry.long <- function(x, ebase=env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
### In terms of the global, the structure of dataset cstsid:
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho) 
### Structure of dataset cstsid:
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits 
  
  cs.vec <- as.numeric(names(x));
  cs.cntry.vec <- digitpull(cs.vec,digit.cntry.begin,digit.cntry.end);  
  cntry.vec <- unique.default(cs.cntry.vec);
  n.cntry <- length(cntry.vec);
  nam <- lapply(x,function(x){return(rownames(x))})
  ind <-  as.list(cntry.vec);
  names(ind) <- cntry.vec;

  func <- function(n,x,cs.cntry.vec,nam){
    cntry <- n;
    c.list <- x[cs.cntry.vec == cntry];
    nam.list <- nam[cs.cntry.vec == cntry];
    y.long <- unlist(c.list);
    y.long.names <- unlist(nam.list)
    names(y.long) <- y.long.names;
    y.long <- as.array(y.long);
    return(y.long)
  }


  l <- lapply(ind,FUN=func,x,cs.cntry.vec,nam);
 return(invisible(l))
}


######################################################################
######################################################################
######################################################################

unlist.by.cntry.long <- function(y, ebase= env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
### In terms of the global, the structure of dataset cstsid:
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho) 
### Structure of dataset cstsid: 
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits 
  
  new.list <- NULL;
  for (i in 1:length(y)){
    x <- y[[i]];
    agevec <- digitpull(as.numeric(rownames(x)),digit.age.begin,digit.age.end);
    f <- factor(agevec);
    z <- split(as.data.frame(x),f);
    names(z) <- paste(names(y)[i],conv.char(as.numeric(names(z))),sep="");
    z <-  lapply(z,function(y){as.matrix(y)});
    new.list <- c(new.list,z);
  }
  return(invisible(new.list))
}

## ************************************************************************
## ************************************************************************
##
## PROGRAM NAME:      expand.covariates
##
## PLACE:     Preprocessing module, covariates for all age groups
##
## IMPORTED functions: none
##
## DESCRIPTION: The covariates in SIZE_(fat,gdp,tfr and hc).txt are 
##              for every year(1920-2000) and one age group("00"), 
##              since they depend on time series but not on age specific group
##              expand.covariates extends the covariates to all age groups. 
##
## FORMAT:      expand.covariates(age.groups= 0*(0:16),NA,
##                                all.cov= c("fat","gdp","hc", "tfr"),
##                                whocovpath ="/usr2/data/death/WHOdata/Jun2002_data/")
##
## INPUT:      The covariates, all.cov, which are age independent;
##             the age.groups; cntry selection or NA if all cntry are selected,
##             and the file path of input files SIZE_cov 
##
## OUTPUT:     Files SS.US_(fat,gdp,tfr and hc).txt,are three
##             cols= covariate, cstsid gender= NA (gender independent)
##             Rows that depends on 17 age groups: 0, 5, 10...80 
##             and cstsid=cntry+age+year (cross sectional time series identifiers); 
##             for select="US" only 2450 and otherwise for all countries.  
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 09/19/2003
##
## ************************************************************************
## ************************************************************************
 
expand.covariates <- function(age.groups= NULL,select= NULL,  all.cov= NULL,  
                              whocovpath =NULL, ebase=env.base){
   if (identical(.GlobalEnv,parent.frame()) && length(whocovpath) <= 0){
### if you are working in the library no need to source
    ewho <- namelists(); 
    whocovpath <- get("cov.path", env=ewho)
 } else {
   ebase <- get("env.base", env=parent.frame());
   env.base <- ebase;
   if(length(whocovpath) <= 0)
     whocovpath <- get("whocovpath", env=get("env.who", env=ebase))}
   
  if(length(all.cov) <= 0)
   all.cov <- c("fat","gdp","hc", "tfr")
  if(length(age.groups) <= 0)
    age.groups <- 5*(0:16)
  
  Covs.lst <- list()
  age.n <- length(age.groups)
     for(i in 1:length(all.cov)){
       covstring <- paste(whocovpath,"SIZE_",all.cov[i],".txt",sep="")
       print(paste("reading file:",covstring))
       cov <- scan(file=covstring,what=c(numeric(0),integer(0),logical()),
                   quiet=T,multi.line=T)
       cov <- matrix(cov,ncol=3,byrow=T)
### since these covariates are gender independent, gender=NA
       colnames(cov) <- c(all.cov[i], "cstsid","gender")
### if only US
       if (length(select) > 0 && select=="US"){
         indx.US <- grep("^2450",as.character(cov[,2]))
         cov <- cov[indx.US, ]}
### else all the countries are included. 
       time.series <- unique.default(as.numeric(cov[,2])%%10^4)
       time.n    <- length(time.series) 
       cntry.vec <-  unique.default(as.numeric(cov[,2])%/%10^6)
       cntry.n   <- length(cntry.vec)
       cov.ex1 <- rep(cov[,1],age.n)
       cov.ex2 <- rep(cov[,2],age.n)
       cov.ex3 <- rep(cov[,3],age.n)
       cov.expand <- cbind(cov.ex1,cov.ex2,cov.ex3)
       colnames(cov.expand) <- c(all.cov[i], "cstsid","gender")
### list by years of time series
       cov.lst <- split.data.frame(cov.expand,as.numeric(cov.expand[,2])%%10^4)
### Given that all year groups have same covariates.
### Repeating the values of covs for age ="00" modify
### the time series to include all age groups  
       
       cov.lst <- lapply(cov.lst, function(x, age.groups){
                        ord <- order(as.numeric(x[,2]))
                        x     <- x[ord, ]
                        yr    <- as.numeric(x[1,2])%%10^4
                        years.string <- formatC(age.groups, width =2, format="d", flag="0")
                        ctry.age <- kronecker(unique.default(as.numeric(x[,2])%/%10^6), years.string, FUN="paste", sep="")
                        ctry.age.yr <- as.numeric(paste(ctry.age,yr,sep=""))
                        ctry.age.yr <- sort(ctry.age.yr)
                        if(length(ctry.age.yr) != length(x[,2]))
                          stop("Building the wrong matrix in expand.covariates")
                        else
                        x[,2] <- ctry.age.yr
                        return(x)}, age.groups)
cov.frame <- lapply(cov.lst, as.data.frame)
st <- unlist(cov.frame, recursive=F)
nmcov <- paste(names(cov.frame),".",all.cov[i],sep="")
nmcst <- paste(names(cov.frame),".","cstsid",sep="")
nmgen <- paste(names(cov.frame),".","gender",sep="")
### build a matrix with 3 cols= covariate, cstsid and gender=NA
### with age groups=5*(0:16); and years=1920:2000.
### Covariates are repetition of one given age, say "45" or "00"
### for every single year in time series. 
mm <- matrix(,nrow=length(cov.lst)* age.n * cntry.n, ncol= 3)
colnames(cov) <- c(all.cov[i], "cstsid","gender")
for(n in 1:3){  ##for2 build cols of datamat
  mmc  <- dim(0)
  coln <- sapply(1:length(st), function(i,st){
                x <- n + (i-1) * 3
                if(n <=1 && is.element(names(st)[x],nmcov)==T)
                  mmc <- c(mmc,as.vector(st[x]))
                else if(n <=2 && is.element(names(st)[x],nmcst)==T)
                  mmc <- c(mmc,as.vector(st[x]))
                else if(is.element(names(st)[x],nmgen)==T)
                  mmc <- c(mmc,as.vector(st[x]))
                return(mmc)}, st)
  coln <- unlist(coln)
  if(length(coln) < length(cov.lst)* age.n * cntry.n)
    print("Wrong building jumbo cov")
  else
    mm[,n] <- coln
} ##end for2 build cols of datamat
### order matrix rows according to values of second col=cstsid
indx <- order(mm[,2])
mm   <- mm[indx, ]
colnames(mm) <-  c(all.cov[i], "cstsid","gender")
### asssuming list of covariates is c("fat","gdp","hc", "tfr")
### creates output and text files for preprocessing routines
### Now, to be consistent with previous code eliminate col= 3 with gender=NA
mm <- mm[,-3]
if (i == 1){
  Covs.lst <- c(Covs.lst, fat=list(mm))
  fat.path <- paste(whocovpath,"WHO_fat",".txt",sep="")
  file.remove(fat.path)
  file.create(fat.path)
  mm[,2] <- as.character(mm[,2])
### for consistency with previous code (2 cols and no gender):
   write.table(mm, file=fat.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")
       print(paste("The size of WHO_fat  file is = ",
                  file.info(fat.path)$size))
}else if(i==2){
  Covs.lst <- c(Covs.lst, gdp=list(mm))
  gdp.path <- paste(whocovpath,"WHO_gdp",".txt",sep="")
  file.remove(gdp.path)
  file.create(gdp.path)
  mm[,2] <- as.character(mm[,2])
### for consistency with previous code (2 cols and no gender):
  write.table(mm, file=gdp.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")  
      print(paste("The size of WHO_gdp file is = ",
                  file.info(gdp.path)$size))
}else if (i==3){
  Covs.lst <- c(Covs.lst, hc=list(mm))
  hc.path <- paste(whocovpath,"WHO_hc",".txt",sep="")
  file.remove(hc.path)
  file.create(hc.path)
  mm[,2] <- as.character(mm[,2])
### for consistency with previous code (2 cols and no gender):
   write.table(mm, file=hc.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")  
      print(paste("The size of WHO_hc file is = ",
                  file.info(hc.path)$size))
}else if(i==4){
  Covs.lst <- c(Covs.lst, tfr=list(mm))
  tfr.path <- paste(whocovpath,"WHO_tfr",".txt",sep="")
  file.remove(tfr.path)
  file.create(tfr.path)
  mm[,2] <- as.character(mm[,2])
### for consistency with previous code (2 cols and no gender):
  write.table(mm, file=tfr.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")  
      print(paste("The size of WHO_tfr file is = ",
                  file.info(tfr.path)$size))
}
     }
  return(invisible(Covs.lst)) }

## ************************************************************************

## ************************************************************************
## ************************************************************************
##
## PROGRAM NAME:      list.covariates
##
## PLACE:     Preprocessing module, covariates for all age groups
##
## IMPORTED functions: none
##
## DESCRIPTION: It obtains the names of the covariates contributing to list elemnets
##              for every csid  or cntry and age combination.  
##
## FORMAT:      list.covariates(lst)
##
## INPUT:      The covariates whocov, whoinsampx or whoutsampx,from make.mortality.data;
##             They are list whose elements are csid or country-age ccombinations. 
##
## OUTPUT:     Another list with same number of elements as the original list (or input list)
##             but with only one row with the names of contributing covariates.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 12/11/2003
##
## ************************************************************************
## *************************

  list.covariates <- function(list){
                      cov.lst <- lapply(list, function(x){whocovlist <- colnames(x)})}
