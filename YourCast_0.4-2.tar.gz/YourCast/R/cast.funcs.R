## ************************************************************************
## ************************************************************************
##
## FILE NAME:         cast.funcs
##
## PLACE:     Preprocessing module, funcs functions.
## index of functions:  disease.number,subregvec,
##                      drop.ages, count.observations,
##                      extend.datamat, cntryid, long.causes 
##
## ************************************************************************
## ************************************************************************
##


arguments <- function(driver="yourcast"){
  
  args <- names((formals(driver)))
              }
  
## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      digitpull
##
## PLACE:     Preprocessing module, the old Gauss digitpull.g
##            function rewritten in R
##
## IMPORTED functions: none
##
## DESCRIPTION: digitpull() pulls connected digits from a numeric variable
##
## FORMAT:  x <- digitpull(v, start, stop)
##
## INPUT:   v           vector of numeric data, all of the same length,
##                      and with at least stop digits
##          
##          startdig    the first digit of v to return
##
##          stopdig     the last digit of v to return. 
##                      (stopdig must be >= startdig)
##
## OUTPUT:  x           startdig to stopdig digits of v
##
## REMARKS:    As currently written, digitpull() only works on the 
##             integer portion of v
##
## WRITTEN BY: Federico Girosi & Anita Gulyasne Goldpergel
##             fgirosi@latte.harvard.edu, anitag@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 11/14/2002
## 
## ************************************************************************
## ************************************************************************

digitpull <- function(v, startdig, stopdig) {
  v <- as.numeric(v)
  v <- matrix(v, ncol = 1)
  v <- trunc(v)

### error checking
  if (stopdig < startdig) {
    stop(message="stopdig < startdig in proc preproc.digitpull")
  }

  if (min(abs(v)) < 10^(stopdig-1)) {
    stop(message="narrowest element in v not as wide as stopdig in proc digitpull()")
  }

  if (startdig < 1) {
    stop(message="startdig < 1 in proc digitpull()")
  }
  
  if (ncol(v) > 1) {
    stop(message="v not column vector in proc digitpull()")
  }
### end error checking  

  n <- trunc(log10(v[1]))+1
  a1 <- trunc(v/10^(n-stopdig))
  a2 <- trunc(v/10^(n-startdig+1))
  ret <- a1 - a2*10^(stopdig - startdig +1)
  return(matrix(ret))
}

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      modify.mean.age.profile
##
## 
## IMPORTED functions: list.by.cntry, list.by.csid
##
## USED GLOBALS: none
## DESCRIPTION: given a cross-sectional time series in the usual list
##              format, it applies a given function to each age profile
##              and returns the modified cross-sectional time-series
##              
## FORMAT: new.y <- modify.mean.age.profile(y, func)
##
## INPUT: y: a cross-sectional time series in list format
##
##        func: a function of one argument, which takes an age profile and returns
##              a vector of the same length
##
## OUTPUT:  new.y: a cross-sectional time series obtained from y by replacing each age profile
##                 x by the vector func(x).
##     
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

 
 modify.age.profiles <- function(y,func,param){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase
  ewho <- get("env.who", env=ebase)
   insampy <- list.by.cntry(y);
   insampy <-  lapply(insampy,FUN=function(x,func,param){t(apply(x,1,FUN=func,param))},func,param);
   new.whoinsampy <- list.by.csid(insampy);
   return(invisible(new.whoinsampy))
 }





## ######################################################################################
##
## FUNCTION NAME:      bind.list
##
## IMPORTED functions: none
##
## DESCRIPTION: given two lists of equal length, whose elements are matrices,
##              it returns one list of same length, whose elements are the concatenation
##              of the corresponding elements in the two lists
##              
##
## FORMAT: lst <- bind.list(x,y,bycol=bycol,namex=namex)
##
## INPUT: x,y:  lists of length n. x[[i]] and y[[i]] must have either the same
##              number of rows or the same number of columns
##        bycol: logical. If TRUE concatenation is performed along columns
##               otherwise along rows
##        namex: logical. If TRUE the resulting list inherits the names of x
##               otherwise it inherits the names of y
##
## OUTPUT: lst: a list of length n. if bycol=FALSE then lst[[i]] = rbind(x[[i]],y[[i]]),
##              otherwise lst[[i]] = cbind(x[[i]],y[[i]]).
##              if namex=TRUE then names(lst) = names(x), otherwise names(lst)=names(y)
##
##  Federico Girosi
##  CBRSS
##  Harvard University
##  34 Kirkland St. 
##  Cambridge, MA 02143
##  fgirosi@latte.harvard.edu
##  (C) Copyright 2003   


bind.list <-  function(x,y,bycol=FALSE,namex=TRUE,colname=NULL) {
 
  n <- length(x);
  z <- as.list(1:n);
  
  if(length(x) <= 0)
    return(y)
  if(length(y) <= 0)
    return(x)
 
  z <- lapply(z,FUN=function(n,x=x,y=y,bycol=bycol,colname=colname){
                             
 ###                             print(ncol(x[[n]]))
 ###                             print(ncol(y[[n]]))
 ###                             print(nrow(x[[n]]))
 ###                             print(nrow(y[[n]]))
                             
                              cbool <- (ncol(x[[n]]) > 0 && ncol(y[[n]]) > 0)
                              cbool <- cbool && (ncol(x[[n]]) != ncol(y[[n]]))
                              
                              if (!bycol && cbool)                                
                                stop("Different number of cols no binding possible")
                              
                              rbool <- (nrow(x[[n]]) > 0 && nrow(y[[n]]) > 0)
                              rbool <- rbool && (nrow(x[[n]]) != nrow(y[[n]]))
                              if (bycol && rbool)
                                stop("Different number of rows no binding possible")
                                   
                              if (!bycol)
                               return(rbind(x[[n]],y[[n]]))
                              if(length(colname) > 0 )
                               {
                                 mat <- cbind(x[[n]],y[[n]])
                                 colnames(mat) <- colname
                                 return(mat)
                               }else
                              return(cbind(x[[n]],y[[n]]))},
              x,y,bycol,colname);
  if (namex)
    names(z) <- names(x)
  else
    names(z) <- names(y)
  return(z);
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      make.average.age.profile
##
## 
## IMPORTED functions: list.by.cntry
##
## USED GLOBALS: none
##
## DESCRIPTION: given a cross-sectional time series in list format,
##              it returns the average  age profile (where the average
##              is taken over countries and years)
##
## FORMAT:  mean.age.profile <- make.average.age.profile(y)
##
## INPUT:   y: (list) a cross-sectional time series over C countries
##                      and A age groups, in list format
##
##
## OUTPUT: mean.age.profile: A x 1 vector. The average age profile, with elements named
##                           according to age groups
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

make.average.age.profile <- function(y,bycntry=FALSE, ebase=env.base){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase
  ewho <- get("env.who", env=ebase)
  insampy <- list.by.cntry(y);
  age.profile.list <- lapply(insampy,FUN=function(x){return(mean(as.data.frame(x),na.rm=TRUE))});
  result <- age.profile.list;
 
  if (!bycntry){
    mean.age.profile <- 0*age.profile.list[[1]];
    for (i in 1:length(age.profile.list)){
      mean.age.profile <- mean.age.profile + age.profile.list[[i]];
    }
    result <- mean.age.profile/length(age.profile.list);
  }
  return(result);
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      list.by.cntry
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: given a cross-sectional time series over C countries
## and A age groups, in list format, it returns a list of C matrices,
## one for each country. The matrices have dimension T x A, where T is
## the length of the time series and A is the number of age groups.
## Each column of a matrix is the time series for the corresponding age group
##
## FORMAT:  insampy <- list.by.cntry(whoinsampy)
##
## INPUT:   whoinsampy: (list) a cross-sectional time series over C countries
##                      and A age groups, in list format.
##
##
## OUTPUT: insampy: list of C matrices. The names of the elements of
##                  the list are the country codes. Each matrix is T x A. The names of
##                  the rows are the years of the time series, and the names of the
##                  columns are the names of the age groups.
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

list.by.cntry <- function(x, ebase=1,
                          who.digit.first=0, who.cntry.digits=4,
                          who.age.digits=2, who.year.digits=4)
{
  if (!identical(.GlobalEnv, parent.frame()) && length(ebase) > 0 ){
    
    ebase <- get("env.base", env=parent.frame());
    env.base <- ebase;
    ewho <- get("env.who", env=ebase)
    cntry.vec <- get("cntry.vec", env=ewho)
    age.vec <- get("age.vec", env=ewho)
      
    who.digit.first  <- get("who.digit.first", env=ewho) 
    who.cntry.digits <- get("who.cntry.digits", env=ewho)
    who.age.digits   <- get("who.age.digits",env=ewho)
    who.year.digits  <- get("who.year.digits", env=ewho)
  }
### Structure of dataset cstsid:

  digit.cntry.begin <- who.digit.first + 1
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1
  digit.year.end    <- digit.age.end   + who.year.digits
  
  cs.vec <- as.numeric(names(x));
  cs.cntry.vec <- digitpull(cs.vec,digit.cntry.begin,digit.cntry.end);  
  cntry.vec <- unique.default(cs.cntry.vec);
  age.vec <- unique.default(digitpull(cs.vec,digit.age.begin,digit.age.end));
  n.cntry <- length(cntry.vec);
  n.age <- length(age.vec);
  newlist <-  list();
  
  for (i in 1:n.cntry){
    cntry <- cntry.vec[i];
### get all the elements of the list x which correspond to country cntry 
    c.list <- x[cs.cntry.vec == cntry];
    colnam <- digitpull(as.numeric(names(c.list)),digit.age.begin,digit.age.end)
    
    rownam <- digitpull(as.numeric(rownames(c.list[[1]])),digit.year.begin, digit.year.end);
    
    c.mat <- as.matrix(as.data.frame(c.list));
    colnames(c.mat) <- colnam;
    rownames(c.mat) <- rownam;
    newlist <-  c(newlist, list(c.mat));
  }
  names(newlist) <- cntry.vec;
  return(newlist);
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      list.by.csid
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: it inverts the effect of list.by.cntry.
##
## FORMAT:  whoinsampy <- list.by.csid(insampy)
##
## INPUT:   insampy: (list) the output of list.by.cntry
##
##
## OUTPUT: whoinsampy: (list) ther cross-sectional time series which,
##                      when given as input to list.by.cntry, generates insampy
## 
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## ***********************************************************************
## ************************************************************************

list.by.csid <- function(insampy.c,col.name="dth", ebase=1){
    if (identical(.GlobalEnv, parent.frame()) || length(ebase) <= 0){
### if you are working in the library no need to source
      ewho <- namelists();
      who.age.digits   <- get("age.digits",env=ewho)
    }else{
      ebase <- get("env.base", env=parent.frame());
      env.base <- ebase;
      ewho <- get("env.who", env=ebase)
  ### Structure of dataset cstsid: 
  who.age.digits   <- get("who.age.digits",env=ewho)}
  
  cntry.vec <- as.numeric(names(insampy.c));
  age.vec <- as.numeric(colnames(insampy.c[[1]]));
  n.age <- length(age.vec); 
  csid.vec  <- sort(kronecker(cntry.vec *10^(who.age.digits), age.vec, FUN="+"))
  n.csid <- length(csid.vec)
  indx <- as.list(1:n.csid)
  names(indx) <- as.character(csid.vec)

  newlist <- function(x){
    resto <- x %% n.age
    indx <-  x %/% n.age

    if(resto > 0) indx <- indx + 1
    naming <- as.character(csid.vec[x])
    nm.vec <-  rownames(insampy.c[[indx]]);
    nm.vec <-  paste(naming, nm.vec, sep="") 
    if(resto == 0){
      x <- insampy.c[[indx]][,n.age]
      x <- as.matrix(x);
      rownames(x) <- nm.vec;
      colnames(x) <- col.name;
    } else {
      x <- insampy.c[[indx]][,resto];
      x <- as.matrix(x);
      rownames(x) <- nm.vec;
      colnames(x) <- col.name;
    }
    return(x)
  }
  
  whoinsampy <- lapply(indx,FUN="newlist")
  return(invisible(whoinsampy))
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      split.matrix
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: it splits a matrix in blocks along the rows.
##              
## FORMAT: Y <- split.matrix(X,blocks)
##
## INPUT: X: a matrix, vector, data frame or 2-dimensional array
##
##        blocks: a vector of integers, which sum up to the number of rows of X.
##                it specify the size of the blocks
##
## OUTPUT: Y a list of length equal to the length of blocks, with the blocks as elements
##         the blocks are stored as matrices.
##
## EXAMPLE: if X is a matrix with 10 rows and blocks = c(2,3,5) then Y has the 3 elements;
##           the first elements has the first 2 rows of X, the second has rows 3 to 5, and
##           the 3rd element has rows 6 to 10.
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************


split.matrix <- function(x,blocks){
  x <- as.data.frame(x);
  if (nrow(x) != sum(blocks)) stop("Block structure is wrong in partition.vector");
  f <- factor(rep(1:length(blocks),blocks));
  res <- split(x,f);
  res <- lapply(res,FUN=as.matrix);
  return(res);  
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  make.forecast
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: given a list of coefficients and covariates it returns
##              the corresponding list of predicted values 
##              
## FORMAT: yhat <- make.forecast(coeff,X)
##
## INPUT: coeff: list of regression coefficients, one element for each cross-section;
##
##            X: list  of covariate matrices, one element for each cross-section;
##
##
## OUTPUT: yhat: list of predicted values: yhat[[n]] =X[[n]] %*% coeff[[n]].
##               It inherits the names of X.
##
##
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## 
## ************************************************************************
## ************************************************************************

make.forecast <- function(coeff,X){
  indx <- seq(1,length(X));
  names(indx) <-  names(X);
  yhat <- lapply(indx,FUN=function(n,coeff){
    beta <- coeff[[n]];
    Z <- X[[n]];
    mult <- try(Z%*%beta, silent=T)
    if(class(mult)=="try-error"){
      cat(names(X[n]), "\n")
      cat(dim(beta), "\n")
      cat(dim(Z), "\n")
      return(0)
    }else
      return(mult)}, coeff);  
##    return(Z%*%beta)},coeff);
  return(yhat);
}

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  death.from.logmortality
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: to compute the cross-sectioanl time series of deaths
##              given the cross-sectional time series of log mortality and population
##   
##              
## FORMAT:      d <- death.from.logmortality(logm,popu)
##
## INPUT:    logm: (list) log-mortality cross-sectional time series
##
##           popu: (list) population cross-sectional time series
##  
##
## OUTPUT:      d: (list) cross-sectional time series of deaths
##               
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/7/2003
## 
## ************************************************************************
## ************************************************************************


death.from.logmortality <- function(logm,popu){
  ind <- as.list(1:length(logm));
  names(ind) <-  names(logm);
  func <- function(n,logm,popu){
    x <- logm[[n]];
    y <- popu[[n]];
    dth <- y*exp(x)
    dth[dth <= 0.5] <- 0.5
    return(dth)
  }
  d <-  lapply(ind,FUN="func",logm,popu);
  return(invisible(d));
}




##
## DESCRIPTION: to compute the cross-sectioanl time series of deaths
##              given the cross-sectional time series of log mortality and population
##   
##              
## FORMAT:      s <- model.string()
##
## INPUT:    none
##
## OUTPUT:      s: (string) a string which uniquely identifies the model being used,
##                 consisting of whomodel and some other strings specifying parameters value.
##                 Right now is equal to whomodel, except when whomodel is "OLS".
##                 In this case, if we use an heteroskedastic OLS, with observations
##                 weighted by number of deaths (a la Wilmoth) the string is "OLSH"
##                
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/7/2003
## 
## ************************************************************************
## ************************************************************************


model.string <- function(ebase=env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  whomodel <- get("whomodel", env= ewho)
  who.ols.sigma.param <- get("who.ols.sigma.param", env=ewho)
  s <-  whomodel;
  if (whomodel == "OLS"){
    if (who.ols.sigma.param$use.deaths == TRUE && who.ols.sigma.param$average == FALSE){
      s <- "OLSH";
    }
  }
  return(s);
}


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  strpad
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: to convert a list of strings of different lenghts into
##              a list of strings of the same length, given by the maximum
##              string length in the list. This is achieved by padding the shorter
##              string with blanks, It is useful in printing statements.##   
##              
## FORMAT:      s <- strpad(x)
##
## INPUT:       x: (list) a list of strings
##
## OUTPUT:      s: (list) the same list as x, but with  right-padding with blanks, so
##                 that all the elements have the same length.
##                
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/7/2003
## 
## ************************************************************************
## ************************************************************************


strpad <- function(x){
  l <- max(nchar(x));
  z <-  lapply(x,FUN=function(x,l){a <- paste(x,paste(rep(" ",l-nchar(x)),sep="",collapse=""),sep="");return(a)},l)
}




## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  list.coeff.by.cntry 
##
## 
## IMPORTED functions: none
##
## USED GLOBALS: none
##
## DESCRIPTION: 
##              
## FORMAT:   s <- list.coeff.by.cntry(coeff,cntry.vec,age.vec)
##
## INPUT:    coeff: (list) a cross-sectional list of regression coefficients,
##                  indexed by country and age.
##
##       cntry.vec: (vector) vector of country codes represented in the list coeff
##
##         age.vec: (vector) vector of age groups represented in the list coeff
##
##         if either of cntry.vec or age.vec are not defined, get them from the
##         ewho environmnet: ewho= get("env.who", env = env.base); ebase= env.base
##
## OUTPUT:       s: (list) a cross-sectional list indexed by countries.
##                  For each county the regression coefficients corresponding
##                  to different age groups are concatenated one after the
##                  the other, according to the order of the age groups in age.vec
##
##
##                
## WRITTEN BY: Federico Girosi
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
##
## Last modified: 08/7/2003
## 
## ************************************************************************
## ************************************************************************


list.coeff.by.cntry <- function(coeff,cntry.vec=NULL,age.vec=NULL, ebase = env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  who.age.digits <- get("who.age.digits", env=ewho)
  if(length(cntry.vec) <= 0)
    cntry.vec <- get("cntry.vec", env=ewho)
  if(length(age.vec) <= 0)
    age.vec <- get("age.vec", env=ewho)
  
  age.char <- formatC(age.vec,wid= who.age.digits,format="d", flag="0")

### cov.list is the vector of covariates in the n-th cross-section;
  names(cntry.vec) <- cntry.vec;
  b <- lapply(cntry.vec,FUN=function(x,coeff,age.char){
    ind <- paste(x,age.char,sep="");
    return(unlist(coeff[ind]))},coeff,age.char);
  return(b);  
}




## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  impute.ts
##
## DESCRIPTION: it imputes missing values in a multivariate time series
##
## IMPORTED FUNCTIONS: 
##
## FORMAT: x.imp <- impute.ts(x)
##
## INPUT:        x:  (array) a multivariate time series with missing values 
##
## 
## OUTPUT:   x.imp: (array) <- the multivariate time series x with the
##                  missing values imputed by local linear interpolation.
##                  names of x are preserved.
##
##     
##
## WRITTEN BY: Federico Girosi 
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 08/14/2003
## 
## ************************************************************************
## ************************************************************************

impute.ts <- function(x){
  nr <- nrow(x);
  nc <- ncol(x);
  ind <- 1:nc;
  z <- apply(as.array(ind),MARGIN=1,FUN=function(n,x){s <- x[,n];
                                                      if (any(is.na(s))){
                                            s <- approx(1:length(s),s,xout=1:length(s),rule=2)$y;}
                                            return(s)},x)
  colnames(z) <-  colnames(x);
  rownames(z) <-  rownames(x);
  return(z);
}



## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:  impute.csts
##
## DESCRIPTION: it imputes missing values in a cross-sectional multivariate time series
##
## IMPORTED FUNCTIONS: 
##
## FORMAT: x.imp <- impute.csts(x)
##
## INPUT:        x:  (list) a cross-sectional multivariate time series with missing values 
##
## 
## OUTPUT:   x.imp: (array) <- the cross-sectional multivariate time series x with the
##                  missing values imputed by local linear interpolation.
##                  names of x are preserved.
##
##     
##
## WRITTEN BY: Federico Girosi 
##             fgirosi@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 08/14/2003
## 
## ************************************************************************
## ************************************************************************

impute.csts <- function(y){
         s <- lapply(y,FUN=impute.ts);
return(invisible(s))
}


######################################################################

list.by.cntry.long <- function(x, ebase=env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
### In terms of the global, the structure of dataset cstsid:
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho) 
### Structure of dataset cstsid:
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits 
  
  cs.vec <- as.numeric(names(x));
  cs.cntry.vec <- digitpull(cs.vec,digit.cntry.begin,digit.cntry.end);  
  cntry.vec <- unique.default(cs.cntry.vec);
  n.cntry <- length(cntry.vec);
  nam <- lapply(x,function(x){return(rownames(x))})
  ind <-  as.list(cntry.vec);
  names(ind) <- cntry.vec;

  func <- function(n,x,cs.cntry.vec,nam){
    cntry <- n;
    c.list <- x[cs.cntry.vec == cntry];
    nam.list <- nam[cs.cntry.vec == cntry];
    y.long <- unlist(c.list);
    y.long.names <- unlist(nam.list)
    names(y.long) <- y.long.names;
    y.long <- as.array(y.long);
    return(y.long)
  }


  l <- lapply(ind,FUN=func,x,cs.cntry.vec,nam);
 return(invisible(l))
}


######################################################################
######################################################################
######################################################################

unlist.by.cntry.long <- function(y, ebase= env.base){
ebase <- get("env.base", env=parent.frame());
  env.base <- ebase;
### In terms of the global, the structure of dataset cstsid:
  ewho <- get("env.who", env=ebase)
  who.digit.first  <- get("who.digit.first", env=ewho) 
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits   <- get("who.age.digits",env=ewho)
  who.year.digits  <- get("who.year.digits", env=ewho) 
### Structure of dataset cstsid: 
  digit.cntry.begin <- who.digit.first + 1 
  digit.cntry.end   <- who.digit.first + who.cntry.digits
  digit.age.begin   <- digit.cntry.end + 1
  digit.age.end     <- digit.cntry.end + who.age.digits
  digit.year.begin  <- digit.age.end   + 1 
  digit.year.end    <- digit.age.end   + who.year.digits 
  
  new.list <- NULL;
  for (i in 1:length(y)){
    x <- y[[i]];
    agevec <- digitpull(as.numeric(rownames(x)),digit.age.begin,digit.age.end);
    f <- factor(agevec);
    z <- split(as.data.frame(x),f);
    names(z) <- paste(names(y)[i],conv.char(as.numeric(names(z))),sep="");
    z <-  lapply(z,function(y){as.matrix(y)});
    new.list <- c(new.list,z);
  }
  return(invisible(new.list))
}



## ************************************************************************
## ************************************************************************
##
## PROGRAM NAME:      list.covariates
##
## PLACE:     Preprocessing module, covariates for all age groups
##
## IMPORTED functions: none
##
## DESCRIPTION: It obtains the names of the covariates contributing to list elemnets
##              for every csid  or cntry and age combination.  
##
## FORMAT:      list.covariates(lst)
##
## INPUT:      The covariates whocov, whoinsampx or whoutsampx,from make.mortality.data;
##             They are list whose elements are csid or country-age ccombinations. 
##
## OUTPUT:     Another list with same number of elements as the original list (or input list)
##             but with only one row with the names of contributing covariates.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 12/11/2003
##
## ************************************************************************
## *************************

  list.covariates <- function(list){
    if( ncol(list[[1]])<=1 )
        cov.lst <- lapply(list, function(x){whocovlist <- rownames(x)})
    else
      cov.lst <- lapply(list, function(x){whocovlist <- colnames(x)})}


######################################################################


prior.variance <- function(ecxc,N=100,graphics=FALSE){

vlist <- ls(ecxc)
for (v in vlist){
  assign(v,get(v,ecxc))
}

S <- sample.improper.normal(D,1,N)
D.pinv <- S$covar;
beta <- S$x

## make covariates  matrix 
Z <- matrix(0,nrow=sum(t.list),ncol=sum(beta.dim))
row.max <- cumsum(t.list)
row.min <- row.max-t.list+1
col.max <- cumsum(beta.dim)
col.min <- col.max-beta.dim+1
Z.rownames <- rep(NA,nrow(Z))

for (i in 1:length(whocov)){
  Z[row.min[i]:row.max[i],col.min[i]:col.max[i]] <- whocov[[i]]
  Z.rownames[row.min[i]:row.max[i]] <- rownames(whocov[[i]])
}
rownames(Z) <- Z.rownames

var.vec <- diag(Z%*%D.pinv%*%t(Z))
names(var.vec) <- rownames(Z)


mu <- Z%*%beta

aux <- split.matrix(mu,t.list)

mu.time <- NULL
for (i in 1:length(aux)){
  mu.time <- cbind(mu.time,aux[[i]]+who.mean.age.profile[i])
}

if(graphics){
op <- par(cex.lab=1.4,omi=c(0,0.1,0,0),cex.main=1,bg="lavenderblush1",font=2,font.axis=2);
matplot(mu.time[,1:N],type="l",ylim=c(-13,-10),main=paste("Ha.sigma=",round(Ha.sigma,2),
                                 ", Ht.sigma=",round(Ht.sigma,2),
                                 ", Hat.sigma",round(Hat.sigma,2)))
}
mu.age <- NULL
for (i in 1:t.list[1]){
  mu.age  <- cbind(mu.age,mu[row.min+i-1,])
}

mu.age <- mu.age + who.mean.age.profile

mu.age.time <- lapply(1:ncol(mu),
                      FUN=function(k,mu,t.list,who.mean.age.profile){
                        m <- matrix(mu[,k],nrow=t.list[1]);
                      m <-  scale(m,center=-who.mean.age.profile,scale=FALSE)},mu,t.list,who.mean.age.profile)

return(list(mu.age.time=mu.age.time,var.vec=var.vec,mu.time=mu.time,mu.age=mu.age))
}

######################################################################

long.to.square.format <- function(mat){
  if (ncol(mat) != 3) stop("long.to.square.format argument must have 3 columns")
  rn <- paste(mat[,1],mat[,2],sep="_")
  if(length(rn) != length(unique.default(rn))){cat(length(rn), "\n")
             cat(length(unique.default(rn)), "\n");stop("long.to.square.format argument contains duplicates")}
  rownames(mat) <- rn
  x <- sort(unique.default(mat[,1]))
  y <- sort(unique.default(mat[,2]))
  z <- matrix(0,nrow=length(x),ncol=length(y))
  rownames(z) <- paste(x)
  colnames(z) <- paste(y)
  aux <- NULL
  for (i in 1:length(x)){
    for(j in 1:length(y)){
      z[i,j] <- mat[paste(x[i],y[j],sep="_"),3]
      aux <- rbind(aux,c(x[i],y[j],z[i,j]))
    }
  }

### sanity check
  rownames(aux) <- paste(aux[,1],aux[,2],sep="_")
  if(length(intersect(rownames(aux),rownames(mat))) != nrow(mat)) stop("mismatch")
  aux <- aux[rownames(mat),]
#  if (sum((aux-mat)^2) > 0)  stop("mismatch")
  return(list(x=x,y=y,z=z))
}

######################################################################


## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      dt.da.stat
##
##
## DESCRIPTION: Use this to compute a summary statistics: absolute change in time trend
##              of log-mortality from one age group to the next:
##              [mu(a,t) - mu(a, t-1)] - [mu(a-1,t) - mu(a-1,t-1)]
##              
##
## INPUT:   y: a list of lof-mortality matrices (T X A), one for each country
##
## OUTPUT: a vector of summary statistics, ready to be histogrammed
##
## WRITTEN BY: Federico Girosi, 7/19/2005
## 
## ********************************************************************
## ********************************************************************

dt.da.stat <- function(mu.age.time){
  dtda <- NULL
  for (i in 1:length(mu.age.time)){
    y <-  mu.age.time[[i]]
    mat <- matrix(0,nrow=nrow(y)-1,ncol=nrow(y))
    diag(mat) <-  -1
    for (k in 1:nrow(mat)){
      mat[k,k+1] <- 1
    }
    dmu <- mat %*% y
    dtda <- c(dtda,apply(dmu,1,FUN=function(x){mean(abs(diff(x)))}))
  }
  return(dtda)
}
