##############################################################################
##
## FUNCTION NAME: plot.cast
##
## DESCRIPTION: This function does the plotting.  It takes in as
## its input a data matrix corresponding with a country, gender and
## disease combination and plots two graphs -- time series and age
## profiles.
##
## IMPORTED FUNCTIONS:   none
##
##
## FORMAT: plot.cast(your.result,disease.name,gender.str,cntry.str,
##                   plot.time.series, plot.age.profiles)
##
## INPUT:     your.result : M x N matrix of log-mortality rates for a given
##                          country, gender and cause of death, where M
##                          corresponds with years and N corresponds with
##                          age groups.
##            disease.name: a character string that identifies cause of death.
##                          (eg. "All Cause ")
##              gender.str: "m" for male and "f" for female
##               cntry.str: a character string that identifies the country
##        plot.time.series: Logical variable telling the function whether or
##                          not to plot the time series graph. (default: TRUE)
##       plot.age.profiles: Logical variable telling the function whether or
##                          not to plot the age profiles graph. (default: TRUE)
##                           
## OUTPUT: 2 graphs are produced side by side, with the time series on the left
##         and the age profiles on the right, unless otherwise specified. 
##
## WRITTEN BY: Federico Girosi and Nirmala Ravishankar
##             fgirosi@latte.harvard.edu, ravishan@fas.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 12/04/2003 by Nirmala Ravishankar
## 
## ###########################################################################


plotcast.new <- function(pred.in, pred.out, obs.in, obs.out,
                          disease.name,gender.str=NULL, cntry.str,
                         print2file, plot.time.series,pred.outsample,
                         pred.insample,obs.outsample,obs.insample,
                         plot.age.profiles, ylim=NA){
                          
     
      gender.str.title <- paste("(",gender.str,")",sep="");
      if(identical(gender.str.title, "()"))
        gender.str.title <- "  ";

  age.vec <- colnames(obs.in);
  titlestr <- paste(disease.name,gender.str.title,cntry.str)  
 
  if (print2file == F) par(ask = T)
  ##Plotting time series data
  if (plot.time.series == T){
  
    mat1 <- rbind(pred.in, pred.out)
    
    if (pred.outsample == T){  
      mat2 <- pred.out
      aux <- matrix(NA,nrow=5,ncol=ncol(mat1));
      rownames(aux) <- seq(as.numeric(rownames(mat1)
                                      [nrow(mat1)])+1,length=5);
        
      mat1 <- rbind(mat1,aux);
    } else{
  
      if (obs.outsample == T && nrow(na.omit(obs.out)) >0){
        mat2 <- na.omit(obs.out)
        last.year.outsamply <- as.numeric(rownames(mat2)[nrow(mat2)])
        last.year.yhatin  <- as.numeric(rownames(pred.in)[nrow(pred.in)])
        if (last.year.yhatin > last.year.outsamply) mat2 <- pred.in
        
      } else{
        if (pred.insample == T){ 
          mat2 <- pred.in
        } else{
          mat2 <- obs.in}
      }
    }
    
    xl <- "Time";
    yl <- "Data and Forecasts";
    colo <- rainbow(ncol(mat1));
    colo[3] <- colo[2];
    colo[5] <- colo[4];
 
    y.age.labels <- mat2[nrow(mat2),];
   
    if(any(is.na(ylim))){
     
      matplot(rownames(mat1),mat1,type="l",
              lty=1,col= 0 ,main=titlestr,xlab=xl,ylab=yl)
    }else{
      
      matplot(rownames(mat1),mat1,type="l",
              lty=1,col= 0 ,main=titlestr,xlab=xl,ylab=yl, ylim=ylim)
    }
   
    if (pred.insample == T) matplot(rownames(pred.in),pred.in,type="l",
          lty=1,col= colo,main=titlestr,xlab=xl,ylab=yl, add= T)
   
    if (pred.outsample == T) matplot(rownames(pred.out),pred.out,type="l",
          lty=1,col= colo,main=titlestr,xlab=xl,ylab=yl, add = T)
   
    if (obs.outsample == T && !all(is.na(obs.out)))
      matplot(rownames(obs.out),obs.out,type="l",
          lty=2,col= colo,main=titlestr,xlab=xl,ylab=yl, add = T)

    if (obs.insample == T) matplot(rownames(obs.in),obs.in,type="l",
          lty=2,col= colo,main=titlestr,xlab=xl,ylab=yl, add = T)


    last.year <- as.numeric(rownames(mat2)[nrow(mat2)]);
    age.length <- length(age.vec)
    if (age.length%%2 == 1) {
      y.age.labels[age.length +1] <- NA
      age.length <- age.length + 1}
    text(x=matrix(c(last.year +1,last.year + 5),nrow=age.length,
           ncol=1),y=y.age.labels,age.vec,cex=0.7);
  }
    
    
    
  ## Plotting age profiles  
  if (plot.age.profiles == T){
    outsam <- NA
    insam <- NA
    if (pred.outsample == T) outsam <- pred.out else if (obs.outsample == T) outsam <- obs.out 
    if (pred.insample == T) insam <- pred.in else if (obs.insample == T) insam <- obs.in
    
    y.plot <- rbind(insam, outsam)
    y.plot <- na.omit(y.plot)
    colo <- rainbow(nrow(y.plot));
    xl <- "Age";
    yl <- "Data and Forecasts";
    r <- range(na.omit(y.plot));
    a.vec <- as.numeric(age.vec);
   
    xp <- seq(from=a.vec[2],to=a.vec[round
                              (length(a.vec)/3)],length=nrow(y.plot));
    yp <- rep(r[2]-0.1*(r[2]-r[1]),nrow(y.plot));
     if(any(is.na(ylim))){
       
       matplot(age.vec,t(y.plot),type="l",lty=1,col=colo,main=titlestr,
              xlab=xl, ylab = yl);
     }else
      matplot(age.vec,t(y.plot),type="l",lty=1,col=colo,main=titlestr,
              xlab=xl, ylab = yl, ylim=ylim);
    
    points(xp,yp,col=colo);
    text(a.vec[1],yp[1],rownames(y.plot)[1],cex=0.8);
    text(a.vec[round(length(a.vec)/3)+1],yp[1],rownames(y.plot)
         [nrow(y.plot)],cex=0.8)
  }
  
    if (plot.age.profiles == F & plot.time.series ==F) cat("No graphs selected.","\n")
}

