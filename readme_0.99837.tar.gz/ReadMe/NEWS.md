# ReadMe 0.99837

* Removed Design package dependency.

* Added a `NEWS.md` file to track changes to the package.



