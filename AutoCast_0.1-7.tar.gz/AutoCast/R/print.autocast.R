print.autocast <- function(x,...){summary(x)}
