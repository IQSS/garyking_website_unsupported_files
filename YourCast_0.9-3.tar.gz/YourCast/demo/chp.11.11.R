

chapter11.11 <- function()
{

  message("Examples 11.11 Chile, Argentina and transportation accidents...")
  
  verb <- T
  verb <- user.prompt(1)
  if(exists("datobj", inherits=TRUE))
    try(rm(datobj, inherits=T), silent=T)
  
  trns <- eval(as.symbol(data(trns)))
  gdp  <- eval(as.symbol(data(gdp)))
  population <- eval(as.symbol(data(population)))
  cntrycode  <- eval(as.symbol(data(cntry.codes)))
  trns[trns[,"trns"] <= 0.5 & !is.na(trns[,"trns"]),"trns"] <- 0.5
  
  datobj <<- dataobj(disease=trns, pop=population,cov.REDUCE=gdp, 
                         cov.FULL=NULL,lagyears = 30,  
                         cntry.vec =c(Chile=2120, Argentina=2020),
                         nobvs=NULL, covselect=seq(0,10, 5), 
                         icode="ggggaatttt",proxfile=NULL,
                         Gnames=cntrycode, selectages=seq(from=15, to=80, by=5), verbose=verb)
   
   
  message("Formula for male transportation accidents and covariate gdp...")
  ff <- log(trns2/popu2) ~ log(gdp) + time^2
  print(ff)
  
  message("Running yourcast with OLS model...")
  user.prompt()
  yols <- yourcast(formula=ff, dataobj=datobj, model="OLS",elim.collinear=FALSE, verbose=verb)
  message("Generating the graphics for OLS...")
  yourgraph(yols,demoFile="chp.11.11")
 
  }

chapter11.11()
