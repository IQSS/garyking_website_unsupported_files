


chapter11.11 <- function()
{

  message("Examples 11.11 Chile, Angertina...")
  message("Dataobj for transportation accidents...")
  user.prompt()
  if(exists("dataobj", inherits=TRUE))
    try(rm(dataobj, inherits=T), silent=T)
  
  trns <- eval(as.symbol(data(trns)))
  gdp  <- eval(as.symbol(data(gdp)))
  population <- eval(as.symbol(data(population)))
  adjacency  <- eval(as.symbol(data(adjacency)))
  cntrycode  <- eval(as.symbol(data(cntry.codes)))
  
  dataobj <<- dataobjWHO(disease=trns, pop=population, cov.REDUCE=gdp, 
                    cov.FULL=NULL,lagyears = 30, timeseries=TRUE, 
                    cntry.vec =c(Chile=2120, Argentina=2020),
                    nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                    icode="ggggaatttt",proxfile=adjacency,
                    Gnames=cntrycode, selectages=seq(from=15, to=80, by=5))
  
###  dataobj <- dataobjWHO(disease="trns", cov.FULL= c("FULL.gdp"), 
###                            timeseries=T, lagyears=30,
###                            cntry.vec=c(Chile=2120, Argentina=2020),
###                            selectages=seq(from=15, to=80, by=5))
   
  message("Formula for male transportation accident and covariate gdp...")
  ff <- log((trns2+ 0.5)/popu2) ~ log(gdp) + time^2
  print(ff)
  
  message("Running yourcast with OLS model...")
  user.prompt()
  yols <- yourcast(formula=ff, dataobj=dataobj, model="OLS",elim.collinear=FALSE)
  message("Generating the graphics for OLS...")
  yourgraph(yols)
 
  }

chapter11.11()
