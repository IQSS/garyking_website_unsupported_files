
chapter11.9 <- function()
{
  fhisto <- function(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, ff){
    silent <- readline("\nEnter 'h' to see the histograms else <return>...\n")
    
    if(silent=='h'){
      depvar <- leftside.formula(ff)$numerator
      histograph(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, depvar,
                 model="ebayes", graphics.file=NA)
    }
    else
      return(list())
  }
  message("Examples 11.9 breast cancer Croatia...")
 
 
  message("Countries with unless 25 death observations; lag 30 years...")
  user.prompt()
  if(exists("dataobj", inherits=TRUE))
    try(rm(dataobj, inherits=T), silent=T)
  
  brst <- eval(as.symbol(data(brst)))
  gdp  <- eval(as.symbol(data(gdp)))
  fat  <- eval(as.symbol(data(fat)))
  hc   <-  eval(as.symbol(data(hc)))
  tobacco <- eval(as.symbol(data(tobacco)))
  population <- eval(as.symbol(data(population)))
  adjacency  <- eval(as.symbol(data(adjacency)))
  cntrycode  <- eval(as.symbol(data(cntry.codes)))
  dataobj <<- dataobjWHO(disease=brst, pop=population, cov.REDUCE=c(list(gdp),list(fat), list(hc)), 
                      cov.FULL=tobacco,lagyears = 30, timeseries=TRUE, 
                      cntry.vec =NULL,nobvs=25, covselect.WHO=seq(0,10, 5), 
                      icode="ggggaatttt",proxfile=adjacency,
                      Gnames=cntrycode, selectages=seq(from=25, to=80, by=5))
  
###  dataobj <- dataobjWHO(disease="brst", cov.FULL= c("FULL.hc","FULL.gdp", "tobacco", "FULL.fat"), 
###                     timeseries=T, lagyears=30, nobvs=25, selectages=seq(from=25, to=80, by=5))
       
  
  message("Formula for female breast cancer and covariates fat, gdp, hc, tobacco...")
  ff <- log((brst3 + 0.5)/popu3) ~ log(hc) + log(gdp) + log(tobacco3) + log(fat) + time

  print(ff)
  message("Running yourcast with model ebayes...")
  user.prompt()
  yebayes <- yourcast(formula=ff, dataobj=dataobj, elim.collinear= FALSE, model="ebayes")
  auto <- yebayes$summary
  distvec   <- yebayes$summary.vec
  d1.a.vec <- distvec$d1.a
  d1.t.vec <- distvec$d1.t
  dtda.vec <- distvec$dtda
  SD.vec <- distvec$SD
  message("Summary measures are...")
  auto <- unlist(auto)
   
  fs <- fhisto(d1.a.vec, d1.t.vec,dtda.vec,SD.vec, ff)
    
  d1.a <- auto["d1.a"]
  d1.t <- auto["d1.t"]
  dtda <- auto["dtda"]
  SD   <- auto["SD"]
  
  message("Dataobj for Croatia females and breast cancer...")
  user.prompt()
  if(exists("dataobj", inherits=TRUE))
      try(rm(dataobj, inherits=T), silent=T)
  
  dataobj <<- dataobjWHO(disease=brst, pop=population, cov.REDUCE=c(list(gdp),list(fat), list(hc)), 
                      cov.FULL=tobacco,lagyears = 30, timeseries=TRUE, 
                      cntry.vec =c(Croatia=4038),nobvs=NULL, covselect.WHO=seq(0,10, 5), 
                      icode="ggggaatttt",proxfile=adjacency,
                      Gnames=cntrycode, selectages=seq(from=25, to=80, by=5))
  
###  dataobj <- dataobjWHO(disease="brst", cov.FULL= c("FULL.hc","FULL.gdp", "tobacco", "FULL.fat"), 
###                            timeseries=T, lagyears=30, cntry.vec=c(Croatia=4038),
###                            selectages=seq(from=25, to=80, by=5))
   
  message("Formula...")

  print(ff)
  message("Running yourcast with model OLS...")
  user.prompt()
  yols <- yourcast(formula=ff, dataobj=dataobj, model="OLS",elim.collinear=FALSE)
  message("Generating the graphics for OLS...")
  user.prompt()
  yourgraph(yols, pred.insample=F)
  
  z.mean <- c(-11.391495,-10.147588, -9.305023, -8.692574, -8.232481, -7.953798, -7.798399,
              -7.678475, -7.577912, -7.433581,-7.293615, -6.926301)
  names(z.mean) <- 5:16*5
  message("Running yourcast with MAP model...\n Smoothing parameters as from summary measures")
  user.prompt()
  ymap <- yourcast(model="map", Ha.sigma=c(0.1,1.5,6,d1.a=d1.a, SD=SD),
                   Ht.sigma=c(0.1,1.5,6,d1.t=d1.t, sims=20), Hat.sigma=c(0.1,1.5,6,dtda),
                   zero.mean=z.mean)

  
  message("Generating the graphics for MAP...")
  user.prompt()
  yourgraph(ymap)
  message("Running yourcast with MAP model: Ha.sigma=1.5, Ht.sig
ma=0.94, Hat.sigma=0.34")
   ymap <- yourcast(model="map", Ha.sigma=1.5, Ht.sigma=0.94, Hat.sigma=0.34, zero.mean=z.mean)
  message("Generating the graphics for MAP...")
  yourgraph(ymap)
 
  }

chapter11.9()
