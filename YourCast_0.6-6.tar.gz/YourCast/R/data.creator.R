data.creator <- function(){
allc <- read.depvarAndcov()
allc <<- allc
suic <- read.depvarAndcov(file="suic")
suic <<- suic
dgst <- read.depvarAndcov(file="dgst")
dgst <<- dgst
cerv <- read.depvarAndcov(file="cerv")
cerv <<- cerv 
trns <- read.depvarAndcov(file="trns")
trns <<- trns 
rspi <- read.depvarAndcov(file="rspi")
rspi <<- rspi 
lung <- read.depvarAndcov(file="lung")
lung <<- lung 
brst <- read.depvarAndcov(file="brst")
brst <<- brst
tobacco <- read.depvarAndcov(file="tobacco")
tobacco <<- tobacco
gdp <- read.depvarAndcov(file="gdp", nc=2)
gdp <<- gdp 
hc <- read.depvarAndcov(file="hc", nc=2)
hc <<- hc 
fat <- read.depvarAndcov(file="fat", nc=2)
fat <<- fat
population <- read.depvarAndcov(file="population")
population <<- population
adjacency <- read.depvarAndcov(file="adjacency")
adjacency <<- adjacency 
cntrycode <- read.depvarAndcov(file="cntry.codes",nc=2, codes=T)
cntrycode <<- cntrycode
}
