### Driver for dth files: 
### It calls the WHO_dth files and WHO_pop files for forecast="WHO"
### with 17 age groups and 191 cntrys; data from 1920-2000
### Alternatively, it calls the SS.US_dth and SS.US_pop files forecast="SS"
### with 125 age groups and only one cntry "US"; also 1920-2000
###
make.dth <- function(disease,gender,popu, ebase=env.base){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase; 
  ewho <- get("env.who", env=ebase)
  forecast <- get("forecast", env=ewho)
  datapath <- get("datapath", env=ewho)
  if (forecast == "WHO")
    res <- make.dth.WHO(disease,gender,popu,datapath)
  else if (forecast =="SS")
    res <- make.dth.SS(disease="allc", gender,datapath)
return(res)}

## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      make.dth.WHO
##
## PLACE:     Preprocessing module, make.dth2 function.
## (This is the old make_dth2.g Gauss function rewritten in R.)
##
## IMPORTED functions: data.funcs.R
##
## DESCRIPTION: Preprocessing: It reads the datafiles and creates
##              the datamatrices, and puts them in a list.
##
## FORMAT: death <- make.dth("cvds",2,"who/data") or
##         death <- make.dth("allc",3)
##
## INPUT: disease:  string
##        gender:   integer, 2 or 3
##        datapath: (optional) path of the datafiles, if it's missing,
##                  the global whodatapath variable is used
##        
## OUTPUT: list with 3 elements:
##         dth, cstsid and popu
##
## WRITTEN BY: Federico Girosi & Elena Villalon
##             fgirosi@latte.harvard.edu, evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 09/17/2002
## 
## ************************************************************************
## ************************************************************************
 

  make.dth.WHO <- function(disease, gender,popu,datapath) {
  ## **********************************************************************
  ## make.dth2 function
  ## **********************************************************************
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase;
  dthstring  <- paste(datapath,disease,".txt",sep="")
  print(paste("Reading file ", dthstring, sep=""))
  dth0 <- scan(file=dthstring,
              na.strings="-999.0000",multi.line=T,quiet=T)
  
  if(!is.na(gender))
    dth0 <- matrix(dth0,ncol=3,byrow=T)
  else
    dth0 <- matrix(dth0,ncol=2,byrow=T)
  
  if (!is.na(popu)){
    popstring <- paste(datapath,popu,".txt",sep="")
    print(paste("Reading file ", popstring, sep=""))
    popu0 <- scan(file=popstring,
                  na.strings="-999.0000",multi.line=T,quiet=T)
  if(!is.na(gender))
   popu0 <- matrix(popu0,ncol=3,byrow=T)
  else
   popu0 <- matrix(popu0,ncol=2,byrow=T)
  
   
    if(!identical(popu0[,3],dth0[,3]))
      stop("population and death do not have same strata index for all rows")
    datamat   <- cbind(dth0[ ,1:2], popu0[,1],popu0[,3]) ## concatenates horizontall
    datrows <- split.data.frame(datamat, datamat[,4] == gender)
    datamat <- (datrows$T)[,-4]
  }else{
    datamat <- cbind(dth0[,1:2], 1,dth0[,3])
    datrows <- split.data.frame(datamat, datamat[,4] == gender)
    datamat <- (datrows$T)[,-4]
  }
    
 
  return(list(dth=matrix(datamat[,1]),
         cstsid=matrix(datamat[,2]),
         popu=matrix(datamat[,3])))
}



## ************************************************************************
## ************************************************************************
##
## FUNCTION NAME:      make.dth.SS
##
## PLACE:     Preprocessing module, make.dth.SS function.
##
## IMPORTED functions: data.funcs.R
##
## DESCRIPTION: It reads the datafiles for dth and popu in US
##              with 125 age groups, from years 1920-2000 and all causes.
##              It creates the datamatrices, and puts them in a list.
##
## FORMAT: death <- make.dth.SS("allc",2,"who/data") or
##         death <- make.dth.SS("allc",3)
##
## INPUT: disease:  string
##        gender:   integer, 2 or 3
##        datapath: (optional) path of the datafiles, if it's missing,
##                  the global whodatapath variable is used
##        
## OUTPUT: list with 3 elements:
##         dth, cstsid and popu
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 08/27/2003
## 
## ************************************************************************
## ************************************************************************
 
  make.dth.SS <- function(disease="allc",gender,datapath) {
  ## **********************************************************************
  ## make.dth.SS function
  ## **********************************************************************
 ebase <- get("env.base", env=parent.frame())
  env.base <- ebase;
  if (disease == "ex")
    dthstring <- paste(datapath,"SS.US_ex.txt",sep="")
  else {
    dis.number <- disease.number(disease)
    dthstring  <- paste(datapath,"SS.US_dth",dis.number,".txt",sep="") 
  }
  popstring <- paste(datapath,"SS.US_pop.txt",sep="")

  print(paste("Reading file ", dthstring, sep=""))
  dth0 <- scan(file=dthstring,what=c(numeric(0),integer(0),integer(0)),
              na.strings="NA",multi.line=T,quiet=T)
  dth0 <- matrix(dth0,ncol=3,byrow=T)
  
  popu0 <- scan(file=popstring,what=c(numeric(0),integer(0),integer(0)),
              na.strings="NA",multi.line=T,quiet=T)
  popu0 <- matrix(popu0,ncol=3,byrow=T)

  if(!identical(popu0[,3],dth0[,3]))
    stop("population and death do not have same strata index for all rows")
  
  datamat   <- cbind(dth0[ ,1:2], popu0[,1],popu0[,3]) ## concatenates horizontally
    
###  datrows <- nrow(datamat)/2
  datrows <- split.data.frame(datamat, datamat[,4] == gender)
  datamat <- (datrows$T)[,-4]
  ## if the datafile always have the same number of rows,
  ## we should read only the appropriate gender, not the whole file!!!
  ## scan function can do that with 'nlines' and 'skip' parameters  
###  if (gender == 2) 
###    datamat <- datamat[1:datrows, ] 
###  else 
###     datamat <- datamat[(datrows + 1):nrow(datamat), ]
   

  return(list(dth=matrix(datamat[,1]),
         cstsid=matrix(datamat[,2]),
         popu=matrix(datamat[,3])))
}    











