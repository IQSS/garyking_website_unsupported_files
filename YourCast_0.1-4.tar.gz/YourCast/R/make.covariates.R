### Driver for covariates files: 
### For forecast "WHO", reads files WHO_cov (where cov=gdp,hc,tfr,fat,tobacco, allc),
### with 17 age groups; 191 cntrys; time series data from 1920-2000.
### Because some covariates (e.g., gdp, hc, fat, tfr) are gender and age independent,
### files WHO_cov may not exist for them. Then, it reads SIZE_cov.txt, for the 
### age group independent covariates, which have one entry per cntry and year.
### Alternatively, it may also read SS.US_cov (same values of cov) for forecast="SS"
### with 125 age groups and only one cntry "US"; also years= 1920-2000
###

make.covariates <- function(covlist, cntrylist,type= NULL,ebase=env.base){
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  who.year.digits  <- get("who.year.digits", env=ewho)
  who.cntry.digits <- get("who.cntry.digits", env=ewho)
  who.age.digits <- get("who.age.digits", env=ewho)
  datapath <- get("whocovpath", env=ewho)
  forecast <- get("forecast", env=ewho)
 if (forecast == "WHO"){ 
    res <- make.covariates.WHO(covlist,cntrylist,type, datapath,
                               who.year.digits,who.cntry.digits, who.age.digits)
  }else if (forecast =="SS"){
     res <- make.covariates.SS(covlist=as.vector(covlist),cntrylist=2450, datapath,
                               who.year.digits,who.cntry.digits, who.age.digits )}
return(res)}
                           

## ************************************************************************
## ************************************************************************
##
## PROGRAM NAME:      make.covariates.WHO
##
## PLACE:     Preprocessing module, use with make.mortality.data() 
##
## IMPORTED functions: allc(), full.dependent(), strata.age.independent()
##
## DESCRIPTION: This function makes the covariates, and uses the
##              imported functions to read each of the files.  
##              Some files are age and gender dependent, as for 
##              allc and full.dependent; but others, i.e.  
##              fat, hc, gdp, tfr, (fatHcGdpTfr) are age independent.   
##
## FORMAT:      mat <- make.covariates.WHO(covlist, cntrylist)
##
## INPUT:       two vectors: covlist and cntrylist;
##              with the list of covariates and countries 
##
## OUTPUT:     a matrix with columns one for each covariate of covlist,  
##             and rows= cstsid; i.e., cross sections for any country 
##             of cntrylist, which specified age groups and year of time series.  
##             
##
## WRITTEN BY: Elena Villalon & Federico Girosi  
##             evillalon@latte.harvard.edu,fgirosi@latte.harvard.edu 
##             CBRSS, Harvard University
## 
## Last modified: 10/2/2003
##
## ************************************************************************
## ************************************************************************

make.covariates.WHO <- function(covlist, cntrylist,type, datapath,
                                who.year.digits,who.cntry.digits, who.age.digits) {
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase;
  ewho <- get("env.who", env=env.base)
  whodisease <- get("whodisease", env=ewho)
  whotransform <- get("whotransform", env=ewho)
  whogender <- get("whogender", env=ewho)
  allc <- get("allcauses", env=ewho)
  dth  <- get("dth", env=ewho)
  popu <- get("popu", env=ewho)
  cstsid <- get("cstsid", env=ewho)
  
  datos <- array(0,dim=0)
  isdisease <- match(whodisease, covlist)
  dth  <- as.matrix(dth)
  popu <- as.matrix(popu)
  cstsid <- as.matrix(cstsid)
### some useful quantities defining unique covariates and set up  
 if(length(covlist) > 0){
   unique.cov <- unique.default(covlist)
   unqind <- match(unique.cov,covlist)
   covec  <- rep(NA,length=length(covlist))
   names(covec) <- covlist 
   bool.type <- (length(type) <= 0 || all(is.na(type)))  
 } else if(length(covlist) < length(type))
   stop("Please retry...More types than covariates")
###
  
  if(length(covlist) <= 0) {## if1 covlist is empty
### in legacy code, disease identified with numbers, no longer in use
    datos   <- matrix(NA, length(cstsid))
  }else if(bool.type) {  ##if1(length(covlist))
### if1(covlist is array and not providing any default types for covs )
### read them as full.dependent with age and gender(strata) explicit for all cstsid
         
    for(ch in covlist){
     
      if(identical(ch, whodisease)){ ##if2
### if depvar is enter with no population we have already set popu =1
        cat("Dividing by population if exists.\n") 
        covc <- as.matrix(dth)/as.matrix(popu)
        covc <- complete.structure(as.matrix(covc))
        print(paste("Transforming covariate depvar ", ch))
        covc <- trans(covc, whotransform)
        if(length(covc) != length(cstsid))
          stop("Lengths of cov and cstsid do not match")
        cov  <- cbind(covc,cstsid)
               
      }else if( identical(allc,ch)) { ##if2
              
          cov  <- full.dependent(allc,path=F)
        
          covc <- complete.structure(as.matrix(cov[,1]))
          covc[covc == -999] <- NA
          covc[covc <= 0.5]  <- 0.5
            cat("Dividing by population if exists.\n")  
          cov[,1] <- covc/as.matrix(popu)
          print(paste("Transforming covariate depvar.like ", ch))
          cov[,1] <- trans(cov[,1],whotransform)
          cstsid2 <- cov[,2]
        }else{ ##if2
          if(!is.na(whogender))
            cov <- full.dependent(ch)
          else
            cov <- strata.independent(ch)
        }
        
        if (identical(ch, covlist[1])) cstsid2 <- as.matrix(cov[,2]);
        cov <- matrix(cov[,1])
        colnames(cov) <- ch 
        datos <- cbind(datos, cov)
     }# end for loop (ch in covlist for cov.type <- NA)
    
  }else{ ##if1(length(covlist));  
### if1 (covlist is array and cov.type is provided for some covariates)
### cov.type is a list, with may take values NA, and any of the options in parenthesis
### (strata/age/strata.age/age.strata/).independent and depvar.like,
### say age.independent, strata/strata.age/.independent.
### Any of strata.independent have 2 cols, age.independent has three cols
### and depvar.like is full.dependent 
### make sure that you have a type for all covariates in covlist
### otherwise assign NA as type.
      ind <- sapply(names(type),function(x){
                    x <- paste("^", as.character(x), "$",sep="")
                    return(grep(x,covlist))})
      if(length(ind) > 0){
        covred <- covlist[-ind]
        if(length(covred) > 0){
          for(ch in covred){
            vch <- list(NA)
            names(vch) <- ch
            type <- c(type,vch)}
        }
      }
      indcov <- match(names(type), covlist)
      type <- type[indcov] 
      assign("cov.type",type, env=ewho)      
  
### the gender selection is done inside read.from.cov.type    
      lst   <- read.from.cov.type(type=type,covs=covlist)
      datos <- lst$datos
      cstsid2 <- lst$cstsid2
    }

  colnames.datos <- colnames(datos);
  cstsid2   <- matrix(cstsid2)
  cntrylist <- matrix(cntrylist)
  
### selecting countries only from cntrylist
  tmpindx <- !is.na(match((cstsid2%/%10^(who.year.digits + who.age.digits))%%10^who.cntry.digits, cntrylist))
  datos    <- as.matrix(datos[tmpindx,])
  colnames(datos) <- colnames.datos;
  cstsid2 <- cstsid2[tmpindx]
  rm(tmpindx)
  sc2  <- cbind(datos,cstsid2)
  ord <- order(sc2[,ncol(sc2)])
  sc2 <- sc2[ord,]
  sc2id  <- matrix(sc2[ ,ncol(sc2)])
  sc2dat <- as.matrix(sc2[ ,1:(ncol(sc2)-1)])

  colnames(sc2dat) <- colnames.datos;
  if (length(covlist) == 0)  sc2dat <- NA
  return(list(covariates=sc2dat, covid=sc2id))
}
###
## ************************************************************************
## ************************************************************************
##
## PROGRAM NAME:    full.dependent.dth
##
## PLACE:     Preprocessing module, use with read.cov.type & make.covariates.WHO
##
## IMPORTED functions: complete.structure & trans
##
## DESCRIPTION: Func read.cov.type reads the type=depvar.like and chooses this function
##              to generate the covaraite matrix.
##              It takes any of the death or depvar files as input through covname
##              Reads the files and checks if they are gender dependent and
##              if so chooses the gender and eliminate that column.
##              First col is death and second is cstsid (i.e. 2450451992)
##              We add 0.5 to any zero value of death, ands set NA's if -999
##              Complete structure of NA's after first observation with approx.
##              and linear approximation.  Divide by population (popu) if existent,
##              otherwise gets divided by popu=1. Apply trans depending on whotransform.   
##
## FORMAT:      cov <- full.dependent.dth(covname)
##
## INPUT:       name of covariates corresponding to death or depvar data.  
##              and env.who where all globals and other parameters 
##
## OUTPUT:     a matrix with two columns for covariate = covname of death or depvar type,  
##             and rows= cstsid; i.e., cross sections for any country 
##             with specific age groups and year of time series.
##             The covaraite data is filled with linear approx for missing
##             NA's after first observation. 
##             
##
## WRITTEN BY: Elena Villalon & Federico Girosi  
##             evillalon@latte.harvard.edu,fgirosi@latte.harvard.edu 
##             CBRSS, Harvard University
## 
## Last modified: 09/29/2004
##
## ************************************************************************
## ************************************************************************


   full.dependent.dth <- function(cov.name){
      ebase <- get("env.base", env=parent.frame())
      env.base <- ebase;
### age/gender and time series full blown up covariates
      ewho <- get("env.who", env=ebase)
      datapath <- get("datapath", env=ewho)
      popu <- get("popu", env=ewho)
      cstsid <- get("cstsid", env=ewho)
      whotransform <- get("whotransform", env=ewho)
      whogender <- get("whogender", env=ewho)
      
      dthstring  <- paste(datapath,cov.name,".txt",sep="")
      print(paste("Reading file ", dthstring, sep=""))
      cov <- scan(file=dthstring,
              na.strings="-999.0000",multi.line=T,quiet=T)
      
      if(!is.na(whogender)){
        cov <- matrix(cov,ncol=3,byrow=T)
        cov <- split.data.frame(cov, cov[ ,3] == whogender)$T
        cov <- cov[,-3]
      }else
        cov <- matrix(cov,ncol=2,byrow=T)
      
       covc <-  cov[,1]
       covc[covc == -999] <- NA
       covc[covc <= 0.5] <- 0.5
       
  
       covc <- complete.structure(as.matrix(covc))
         cat("Dividing by population if exists.\n")  
          covc <- covc/as.matrix(popu)
       print(paste("Transforming covariate depvar.like ", cov.name))
          cov[,1] <- trans(covc,whotransform)
          cstsid2 <- cov[,2]
     
       return(cov)
    }
## ************************************************************************
##
## PROGRAM NAME:    full.dependent
##
## PLACE:     Preprocessing module, use with read.cov.type & make.covariates.WHO
##
## IMPORTED functions: 
##
## DESCRIPTION: Func read.cov.type reads = strata.age(age.strata).independent or NA
##              The fiels have all age groups and gender and years observation
##              It is a full deependency covariate so no need for expansion.   
##
## FORMAT:      cov <- full.dependent(covname)
##
## INPUT:       name of covariates corresponding to death or depvar data.  
##              and env.who where all globals and other parameters;
##              path = T, means we are taking the covaraites path from whocovpath (cov.path)
##              while path = F, means we are taking the death path with whodatapath (data.path)
##
## OUTPUT:     a matrix with two columns for covariate = covname of death or depvar type,  
##             and rows= cstsid; i.e., cross sections for any country 
##             with specific age groups and year of time series.
##             
##
## WRITTEN BY: Elena Villalon & Federico Girosi  
##             evillalon@latte.harvard.edu,fgirosi@latte.harvard.edu 
##             CBRSS, Harvard University
## 
## Last modified: 09/29/2004
##
## ************************************************************************
## ***********************************************
   full.dependent <- function(cov.name,path=T,ebase=env.base){
      ebase <- get("env.base", env=parent.frame())
      env.base <- ebase;
### age/gender and time series full blown up covariates
      ewho <- get("env.who", env=ebase)
      if(path)
        whocovpath <-  get("whocovpath", env=ewho)
      else
        whocovpath <- get("whodatapath", env=ewho)
      
      whogender <- get("whogender", env=ewho)
      covstrg <- paste(whocovpath,"FULL.",cov.name,".txt",sep="")
      if (is.na(file.info(covstrg)$size) || file.info(covstrg)$size <= 0 )
         covstrg <- paste(whocovpath,cov.name,".txt",sep="")
      print(paste("Reading file:",covstrg))
      cov <- scan(file=covstrg,multi.line=T,quiet=T)
### even if it is gender (or strata) independent, it will still
### read three cols with NA on the third col
### even if age independent same entries for same cntry and years combos
      cov <- matrix(cov,ncol=3,byrow=T)
### selecting the gender or strata
   
      if(all(!is.na(cov[,3])))
      cov <- split.data.frame(cov, cov[ ,3] == whogender)$T
       ## cstsid2 <- cov[,2]
       ## cov <- matrix(cov[,1])
      
       if(identical(all.equal(cov.name,"tobacco"),T) ||
          identical(all.equal(cov.name,"lc"),T) ){
            tmpcov <- cov[,1]
            tmpcov[tmpcov == -999] = 999 ## recode
            rm(tmpcov)}
        cov <- cov[,-3]
        return(cov)}

### The following covariates: fat, gdp, hc and tfr are 
### gender and age independent (i.e. strata.age.independent or age.strata.independent);
### they are read from txt files:gdp, fat, hc, tfr;
### they have for every cntry and age group the entire time series.
### The information is actually repeated for as many times as age groups, 
### since the values for these covariates depend only on the cntry and
### the year of time series, but not on age group!!!
### Information may be provided as a large files with all possible ages (FULL.);
### and also as a reduce file fat, gdp, hc, tfr;
### Each of gdp, hc, tfr, fat, files has only one age group for each cntry and year
### If we choose to read the reduced files, we must expand each
### covariate to pass all possible age groups to make.covariates.WHO()
### Helper function "expand.cov" actually expands to all possible ages: 
### expand.cov(age.groups= 5*(0:16),select= NA,covname=cov.name, covstring= covstrg, save.FULL= F, ncol=2)
### where select is for cntry selection and NA includes all possible cntrys; 
### covname = the covariate name, covstring location of the reduce file cov.txt;
### save.FULL a boolean to save into files; ncol= 3 with gender dependencies in 3rd col =NA
### since these covarites are gender (strata) independent. When stored in FULL. files
### three cols will be saved, but third col = NA 
### The new set of covariates that the user may provide have only two cols
### if they are strata (or gender ) independent.
### 
       full.independent <- function(cov.name, nc = 2, ebase=env.base){

         ebase <- get("env.base", env=parent.frame())
         env.base <- ebase;
         ewho <- get("env.who", env=ebase)
         whocovpath <- get("whocovpath", env=ewho)
         whogender  <- get("whogender", env=ewho)
         covstring  <- paste(whocovpath,"FULL.",cov.name,".txt",sep="")
      
         if (is.na(file.info(covstring)$size) || file.info(covstring)$size <= 0 ){ ##if (size)
### reads files format: reduced size 
           covstrg <- paste(whocovpath,cov.name,".txt",sep="")
           print(paste("Reading reduced file (one age group & no strata): ",covstrg))
           cov <- expand.cov(covname=cov.name, covstring=covstrg,ncol=nc );
         }else{ ##if (size) reads files formats:long or WHO_
           covstring  <- paste(whocovpath,"FULL.",cov.name,".txt",sep="")
           print(paste("Reading full size file with all age groups:",covstring))
           cov <- scan(file=covstring,quiet=T,multi.line=T)
           cov <- matrix(cov,ncol=3,byrow=T)
         } ##endif (size) read files formats
        
           if (!all(is.na(cov[,3])))
               cov <- split.data.frame(cov, cov[,3]== whogender)$T
           cov <- cov[,-3]
       
        ##cstsid2 <- cov[,2]
        ##cov <- matrix(cov[,1])
        
        colnames(cov) <- c(cov.name, "cstsid2")
        return(cov)}
      

### function that builds covariates from files cov.txt;
### cov="fat","hc", "gdp", "tfr". The files have one single entry (or row)
### for each cntry, year combination and do not depend on age groups.
### expand.cov expands the entries to the number of age.groups specify
### in the function, by repeating as many times as age groups
### any entry belonging to a single cntry+year combination.
### INPUT: age.groups; the cntry we want to select or NA for all of them;
### the covariate we want to expand (either of fat, hc, gdo, tfr);
### location in the directory path to find files cov.txt;
### save.FULL a bolean either T or F, which will save some files.
### ncol is the cols of original reduced file; 
### OUTPUT: expanded matrix of three cols,first col is covariate values and 
### second cstsid = cntry+age+year, third is gender or NA (if gender independent)
### We include the choice of saving the matrices of expanded covariates 
### into files with the input parameter save.FULL = TRUE, which will generate
### the corresponding FULL_cov.txt file. 
### 
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu, 
##             CBRSS, Harvard University
## 
## Last modified: 10/2/2003
###


    expand.cov <- function(covname, covstring, ncol,type=NA,
                           age.groups= 5*(0:16),select= NA, save.FULL=T){
    
         if (!identical(.GlobalEnv,parent.frame())){
           ebase <- get("env.base", env=parent.frame())
           env.base <- ebase;
           ewho <- get("env.who", env=ebase)
           whogender <- get("whogender", env=ewho)
           if (length(save.FULL) <= 0)
             save.FULL <- get("save.FULL", env=ewho)
           flag= F
         }else{
           flag = T; }
    
        cov <- scan(file=covstring,
                    ##what=c(numeric(0),integer(0),integer(0)), (You do not need to specify what;)
                    quiet=T,multi.line=T)
      
        cov <- matrix(cov,ncol=ncol,byrow=T)
    
### for covariates are gender independent, if given then gender=NA
         if(ncol >= 3)
           colnames(cov) <- c(covname, "cstsid","gender")
         else if(ncol >= 2)
           colnames(cov) <- c(covname, "cstsid")
         
### if only US
        if (length(na.omit(select)) > 0 && select=="US"){
          indx.US <- grep("^2450",as.character(cov[,2]))
          cov <- cov[indx.US, ]}
### else all the countries are included.         

        if(identical(all.equal(type,"age.independent"),T)){
        
           mm <-  array(0,dim=0)
           covfac <- split.data.frame(cov, cov[,3])
           mmlst <- lapply(covfac,
                           FUN= select.gender,
                           age.groups=age.groups,covname=covname,ncol=ncol)
           for(mat in mmlst)
           mm <- rbind(mm, mat)
         }else{
        
           mm <- select.gender(cov,age.groups,covname,ncol)
                              
         }
        if(save.FULL == T )
          save.file.WHO(mm, covname,ncol=3,type,flag)
     
### asssuming list of covariates is c("fat","gdp","hc", "tfr")
### creates output and text files for preprocessing routines
### Now, to be consistent with previous code eliminate col= 3 with gender=NA
       
        return(invisible(mm)) }

   select.gender <- function(cov,age.groups,covname,ncol ){
        wd  <-  round(log10(max(age.groups)))
        age.n <- length(age.groups)
        time.series <- unique.default(as.numeric(cov[,2])%%10^4)
        time.n    <- length(time.series) 
        cntry.vec <-  unique.default(as.numeric(cov[,2])%/%10^6)
        cntry.n   <- length(cntry.vec)
        cov.ex1 <- rep(cov[,1],age.n)
        cov.ex2 <- rep(cov[,2],age.n)
        if ( ncol >= 3)
          cov.ex3 <- rep(cov[,3],age.n)
        else if( ncol >= 2){
         cov.ex3 <- NA*cov.ex1
         
        }else
           stop("Insufficient cols")
         
        cov.expand <- cbind(cov.ex1,cov.ex2,cov.ex3)
        
        colnames(cov.expand) <- c(covname, "cstsid","gender")
### list by years of time series
        cov.lst <- split.data.frame(cov.expand,as.numeric(cov.expand[,2])%%10^4)
### Given that all year groups have same covariates.
### Repeating the values of covs for age ="00" modify
### the time series to include all age groups  
        
        cov.lst <- lapply(cov.lst, function(x, age.groups){
                   ord <- order(as.numeric(x[,2]))
                   x     <- x[ord, ]
                   yr    <- as.numeric(x[1,2])%%10^4
                   years.string <- formatC(age.groups, width =wd, format="d", flag="0")
                   ctry.age <- kronecker(unique.default(as.numeric(x[,2])%/%10^6), years.string, FUN="paste", sep="")
                   ctry.age.yr <- as.numeric(paste(ctry.age,yr,sep=""))
                   ctry.age.yr <- sort(ctry.age.yr)
                   if(length(ctry.age.yr) != length(x[,2])){
                      stop("Building the wrong matrix in expand.cov for make.covariates")
                   }else
                     x[,2] <- ctry.age.yr
                   return(x)}, age.groups)
### end cov.lst
        
        cov.frame <- lapply(cov.lst, as.data.frame)
        st <- unlist(cov.frame, recursive=F)
        nmcov <- paste(names(cov.frame),".",covname,sep="")
        nmcst <- paste(names(cov.frame),".","cstsid",sep="")
        nmgen <- paste(names(cov.frame),".","gender",sep="")
### build a matrix with 3 cols= covariate, cstsid and gender
### with age groups=5*(0:16); and years=1920:2000.
### Covariates are repetition of one given age, say "45" or "00"
### for every single year in time series.
        
        mm <- matrix(,nrow=length(cov.lst)* age.n * cntry.n, ncol= 3)  
        colnames(mm) <- c(covname, "cstsid","gender")
        for(n in 1:3){  ##for2 build cols of datamat
          mmc  <- dim(0)
          coln <- sapply(1:length(st), function(i,st){
                  x <- n + (i-1) * 3
                  if(n <=1 && is.element(names(st)[x],nmcov)==T)
                    mmc <- c(mmc,as.vector(st[x]))
                  else if(n <=2 && is.element(names(st)[x],nmcst)==T)
                    mmc <- c(mmc,as.vector(st[x]))
                  else if(is.element(names(st)[x],nmgen)==T)
                    mmc <- c(mmc,as.vector(st[x]))
                  return(mmc)}, st)
          coln <- unlist(coln)
          if(length(coln) < length(cov.lst)* age.n * cntry.n)
            print("Wrong building jumbo expand.cov in make.covariates")
          else
            mm[,n] <- coln
        } ##end for2 build cols of datamat
### order matrix rows according to values of second col=cstsid
        indx <- order(mm[,2])
        mm   <- mm[indx, ]
        colnames(mm) <-  c(covname, "cstsid","gender")
        return(mm)}

 
### expand.cov creates for any age.groups-independent covariates, 
### the matrix of two cols (for strata independent) or three cols for
### gender dependent covariates, other cols are cov values and the cstsid.  
### If we want to save that matrix for further development
### the function expand.cov has the parameter save.WHO = (T or F). 
### If we set the parameter save.WHO= TRUE, expand.cov will call
### function save.file.WHO, which creates the file WHO_cov.txt
### cov= "fat", "gdp", "hc", "tfr"; in the data directory
### specified with whocovpath.
### save.file.WHO(mm, covname) takes two argument the matrix
### of two (three) cols with the covariate and cstsid, and the covariate name. 
### Depending on the covariate it opens the appropiate file name
### and save the matrix = mm in whocovpath directory.
### It also return mm as a list, but has no use in this file.
##
## WRITTEN BY: Elena Villalon 
##             evillalon@latte.harvard.edu, 
##             CBRSS, Harvard University
## 
## Last modified: 10/3/2003


save.file.WHO <- function(mm, covname, ncol, type,flag=F,ebase=env.base){
  if(flag==T ){
    ewho <- namelists();
     whocovpath <- get("cov.path", env=ewho)
  }else{
   ebase <- get("env.base", env=parent.frame())
   env.base <- ebase;
   ewho <- get("env.who", env=ebase)
  whocovpath <- get("whocovpath", env=ewho)}
  
###colnames(mat) <-  c(covname, "cstsid","gender")
### asssuming list of covariates is c("fat","gdp","hc", "tfr")
### creates output and text files for preprocessing routines
  Covs.lst <- list();
  cv.symb = as.symbol(covname)
    Covs.lst <- c(Covs.lst, cv.symb=list(mm))
    cov.path <- paste(whocovpath,"FULL.",covname,".txt",sep="")
    file.remove(cov.path)
    file.create(cov.path)
    mm[,2] <- as.character(mm[,2])
### want to create some formatting:
### mm[,1] <- formatC(mm[,1],digits=5,width=11,flag= " ", format="f")
### any of the FULL. files have three cols, the last is strata
### 
    if(ncol(mm) <= 2)
      mm[,3] <- NA* mm[,1]
    write.table(mm, file=cov.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")
       print(paste("The size of FULL.",covname, " file is = ",
                  file.info(cov.path)$size)) 
       
   return(invisible(Covs.lst)) }
## ************************************************************************
## ************************************************************************
##
## PROGRAM NAME:    read.from.cov.type  
##
## PLACE: Preprocessing module,manual requirements to read from user's files          
##
## IMPORTED functions: allc full.dependent full.independent
##                     strata.independent(),age.independent() 
##
## DESCRIPTION: Reads different input files depending on 
##              the type of covariate and covarite that the user passes 
##              type= NA, strata/age/strata.age/age.strata.independent 
##              For NA uses the default WHO_ historical readers; 
##              for new user types then uses strata/age.independent() funcs and the 
##              updated version of full.independent for strata.age/age.strata/.independent
##
## FORMAT:     read.from.cov.type(type,covs)
##
## INPUT:       type pf covs = list, specifying how to read each cov and covariates 
##
## OUTPUT:     lsit with the covariates and cstsid
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 06/29/2004
##
## ************************************************************************
## ************************************************************************

 read.from.cov.type <- function(type,covs){
      env.base <- get("env.base", env=parent.frame())
      ebase <- env.base
      ewho  <- get("env.who", env=ebase)
      whotransform <- get("whotransform", env=ewho)
      allc <- get("allcauses", env=ewho)
      dth  <- get("dth", env=ewho)
      popu <- get("popu", env=ewho)
      cstsid <- get("cstsid", env=ewho)
      whodisease <- get("whodisease", env=ewho)
      whogender <- get("whogender", env=ewho)
      datos <- array(0,dim=0)
      nm.type <- names(type)
      ind <- match(nm.type,covs)
      if(length(ind) < length(covs))
        stop("Provide cov.type for all covariates")
      
      for(n in 1:length(type)){
### loops through all covariates in covlist according to entries in cov.type      
        s  <- type[[n]]  ## i.e. strata.independent
        ch <- as.character(nm.type[n])  ## i.e. gdp
        cat("Covariate is ", ch, " and its type is ", s, "\n")
### the cov.type entry s for the covariate ch, s= NA, then use default
        if(is.na(s)){
          if(ch == whodisease){
             dth <- as.matrix(dth)
             dth[dth == -999] <- NA
             dth[dth <= 0.5]  <- 0.5
             cat("Dividing by population if exists.\n")  
            covc <- as.matrix(dth)/as.matrix(popu)
            covc <- complete.structure(as.matrix(covc))
         
            print(paste("Transforming covariate depvar.like ", ch))
            covc <- trans(covc, whotransform)
            cov <- cbind(covc, cstsid)
          }else if(identical(allc,ch)){
            cov <- full.dependent(allc,path=F)
            covc <- as.matrix(cov[,1])
             covc[covc == -999] <- NA
            covc[covc <= 0.5]  <- 0.5
            cat("Dividing by population if exists.\n")  
            covc <- covc/as.matrix(popu)
            covc <- complete.structure(as.matrix(covc))
           
            cov[,1] <- covc
            print(paste("Transforming the covariate depvar.like ", ch))
            cov[,1] <- trans(cov[,1], whotransform)
            cstsid2 <- cov[,2]  
          }else {
           if(!is.na(whogender))
             cov <- full.dependent(ch,path=T)
           else
             cov <- strata.independent(ch)
            cstsid2 <- cov[,2]
          }
            
          }else { ##if not NA
### cov.type entry s one of the followings
         if(!is.na(whogender))
           default <- full.dependent
         else
           default <- strata.independent
         
         cov <- switch(EXPR=s,strata.independent=strata.independent(ch),
                               age.independent=age.independent(ch),
                               strata.age.independent= , age.strata.independent=full.independent(ch),
                               depvar.like= full.dependent.dth(ch), default(ch))
       }
       
          if (n <= 1) cstsid2 <- as.matrix(cov[,2]);
          cov <- as.matrix(cov[,1])
          colnames(cov) <- nm.type[n]
          datos <- cbind(datos, cov)
      }
      
        lst <- list(datos=datos, cstsid2=cstsid2)
 
        return(lst)
    }

###
### Reads covariates that do not depend on strata (gender);
### they have 2 cols the covariates' values and cstsid
### the covariates are age dependent, so no need for expansion
### however you may choose to save it as FULL.cov
### with a third col of NA's for gender,
### so that you may read it with cov.type = NA and function full.dependent()
###
strata.independent <- function(cov.name,ncol=2,whocovpath=NULL, save.FULL = T){
         ebase <- get("env.base", env=parent.frame())
         env.base <- ebase
         ewho <- get("env.who", env=ebase)
         if(length(whocovpath) <= 0)
           whocovpath <- get("whocovpath", env=ewho)
         if(length(save.FULL) <= 0)
           save.FULL <- get("save.FULL", env=ewho)
         cov.type <- get("cov.type", env=ewho)
         nm <- names(cov.type)
         tind <- grep(cov.name, nm)
         type <- cov.type[[tind]]
         if(!identical( all.equal(type,"strata.independent"), T))
           stop("Covariate type wrong for strata.independent")
         
         covstring <- paste(whocovpath,cov.name,".txt",sep="")
         print(paste("Reading full size file with all age groups:",covstring))
         cov <- scan(file=covstring,quiet=T,multi.line=T)
         cov <- matrix(cov,ncol=ncol,byrow=T)
### cstsid2 <- cov[,2]
### cov <- matrix(cov[,1])
       mat <- cov       
       
       if ( ncol >= 3 && all(is.na(cov[,3])))
          cov <- cov[,-3]
       else if (ncol >= 3)
          stop("Wrong file for strata.independent")                   
        colnames(cov) <- c(cov.name, "cstsid2")
### let us save it with three cols to be used with cov.type=NA
       if(save.FULL==T){
         if(ncol <= 2){
          adcol <- as.matrix(NA*mat[,1])
          mat <- cbind(mat,adcol)}
          mat[,2] <- as.character(mat[,2])
### want to create some formatting:
### mm[,1] <- formatC(mm[,1],digits=5,width=11,flag= " ", format="f")
          cov.path <- paste(whocovpath,"FULL.",cov.name,".txt",sep="")
          file.remove(cov.path)
          file.create(cov.path) 
    write.table(mat, file=cov.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")
       print(paste("The size of FULL.",cov.name, " file is =  ",
                  file.info(cov.path)$size, sep=""))
       }               
      
        return(cov)}
###      
### we have three cols= value cstsid gender; but the format
### input is reduced since only one age group is provided
### we need to expnad the matrices to account for all age groups even if they are
### repetitions of original values for single age gropup.
### Note that cov values depend on cntry/year of observation but not age.
###
 age.independent <- function(cov.name,nc=3, whocovpath=NULL, save.FULL=T){
         ebase <- get("env.base", env=parent.frame())
         env.base <- ebase;
         ewho <- get("env.who", env=ebase)
         if(length(whocovpath) <= 0)
           whocovpath <- get("whocovpath", env=ewho)
         whogender <- get("whogender", env=ewho)
         cov.type <- get("cov.type", env=ewho)
         if(length(save.FULL) <= 0)
           save.FULL <- get("save.FULL", env=ewho)
         nm <- names(cov.type)
         tind <- grep(cov.name, nm)
         type <- cov.type[[tind]]
         if(!identical( all.equal(type,"age.independent"), T))
           stop("Covariate type wrong for age.independent")
         covstring <- paste(whocovpath,"FULL.",cov.name,".txt",sep="")
         if (is.na(file.info(covstring)$size) || file.info(covstring)$size <= 0 ){ ##if (size)
### reads files format: reduce size that user supplies
           covstrg <- paste(whocovpath,cov.name,".txt",sep="")
           print(paste("Reading reduced file (one age group): ",covstrg))
           cov <- expand.cov(covname=cov.name, covstring=covstrg,ncol=nc,type=type );
        }else{ ##if (size) reads files formats:long or FULL. 
           print(paste("Reading full size file with all age groups:",covstring))
           cov <- scan(file=covstring,quiet=T,multi.line=T)
           cov <- matrix(cov,ncol=nc,byrow=T)
         } ##endif (size) read files formats
        
        ##cstsid2 <- cov[,2]
        ##cov <- matrix(cov[,1])
        colnames(cov) <- c(cov.name, "cstsid2","gender")
        if(!all(is.na(cov[,3])))
          cov <- split.data.frame(cov, cov[,3]==whogender)$T
       
        cov <- cov[,-3]
        return(cov)}

## *************************************************************************
## ****************************************************************************
##
## PROGRAM NAME:    build.covariates  
##
## PLACE: Preprocessing module,manual requirements to read all powers and log powers           
##
## INPUT: cov.remainder, cov.type
##
## DESCRIPTION: Reads the covaraites list that the user supplies and  
##              the type of covariate and covarite that the user passes 
##              It outputs which are power of covariates and the power
##              the log of covaraites and the power, and classified them
##              according to the indices entry along cov.remainder
##
## FORMAT:     build.covaraites(cov.remainder, cov.type)
##
## OUTPUT:     list(covtmp = covtmp, cov.type=cov.type, covnude=covnude,
##                  logpowcol=logpowcol, powcol=powcol, logcol=logcol)
##             covtmp(i.e. gdp, tobacco) those covariates names that are part of cov.remainder
##             cov.type how to read them accoring to strata, age dependencies
##             covnude a list with all indeces of covariates and the simple names
##             (i.e. gdp, tobacco, tobacco, tobacco, gdp)
##             logpowcol names are indices entry along covnude and values power of log covaraites
##             powcol pnames indeces entry along covnude and values are powers of covaraites
##             logcol the indeces for log covariates
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 08/06/2004
##********************************************************************
  build.covariates  <- function(cov.remainder, cov.type){

    covariates <- NULL;
    logcol <-  NA;      ### initialization, useful when cov.remainder is NULL
    covnude <- cov.remainder
    if (is.null(cov.remainder))
      return(NULL)
    
      cov.remainder <- matrix(cov.remainder, ncol=1)
### index to keep so we know which covariates were log
      logcol    <-  grep("^ln", cov.remainder)
      if (length(logcol) != 0){
        logcov    <- matrix( cov.remainder[logcol]) ## covariates with ln; matrix of 1 column 
        covtmp    <- matrix(gsub("^ln","", cov.remainder)) ## all covariates stripped of ln
        covnude  <- covtmp
        if (length(names(cov.type))>0){
          names(cov.type) <- gsub("^ln","",names(cov.type))
          names(cov.type) <- gsub("\\(", "",names(cov.type))
          names(cov.type) <- gsub(")[1-9]", "",names(cov.type))
          names(cov.type) <- gsub(")","",names(cov.type))
        }##  if (length(names(cov.type))>0)
        
      } else {
        logcol <- NA;
        covtmp <- cov.remainder;
      } ##if(length(logcol) != 0)
    
### names of logpowcol are indeces of elements of cov.remainder, which are 
### log of covariates.  Values will be the power of the log or 1
     
      logpowcol <- logcol
      tmp <- logpowcol
      logpowcol <- rep(1, length(logpowcol))
      names(logpowcol) <- tmp
      rm(tmp)
      
      if (is.null(covtmp))
        return(NULL)
    
### opening parenthesis 
        paropcol  <- grep("^\\(",covtmp)
### closing parenthesis without any powers
        parclcol <-  grep(")$",covtmp)
            
        if(length(paropcol) > 0)
          covnude <- gsub("\\(","",covnude)
        if(length(parclcol) >= 0){
          covnude <- gsub(")[1-9]", "", covnude)
          covnude <- gsub(")$", "",covnude)}

       parallcol1 <- c(parclcol, grep(")[1-9]", covtmp))
       parallcol  <- parallcol1
### if length is different it means you have power of covariates,
### such as "(gdp)4", we need to get the pow=4
        if (length(parclcol) <=  length(paropcol)){
   
### all closing parenthesis either as "(gdp)" or as "(gdp)4"
          parallcol <- grep(")",covtmp)
          if(!identical(sort(parallcol1), sort(parallcol)))
            stop("Wrong indeces do not match")
          
          if(length(parallcol) > 0 ){
            covnude <- gsub(")[1-9]", "",covnude)
            covnude <- gsub(")","",covnude)
          }
   
### we need as many open parenthesis as closing
          if(!identical(paropcol, parallcol) ||
             !identical(parclcol, intersect(parclcol,parallcol)))
            stop("Format covariates input wrong...see manual")
        
### those parenthesis follow by power, i.e. "(gdp)4"
          if (length(parclcol) > 0){
            parpowcol <- setdiff(parallcol,parclcol)
            if(!identical(sort(parpowcol), sort(grep(")[1-9]", covtmp))))
                stop("Wrong indeces do not match") 
          }else
            parpowcol <- parallcol
            
### covariates that are elevated to a power 
          covpow <- covtmp[parpowcol]
         
### find the power
          lst <- strsplit(covpow,")")
          pow <- sapply(lst,function(x)
                 return(ifelse(length(x) > 1,as.numeric(x[2]), 1)))
### values of pow are the covariates power
### and names of pow are indices along cov.remainder or covtmp
          names(pow) <- parpowcol
        
### log covariates indeces with power
        lcol <- intersect(names(logpowcol),names(pow))
        
        if (length(lcol) > 0)
          logpowcol[lcol] <- pow[lcol]
        if( length(na.omit(match(names(logpowcol),names(pow)))) > 0)
          powcol <- pow[-na.omit(match(names(logpowcol),names(pow)))]
        else
          powcol <- pow
          covpow <- covtmp[as.numeric(names(powcol))]
        
### for log covariates: name logpowcol is the index along cov.remainder,
### and its value is the power.
### for power covariates: name powcol is the inde

### and its value is the power 
          cov.ind <- list(logpowcol=logpowcol, powcol=powcol)

### to get the log covariates: 
### cov.remainder[as.numeric(names(logpowcol))]
### to get the power covariates:
### cov.remainder[as.numeric(names(powcol))]
          cov.split <- strsplit(covtmp, "\\(")
          cov.split <- sapply(cov.split,function(x) {
            ln <- length(x)
            if (ln <= 1){
              res <- x
            }else{
              res <- strsplit(x[2],")")
              res <- res[[1]][1]
            }
            return(res) })
        
          ind.unq <- match(unique.default(cov.split), cov.split)
          nm <- covtmp[ind.unq]
          nm <- gsub("\\(","", nm)
          nm <- gsub(")[1-9]","",nm)
          nm <- gsub(")","",nm)
       
          names(ind.unq) <- nm
          nmtype <- names(cov.type)
          if(length(nmtype) < length(ind.unq))
            {
              tmp <- setdiff(nm,nmtype)
      cov.type <- c(cov.type, rep(NA, length(ind.unq) - length(nmtype)))
              nmtype <- c(nmtype,tmp)
              names(cov.type) <- nmtype   
            }
          ord <- sort(names(ind.unq))
          ind.unq <- ind.unq[ord]
          covtmp <- names(ind.unq)
          cov.type <- cov.type[ord]
        } ##if(length(parclcol) <= length(paropcol))
    
    
### ind.unq the names for the unique entries covariates and their index in cov.remainder
### names(ind.unq) = covtmp;
### For logpowcol the names are the indeces along cov.remainder of log covariates
### and its values the power of the log
### For powcol the names are indeces along cov.remainder and values the power of covariates (>1)
### group.cov, names for each of the covariates and values their indeces in cov.remainder     
  
### including all powers for any given covariate; say "(gdp)3",
### include also "gdp", "(gdp)2",if they do not exist
       
        cov.p  <- covnude[as.numeric(names(powcol))]
        ucov.p <- unique.default(cov.p)
        covrec <- rep(NA,length(covnude))
        names(covrec) <- covnude
       
       if(length(ucov.p) <= length(cov.p) && length(cov.p) != 0 && length(ucov.p) != 0 ){
         ln <- 1:length(powcol)
         for(x in ln){
           rr <- as.numeric(names(powcol)[x])
           pw <- powcol[x]
           if(is.na(covrec[rr]))
             covrec[rr] <- powcol[x] 
         }
        
        for (ch in ucov.p) {
          ind <- grep(ch, names(covrec))
          mm  <- max(na.omit(covrec[ind]))
          im  <- match(mm,covrec[ind])
          ind <- ind[-im]
          covrec[ind] <- NA
        }
      
       lst <- NULL
      
       if(length(powcol) > 0){
    
        for(x in 1:length(powcol)) {
             
          nm <- names(covrec)[as.numeric(names(powcol)[x])]
          if (is.na(covrec[as.numeric(names(powcol)[x])])){
            next;
           }else{
            no <- powcol[x]
          
            if(no >= 2){
              cov <- c(nm,paste("(",nm,")",2:no,sep=""))
            }else
              nm
            
            ind <- na.omit(match(cov.remainder,cov))
          if(length(ind)>0)
            cov <- cov[-ind]
            
          np <- names(powcol)
          ln <- length(cov.remainder) + 1
          vec <- ln: (ln+length(cov)- 1)
          np <- names(powcol)
          vno <- strsplit(cov,")")
          vno <- as.numeric(sapply(vno, function(x) return(x[2])))
          powcol <- c(powcol,vno)
          names(powcol) <- c(np,vec)
          cov.remainder <- c(cov.remainder,cov)
          covnude <- c(covnude,rep(nm,length(cov)))
          }##if (is.na(covrec[as.numeric(names(powcol)[x])]))
        }##for(x in 1:length(powcol))
       
      } ##if(length(powcol) > 0))
     
       } ##if(length(ucov.p) <= length(cov.p) &&......

       lst <- list(covtmp = covtmp, cov.type=cov.type, covnude=covnude,
                    logpowcol=logpowcol, powcol=powcol, logcol=logcol)
        return(lst)
  }
## *************************************************************************
## *************************************************************************
## PROGRAM NAME:    covariates.mat  
##
## PLACE: Preprocessing module,manual requirements to read all powers and log powers           
##
## INPUT: lst and covariates, which are from lst <- build.covariates()
##        and from covariates <- make.covariates.WHO() 
##
## DESCRIPTION:Takes results from build.covariates and the matrix of plain covaraites
##             and elevates them to powers and/or take the log and elevate them to powers
##             The expanded matrix of covaraites contains all covaraites and its powers,
##             and log of powers as prescribed in cov or whocovaraites and also expansion
##             to lower powers if not included (see manual).  
##
## FORMAT:     covariates.mat(cov.remainder, cov.type)
##
## OUTPUT:    Matrix of covariates with their powers and log, if pescribed in
##            the user input cov. For every country, age and year
##            after reading the covariates files with make.covariates.WHO  
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 08/06/2004
##********************************************************************

covariates.mat <- function(lst, covariates){
  ebase <- get("env.base", env=parent.frame());
  env.base <- ebase; 
  ewho <- get("env.who", env=ebase)
  env.who <- ewho 
   whotransform <- get("whotransform", env=ewho)
   whodisease <- get("whodisease", env=ewho)
   allc <- get("allcauses", env=ewho)
  if(length(lst) <= 0)
    return(NULL)
  
    covtmp    <- lst$covtmp
    cov.type  <- lst$cov.type
    covnude   <- lst$covnude
    logpowcol <- lst$logpowcol
    powcol <- lst$powcol
    logcol <- lst$logcol
    cc <-  0
    covar <- NULL

    for(x in covnude){
      cc <- cc + 1
      ind  <- grep(x, covtmp)
      cov0 <- covtmp[ind]
      ind <- grep(cov0,colnames(covariates))
      cov <- as.matrix(covariates[,ind])
      colnames(cov) <- cov0
      intype <- grep(x,names(cov.type))
      dth.type <- F
      bool.vec <- F
      v.bool <- F
      if (identical(as.character(x),whodisease) ||
           identical(as.character(x), allc))
         dth.type <- T
      
      if (length(intype) > 0 && !dth.type ){
        tp <- cov.type[intype[1]]
               
        if (identical(as.character(tp),"depvar.like"))
          dth.type <- T
      }
      
    
      tmp <- cov[,1]
      tmp[tmp == -999] <- NA 
      cov[,1] <- tmp
   
      if(dth.type){

         bool.vec <- na.omit(cov[,1]) & (na.omit(cov[,1]) <0)
         v.bool <- any(bool.vec)}

      if (v.bool && !is.element(whotransform, c(1,3))) 
     cat("Death < 0 in covariates with transform ", whotransform, "\n");
     
### log of covariates and log powers;
### names(logpowcol) = NA means no logs in cov list, othrewise is the entry index      
      if( !is.na(names(logpowcol)) && is.element(cc,as.numeric(names(logpowcol)))){
        lowc <- paste("^",as.character(cc),"$", sep="")
        ind <- grep(lowc, names(logpowcol))
        pow <- logpowcol[ind]
        if(any(bool.vec))
           stop(paste("Taking the log of negative covariate = ", cov0, "Check your data"))
        
        if(!is.na(whotransform)) 
          using.logs <- whotransform == 1 || whotransform == 3
        else
          using.logs <- F
        if (dth.type && using.logs )
          stop(paste("You cannot have both the log of depvar cov.type, and set whotransform = ", whotransform)) 
        
        cov <- log(cov)
        if (pow > 1 && !is.na(pow)){
          cov <- cov^pow
          colnames(cov) <- paste("ln(",cov0,")",as.character(pow),sep="")
        }else 
        colnames(cov) <-  paste("ln(",cov0,")",sep="")
### power of covariates; if length(powcol) = 0 no powers of any covariates > 1
### you may still have a power of 1, say "gdp", which corresponds to entry index NA
        
      }else if(length(powcol) > 0 && is.element(cc,as.numeric(names(powcol)))){
        powc <- paste("^",as.character(cc),"$", sep="")
        ind <- grep(powc, names(powcol))
        pow <- powcol[ind]
### we set = NA to power of 1, say "gdp" has pow=NA
        if(!is.na(pow)&& pow >1 ){
          cov <- cov^pow
          colnames(cov) <- paste("(",cov0,")",as.character(pow),sep="")
        }else
        colnames(cov) <- cov0
      } ##if(is.element(cc,as.numeric(names(powcol))))
                   
      covar <- cbind(covar, cov)
     
                    } ##for(x in covnude)
    return(covar)
}
## *************************************************************************
## *************************************************************************
## PROGRAM NAME:    yearsmiss  
##
## PLACE: Preprocessing module,manual requirements to read powers and log powers
##        of allc and depvar (or whodisease)
##
## INPUT: depvar(whodisease) or allc ; all countries in data set and all years observed
##        for all age groups
##
## DESCRIPTION: Finds the indeces for NA after the first observations 
##
## FORMAT:     yearsmiss(mat) ; mat=matrix of 1 col or vector)
##
## OUTPUT:   indeces along mat for NA's after first observed and indeces of !NA
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 09/09/2004
##********************************************************************

yearsmiss <- function(x,cs){
  ebase <- get("env.base",env=parent.frame())
  ewho  <- get("env.who", env=ebase)
  env.base <- ebase
 
  digit.cntry.begin <- get("digit.cntry.begin", env=ewho)
  digit.cntry.end <- get("digit.cntry.end", env=ewho)
  digit.age.end <- get("digit.age.end", env=ewho)
  whousercntrylist <- get("whousercntrylist", env=ewho)
  x[x==-999] <- NA
   if(length(cs) != length(x)){
     print("wrong length for death data")
      print(length(cs))
     print(length(x))}
   names(x) <- cs
### split input matrix x according to csid= cntry + age group
   xsplit <- split.data.frame(x, substr(names(x),digit.cntry.begin,digit.age.end))
   count <- 0
   listna <- sapply(xsplit, function(x){
### indeces of observations for dth
              
     indobv <- seq(along= x)[!is.na(x)]
     fo <- ifelse(length(indobv) > 0, min(indobv), NA)
     if(is.na(fo))
       stop("Death data is all NA; take another choice for covariate or depvar")
     lo <- max(indobv)
     total.obs <- lo  - fo + 1
### find missing values in the sequence but from first observed
     indna <- NULL
     if (total.obs > length(indobv)){
### indeces of NA's
     indna <- setdiff(fo:lo, indobv)
     fo.na <- min(indna)
     lo.na <- max(indna)
   }
   lst <- list(indna=indna, indobv=indobv)
   return(indna)
   })
  
  lst <- list(listna=listna,dthsplit=xsplit) 
    return(lst) }    
   
## *************************************************************************
## *************************************************************************
## PROGRAM NAME:    complete.structure  
##
## PLACE: Preprocessing module,manual requirements to read powers and log powers
##        of allc and depvar (or whodisease)
##
## INPUT: depvar(whodisease) or allc ; all countries in data set and all years observed
##        for all age groups
##
## DESCRIPTION: Uses yearmiss(dth,cs) to find indeces for NA after
##              first observations, then it complets those values that are missed
##              between first and last observed using approx and linear interpolation
##              
##
## FORMAT:     complete.structure(dth) ; dth=matrix of 1 col or vector)
##
## OUTPUT:   all csid with complete observations between first and last
##           observed and no NA's in between 
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 09/09/2004
##********************************************************************

        
complete.structure <- function(dth){
 ebase <- get("env.base",env=parent.frame())
 ewho  <- get("env.who", env=ebase)
 env.base <- ebase
 cs <- get("cstsid", env=ewho)
 print("Completing missing data after first observed for either \"allc\" or depvar as covariates......")
 ry <- yearsmiss(x=dth,cs=cs)
 listna <- ry$listna
 dthsplit <- ry$dthsplit
 vec <- as.list(1:length(listna))
 names(vec) <- names(dthsplit)
 dthsplit <- lapply(vec, FUN="fillna",listna,dthsplit)
    
 return(as.matrix(unlist(dthsplit,use.names=T)))
 
}
     
     

 fillna <- function(n,listna,dthsplit){
   indna <- listna[[n]]
   cage <- dthsplit[[n]]
   if (length(indna) <= 0)
     return(cage)
   j <- 0
   vec <- min(indna):length(cage)
   if(length(cage) > max(indna))
     rng <- min(indna):(max(indna)+ 1)
   else
       rng <- min(indna):max(indna)
   
   indth <- setdiff(rng,indna)
    
   for(i in rng){
    if (i == min(indna)){
### first observed
      fdth <- ifelse(min(indna) > 1, cage[min(indna) - 1], cage[1])
      jf <-  ifelse(i > 1, i - 1, 1)
      j  <-  i
      next;
    }     
### we already pass all indeces of NA's before first observed
     d <- match(i,indna)
    if(!is.na(d)){
      j <- i
    }else if(is.na(d) && j > 0 ){
      j    <- 0
      ldth <- cage[i]
      xrng   <- c(jf,i)
      dthrng <- c(fdth, ldth)
      ymiss <- i - jf + 1
      cage[jf:i] <- approx(xrng,dthrng, method="linear",n= ymiss)$y 
    }else if(is.na(d) && j == 0){
      fdth <- cage[i-1]
      jf <-  i-1 
      next;
    }
}
   
 return(cage)}      

## ************************************************************************
## ************************************************************************
##
## PROGRAM NAME:      make.covariates.SS 
##
## PLACE:     Preprocessing module, the old Gauss make_covariates2.g
##            function rewritten in R
##
## IMPORTED functions: none
##
## DESCRIPTION: This function makes the covariates for the
##              US social security ages=1:125;
##              fat, hc, tfr and gdp are gender and age independent
##              tobacco and "allc" (dth) are not.  
##
## FORMAT:
##
## INPUT:
##
## OUTPUT:
##
## WRITTEN BY: Elena Villalon
##             evillalon@latte.harvard.edu
##             CBRSS, Harvard University
## 
## Last modified: 08/27/2003
##
## ************************************************************************
## ************************************************************************


make.covariates.SS <- function(covlist,cntrylist=2450, whocovpath,
                               who.year.digits,who.cntry.digits, who.age.digits, ebase=env.base) {
  ebase <- get("env.base", env=parent.frame())
  env.base <- ebase;
  ewho <- get("env.who", env=ebase)
  whogender <- get("whogender", env=ewho)
  allc <- get("allcauses", env=ewho)
  datos <- array(0,dim=0)
  if (length(covlist) != 0) { ## if1 (this is an array!! )
    for (i in 1:length(covlist)) {## for loop covlist
      if (identical(covlist[i],allc)){ ##if2 (allc)
        dthstring  <- paste(whocovpath,"SS.US_dth1.txt",sep="")
        print(paste("Reading file ", dthstring, sep=""))
        dth0 <- scan(file=dthstring,what=c(numeric(0),integer(0),integer(0)),
                     na.strings="NA",multi.line=T)
        cov  <- matrix(dth0,ncol=3,byrow=T)
        
        cov  <- (split.data.frame(cov, cov[ ,3] == whogender))$T
        if (i ==1) cstsid2 <- cov[,2]
        cov <- cov[,1]
        
      } else { ##if2 (allc)
       
      covstring <- paste(whocovpath,"SS.US_",covlist[i],".txt",sep="")
      print(paste("reading file:",covstring))

      if (covlist[i] == "tobacco") { ## if3 gender dependent covariates
        cov <- scan(file=covstring,what=c(numeric(0),integer(0),integer(0)),
                     na.strings="NA", multi.line=T,quiet=T)
        cov <- matrix(cov,ncol=3,byrow=T)
        cov <- (split.data.frame(cov, cov[ ,3] == whogender))$T
        if (i ==1) cstsid2 <- cov[,2]
        cov <- cov[,1]
        n <- length(cov)
      } else { ## if3 gender independent covariates
        cov <- scan(file=covstring,what=c(numeric(0),integer(0),logical(0)),
                    na.strings="NA",quiet=T,multi.line=T)
        cov <- matrix(cov,ncol=3,byrow=T)
        cov <- cov[,-3]
        if (i ==1)   cstsid2 <- cov[,2]
        cov <- cov[,1]
      }## end if3
    } ##end if2
      
      cov <- matrix(cov)
      colnames(cov) <- covlist[i];
      datos <- cbind(datos,cov)
    } ## endfor loop covlist
  }## if1
  else {## if1 covlist is empty 
    covstring <- paste(whocovpath,"SS.US_","gdp",".txt",sep="")
    cov <- scan(file=covstring,what=c(numeric(0),integer(0)),logical(0), 
                na.strings="NA",quiet=T,multi.line=T)
    cov <- matrix(cov,ncol=3,byrow=T)
### it reads the _gdp file only for the list of cstsid2, gdp discarded
    
    cstsid2 <- cov[,2]
### cov[,1] <- NA
### cov     <- matrix(cov[,3])
    datos   <- matrix(NA, length(cstsid2))
  } ## end if1

  colnames.datos <- colnames(datos);
  cstsid2   <- matrix(as.numeric(cstsid2))
  cntrylist <- matrix(cntrylist)
  tmpindx <- !is.na(match((cstsid2%/%10^(who.year.digits + who.age.digits))%%10^who.cntry.digits,
                         as.vector( cntrylist)))
  datos    <- as.matrix(datos[tmpindx,])
  colnames(datos) <- colnames.datos;
  cstsid2 <- cstsid2[tmpindx]
  rm(tmpindx)
  sc2  <- cbind(datos,cstsid2)
  ord <- order(sc2[,ncol(sc2)])
  sc2 <- sc2[ord,]
  sc2id  <- matrix(sc2[ ,ncol(sc2)])
  sc2dat <- as.matrix(sc2[ ,1:(ncol(sc2)-1)])
  colnames(sc2dat) <- colnames.datos;
  if (length(covlist) == 0)  sc2dat <- NA
  return(list(covariates=sc2dat, covid=sc2id))
}


### test files
make.age.independ <- function(){
         ebase <- get("env.base", env=parent.frame())
         env.base <- ebase;
         ewho <- get("env.who", env=ebase)
         whocovpath <- get("whocovpath", env=ewho)
         whogender <- get("whogender", env=ewho)
         covstring <- paste(whocovpath,"gdp",".txt",sep="")
         cov <- scan(file=covstring,
                    ##what=c(numeric(0),integer(0),integer(0)), (You do not need to specify what;)
                    quiet=T,multi.line=T)
        cov <- matrix(cov,ncol=2,byrow=T)
        cov2 <- cov
        cov3 <- cov
        cov2 <- cbind(cov2,2)
        cov3 <- cbind(cov3,3)
         
     mm <- rbind(cov2,cov3)
    cov.path <- paste(whocovpath,"age.independ",".txt",sep="")
    file.remove(cov.path)
    file.create(cov.path)
    mm[,2] <- as.character(mm[,2])
### want to create some formatting:
### mm[,1] <- formatC(mm[,1],digits=5,width=11,flag= " ", format="f")
### for consistency with previous code (2 cols and no gender) if 
### covariate is gender (strata)  independent save two cols,
### if it cov is strata dependent save the three cols 
    
    write.table(mm, file=cov.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")
       print(paste("The size of age.independ","file is = ",
                  file.info(cov.path)$size)) 
       
}



make.gender.independ <- function(){
         ebase <- get("env.base", env=parent.frame())
         env.base <- ebase;
         ewho <- get("env.who", env=ebase)
         whocovpath <- get("whocovpath", env=ewho)
         whogender <- get("whogender", env=ewho)
         covstring <- paste(whocovpath,"FULL.","gdp",".txt",sep="")
         cov <- scan(file=covstring,
                    ##what=c(numeric(0),integer(0),integer(0)), (You do not need to specify what;)
                    quiet=T,multi.line=T)
        cov <- matrix(cov,ncol=3,byrow=T) 
        cov <- cov[,-3]
    cov.path <- paste(whocovpath,"gender.independ",".txt",sep="")
    file.remove(cov.path)
    file.create(cov.path)
    cov[,2] <- as.character(cov[,2])
### want to create some formatting:
### mm[,1] <- formatC(mm[,1],digits=5,width=11,flag= " ", format="f")
### for consistency with previous code (2 cols and no gender) if 
### covariate is gender (strata)  independent save two cols,
### if it cov is strata dependent save the three cols 
    
    write.table(cov, file=cov.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")
       print(paste("The size of gender.independ","file is = ",
                  file.info(cov.path)$size)) 
       
}

make.SIZE <- function(covname){
### covname may be any of alcohol, gdp, fat, hc,tfr
### they all have NA in the third cols so save them with 2 cols
         ebase <- get("env.base", env=parent.frame())
         env.base <- ebase;
         ewho <- get("env.who", env=ebase)
         whocovpath <- get("whocovpath", env=ewho)
         whogender <- get("whogender", env=ewho)
         covstring <- paste(whocovpath,"SIZE_",covname,".txt",sep="")
         mm <- scan(file=covstring,
                    ##what=c(numeric(0),integer(0),integer(0)), (You do not need to specify what;)
                    quiet=T,multi.line=T)
        mm <- matrix(mm,ncol=3,byrow=T)
        mm <- mm[,-3]
      
    cov.path <- paste(whocovpath,covname,".txt",sep="")
    file.remove(cov.path)
    file.create(cov.path)
    mm[,2] <- as.character(mm[,2])
### want to create some formatting:
### mm[,1] <- formatC(mm[,1],digits=5,width=11,flag= " ", format="f")
### for consistency with previous code (2 cols and no gender) if 
### covariate is gender (strata)  independent save two cols,
### if it cov is strata dependent save the three cols 
    
    write.table(mm, file=cov.path,quote=F, sep="\t",eol="\n",row.names=F, col.names=F, na="NA")
       print(paste("The size of ",covname," file is = ",
                  file.info(cov.path)$size))
         
         covstring <- paste(whocovpath,"SIZE_",covname,".txt",sep="")
         mat.SIZE <- scan(file=covstring,
                    ##what=c(numeric(0),integer(0),integer(0)), (You do not need to specify what;)
                    quiet=T,multi.line=T)
         covstring <- paste(whocovpath,covname,".txt",sep="")
         mat <- scan(file=covstring,
                    ##what=c(numeric(0),integer(0),integer(0)), (You do not need to specify what;)
                    quiet=T,multi.line=T)
        mat <- matrix(mat,ncol=2,byrow=T)
        mat.SIZE <- matrix(mat.SIZE,ncol=3,byrow=T)
        mat.SIZE <- mat.SIZE[,-3]
        len.sz <- length(mat.SIZE)
        len <- length(mat)
        bool <- identical(all.equal(mat.SIZE, mat),T)
      
      
       
}
